//+------------------------------------------------------------------+
//| HITMAN_AI.mq5                                                     |
//| BUILD_ID: HA_ULTRA_93                                             |
//| HITMAN AI — MASTER + ULTRA FAST SIGNAL ENGINE v1.0                |
//| Comment: HITMAN AI | MaxOpen=3 | EntryTF follows chart            |
//+------------------------------------------------------------------+
#property copyright "HITMAN AI"
#property link      "https://github.com/theteletsak-max/NEUROX-SCALERT-AI"
#property version   "1.00"
#property description "HITMAN AI ULTRA X — Full Architecture Blueprint"
#property description "BUILD=HA_ULTRA_93 Comment=HITMAN AI MaxOpen=3"

#include <Trade/Trade.mqh>

#define BG_OBJECT_NAME "HitmanAI_ChartBackground"

CTrade g_Trade;

//==================== HITMAN AI — SINGLE-FILE MASTER =================//

//===== BEGIN Shell_A_InputsGlobals.mqh =====
#ifndef HITMAN_ULTRA_SHELL_A_MQH
#define HITMAN_ULTRA_SHELL_A_MQH
//+------------------------------------------------------------------+
//| Shell A — Inputs, globals, forward declarations (pre-Ultra)      |
//+------------------------------------------------------------------+

//======================== INPUTS ===================================//

input group "GENERAL"

input long MagicNumber = 40001;
input string TradeComment = "HITMAN AI";

input group "INSTANT OPEN + QUALITY PREFER"
// BEST QUALITY selects the trade (structure + IDP + ADX).
// AGGRESSIVE INSTANT executes immediately once selected (tick path, no idle cooldown).
input bool   InstantQualityMode          = true;   // profile banner / intent lock


// OK93: PRIME inputs replaced — see ULTRA CORE / MARKET / FIB / STRATEGIES inputs in ULTRA module.
// Kept for .set compatibility (unused by live router):
input bool   Enable_FlashSweep   = true;
input bool   Enable_ContSniper   = true;
input bool   Enable_RevSniper    = true;
input bool   Enable_FibSniper    = true;
input bool   Enable_BreakImpulse = true;
input int    MinStrategyScore    = 58;
input int    InstantFireScore    = 75;
input bool   BlockOppositeSameSymbol = true;
input double FibBuyLow         = 0.50;
input double FibBuyHigh        = 0.886;
input double FibSellLow        = 0.114;
input double FibSellHigh       = 0.50;
input bool   SoftPreferFib     = true;


input group "SNIPER IDP - BUILT INTO EA (signal core)"
// Institutional Displacement Pulse computed INSIDE the EA (same math as SNIPER_IDP).
// No separate indicator required for trading. Chart SNIPER_IDP is optional visual only.
input bool   EnableIDPConfluence     = true;   // master: IDP pulse gates live FIRE
input bool   IDP_HardGate            = false;  // OK81: IDP prefer/log only — NEVER hard-block
input bool   IDP_RequireStrong       = false;  // false=QUALITY |pulse|; true=STRONG only
input double IDP_MinAbsPulse         = 30.0;   // OK81 quality prefer threshold (soft)
input double IDP_StrongAbsPulse      = 70.0;   // STRONG floor
input int    IDP_PulseShift          = 1;      // OK79: closed bar = stable quality pulse
input int    IDP_ATR_Period          = 14;
input int    IDP_EMA_Period          = 50;     // trend-side reference
input int    IDP_SwingLookback       = 5;
input double IDP_SweepMinWickRatio   = 0.33;
input double IDP_SweepMinDepthATR    = 0.08;
input double IDP_DispMinBodyRatio    = 0.48;
input double IDP_DispMinATR          = 0.35;
input bool   IDP_ApplyToAPEX         = true;   // gate APEX through IDP
input bool   IDP_ApplyToContFallback = true;   // gate ContFallback through IDP
input bool   IDP_LogGate             = true;   // print IDP pass/fail

input group "PRISM BEAST MODE ENGINE (support only — not a live entry path)"
// OK67: live entries are APEX/ContFallback only. Beast/Ultra still finalize those tags.

input bool   EnableBeastMode                 = true;  // unified PRISM beast pipeline
input bool   EnableSniperMode                = true;  // aggressive fire when beast gates pass
input bool   BeastUseUnifiedStructure        = true;  // MPI/ICE/rank share one structure snapshot
input bool   BeastRequireReversalStack       = true;  // RevSniper/LiquiditySweep need liquidity stack
input int    BeastMinReversalLiquidityScore  = 8;     // BEST: higher Rev liquidity floor (max 15)
// ALLTRADE56: do not block same-bar Cont re-fire across multi-chart attaches.
// OK54 logic still safe if turned back on (only while direction still open).
input bool   BeastDuplicateBarGuard          = false; // OFF: never suppress Cont/Rev after FIRE
input bool   BeastCaptureSignalSnapshot      = true;  // record MPI/ICE at decision time
input bool   EnableBeastDashboard            = true;  // rich HUD when EnableDashboard=true

input group "MARKET REVERSAL SNIPER (RETIRED live — RevSniper offline OK67)"

input bool   EnableEarlyMarketReversal       = true;  // catch flips before full trend ADX
input bool   ReversalRequireTrendADX         = false; // false = don't wait for new trend+ADX
input bool   ReversalAcceptCHoCHOrSweep      = true;  // CHoCH can help reclaim confirm
input bool   ReversalIMCESoftInTrend         = true;  // allow Rev in TREND if stack is strong
input int    ReversalStructureRecencyBars    = 30;    // lookback for sweep/CHoCH
input bool   ReversalRequireCorrectSideSweep = true;  // BUY needs lows swept; SELL needs highs swept
input bool   ReversalRequireReclaimConfirm   = true;  // CHoCH / displacement / stop-hunt / inducement
input bool   ReversalRequireZone             = true;  // OB or FVG in trade direction
input bool   ReversalStrictCorrectSignal     = true;  // plain candle alone is NOT enough reclaim
input bool   ReversalRejectWrongSideRecent   = true;  // block if opposite sweep is more recent
input bool   ReversalPreferStopHunt          = false; // true = require stop-hunt candle (stricter)
input bool   ReversalLogValidation           = true;  // print why Rev passed/failed

input group "PRISM ULTRA CORE v11"
// BEST QUALITY: Cont/Rev need structure + confirmations. InstantTrend is
// fallback only. Ultra still fires fast AFTER quality path + engines pass.
// Score floors apply hard to InstantTrend; Cont/Rev use HP confirms.

input bool   EnableUltraCore                 = true;  // master Ultra Core switch
input bool   UltraCycleCache                 = true;  // cache structure/score per cycle
input bool   UltraSmartTickFilter            = true;  // skip re-eval when bid/ask+bar unchanged
input bool   UltraSniperEntryGate            = true;  // checklist (soft on Cont/Instant when aggressive)
input bool   UltraAggressiveFire             = true;  // fire AFTER quality path+engines pass
input int    UltraMinBeastScore              = 30;    // InstantTrend hard floor (0=off)
input int    UltraMinConfidencePct           = 35;    // InstantTrend hard floor (0=off)
input bool   UltraInstantTrendSoftGates      = false; // BEST: Instant must pass full gates
input bool   UltraLogRejectReasons           = true;  // explain signal rejects (throttled 1x/bar)
input bool   UltraHealthMonitor              = true;  // track decision latency + health
input bool   EnableUltraDashboard            = true;  // Ultra HUD (latency, score, last reject)
input bool   UltraHighProbability            = true;  // prefer Cont/Rev; Instant only as fallback
input int    UltraHP_MinConfirmations        = 4;     // Cont/Rev HARD min confirms when BestQualitySetups

// RETIRED ContSniper/Instant live switches (OK67) — kept for old .set compatibility only
input bool   BestQualitySetups           = true;  // used by ContFallback structure quality helpers only
input bool   BestPathsOnly               = true;  // RETIRED live
input bool   AggressiveInstantQuality    = true;  // RETIRED live
input bool   PreferQualityPaths          = true;  // RETIRED live
input bool   TryNextPathIfEnginesFail    = false; // RETIRED — no Instant fallback
input bool   EnableAdaptivePathRanking   = false; // RETIRED live
input int    AdaptivePathMinTrades       = 10;
input bool   PrintPathStatsOnInit        = true;

input group "APEX - WORLD-CLASS LIQUIDITY SNIPER (LIVE)"
// From-scratch best path: structural HTF bias (swings+MA) → map liquidity
// pool → stop-hunt sweep of that pool → displacement reclaim with tick-vol
// expansion → enter only unmitigated FVG/OB → SL beyond sweep.
// ONE decision. NO post-FIRE veto (tag APEX bypasses ICE/IMCE/Ultra re-check).

input bool   EnableAPEXStrategy          = false; // OK91 DELETED live — retired
// OK67 PURE: live path is ONLY APEX → ContFallback (BOS+zone). No PRISM/LCS/ContSniper live.
input bool   EnableAntiScalpMode         = false;  // OK81: off — was enabling wait gates
input bool   EnableContFallback          = false;  // OK91 DELETED live — retired
input bool   ContFallbackBypassEngines   = true;   // ContFallback skips ICE/IMCE after structure pass
input bool   ContFallbackOncePerBar      = false;  // OK81: never OncePerBar-block
input int    ContFallbackCooldownMinutes = 0;      // OK81: NEVER ContFallbackCooldown block
input int    ContFallbackMinimumHoldBars = 8;      // OK79: quality hold (not scalp)
input double ContFallbackSL_ATR_Boost    = 1.5;    // wider SL — not a scalp stop
input int    ContFallbackMaxOpen         = 1;      // max open ContFallback positions on this symbol
input bool   ContFallbackDisableAdaptiveHold = true; // do not shorten hold in ranging for ContFallback/APEX

input group "CONT STRUCTURE - INSTANT OPEN (OK81)"
// Anytime: sessions never hard-block.
// Instant quality ContFallback: trend + BOS + zone + (near OR disp) + score.
// ADX not hard-required (still scores). IDP still hard-gates direction.
input int    ContStruct_BOS_MaxBars          = 18;    // OK80 wider BOS window
input bool   ContStruct_RequireTwoBarBOS     = false; // OK80: fresh single BOS OK
input bool   ContStruct_FreshOBOnly          = false; // OK80: allow active OB/FVG
input double ContStruct_MinFVG_ATR           = 0.20;  // quality FVG size vs ATR
input double ContStruct_MaxFVGFillPct        = 55.0;  // reject mostly-filled FVGs
input double ContStruct_ZoneProximityATR     = 1.15;  // OK79 quality near-zone
input bool   ContStruct_RequireDisplacement  = false; // use ZoneOrDisp
input bool   ContStruct_ZoneOrDisplacement   = true;  // near-zone OR displacement required
input double ContStruct_MinDispBodyRatio     = 0.48;  // OK79 quality displacement
input double ContStruct_MinDispATR           = 0.35;  // OK79 quality displacement
input bool   ContStruct_RequireHTF_BOS       = false; // optional HTF BOS
input bool   ContStruct_PreferDiscountPrem   = false; // soft only (scores bonus; not hard gate)
input bool   ContStruct_RequireTrendADX      = false; // OK80: ADX soft (fixes ADX waits)
input bool   ContStruct_SkipRanging          = false; // OK80: FIX ranging-regime hard wait
input int    ContStruct_MinScore             = 20;    // OK81 low floor — quality via components
input bool   ContStruct_LogDetail            = false; // wait logs once/bar via Ultra throttle

input ENUM_TIMEFRAMES APEX_BiasTF        = PERIOD_H4;
input ENUM_TIMEFRAMES APEX_EntryTF       = PERIOD_CURRENT; // OK80 chart TF
input int    APEX_BiasMA_Period          = 200;
input int    APEX_SwingStrength          = 2;      // bars left/right for swing pivot
input int    APEX_SwingLookback          = 40;      // BiasTF bars to map structure
input int    APEX_PoolLookback           = 30;      // EntryTF bars to find equal H/L pool
input double APEX_EqualTolATR            = 0.12;    // equal high/low tolerance vs ATR
input int    APEX_SweepLookback          = 24;     // OK62 longer
input double APEX_MinSweepWickRatio      = 0.28;   // OK62 relaxed
input double APEX_MinSweepDepthATR       = 0.06;
input double APEX_DispMinBodyRatio       = 0.48;   // OK79 best quality
input double APEX_DispMinATR             = 0.40;   // OK79 best quality
input double APEX_TickVolExpansion       = 1.25;    // bar1 tick vol vs avg (1.0=off soft)
input bool   APEX_RequireTickVol         = false;
input bool   APEX_RequireUnmitigatedZone = false;  // OK69: OFF so APEX can fill (zone still preferred in path)
input bool   APEX_RequireStructureBias   = false;
input bool   APEX_RequireMAAlign         = true;
input bool   APEX_BiasNeedStructOrMA     = true;
input bool   APEX_RelaxedEntries         = true;   // OK62: softer wick/disp + swing-sweep path
input bool   APEX_UseSweepSL             = true;
input double APEX_SL_BufferATR           = 0.12;
input double APEX_MaxSL_ATR              = 4.0;
input bool   APEX_LogValidation          = true;
input bool   APEX_LogFailsEveryBar       = true;

input group "SESSION DETECT (London / New York / Asia)"
// OK72: detect sessions for analysis. HardBlock OFF = TRADE ANYTIME.
// Strong quality comes from structure/ADX — not from session blocking.

input bool   EnableSessionDetect         = true;   // ON: detect & log London/NY/Asia
input bool   EnableAPEXSessionFilter     = true;   // ON: kill-zone awareness (annotate)
input bool   APEX_SessionHardBlock       = false;  // OK72 LOCK: false = TRADE ANYTIME
input bool   APEX_UseGMT                 = true;   // true=TimeGMT hours; false=broker server hours
input bool   SessionLogOnChange          = true;   // print when session name changes
input bool   APEX_AllowLondon            = true;   // London counts as kill-zone
input int    APEX_LondonStartHourGMT     = 7;      // inclusive
input int    APEX_LondonEndHourGMT       = 16;     // exclusive (covers London open into NY overlap)
input bool   APEX_AllowNewYork           = true;   // NY counts as kill-zone
input int    APEX_NYStartHourGMT         = 12;     // inclusive
input int    APEX_NYEndHourGMT           = 21;     // exclusive
input bool   APEX_AllowAsia              = true;   // OK71: Asia detected + optional kill-zone
input int    APEX_AsiaStartHourGMT       = 0;      // inclusive
input int    APEX_AsiaEndHourGMT         = 7;      // exclusive (until London)
input bool   APEX_SessionFilterCryptoToo = false;  // crypto: always anytime unless hard+this true

input group "LCS - RETIRED (not on live path OK67)"
input bool   EnableLCSStrategy           = false;  // RETIRED — ignored by EvaluateStrategySignals
input bool   LCSOnlyLivePath             = false;
input ENUM_TIMEFRAMES LCS_BiasTF         = PERIOD_H4;
input ENUM_TIMEFRAMES LCS_EntryTF        = PERIOD_H1;
input int    LCS_BiasMA_Period           = 200;
input int    LCS_SweepLookbackBars       = 12;
input int    LCS_SwingPadBars            = 5;
input double LCS_MinSweepWickRatio       = 0.40;
input double LCS_MinSweepDepthATR        = 0.08;
input double LCS_DispMinBodyRatio        = 0.55;
input double LCS_DispMinATR              = 0.60;
input bool   LCS_RequireZone             = true;
input bool   LCS_RequireDisplacement     = true;
input bool   LCS_UseSweepSL              = true;
input double LCS_SL_BufferATR            = 0.10;
input bool   LCS_LogValidation           = true;

input bool   EnableAlwaysQualityMode     = true;
input bool   QualityRequireStructureZone = true;  // Cont needs BOS/OB/FVG (or pullback)
input bool   QualityRequireTrendAndADX   = true;  // OK72: strong setups prefer trend+ADX
input bool   QualityDisableWeakPaths     = true;  // BEST: suppress weak VolBreakout unless stacked
input int    QualityMPIScore             = 0;

input bool   EnableInstantSniperMode     = false; // RETIRED live — InstantTrend offline
input bool   AllowTrendOnlyInstantEntry  = false; // RETIRED — no trend-only scalp fallback
input bool   AggressiveSniperEntries     = true;
input bool   NeverBlockValidSniperEntry  = true;  // don't veto approved Cont/Rev
input bool   ResolveConflictByTrend      = true;
input bool   AggressiveInstitutionalExecution = true; // fast Cont/Rev once quality stack OK
input double PullbackMaxATRMultiple      = 2.5;   // max ATR distance from EMA to count as pullback
input double InstantPullbackATRMultiple  = 2.5;   // tighter pullback for quality Cont
input int    InstantStructureRecencyBars = 24;
input int    InstantMinimumMPIScore      = 0;
input bool   InstantTwoOfThreeLiquidity  = true;
input bool   InstantFvgOrOb              = true;
input double InstantChannelBreakATR      = 0.35;
input int    DirectionalBOS_LookbackBars = 8;     // OK68: tighter same-dir BOS window

input group "TRADE SIZE & LIMITS (adjustable)"
// Change these in EA Inputs after attach — they are live settings.

input double LotSize = 0.01;              // lots per trade (when UseFixedLot=true)
input bool   UseFixedLot = true;          // true = use LotSize; false = risk % of equity
input double RiskPercent = 1.0;           // used only when UseFixedLot=false
input double MaxLotSizeHardCap = 5.0;     // hard ceiling so sizing never goes insane

input group "OPEN TRADES CAPS (adjustable — set in Inputs)"
// All caps are live Inputs. Set any to 0 = unlimited / off for that cap.
// Turn EnforceOpenTradeCaps=false to ignore ALL open-trade count limits.

input bool   EnforceOpenTradeCaps         = true;  // master: false = no open-trade count blocks
input int    MaxOpenTrades                = 3;     // OK91: max 3 open trades
input int    MaxTotalOpenTradesAllSymbols = 0;     // ALLTRADE56: 0=unlimited — was 9 blocking multi-chart
input int    MaxOpenTradesPerCurrency     = 0;     // ALLTRADE56: 0=off — was 4 blocking EUR/GBP/XAU USD share

input group "SMT - SMART MONEY TECHNIQUE"
// RIGHT PLACE: SMT belongs on REVERSAL / liquidity paths (RevSniper,
// LiquiditySweep). It must NOT hard-block InstantTrend/ContSniper — that
// duplicated RevSniper's sweep+zone checks and killed BTC trend execution.

input bool   EnableSMT                 = true;
input string SMTReferenceSymbol        = "";   // e.g. ETHUSD.m for BTC — blank = internal SMT only
input bool   SMTAllowInternal          = true;
input bool   SMTRequireForEntry        = true;  // HARD on RevSniper/LiquiditySweep when stack fails
input bool   SMTBlockContinuationPaths = false; // keep FALSE so Cont/Instant are not SMT-blocked
input int    SMTSwingLookbackBars      = 20;
input bool   SMTFailOpenIfNoRefData    = true;  // if ref blank/unavailable, do not block (fail-open)

input group "IMCE - INSTITUTIONAL MARKET CONTEXT ENGINE"
// HARD context gate — blocks chop on reversal paths; continuation/InstantTrend
// can still fire when trend+ADX agree (fixes OK27 BTC chop deadlock).

input bool   EnableIMCE                = true;
input bool   IMCERequireForEntry       = true;  // HARD gate
input bool   IMCEBlockManipulationChop = true;
input bool   IMCEAllowTrendContinuationsInChop = true; // InstantTrend/Cont in chop when trend agrees

input group "ICE - INSTITUTIONAL CONFIDENCE ENGINE"
// Your log: HARD ICE 25 < 50 — old saved input floor was 50.
// NEW input name ICE_MinScore resets that. Trend+ADX+IMCE now scores ~45.

input bool   EnableInstitutionalConfidence = true;
input bool   ICERequireForEntry            = true;  // HARD gate
input int    ICE_MinScore                  = 25;    // ALLTRADE56: was 32 — fewer false Cont rejects

input group "FILTERS"

input bool UseEMA = true;
input bool UseADX = true;
input bool UseATR = true;

input group "TIMEFRAMES"

input ENUM_TIMEFRAMES TrendTF = PERIOD_CURRENT; // follows chart — change chart TF to change trend TF
input ENUM_TIMEFRAMES EntryTF = PERIOD_CURRENT; // follows chart — H1 chart=H1, H4 chart=H4, M15 chart=M15

input group "LONG TERM HOLDING"

input bool EnableLongTermHolding = true;
input int  MinimumHoldBars = 24; // OK64: longer hold on EntryTF (H1≈24h)

input group "ATR TRAILING STOP"

input bool   EnableATRTrailing = true;
input double ATR_TrailingMultiplier = 2.5;

input group "TREND EXIT"

input bool EnableTrendExit = false; // FIX: was true by default - this is the second time in this project trend-exit has turned out to be closing trades that weren't actually supposed to close. Rather than keep special-casing individual symbols (as was done for BTC/ETH), it's now off everywhere by default. SL/TP1/TP2/TP3/trailing still fully protect every trade; turn this back on deliberately if you specifically want ADX-based early exits.
input int  TrendExitADXLevel = 20;

input group "HIGHER TIMEFRAME CONFIRMATION"

input bool             EnableHTFConfirmation = false; // OFF: HTF was a hard blocker; aggressive sniper uses entry-TF structure
input ENUM_TIMEFRAMES  HigherTimeframe = PERIOD_H4;

input group "NEWS AWARENESS"
// Know news via calendar logs. Hard-block retired — never pauses trading for news.

input bool EnableNewsAwareness = true;  // know/log high-impact news (does NOT block)
input int  MinutesBeforeNews = 30;
input int  MinutesAfterNews = 30;
input bool NewsAwarenessLogOncePerBar = true; // log at most once per EntryTF bar
// Hard news block RETIRED (OK66): EnableNewsFilter / BlockHighImpact* removed — awareness only.

// EVENT TIGHTEN RETIRED (OK67) — news awareness must not raise ICE/MPI or block.
input bool   EnableEventQualityMode       = false; // forced inert via EventQualityModeActive()
input bool   EventQualityAppliesToCrypto  = false;
input bool   EventDisableWeakPaths        = false;
input bool   EventRequireStructureZone    = false;
input bool   EventRequireTrendAndADX      = false;
input int    EventQualityMPIScore         = 0;
input int    EventICE_MinScoreBoost       = 0;
input int    EventMinutesBeforeNews       = 30;
input int    EventMinutesAfterNews        = 30;

//======================== GLOBALS ==================================//

bool TradingAllowed=true;

// APEX runtime (world-class path invalidation → Execute SL)
double   g_APEX_InvalidationPrice = 0.0;
datetime g_APEX_SweepBarTime      = 0;
string   g_APEX_LastDetail        = "";
string   g_APEX_LastBuyFail       = "";
string   g_APEX_LastSellFail      = "";

// LCS runtime (fallback path)
double   g_LCS_InvalidationPrice = 0.0;
datetime g_LCS_SweepBarTime      = 0;
string   g_LCS_LastDetail        = "";

string BrokerSymbol="";

// Trade statistics (persisted via GlobalVariable - see Part 18)
int    Stat_TotalTrades      = 0;
int    Stat_WinTrades        = 0;
int    Stat_LossTrades       = 0;
double Stat_GrossProfit      = 0.0;
double Stat_GrossLoss        = 0.0;
int    Stat_ConsecutiveWins  = 0;
int    Stat_ConsecutiveLosses = 0;

// Daily loss tracking (real per-day reference balance, not a placeholder)

datetime DailyTrackedDay=0;
double   DailyStartBalance=0.0;
datetime WeeklyTrackedWeekStart=0;
double   WeeklyStartBalance=0.0;
datetime MonthlyTrackedMonthStart=0;
double   MonthlyStartBalance=0.0;

// Indicator Handles - PER SYMBOL (see MULTI-SYMBOL EXECUTION, Part 19).
// Arrays instead of single handles so each symbol in MultiSymbolList gets
// its own indicator instance; index-matched to MultiSymbolList[].
int EMAHandles[];
int ADXHandles[];
int ATRHandlesArr[];
int FilterATRHandles[];
int HTFEMAHandlesArr[];

// NEW - Mean-Reversion strategy module handles (see Part 15b). Per-symbol,
// same indexing pattern as every other indicator handle array above.
int RSIHandlesArr[];
int BBHandlesArr[];

// NEW - Trend-Following strategy module (Part 15d). Deliberately SEPARATE
// from EMAHandles above (the existing single 200-period EMA used by the
// SMC engine's trend filter) - this needs a genuine fast/slow PAIR to
// detect an actual crossover, not one trend-direction reference line.
int FastEMAHandlesArr[];
int SlowEMAHandlesArr[];

string MultiSymbolList[];
string PrimarySymbol=""; // the chart's own symbol - used for dashboard display and as the fallback when multi-symbol trading is off

// Per-trade tracking - PER SYMBOL, index-matched to MultiSymbolList[].
// FIX: these used to be single global values, which meant in multi-symbol
// mode a trade opening on one symbol would incorrectly start the cooldown
// (and post-loss cooldown) for every OTHER symbol too, since the cooldown
// checks read one shared value regardless of which symbol was being
// evaluated.
datetime LastTradeTimeArr[];
datetime LastAttemptTimeArr[];
bool     LastTradeWasLossArr[];
datetime LastLossCloseTimeArr[];

// OK64 anti-scalp ContFallback tracking (NeverBlock cannot bypass these)
datetime g_ContFallbackLastSignalBar = 0;
datetime g_ContFallbackLastFillTime  = 0;
datetime g_NewsAwareLastLogBar       = 0;

// FIX: same class of bug as above, found during this review - these were
// previously single globals/statics shared across every symbol instead of
// arrays index-matched to MultiSymbolList. In multi-symbol mode this meant:
//  - LastEntryEvalBarTime (bar-gate for new entries) being stamped by
//    whichever symbol last ran InstantExecution(), so other symbols could
//    have their own genuinely-new bar silently skipped (or, less often,
//    incorrectly allowed) depending on timing coincidences between symbols.
//  - DetectCHoCH()'s internal state (previously function-local statics)
//    comparing one symbol's trend flip against a DIFFERENT symbol's last
//    recorded state, and gating "already evaluated this bar" against
//    whichever symbol happened to run last - producing false or missed
//    CHoCH signals whenever more than one symbol was traded.
// Both are now arrays, index-matched to MultiSymbolList like everything
// else per-symbol in this file.
datetime LastEntryEvalBarTimeArr[];

// NEW - per-symbol consecutive win/loss tracking (fixes adaptive scoring
// penalty bleeding between unrelated symbols - see OnTradeTransaction and
// GetEffectiveMinimumScore). In-memory only, same documented tradeoff as
// SignalSnapshots[] - resets on restart rather than adding yet another
// persisted GlobalVariable set; the aggregate Stat_ConsecutiveLosses this
// supplements is still persisted as before.
int ConsecutiveLossesPerSymbolArr[];
int ConsecutiveWinsPerSymbolArr[];
datetime CHoCH_LastBarTimeArr[];
bool     CHoCH_LastBullTrendArr[];
bool     CHoCH_StateInitializedArr[];
datetime DiagLastBarTimeArr[];
datetime LastBOSTrueBarTimeArr[];
datetime LastCHoCHTrueBarTimeArr[];
bool     LastCHoCHWasBullArr[]; // AUDITFIX49: direction of last confirmed CHoCH (for reclaim polarity)
datetime LastSweepTrueBarTimeArr[]; // CRITICAL FIX (this pass): DetectLiquiditySweep() was being required to coincide on the exact same bar as CHoCH/OB in the live PRISM strategy setups - see the fix at LiquiditySweepBuySetup()/SellSetup() for the full explanation.

// FIX: DetectCHoCH() is called from many places inside a single decision
// cycle (CalculateTradeScore, HasStructureConfluence, HasHTFStructureConfluence,
// CapturePendingSignalSnapshot, the dashboard...). It used to flag itself as
// "already evaluated this bar" the instant the FIRST caller ran it, so only
// that first caller ever saw the real true/false answer - every other
// caller in the SAME cycle silently got false, even on a bar where a
// genuine CHoCH had just fired. That meant CHoCH's score contribution and
// the confluence checks could disagree with each other purely due to call
// order. These two arrays cache the real per-bar result once per (symbol,
// g_CycleCounter tick) - same pattern already used for the EMA/ADX/ATR
// indicator cache - so every consumer within one decision cycle agrees.
long CHoCH_CacheCycleArr[];
bool CHoCH_CacheResultArr[];

// NEW (this pass) - ORDER BLOCK FRESH/MITIGATED/INVALIDATED TRACKING:
// DetectBullishOrderBlock()/DetectBearishOrderBlock() only ever look at the
// last 2 candles, so by the time a caller asks about an order block a few
// bars later, the zone has already scrolled out of that window and the
// function just (correctly, but unhelpfully) returns false - there was no
// way to know a zone existed, was still untouched ("fresh"), had already
// been tapped once ("mitigated"), or had been fully closed through
// ("invalidated"). These arrays persist the single most recent bullish and
// bearish order-block zone per symbol so its state can be tracked forward
// bar by bar. Only the latest zone per direction is kept (not a full
// history) - simpler, and the latest zone is what matters for scoring the
// current setup.
datetime OB_Bull_BarTimeArr[];
double   OB_Bull_TopArr[];
double   OB_Bull_BottomArr[];
bool     OB_Bull_ActiveArr[];
bool     OB_Bull_MitigatedArr[];

datetime OB_Bear_BarTimeArr[];
double   OB_Bear_TopArr[];
double   OB_Bear_BottomArr[];
bool     OB_Bear_ActiveArr[];
bool     OB_Bear_MitigatedArr[];

datetime OB_LastProcessedBarTimeArr[]; // gates UpdateOrderBlockTracking() to run once per newly closed bar per symbol

// NEW (this pass) - FVG MITIGATION TRACKING: same idea as the order-block
// tracking above. GetBullishFVGQualityScore()/GetBearishFVGQualityScore()
// score a gap's size against ATR but have no idea whether that gap has
// since been partly or fully traded back into (a half-filled gap is much
// weaker supporting evidence than one price hasn't touched since it formed).
datetime FVG_Bull_BarTimeArr[];
double   FVG_Bull_TopArr[];
double   FVG_Bull_BottomArr[];
bool     FVG_Bull_ActiveArr[];
double   FVG_Bull_FilledPctArr[];

datetime FVG_Bear_BarTimeArr[];
double   FVG_Bear_TopArr[];
double   FVG_Bear_BottomArr[];
bool     FVG_Bear_ActiveArr[];
double   FVG_Bear_FilledPctArr[];

datetime FVG_LastProcessedBarTimeArr[]; // gates UpdateFVGTracking() to run once per newly closed bar per symbol

// PERFORMANCE (this pass): GetRecentHigh()/GetRecentLow() at EntryTF are
// called many times per decision cycle (BOS, liquidity sweep, equal-highs/
// lows, FVG-adjacent checks, fake-breakout trap, premium/discount,
// displacement, dynamic S/R...) and each call re-scans a StructureLookback
// x SwingBars nested loop from scratch. Cached once per (symbol,
// g_CycleCounter tick) - same pattern as the CHoCH cache above - so a
// whole decision cycle pays for that scan once instead of 5-10 times. Only
// covers the EntryTF (PERIOD_CURRENT/default) case, which is the hot path;
// explicit-timeframe calls (HTF confluence) are infrequent enough not to
// need caching.
long   SwingHighCacheCycleArr[];
double SwingHighCacheArr[];
long   SwingLowCacheCycleArr[];
double SwingLowCacheArr[];

// PERFORMANCE (this pass): DetectBOS() re-derives the swing levels and
// re-reads closes on every call; it's called from CalculateTradeScore(),
// HasStructureConfluence(), diagnostics, and the signal snapshot capture -
// several times per cycle. Same per-cycle cache pattern.
long BOS_CacheCycleArr[];
bool BOS_CacheResultArr[];

// DUPLICATE SIGNAL FILTER (this pass): CooldownFinished() only throttles by
// elapsed TIME since the last FILLED trade - it says nothing about whether
// the CURRENT signal is the same one that already fired earlier on this
// same bar. With EnableTickLevelSignalDetection on (default), every tick
// re-runs EvaluateStrategySignals(); if TradeCooldownMinutes is short (or
// zero) relative to the bar period, the same underlying setup could in
// principle trigger more than one entry attempt before the bar closes.
// These record the bar time of the last APPROVED (score passed) signal per
// direction per symbol, independent of cooldown minutes, so a second
// approval on the same still-forming bar is recognized as a duplicate of
// the one just acted on rather than a fresh opportunity.
datetime LastApprovedBuyBarTimeArr[];
datetime LastApprovedSellBarTimeArr[];

// MARKET REGIME HYSTERESIS (this pass): a raw ADX-vs-threshold read flips
// REGIME_TRENDING/REGIME_RANGING back and forth on every bar where ADX is
// hovering near RegimeADXThreshold - "switching accuracy" in the literal
// sense the request asks about. Persists the last confirmed regime per
// symbol and only allows a flip once ADX clears the threshold by a buffer
// band, so borderline noise doesn't relabel the regime every bar.
int      RegimeLastStateArr[]; // stores MarketRegime as int, -1 = not yet set

void PrintStrategyPerformanceReport(); // full upgrade: print on init
int  PathBasePriority(const string tag);
int  PathQualityRankScore(const string tag, const bool buy);

// CopyBuffer() every single call - unlike GetEMA()/GetADX()/GetATR(),
// which already cache once per (symbol, trading cycle) via
// IndicatorCacheCycleArr. The mean-reversion functions that used these are
// no longer reachable (legacy strategy modes removed - PRISM is the only
// strategy now), but the cache is harmless to keep in case they're ever
// re-enabled. Same caching pattern as above.
long   RSI_CacheCycleArr[];
double RSI_CacheValueArr[];
long   BB_CacheCycleArr[];
double BB_CacheUpperArr[];
double BB_CacheLowerArr[];
double BB_CacheMidArr[];

// Buffers

double EMABuffer[];
double ADXBuffer[];
double ATRBuffer[];
double HTF_EMABuffer[];

//======================== INIT =====================================//


// --- OK93 early decls for modular includes ---
input bool EnableMultiSymbolTrading = false;
input int  MultiSymbolTimerSeconds  = 15;
input bool EnableDashboard = true;   // OK93 modular: early decl for Dashboard module
input int DashboardRefreshMillis = 1000;
int GetSymbolIndex(string symbol);

#endif
//===== END Shell_A_InputsGlobals.mqh =====

//===== BEGIN 00_Types.mqh =====
#ifndef HITMAN_ULTRA_00_TYPES_MQH
#define HITMAN_ULTRA_00_TYPES_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 00_TYPES — Enums · Structures · Shared Definitions
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| 00. Shared Types — HITMAN AI                               |
//+------------------------------------------------------------------+
enum ENUM_ULTRA_REGIME
{
   UREG_STRONG_TREND = 0,
   UREG_WEAK_TREND,
   UREG_HEALTHY_TREND,
   UREG_RANGE,
   UREG_COMPRESSION,
   UREG_EXPANSION,
   UREG_BREAKOUT,
   UREG_REVERSAL,
   UREG_ACCUMULATION,
   UREG_DISTRIBUTION,
   UREG_EXHAUSTION
};

struct UltraCoreState
{
   bool   loaded;
   bool   configOK;
   bool   dataOK;
   bool   validated;
   bool   healthy;
   long   lastCycleMs;
   long   lastLatencyMs;
   int    errorCount;
   int    recoveryCount;
   string lastError;
};

struct UltraStructure
{
   bool hh, hl, lh, ll;
   bool swingHighOK, swingLowOK;
   bool internalBull, internalBear;
   bool externalBull, externalBear;
   bool continuation, reversal;
   int  strength;   // 0-100
   int  quality;    // 0-100
   double swingHigh, swingLow;
   int    cycle;       // ENUM_MARKET_CYCLE as int
   string cycleName;   // ACCUMULATION / MARKUP / DISTRIBUTION / MARKDOWN
};

struct UltraBOS
{
   bool buy, sell;
   bool strong, weak;
   bool confirmed, failed;
   int  strength, quality, confirmation, reliability, score;
};

struct UltraCHoCH
{
   bool buy, sell;
   bool internalC, externalC;
   bool majorC, minorC;
   int  strength, confidence;
};

struct UltraLiquidity
{
   bool buySideLiq, sellSideLiq;
   bool poolBuy, poolSell;
   bool equalLows, equalHighs;   // Master Blueprint aliases
   bool grabBuy, grabSell;
   bool stopHuntBuy, stopHuntSell;
   bool sweepBuy, sweepSell;
   bool confirmedBuy, confirmedSell;
   double poolLow, poolHigh;
   double sweepExtBuy, sweepExtSell;
   double depthATR, speed, strength, quality;
   int rejectionScore;
};

struct UltraFib
{
   double f0, f100, f382, f500, f618, f786;
   double ext127, ext161;
   bool atBuyZone, atSellZone;
   bool impulseOK;
   int zoneRank, confluence, quality, confidence;
   double retracePos;
};

struct UltraInst
{
   bool obBuy, obSell;
   bool breakerBuy, breakerSell;
   bool mitigationBuy, mitigationSell;
   bool fvgBuy, fvgSell;
   bool imbalanceBuy, imbalanceSell;     // raw imbalance (gap) distinct from FVG zone use
   bool institutionalLiqBuy, institutionalLiqSell;
   bool instZoneBuy, instZoneSell;
   bool rejectZoneBuy, rejectZoneSell;
   bool smConfluence;
   bool dispBuy, dispSell;
   bool inDiscount, inPremium;
};

struct UltraTrend
{
   bool bull, bear;
   int  strength, quality, persistence;
   bool continuation, exhaustion;
   bool htfBull, htfBear, macroBull, macroBear;
   bool weekBull, weekBear, monthBull, monthBear;
   int  mtfVotesBuy, mtfVotesSell;
};

struct UltraMomentum
{
   int  direction; // +1/-1/0
   int  strength, acceleration, quality, confirmation;
   bool momBuy, momSell;
   bool weakness, impulse;
};

struct UltraVolatility
{
   double atr;
   bool expansion, compression;
   double relative;
   int  classification; // -1 compress, 0 normal, 1 expand
};

struct UltraSessionNews
{
   string session;
   bool   asia, london, newyork, overlap;
   bool   killZone;
   bool   sessionLiquidity;          // overlap / kill-zone liquidity window
   int    sessionConfidence, sessionQuality;
   bool   newsVol;
   bool   highImpactProxy, midImpactProxy, lowImpactProxy;
   bool   beforeNews, duringNews, afterNews; // context phases — NEVER block
   string newsPhase;                 // "BEFORE" | "DURING" | "AFTER" | "NONE"
   double spreadPts, slipProxy;
   // Session + News: CONTEXT ONLY · Trades 24/5 · never hard-block
};

struct UltraIndicators
{
   double smi;   // Sniper Momentum Index -100..100
   double meo;   // Market Energy Oscillator 0..100
   double ifi;   // Institutional Footprint Index -100..100
};

struct UltraScores
{
   int confidence;   // Final AI Confidence
   int precision;
   int probability;
   int successProb;
   int riskProb;
   int confluence;
};

struct UltraMemory
{
   int   trades;
   int   wins;
   double profitSum;
   double lossSum;
   double avgRR;
   double winRate;
   double profitFactor;
   double expectancy;
   long   lastSave;
};

struct UltraDiag
{
   bool tickOK, brokerOK, connectionOK, indicatorOK, memoryOK;
   long processSpeedMs;
   string health;
};

struct UltraSnap
{
   UltraStructure   st;
   UltraBOS         bos;
   UltraCHoCH       choch;
   UltraLiquidity   liq;
   UltraFib         fib;
   UltraInst        ict;
   UltraTrend       trend;
   UltraMomentum    mom;
   UltraVolatility  vol;
   ENUM_ULTRA_REGIME regime;
   UltraSessionNews ctx;
   UltraIndicators  ind;
   UltraScores      score;
   UltraDiag        diag;
   bool buyBias, sellBias;
};

struct UltraSignal
{
   bool buy, sell;
   int  score;
   string tag;
   string reason;
   string explanation; // Master Blueprint explainable decision text
};

UltraCoreState g_UltraCore;
UltraMemory    g_UltraMem;
UltraSnap      g_UltraLastSnap;
UltraSignal    g_UltraLastSignal;
datetime       g_UltraLastFireBar = 0;

//--------------------------------------------------------------------//
// DEFENSE LINE ENGINE v1.0 — shared enums / report
//--------------------------------------------------------------------//
enum ENUM_DEFENSE_LEVEL
{
   DEF_GREEN  = 0, // Trade Allowed
   DEF_YELLOW = 1, // Wait for Confirmation
   DEF_RED    = 2  // Block Trade
};

enum ENUM_DEFENSE_ACTION
{
   DEF_ACT_EXECUTE = 0,
   DEF_ACT_WAIT,
   DEF_ACT_NO_TRADE,
   DEF_ACT_DO_NOT_EXECUTE
};

struct UltraDefenseLine
{
   int                id;       // 1..10
   string             name;
   bool               pass;
   ENUM_DEFENSE_LEVEL level;
   string             reason;
};

struct UltraDefenseReport
{
   bool               valid;
   bool               buySide;
   ENUM_DEFENSE_LEVEL overall;
   ENUM_DEFENSE_ACTION action;
   bool               allowEntry;
   bool               allowExecute;
   UltraDefenseLine   line[11]; // 1..10 used
   string             summary;
};

UltraDefenseReport g_UltraDefenseLast;

//--------------------------------------------------------------------//
// MISSION CONTROL — BUY / SELL / WAIT / HOLD / MANAGE / EXIT
//--------------------------------------------------------------------//
enum ENUM_SUPREME_DECISION
{
   SUP_BUY = 0,
   SUP_SELL,
   SUP_WAIT,
   SUP_HOLD,
   SUP_MANAGE,
   SUP_EXIT
};

// Forward — Mission Control is sole close authority (defined later)
bool UltraMission_ClosePosition(const ulong ticket, const string whyIn, const bool riskForced);
bool UltraMission_ClosePartial(const ulong ticket, const double volume, const string why);
void UltraMission_NoteOpen(const ulong ticket, const string s, const bool isBuy, const string tag);
bool UltraMission_AllowNewEntry(const string s);

//--------------------------------------------------------------------//
// 1. ULTRA CORE / DATA / CONFIG / VALIDATION / RECOVERY / LOG / PERF
//--------------------------------------------------------------------//

#endif // HITMAN_ULTRA_00_TYPES_MQH
//===== END 00_Types.mqh =====

//===== BEGIN 31_Inputs.mqh =====
#ifndef HITMAN_ULTRA_31_INPUTS_MQH
#define HITMAN_ULTRA_31_INPUTS_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 31_INPUTS                                       |
//| Trading · Risk · Dashboard · Strategy · Session · News ·          |
//| Execution · Capital Protection                                    |
//| Shell_A still holds Magic / TradeComment / MaxOpenTrades=3        |
//+------------------------------------------------------------------+

input group "31 · TRADING INPUTS"
input bool   UltraCoreEnabled            = true;
input bool   UltraDataEngineEnabled      = true;
input bool   UltraConfigEngineEnabled    = true;
input bool   UltraValidationEnabled      = true;
input bool   UltraStateSyncEnabled       = true;
input bool   UltraTrade24x5              = true; // always allow (24/5)

input group "31 · STRATEGY INPUTS"
input bool   UltraEnable_FlashSweep      = true;
input bool   UltraEnable_ContSniper      = true;
input bool   UltraEnable_RevSniper       = true;
input bool   UltraEnable_FibSniper       = true;
input bool   UltraEnable_BreakImpulse    = true;
input bool   UltraEnable_InstZone        = true;
input int    UltraSwingStrength          = 2;
input int    UltraStructLookback         = 48;
input int    UltraBOS_ConfirmBars        = 14;
input int    UltraSweepLookback          = 24;
input double UltraEqualTolATR            = 0.12;
input double UltraSweepWickMin           = 0.28;
input double UltraSweepDepthATR          = 0.06;
input double UltraDispBodyMin            = 0.48;
input double UltraDispATRMin             = 0.35;
input double UltraFVG_MinATR             = 0.12;
input double UltraVolExpandMult          = 1.20;
input int    UltraMomentumBars           = 3;
input double UltraFibBuyLow              = 0.50;
input double UltraFibBuyHigh             = 0.886;
input double UltraFibSellLow             = 0.114;
input double UltraFibSellHigh            = 0.50;
input bool   UltraSoftPreferFib          = true;
input double UltraFibExt127              = 1.272;
input double UltraFibExt161              = 1.618;
input int    UltraMinConfluence          = 45;   // Live floor (InstantQuality softens further)
input int    UltraInstantFireConf        = 58;
input int    UltraMinPrecision           = 38;
input int    UltraMinProbability         = 38;
input bool   UltraBlockOppositeSameSym   = true;

input group "31 · RISK INPUTS"
input bool   UltraErrorHandlingEnabled   = true;
input bool   UltraPerfEngineEnabled      = true;
input bool   UltraMemoryEngineEnabled    = true;
input bool   UltraLoggingEnabled         = true;
input bool   UltraRecoveryEnabled        = true;

input group "31 · SESSION INPUTS (context only — NEVER blocks)"
input bool   UltraSessionIntelEnabled    = true;
input bool   UltraBoostKillZone          = true;

input group "31 · NEWS INPUTS (context only — NEVER blocks)"
input bool   UltraNewsIntelEnabled       = true;
input bool   UltraBoostNewsVol           = true;

input group "31 · EXECUTION INPUTS"
input bool   UltraExecQualityEnabled     = true;
input ENUM_TIMEFRAMES UltraTF_Bias       = PERIOD_H4;
input ENUM_TIMEFRAMES UltraTF_Macro      = PERIOD_D1;
input ENUM_TIMEFRAMES UltraTF_Week       = PERIOD_W1;
input ENUM_TIMEFRAMES UltraTF_Month      = PERIOD_MN1;
input bool   UltraUseMTFVoting           = true;
input bool   UltraUseM30                 = true;
input bool   UltraUseM15                 = true;
input bool   UltraUseM5                  = true;
input bool   UltraUseM1Optional          = false;

input group "31 · CAPITAL PROTECTION INPUTS"
input bool   UltraCapitalProtectEnabled  = true;

input group "31 · ULTRA FAST SIGNAL ENGINE v1.0"
input bool   UltraFastSignalEnabled      = true;  // event-driven cache + scanner
input bool   UltraMasterTrendLock        = true;  // LTF cannot reverse HTF master
input bool   UltraSignalLockEnabled      = true;  // block duplicates until unlock event
input bool   UltraUFSE_ExplainLog        = true;  // PASS/FAIL explain on fire/wait
input bool   UltraUFSE_EntryTriggerGate  = true;  // formal entry trigger checklist

input group "31 · DEFENSE LINE ENGINE v1.0"
input bool   UltraDefenseEnabled         = true;  // master switch — 10 defense lines
input bool   UltraDefenseStrict          = false; // true = hard gates; false = InstantQuality soft
input bool   UltraDefenseLog             = true;  // journal GREEN/YELLOW/RED explain
input bool   UltraDefenseGateEntry       = true;  // Lines 1-6 + 10 on UltraAIDecide
input bool   UltraDefenseGateExec        = true;  // Line 7 before fire
input bool   UltraDefensePosition        = true;  // Line 8 open-position protect
input bool   UltraDefenseCloseOnFlip     = false; // L8 hard-close on adverse flip (else BE only)
input bool   UltraDefenseEmergency       = true;  // Line 9 auto-recover

input group "31 · TRADE ENTRY DISCIPLINE v1.0"
input bool   UltraDisciplineEnabled      = true;  // irregular trade prevention master
input bool   UltraDisciplineStrict       = false; // true = hard 12-rule gates
input bool   UltraDisciplineLog          = true;  // journal discipline PASS/WAIT
input int    UltraDisciplineStableEvals  = 2;     // Rule #3: consecutive same-dir evals
input int    UltraDisciplineMTFMinAgree  = 3;     // Rule #6: H4..M5 agreement (of 5)
input bool   UltraDisciplineNeedNewStruct= false; // Rule #11: require new structure after fill

input group "31 · ULTRA UPGRADE PACK (Levels 1-20)"
input bool   UltraUpgradeEnabled         = true;  // master switch for upgrade pack
input bool   UltraUpgradeStrict          = false; // soft InstantQuality-compatible
input bool   UltraUpgradeLog             = true;  // log supreme / thesis / exits
input bool   UltraSupremeEnabled         = true;  // L1/L20 Supreme Command
input bool   UltraUSM2Enabled            = true;  // L4 Ultra Scoring Machine 2.0
input bool   UltraDynWeightsEnabled      = true;  // L5 Dynamic Weight Engine
input bool   UltraSignalEvoEnabled       = true;  // L3 Signal Evolution
input bool   UltraThesisEnabled          = true;  // L11 Trade Thesis Engine
input bool   UltraHoldScoreEnabled       = true;  // L12 Hold Score
input bool   UltraCorrectionEnabled      = true;  // L13 Correction Detector
input bool   UltraSmartExitEnabled       = true;  // L14 Smart Exit
input bool   UltraSystemHealthEnabled    = true;  // L15-17 System Health

input group "31 · DASHBOARD INPUTS"
input bool   UltraDashboardEnabled       = true;
input bool   UltraDiagnosticsEnabled     = true;
input bool   UltraMarketMemoryEnabled    = true;
input bool   UltraDebugEnabled           = false;

#endif // HITMAN_ULTRA_31_INPUTS_MQH
//===== END 31_Inputs.mqh =====

//===== BEGIN 28_Utilities.mqh =====
#ifndef HITMAN_ULTRA_28_UTILITIES_MQH
#define HITMAN_ULTRA_28_UTILITIES_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 28_UTILITIES — Helpers · Math · Time · Price
//+------------------------------------------------------------------+
// Timeframe / ATR / SMA / Swing helpers
ENUM_TIMEFRAMES UltraETF()
{
   return (EntryTF == PERIOD_CURRENT) ? (ENUM_TIMEFRAMES)Period() : EntryTF;
}
double UltraATR(const string s, const int period=14)
{
   int p = MathMax(period, 5);
   ENUM_TIMEFRAMES tf = UltraETF();
   if(Bars(s, tf) < p + 5) return 0.0;
   double sum = 0.0;
   for(int i = 1; i <= p; i++)
   {
      double h = iHigh(s, tf, i), l = iLow(s, tf, i), pc = iClose(s, tf, i + 1);
      sum += MathMax(h - l, MathMax(MathAbs(h - pc), MathAbs(l - pc)));
   }
   return sum / p;
}
double UltraSMA(const string s, const ENUM_TIMEFRAMES tf, const int period, const int shift=1)
{
   if(Bars(s, tf) < period + shift + 2) return 0.0;
   double a = 0.0;
   for(int i = shift; i < shift + period; i++) a += iClose(s, tf, i);
   return a / period;
}
bool UltraSwingHighAt(const string s, const ENUM_TIMEFRAMES tf, const int bar, const int strength)
{
   int bars = Bars(s, tf);
   if(bar - strength < 0 || bar + strength >= bars) return false;
   double h = iHigh(s, tf, bar);
   for(int i = 1; i <= strength; i++)
      if(iHigh(s, tf, bar - i) >= h || iHigh(s, tf, bar + i) >= h) return false;
   return true;
}
bool UltraSwingLowAt(const string s, const ENUM_TIMEFRAMES tf, const int bar, const int strength)
{
   int bars = Bars(s, tf);
   if(bar - strength < 0 || bar + strength >= bars) return false;
   double l = iLow(s, tf, bar);
   for(int i = 1; i <= strength; i++)
      if(iLow(s, tf, bar - i) <= l || iLow(s, tf, bar + i) <= l) return false;
   return true;
}
bool UltraFindSwings(const string s, const ENUM_TIMEFRAMES tf, const int lb, const int strength,
                     int &iH1, int &iH2, int &iL1, int &iL2)
{
   iH1 = iH2 = iL1 = iL2 = 0;
   int sw = MathMax(strength, 1), look = MathMax(lb, 20);
   for(int i = sw + 1; i <= look; i++)
   {
      if(iH1 == 0 && UltraSwingHighAt(s, tf, i, sw)) iH1 = i;
      else if(iH1 > 0 && iH2 == 0 && UltraSwingHighAt(s, tf, i, sw)) iH2 = i;
      if(iL1 == 0 && UltraSwingLowAt(s, tf, i, sw)) iL1 = i;
      else if(iL1 > 0 && iL2 == 0 && UltraSwingLowAt(s, tf, i, sw)) iL2 = i;
      if(iH1 && iH2 && iL1 && iL2) break;
   }
   return (iH1 && iH2 && iL1 && iL2);
}

// MQL5-safe bool→text (never concatenate bare bool into strings / Print)
string UltraYN(const bool v)
{
   if(v) return "Y";
   return "N";
}

int UltraSymDigits(const string s)
{
   long v = 0;
   SymbolInfoInteger(s, SYMBOL_DIGITS, v);
   return (int)v;
}

long UltraSymSpread(const string s)
{
   long v = 0;
   SymbolInfoInteger(s, SYMBOL_SPREAD, v);
   return v;
}

long UltraSymStopsLevel(const string s)
{
   long v = 0;
   SymbolInfoInteger(s, SYMBOL_TRADE_STOPS_LEVEL, v);
   return v;
}

long UltraSymFreezeLevel(const string s)
{
   long v = 0;
   SymbolInfoInteger(s, SYMBOL_TRADE_FREEZE_LEVEL, v);
   return v;
}

long UltraSymFillingMode(const string s)
{
   long v = 0;
   SymbolInfoInteger(s, SYMBOL_FILLING_MODE, v);
   return v;
}

#endif // HITMAN_ULTRA_28_UTILITIES_MQH
//===== END 28_Utilities.mqh =====

//===== BEGIN 27_Logger.mqh =====
#ifndef HITMAN_ULTRA_27_LOGGER_MQH
#define HITMAN_ULTRA_27_LOGGER_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 27_LOGGER — Error · Trade · AI · Execution · System logs
//+------------------------------------------------------------------+
void UltraLog(const string msg)
{
   if(UltraLoggingEnabled)
      Print("ULTRA| ", msg);
}
void UltraSetError(const string e)
{
   if(!UltraErrorHandlingEnabled) return;
   g_UltraCore.errorCount++;
   g_UltraCore.lastError = e;
   UltraLog("ERR " + e);
}

void UltraLogTrade(const string msg){ UltraLog("TRADE| " + msg); }
void UltraLogAI(const string msg){ UltraLog("AI| " + msg); }
void UltraLogExec(const string msg){ UltraLog("EXEC| " + msg); }
void UltraLogPerf(const string msg){ UltraLog("PERF| " + msg); }

#endif // HITMAN_ULTRA_27_LOGGER_MQH
//===== END 27_Logger.mqh =====

//===== BEGIN 30_Recovery.mqh =====
#ifndef HITMAN_ULTRA_30_RECOVERY_MQH
#define HITMAN_ULTRA_30_RECOVERY_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 30_RECOVERY — Restart · Connection · State · Position recovery
//+------------------------------------------------------------------+
void UltraRecover(const string why)
{
   if(!UltraRecoveryEnabled) return;
   g_UltraCore.recoveryCount++;
   UltraLog("RECOVERY " + why);
   g_UltraCore.healthy = true;
}

bool UltraRecovery_ConnectionOK()
{
   return (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
}

bool UltraRecovery_TerminalTradeOK()
{
   return (bool)TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)
       && (AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) != 0);
}

void UltraRecovery_OnReconnect(const string why)
{
   if(!UltraRecovery_ConnectionOK()) return;
   UltraRecover(why);
}

#endif // HITMAN_ULTRA_30_RECOVERY_MQH
//===== END 30_Recovery.mqh =====

//===== BEGIN 01_Core.mqh =====
#ifndef HITMAN_ULTRA_01_CORE_MQH
#define HITMAN_ULTRA_01_CORE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 01_CORE — Init · Loader · Config · Validation · State Controller
//+------------------------------------------------------------------+
bool UltraConfigOK()
{
   if(!UltraConfigEngineEnabled) return true;
   if(TradeComment != "HITMAN AI") return false;
   if(MaxOpenTrades < 1) return false;
   if(UltraMinConfluence < 1 || UltraMinConfluence > 100) return false;
   return true;
}
bool UltraValidateSymbol(const string s)
{
   if(!UltraValidationEnabled) return true;
   long sel = 0;
   if(s == "" || !SymbolInfoInteger(s, SYMBOL_SELECT, sel) || sel == 0) return false;
   if(Bars(s, UltraETF()) < 60) return false;
   return true;
}
void UltraCoreInit()
{
   g_UltraCore.loaded = false;
   g_UltraCore.configOK = false;
   g_UltraCore.dataOK = false;
   g_UltraCore.validated = false;
   g_UltraCore.healthy = false;
   g_UltraCore.lastCycleMs = 0;
   g_UltraCore.lastLatencyMs = 0;
   g_UltraCore.errorCount = 0;
   g_UltraCore.recoveryCount = 0;
   g_UltraCore.lastError = "";
   g_UltraMem.trades = 0;
   g_UltraMem.wins = 0;
   g_UltraMem.profitSum = 0;
   g_UltraMem.lossSum = 0;
   g_UltraMem.avgRR = 0;
   g_UltraMem.winRate = 0;
   g_UltraMem.profitFactor = 0;
   g_UltraMem.expectancy = 0;
   g_UltraMem.lastSave = 0;
   g_UltraCore.loaded = true;
   g_UltraCore.configOK = UltraConfigOK();
   g_UltraCore.healthy = g_UltraCore.configOK;
   string cfg = "N";
   if(g_UltraCore.configOK) cfg = "Y";
   UltraLog("CORE loaded configOK=" + cfg);
}

void UltraSystemController_Boot()
{
   UltraCoreInit();
   if(!UltraConfigOK())
      UltraSetError("config validation failed at boot");
}

#endif // HITMAN_ULTRA_01_CORE_MQH
//===== END 01_Core.mqh =====

//===== BEGIN 02_Data.mqh =====
#ifndef HITMAN_ULTRA_02_DATA_MQH
#define HITMAN_ULTRA_02_DATA_MQH
//+------------------------------------------------------------------+
//| HITMAN AI ULTRA X — LEVEL 2 ULTRA DATA CORE                      |
//| Tick cache · Smart cache · Memory · Integrity · Multi-symbol     |
//+------------------------------------------------------------------+

struct UltraDataCache
{
   string   symbol;
   datetime barTime;
   datetime tickTime;
   double   bid, ask;
   double   spreadPts;
   double   atr;
   long     tickVol;
   bool     valid;
   bool     integrityOK;
};

#define ULTRA_MSYM_CACHE_MAX 32
UltraDataCache g_UltraDataCache;
UltraDataCache g_UltraMSymCache[ULTRA_MSYM_CACHE_MAX];
int            g_UltraMSymCacheN = 0;

int UltraData_MSymFind(const string s)
{
   for(int i = 0; i < g_UltraMSymCacheN; i++)
      if(g_UltraMSymCache[i].symbol == s) return i;
   return -1;
}

int UltraData_MSymAlloc(const string s)
{
   int idx = UltraData_MSymFind(s);
   if(idx >= 0) return idx;
   if(g_UltraMSymCacheN >= ULTRA_MSYM_CACHE_MAX) return 0;
   idx = g_UltraMSymCacheN++;
   g_UltraMSymCache[idx].symbol = s;
   return idx;
}

bool UltraData_Integrity(const string s, const UltraDataCache &c)
{
   if(!c.valid) return false;
   if(c.bid <= 0.0 || c.ask < c.bid) return false;
   if(c.spreadPts < 0.0) return false;
   if(c.barTime <= 0) return false;
   long tm = 0;
   if(!SymbolInfoInteger(s, SYMBOL_TRADE_MODE, tm)) return false;
   return true;
}

bool UltraData_Refresh(const string s)
{
   g_UltraDataCache.symbol = s;
   g_UltraDataCache.bid = SymbolInfoDouble(s, SYMBOL_BID);
   g_UltraDataCache.ask = SymbolInfoDouble(s, SYMBOL_ASK);
   long spr = 0; SymbolInfoInteger(s, SYMBOL_SPREAD, spr);
   g_UltraDataCache.spreadPts = (double)spr;
   g_UltraDataCache.barTime = iTime(s, UltraETF(), 0);
   g_UltraDataCache.tickTime = TimeCurrent();
   g_UltraDataCache.atr = UltraATR(s, IDP_ATR_Period);
   g_UltraDataCache.tickVol = iTickVolume(s, UltraETF(), 0);
   if(g_UltraDataCache.tickVol <= 0)
      g_UltraDataCache.tickVol = iVolume(s, UltraETF(), 0);
   g_UltraDataCache.valid = (g_UltraDataCache.bid > 0 && g_UltraDataCache.ask > 0);
   g_UltraDataCache.integrityOK = UltraData_Integrity(s, g_UltraDataCache);

   int m = UltraData_MSymAlloc(s);
   g_UltraMSymCache[m] = g_UltraDataCache;
   // Soft: allow snapshot on valid prices even if integrity advisory fails
   return g_UltraDataCache.valid;
}

// Smart cache: reuse same-bar snapshot fields when still fresh
bool UltraData_SmartCacheHit(const string s)
{
   if(g_UltraDataCache.symbol != s) return false;
   if(!g_UltraDataCache.valid || !g_UltraDataCache.integrityOK) return false;
   datetime bar = iTime(s, UltraETF(), 0);
   return (bar > 0 && bar == g_UltraDataCache.barTime);
}

double UltraData_Bid(const string s){ return SymbolInfoDouble(s, SYMBOL_BID); }
double UltraData_Ask(const string s){ return SymbolInfoDouble(s, SYMBOL_ASK); }
double UltraData_Spread(const string s){ long v=0; SymbolInfoInteger(s, SYMBOL_SPREAD, v); return (double)v; }
int    UltraData_Digits(const string s){ long v=0; SymbolInfoInteger(s, SYMBOL_DIGITS, v); return (int)v; }
double UltraData_Point(const string s){ return SymbolInfoDouble(s, SYMBOL_POINT); }
long   UltraData_Volume(const string s)
{
   long v = iTickVolume(s, UltraETF(), 0);
   if(v <= 0) v = iVolume(s, UltraETF(), 0);
   return v;
}

double UltraData_Open(const string s, const int shift){ return iOpen(s, UltraETF(), shift); }
double UltraData_High(const string s, const int shift){ return iHigh(s, UltraETF(), shift); }
double UltraData_Low(const string s, const int shift){ return iLow(s, UltraETF(), shift); }
double UltraData_Close(const string s, const int shift){ return iClose(s, UltraETF(), shift); }

bool UltraData_BrokerInfo(string &company, long &login)
{
   company = AccountInfoString(ACCOUNT_COMPANY);
   login = AccountInfoInteger(ACCOUNT_LOGIN);
   return (login != 0);
}

string UltraData_Dashboard()
{
   string t = "DATA: ";
   if(g_UltraDataCache.integrityOK) t += "OK"; else t += "BAD";
   t += " msym=";
   t += IntegerToString(g_UltraMSymCacheN);
   if(UltraData_SmartCacheHit(g_UltraDataCache.symbol)) t += " CACHE";
   return t;
}

#endif // HITMAN_ULTRA_02_DATA_MQH
//===== END 02_Data.mqh =====

//===== BEGIN 11_Volatility.mqh =====
#ifndef HITMAN_ULTRA_11_VOLATILITY_MQH
#define HITMAN_ULTRA_11_VOLATILITY_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 11_VOLATILITY — ATR Expand/Compress · Classification
//+------------------------------------------------------------------+
void UltraEngVolatility(const string s, UltraSnap &u)
{
   ENUM_TIMEFRAMES tf = UltraETF();
   u.vol.atr = UltraATR(s, IDP_ATR_Period);
   if(u.vol.atr <= 0) return;
   double avg = 0.0;
   for(int i = 2; i <= 21; i++) avg += (iHigh(s, tf, i) - iLow(s, tf, i));
   avg /= 20.0;
   double r1 = iHigh(s, tf, 1) - iLow(s, tf, 1);
   u.vol.relative = (avg > 0) ? (r1 / avg) : 1.0;
   u.vol.expansion = (u.vol.relative >= 1.35);
   u.vol.compression = (u.vol.relative <= 0.70);
   if(u.vol.expansion) u.vol.classification = 1;
   else if(u.vol.compression) u.vol.classification = -1;
   else u.vol.classification = 0;
}

#endif // HITMAN_ULTRA_11_VOLATILITY_MQH
//===== END 11_Volatility.mqh =====

//===== BEGIN 03_MarketStructure.mqh =====
#ifndef HITMAN_ULTRA_03_MARKETSTRUCTURE_MQH
#define HITMAN_ULTRA_03_MARKETSTRUCTURE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 03_MARKET_STRUCTURE — HH/HL/LH/LL · Swings · Internal/External
//+------------------------------------------------------------------+
void UltraEngStructure(const string s, UltraSnap &u)
{
   ENUM_TIMEFRAMES tf = UltraETF();
   int iH1, iH2, iL1, iL2;
   if(UltraFindSwings(s, tf, UltraStructLookback, UltraSwingStrength, iH1, iH2, iL1, iL2))
   {
      double h1 = iHigh(s, tf, iH1), h2 = iHigh(s, tf, iH2);
      double l1 = iLow(s, tf, iL1), l2 = iLow(s, tf, iL2);
      u.st.hh = (h1 > h2); u.st.hl = (l1 > l2); u.st.lh = (h1 < h2); u.st.ll = (l1 < l2);
      u.st.swingHigh = h1; u.st.swingLow = l1;
      u.st.swingHighOK = true; u.st.swingLowOK = true;
      u.st.externalBull = (u.st.hh && u.st.hl);
      u.st.externalBear = (u.st.lh && u.st.ll);
   }
   else
   {
      u.st.swingHigh = iHigh(s, tf, iHighest(s, tf, MODE_HIGH, UltraStructLookback, 1));
      u.st.swingLow  = iLow(s, tf, iLowest(s, tf, MODE_LOW, UltraStructLookback, 1));
   }
   // Internal structure (shorter lookback)
   int jH1, jH2, jL1, jL2;
   if(UltraFindSwings(s, tf, MathMax(UltraStructLookback / 2, 16), UltraSwingStrength, jH1, jH2, jL1, jL2))
   {
      bool ihh = iHigh(s, tf, jH1) > iHigh(s, tf, jH2);
      bool ihl = iLow(s, tf, jL1) > iLow(s, tf, jL2);
      bool ilh = iHigh(s, tf, jH1) < iHigh(s, tf, jH2);
      bool ill = iLow(s, tf, jL1) < iLow(s, tf, jL2);
      u.st.internalBull = (ihh && ihl);
      u.st.internalBear = (ilh && ill);
   }
   u.st.continuation = (u.st.externalBull && u.st.internalBull) || (u.st.externalBear && u.st.internalBear);
   u.st.reversal = (u.st.externalBull && u.st.internalBear) || (u.st.externalBear && u.st.internalBull);
   u.st.strength = 40;
   if(u.st.externalBull || u.st.externalBear) u.st.strength += 20;
   if(u.st.internalBull || u.st.internalBear) u.st.strength += 15;
   if(u.st.continuation) u.st.strength += 15;
   if(u.st.reversal) u.st.strength += 10;
   if(u.st.strength > 100) u.st.strength = 100;
   u.st.quality = u.st.strength;
   if(u.st.swingHigh <= u.st.swingLow) u.st.quality = MathMax(u.st.quality - 20, 0);
}

#endif // HITMAN_ULTRA_03_MARKETSTRUCTURE_MQH
//===== END 03_MarketStructure.mqh =====

//===== BEGIN 04_BOS.mqh =====
#ifndef HITMAN_ULTRA_04_BOS_MQH
#define HITMAN_ULTRA_04_BOS_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 04_BOS                                          |
//| Proprietary · Strong/Weak · Confirmed/Failed · Quality/Strength   |
//+------------------------------------------------------------------+
void UltraEngBOS(const string s, UltraSnap &u)
{
   ENUM_TIMEFRAMES tf = UltraETF();
   int iH1, iH2, iL1, iL2;
   double breakHi = u.st.swingHigh;
   double breakLo = u.st.swingLow;
   if(UltraFindSwings(s, tf, UltraStructLookback, UltraSwingStrength, iH1, iH2, iL1, iL2))
   {
      if(iH2 > 0) breakHi = iHigh(s, tf, iH2);
      if(iL2 > 0) breakLo = iLow(s, tf, iL2);
   }

   u.bos.buy = false;
   u.bos.sell = false;
   u.bos.strong = u.bos.weak = false;
   u.bos.confirmed = u.bos.failed = false;

   int lb = MathMax(UltraBOS_ConfirmBars, 5);
   bool brokeHi = false, brokeLo = false;
   bool closedBeyondHi = false, closedBeyondLo = false;
   for(int i = 1; i <= lb; i++)
   {
      double c = iClose(s, tf, i);
      double h = iHigh(s, tf, i);
      double l = iLow(s, tf, i);
      if(breakHi > 0 && h > breakHi) brokeHi = true;
      if(breakLo > 0 && l < breakLo) brokeLo = true;
      if(breakHi > 0 && c > breakHi) { u.bos.buy = true; closedBeyondHi = true; }
      if(breakLo > 0 && c < breakLo) { u.bos.sell = true; closedBeyondLo = true; }
   }

   // Soft structure BOS bias
   if(!u.bos.buy && u.st.hh && u.st.hl && (u.st.externalBull || u.st.internalBull))
      u.bos.buy = true;
   if(!u.bos.sell && u.st.lh && u.st.ll && (u.st.externalBear || u.st.internalBear))
      u.bos.sell = true;

   // Failed BOS: wicked beyond level but closed back inside
   if(brokeHi && !closedBeyondHi && breakHi > 0)
   {
      double c1 = iClose(s, tf, 1);
      if(c1 < breakHi) u.bos.failed = true;
   }
   if(brokeLo && !closedBeyondLo && breakLo > 0)
   {
      double c1 = iClose(s, tf, 1);
      if(c1 > breakLo) u.bos.failed = true;
   }

   u.bos.confirmation = 0;
   if(u.bos.buy || u.bos.sell)
   {
      double body = MathAbs(iClose(s, tf, 1) - iOpen(s, tf, 1));
      double rng = iHigh(s, tf, 1) - iLow(s, tf, 1);
      u.bos.confirmation = (rng > 0 && body / rng >= UltraDispBodyMin * 0.85) ? 80 : 55;
      u.bos.confirmed = (u.bos.confirmation >= 70 && !u.bos.failed);
   }

   u.bos.strength = u.bos.confirmation;
   if((u.bos.buy && u.st.externalBull) || (u.bos.sell && u.st.externalBear)) u.bos.strength += 15;
   if(u.vol.expansion) u.bos.strength += 8;
   if(u.bos.failed) u.bos.strength = MathMax(u.bos.strength - 25, 0);
   if(u.bos.strength > 100) u.bos.strength = 100;

   u.bos.strong = (u.bos.buy || u.bos.sell) && u.bos.strength >= 70 && u.bos.confirmed;
   u.bos.weak   = (u.bos.buy || u.bos.sell) && !u.bos.strong && !u.bos.failed;

   u.bos.quality = u.bos.strength;
   u.bos.reliability = (u.bos.confirmed && u.st.quality >= 50) ? 75 : (u.bos.failed ? 20 : 45);
   u.bos.score = (u.bos.strength + u.bos.quality + u.bos.reliability) / 3;
}

#endif // HITMAN_ULTRA_04_BOS_MQH
//===== END 04_BOS.mqh =====

//===== BEGIN 05_CHoCH.mqh =====
#ifndef HITMAN_ULTRA_05_CHOCH_MQH
#define HITMAN_ULTRA_05_CHOCH_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 05_CHOCH — Proprietary Change Of Character
//+------------------------------------------------------------------+
void UltraEngCHoCH(const string s, UltraSnap &u)
{
   u.choch.buy  = u.bos.buy  && (u.st.ll || u.st.externalBear || u.st.internalBear);
   u.choch.sell = u.bos.sell && (u.st.hh || u.st.externalBull || u.st.internalBull);
   u.choch.internalC = (u.choch.buy || u.choch.sell) && (u.st.internalBull || u.st.internalBear);
   u.choch.externalC = (u.choch.buy || u.choch.sell) && (u.st.externalBull || u.st.externalBear);
   u.choch.majorC = u.choch.externalC && u.bos.score >= 65;
   u.choch.minorC = (u.choch.buy || u.choch.sell) && !u.choch.majorC;
   u.choch.strength = 0;
   if(u.choch.buy || u.choch.sell) u.choch.strength = 50 + (u.choch.majorC ? 30 : 10) + (u.choch.internalC ? 10 : 0);
   if(u.choch.strength > 100) u.choch.strength = 100;
   u.choch.confidence = u.choch.strength;
}

#endif // HITMAN_ULTRA_05_CHOCH_MQH
//===== END 05_CHoCH.mqh =====

//===== BEGIN 06_Liquidity.mqh =====
#ifndef HITMAN_ULTRA_06_LIQUIDITY_MQH
#define HITMAN_ULTRA_06_LIQUIDITY_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 06_LIQUIDITY — Sweeps · Pools · Stop Hunts
//+------------------------------------------------------------------+
void UltraEngLiquidity(const string s, UltraSnap &u)
{
   ENUM_TIMEFRAMES tf = UltraETF();
   if(u.vol.atr <= 0) return;
   double tol = u.vol.atr * UltraEqualTolATR;
   int lb = MathMax(UltraStructLookback / 2, 12);
   double lo = iLow(s, tf, iLowest(s, tf, MODE_LOW, lb, 1));
   double hi = iHigh(s, tf, iHighest(s, tf, MODE_HIGH, lb, 1));
   int nL = 0, nH = 0;
   for(int i = 1; i <= lb; i++)
   {
      if(MathAbs(iLow(s, tf, i) - lo) <= tol) nL++;
      if(MathAbs(iHigh(s, tf, i) - hi) <= tol) nH++;
   }
   u.liq.poolBuy = (nL >= 2);  // equal lows = sell-side pool / buy grab target
   u.liq.poolSell = (nH >= 2);
   u.liq.equalLows = u.liq.poolBuy;
   u.liq.equalHighs = u.liq.poolSell;
   u.liq.sellSideLiq = u.liq.poolBuy || (u.st.swingLow > 0);
   u.liq.buySideLiq  = u.liq.poolSell || (u.st.swingHigh > 0);
   u.liq.poolLow = u.liq.poolBuy ? lo : u.st.swingLow;
   u.liq.poolHigh = u.liq.poolSell ? hi : u.st.swingHigh;
   if(u.liq.poolLow <= 0) u.liq.poolLow = lo;
   if(u.liq.poolHigh <= 0) u.liq.poolHigh = hi;

   double minD = u.vol.atr * UltraSweepDepthATR * 0.85;
   int swlb = MathMax(UltraSweepLookback, 8);
   double bestDepth = 0;
   double wickMin = UltraSweepWickMin * 0.85;
   for(int i = 1; i <= swlb; i++)
   {
      double h = iHigh(s, tf, i), l = iLow(s, tf, i), c = iClose(s, tf, i), o = iOpen(s, tf, i);
      double rng = h - l; if(rng <= 0) continue;
      if(!u.liq.sweepBuy && u.liq.poolLow > 0 && l < u.liq.poolLow - minD && c > u.liq.poolLow)
      {
         double wick = (MathMin(c, u.liq.poolLow) - l) / rng;
         if(wick >= wickMin)
         {
            u.liq.sweepBuy = true; u.liq.grabBuy = true; u.liq.sweepExtBuy = l;
            bestDepth = MathMax(bestDepth, (u.liq.poolLow - l) / u.vol.atr);
            u.liq.confirmedBuy = (c > o);
         }
      }
      if(!u.liq.sweepSell && u.liq.poolHigh > 0 && h > u.liq.poolHigh + minD && c < u.liq.poolHigh)
      {
         double wick = (h - MathMax(c, u.liq.poolHigh)) / rng;
         if(wick >= wickMin)
         {
            u.liq.sweepSell = true; u.liq.grabSell = true; u.liq.sweepExtSell = h;
            bestDepth = MathMax(bestDepth, (h - u.liq.poolHigh) / u.vol.atr);
            u.liq.confirmedSell = (c < o);
         }
      }
      double upper = h - MathMax(c, o);
      double lower = MathMin(c, o) - l;
      if(lower / rng >= 0.40 && c > o) u.liq.stopHuntBuy = true;
      if(upper / rng >= 0.40 && c < o) u.liq.stopHuntSell = true;
   }
   u.liq.depthATR = bestDepth;
   u.liq.speed = (u.liq.sweepBuy || u.liq.sweepSell) ? MathMin(100.0, 40.0 + bestDepth * 40.0) : 0;
   u.liq.strength = u.liq.speed;
   u.liq.quality = 40;
   if(u.liq.confirmedBuy || u.liq.confirmedSell) u.liq.quality += 25;
   if(u.liq.stopHuntBuy || u.liq.stopHuntSell) u.liq.quality += 15;
   if(u.liq.poolBuy || u.liq.poolSell) u.liq.quality += 10;
   if(u.liq.quality > 100) u.liq.quality = 100;
   u.liq.rejectionScore = (int)MathRound(u.liq.quality);
}

#endif // HITMAN_ULTRA_06_LIQUIDITY_MQH
//===== END 06_Liquidity.mqh =====

//===== BEGIN 07_Fibonacci.mqh =====
#ifndef HITMAN_ULTRA_07_FIBONACCI_MQH
#define HITMAN_ULTRA_07_FIBONACCI_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 07_FIBONACCI — Proprietary Fib Intelligence (UFIE)
//+------------------------------------------------------------------+
void UltraEngFib(const string s, UltraSnap &u)
{
   // Proprietary swing selection = structure swings; impulse = external structure move
   u.fib.f100 = u.st.swingHigh; u.fib.f0 = u.st.swingLow;
   double rng = u.fib.f100 - u.fib.f0;
   if(rng <= 0) return;
   u.fib.impulseOK = (u.vol.atr > 0 && rng >= u.vol.atr * 1.2);
   u.fib.f382 = u.fib.f0 + rng * 0.382;
   u.fib.f500 = u.fib.f0 + rng * 0.500;
   u.fib.f618 = u.fib.f0 + rng * 0.618;
   u.fib.f786 = u.fib.f0 + rng * 0.786;
   u.fib.ext127 = u.fib.f100 + rng * (UltraFibExt127 - 1.0);
   u.fib.ext161 = u.fib.f100 + rng * (UltraFibExt161 - 1.0);
   // For bear impulse, extensions below f0
   if(u.st.externalBear)
   {
      u.fib.ext127 = u.fib.f0 - rng * (UltraFibExt127 - 1.0);
      u.fib.ext161 = u.fib.f0 - rng * (UltraFibExt161 - 1.0);
   }
   double px = SymbolInfoDouble(s, SYMBOL_BID);
   u.fib.retracePos = (px - u.fib.f0) / rng;
   u.fib.atBuyZone  = (u.fib.retracePos >= UltraFibBuyLow && u.fib.retracePos <= UltraFibBuyHigh);
   u.fib.atSellZone = (u.fib.retracePos >= UltraFibSellLow && u.fib.retracePos <= UltraFibSellHigh);
   // Zone ranking: 0.618 best, then 0.5, 0.786, 0.382
   u.fib.zoneRank = 0;
   if(MathAbs(u.fib.retracePos - 0.618) < 0.05) u.fib.zoneRank = 100;
   else if(MathAbs(u.fib.retracePos - 0.500) < 0.05) u.fib.zoneRank = 85;
   else if(MathAbs(u.fib.retracePos - 0.786) < 0.05) u.fib.zoneRank = 75;
   else if(MathAbs(u.fib.retracePos - 0.382) < 0.05) u.fib.zoneRank = 65;
   else if(u.fib.atBuyZone || u.fib.atSellZone) u.fib.zoneRank = 55;
   u.fib.confluence = u.fib.zoneRank;
   if(u.fib.impulseOK) u.fib.confluence += 10;
   if((u.fib.atBuyZone && u.liq.sweepBuy) || (u.fib.atSellZone && u.liq.sweepSell)) u.fib.confluence += 15;
   if(u.fib.confluence > 100) u.fib.confluence = 100;
   u.fib.quality = u.fib.confluence;
   u.fib.confidence = u.fib.quality;
}

#endif // HITMAN_ULTRA_07_FIBONACCI_MQH
//===== END 07_Fibonacci.mqh =====

//===== BEGIN 08_Institutional.mqh =====
#ifndef HITMAN_ULTRA_08_INSTITUTIONAL_MQH
#define HITMAN_ULTRA_08_INSTITUTIONAL_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 08_INSTITUTIONAL — OB · Breaker · FVG · Smart Money
//+------------------------------------------------------------------+
void UltraEngInstitutional(const string s, UltraSnap &u)
{
   ENUM_TIMEFRAMES tf = UltraETF();

   // Displacement: any strong body in last 3 closed bars
   for(int i = 1; i <= 3; i++)
   {
      double o = iOpen(s, tf, i), c = iClose(s, tf, i);
      double h = iHigh(s, tf, i), l = iLow(s, tf, i);
      double r = h - l;
      if(r <= 0) continue;
      double br = MathAbs(c - o) / r;
      bool atrOK = (u.vol.atr <= 0) || (r >= u.vol.atr * UltraDispATRMin * 0.85);
      if(br >= UltraDispBodyMin * 0.90 && atrOK)
      {
         if(c > o) u.ict.dispBuy = true;
         if(c < o) u.ict.dispSell = true;
      }
   }

   // FVG + raw imbalance lookback across recent bars
   for(int g = 1; g <= 5; g++)
   {
      double gapB = iLow(s, tf, g) - iHigh(s, tf, g + 2);
      double gapS = iLow(s, tf, g + 2) - iHigh(s, tf, g);
      if(gapB > 0)
      {
         u.ict.imbalanceBuy = true;
         if(u.vol.atr <= 0 || gapB >= u.vol.atr * UltraFVG_MinATR * 0.8)
            u.ict.fvgBuy = true;
      }
      if(gapS > 0)
      {
         u.ict.imbalanceSell = true;
         if(u.vol.atr <= 0 || gapS >= u.vol.atr * UltraFVG_MinATR * 0.8)
            u.ict.fvgSell = true;
      }
   }

   double o2 = iOpen(s, tf, 2), c2 = iClose(s, tf, 2);
   if(u.ict.dispBuy && c2 < o2) u.ict.obBuy = true;
   if(u.ict.dispSell && c2 > o2) u.ict.obSell = true;
   // Soft OB: opposite candle before displacement in last 4 bars
   if(!u.ict.obBuy && u.ict.dispBuy)
   {
      for(int i = 2; i <= 4; i++)
         if(iClose(s, tf, i) < iOpen(s, tf, i)) { u.ict.obBuy = true; break; }
   }
   if(!u.ict.obSell && u.ict.dispSell)
   {
      for(int i = 2; i <= 4; i++)
         if(iClose(s, tf, i) > iOpen(s, tf, i)) { u.ict.obSell = true; break; }
   }

   if(u.bos.buy && u.ict.obSell) u.ict.breakerBuy = true;
   if(u.bos.sell && u.ict.obBuy) u.ict.breakerSell = true;

   double px = SymbolInfoDouble(s, SYMBOL_BID);
   if(u.ict.obBuy && px <= MathMax(o2, c2) && px >= MathMin(o2, c2)) u.ict.mitigationBuy = true;
   if(u.ict.obSell && px <= MathMax(o2, c2) && px >= MathMin(o2, c2)) u.ict.mitigationSell = true;
   if(u.st.swingHigh > u.st.swingLow)
   {
      double mid = (u.st.swingHigh + u.st.swingLow) * 0.5;
      u.ict.inDiscount = (px <= mid); u.ict.inPremium = (px >= mid);
   }
   u.ict.instZoneBuy = (u.ict.obBuy || u.ict.fvgBuy || u.ict.breakerBuy) && (u.ict.inDiscount || u.fib.atBuyZone);
   u.ict.instZoneSell = (u.ict.obSell || u.ict.fvgSell || u.ict.breakerSell) && (u.ict.inPremium || u.fib.atSellZone);
   u.ict.rejectZoneBuy = u.liq.stopHuntBuy && u.ict.inDiscount;
   u.ict.rejectZoneSell = u.liq.stopHuntSell && u.ict.inPremium;
   // Institutional liquidity = pools / equal HL + displacement / OB confluence
   u.ict.institutionalLiqBuy =
      (u.liq.poolBuy || u.liq.equalLows || u.liq.sweepBuy) &&
      (u.ict.obBuy || u.ict.fvgBuy || u.ict.dispBuy || u.ict.imbalanceBuy);
   u.ict.institutionalLiqSell =
      (u.liq.poolSell || u.liq.equalHighs || u.liq.sweepSell) &&
      (u.ict.obSell || u.ict.fvgSell || u.ict.dispSell || u.ict.imbalanceSell);

   u.ict.smConfluence = ((u.ict.obBuy || u.ict.fvgBuy) && (u.liq.sweepBuy || u.ict.dispBuy)) ||
                        ((u.ict.obSell || u.ict.fvgSell) && (u.liq.sweepSell || u.ict.dispSell)) ||
                        u.ict.institutionalLiqBuy || u.ict.institutionalLiqSell;
}

#endif // HITMAN_ULTRA_08_INSTITUTIONAL_MQH
//===== END 08_Institutional.mqh =====

//===== BEGIN 09_Trend.mqh =====
#ifndef HITMAN_ULTRA_09_TREND_MQH
#define HITMAN_ULTRA_09_TREND_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 09_TREND — Adaptive Trend · Strength · Persistence
//+------------------------------------------------------------------+
void UltraEngTrend(const string s, UltraSnap &u)
{
   u.trend.bull = u.st.externalBull || u.st.internalBull;
   u.trend.bear = u.st.externalBear || u.st.internalBear;
   // HTF / Macro / Week / Month
   int iH1, iH2, iL1, iL2;
   if(UltraFindSwings(s, UltraTF_Bias, 40, UltraSwingStrength, iH1, iH2, iL1, iL2))
   {
      bool hh = iHigh(s, UltraTF_Bias, iH1) > iHigh(s, UltraTF_Bias, iH2);
      bool hl = iLow(s, UltraTF_Bias, iL1) > iLow(s, UltraTF_Bias, iL2);
      bool lh = iHigh(s, UltraTF_Bias, iH1) < iHigh(s, UltraTF_Bias, iH2);
      bool ll = iLow(s, UltraTF_Bias, iL1) < iLow(s, UltraTF_Bias, iL2);
      u.trend.htfBull = (hh && hl); u.trend.htfBear = (lh && ll);
   }
   double smaH = UltraSMA(s, UltraTF_Bias, 50);
   double cH = iClose(s, UltraTF_Bias, 1);
   if(smaH > 0){ if(cH > smaH) u.trend.htfBull = true; if(cH < smaH) u.trend.htfBear = true; }
   double smaD = UltraSMA(s, UltraTF_Macro, 20);
   double cD = iClose(s, UltraTF_Macro, 1);
   if(smaD > 0){ u.trend.macroBull = (cD > smaD); u.trend.macroBear = (cD < smaD); }
   double smaW = UltraSMA(s, UltraTF_Week, 10);
   double cW = iClose(s, UltraTF_Week, 1);
   if(smaW > 0){ u.trend.weekBull = (cW > smaW); u.trend.weekBear = (cW < smaW); }
   double smaM = UltraSMA(s, UltraTF_Month, 6);
   double cM = iClose(s, UltraTF_Month, 1);
   if(smaM > 0){ u.trend.monthBull = (cM > smaM); u.trend.monthBear = (cM < smaM); }

   u.trend.mtfVotesBuy = 0; u.trend.mtfVotesSell = 0;
   if(u.trend.bull) u.trend.mtfVotesBuy++; if(u.trend.bear) u.trend.mtfVotesSell++;
   if(u.trend.htfBull) u.trend.mtfVotesBuy++; if(u.trend.htfBear) u.trend.mtfVotesSell++;
   if(u.trend.macroBull) u.trend.mtfVotesBuy++; if(u.trend.macroBear) u.trend.mtfVotesSell++;
   if(u.trend.weekBull) u.trend.mtfVotesBuy++; if(u.trend.weekBear) u.trend.mtfVotesSell++;
   if(u.trend.monthBull) u.trend.mtfVotesBuy++; if(u.trend.monthBear) u.trend.mtfVotesSell++;
   if(UltraUseMTFVoting)
   {
      ENUM_TIMEFRAMES tfs[3]; int n = 0;
      if(UltraUseM30) tfs[n++] = PERIOD_M30;
      if(UltraUseM15) tfs[n++] = PERIOD_M15;
      if(UltraUseM5)  tfs[n++] = PERIOD_M5;
      if(UltraUseM1Optional) { /* optional skipped into compact array */ }
      for(int i = 0; i < n; i++)
      {
         double sma = UltraSMA(s, tfs[i], 20);
         double c = iClose(s, tfs[i], 1);
         if(sma <= 0) continue;
         if(c > sma) u.trend.mtfVotesBuy++; else if(c < sma) u.trend.mtfVotesSell++;
      }
   }
   u.trend.strength = 30 + u.trend.mtfVotesBuy * 8 + u.trend.mtfVotesSell * 0;
   if(u.trend.bear) u.trend.strength = 30 + u.trend.mtfVotesSell * 8;
   if(u.trend.bull && u.trend.bear) u.trend.strength = 40;
   if(u.trend.strength > 100) u.trend.strength = 100;
   u.trend.quality = u.trend.strength;
   u.trend.persistence = MathMin(100, 20 + MathAbs(u.trend.mtfVotesBuy - u.trend.mtfVotesSell) * 12);
   u.trend.continuation = u.st.continuation ||
                          ((u.trend.bull && u.trend.htfBull) || (u.trend.bear && u.trend.htfBear));
   u.trend.exhaustion = false; // filled after momentum in UltraEngRegime
}

#endif // HITMAN_ULTRA_09_TREND_MQH
//===== END 09_Trend.mqh =====

//===== BEGIN 10_Momentum.mqh =====
#ifndef HITMAN_ULTRA_10_MOMENTUM_MQH
#define HITMAN_ULTRA_10_MOMENTUM_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 10_MOMENTUM — SMI · Strength · Acceleration · Quality
//+------------------------------------------------------------------+
void UltraEngMomentum(const string s, UltraSnap &u)
{
   ENUM_TIMEFRAMES tf = UltraETF();
   int up = 0, dn = 0;
   double bodySum = 0, prevBody = 0;
   for(int i = 1; i <= MathMax(UltraMomentumBars, 3); i++)
   {
      double o = iOpen(s, tf, i), c = iClose(s, tf, i);
      double b = MathAbs(c - o);
      if(c > o) up++; if(c < o) dn++;
      if(i == 1) prevBody = b; else bodySum += b;
   }
   u.mom.momBuy = (up >= 2); u.mom.momSell = (dn >= 2);
   u.mom.direction = (up > dn) ? 1 : (dn > up ? -1 : 0);
   u.mom.strength = MathMin(100, (int)MathRound(100.0 * MathMax(up, dn) / MathMax(UltraMomentumBars, 3)));
   double avgPrev = bodySum / MathMax(UltraMomentumBars - 1, 1);
   u.mom.acceleration = (avgPrev > 0 && prevBody > avgPrev * 1.25) ? 80 : ((avgPrev > 0 && prevBody < avgPrev * 0.75) ? 30 : 55);
   u.mom.quality = (u.mom.strength + u.mom.acceleration) / 2;
   u.mom.confirmation = (u.mom.momBuy && u.ict.dispBuy) || (u.mom.momSell && u.ict.dispSell) ? 80 : 45;
   u.mom.weakness = (u.mom.acceleration <= 35 || u.mom.strength <= 40);
   u.mom.impulse  = (u.mom.acceleration >= 70 && u.mom.strength >= 60) ||
                    ((u.mom.momBuy && u.ict.dispBuy) || (u.mom.momSell && u.ict.dispSell));
}
void UltraEngIndicators(const string s, UltraSnap &u)
{
   // SMI: direction * momentum * acceleration scaled -100..100
   double dir = (double)u.mom.direction;
   double smi = dir * (0.45 * u.mom.strength + 0.35 * u.mom.acceleration + 0.20 * u.mom.confirmation);
   if(smi > 100) smi = 100; if(smi < -100) smi = -100;
   u.ind.smi = smi;

   // MEO: market energy / participation / trend energy 0..100
   double energy = 0.35 * (u.vol.relative * 40.0) + 0.35 * u.trend.strength + 0.30 * u.liq.quality;
   if(energy < 0) energy = 0; if(energy > 100) energy = 100;
   u.ind.meo = energy;

   // IFI: institutional footprint from sweep+disp+OB/FVG+vol expand
   double ifi = 0;
   if(u.liq.sweepBuy || u.ict.dispBuy || u.ict.obBuy || u.ict.fvgBuy) ifi += 25;
   if(u.liq.sweepSell || u.ict.dispSell || u.ict.obSell || u.ict.fvgSell) ifi -= 25;
   if(u.ict.smConfluence) ifi += (u.ict.dispBuy ? 20 : -20);
   if(u.vol.expansion) ifi += (ifi >= 0 ? 15 : -15);
   if(ifi > 100) ifi = 100; if(ifi < -100) ifi = -100;
   u.ind.ifi = ifi;
}

#endif // HITMAN_ULTRA_10_MOMENTUM_MQH
//===== END 10_Momentum.mqh =====

//===== BEGIN 12_MarketRegime.mqh =====
#ifndef HITMAN_ULTRA_12_MARKETREGIME_MQH
#define HITMAN_ULTRA_12_MARKETREGIME_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 12_MARKET_REGIME                                |
//| Strong/Weak Trend · Range · Breakout · Reversal · Acc/Dist        |
//+------------------------------------------------------------------+
void UltraEngRegime(UltraSnap &u)
{
   u.trend.exhaustion = (u.mom.acceleration <= 30 && u.vol.expansion && u.trend.strength >= 55);

   if(u.vol.compression && !(u.trend.bull || u.trend.bear)) u.regime = UREG_COMPRESSION;
   else if(u.vol.expansion && (u.bos.buy || u.bos.sell) && u.bos.strong)
      u.regime = UREG_BREAKOUT;
   else if(u.vol.expansion && (u.choch.buy || u.choch.sell)) u.regime = UREG_REVERSAL;
   else if(u.vol.expansion && u.trend.strength >= 70) u.regime = UREG_EXPANSION;
   else if(u.trend.exhaustion) u.regime = UREG_EXHAUSTION;
   else if(u.trend.strength >= 75 && u.trend.continuation) u.regime = UREG_STRONG_TREND;
   else if(u.trend.strength >= 55 && u.trend.continuation) u.regime = UREG_HEALTHY_TREND;
   else if(u.trend.strength >= 40 && (u.trend.bull || u.trend.bear)) u.regime = UREG_WEAK_TREND;
   else if(u.liq.sweepBuy && u.ict.inDiscount && !u.trend.htfBear) u.regime = UREG_ACCUMULATION;
   else if(u.liq.sweepSell && u.ict.inPremium && !u.trend.htfBull) u.regime = UREG_DISTRIBUTION;
   else if(u.mom.acceleration <= 30 && u.vol.expansion) u.regime = UREG_EXHAUSTION;
   else u.regime = UREG_RANGE;
}
string UltraRegimeName(const ENUM_ULTRA_REGIME r)
{
   switch(r)
   {
      case UREG_STRONG_TREND: return "STRONG_TREND";
      case UREG_WEAK_TREND: return "WEAK_TREND";
      case UREG_HEALTHY_TREND: return "HEALTHY_TREND";
      case UREG_RANGE: return "RANGE";
      case UREG_COMPRESSION: return "COMPRESSION";
      case UREG_EXPANSION: return "EXPANSION";
      case UREG_BREAKOUT: return "BREAKOUT";
      case UREG_REVERSAL: return "REVERSAL";
      case UREG_ACCUMULATION: return "ACCUMULATION";
      case UREG_DISTRIBUTION: return "DISTRIBUTION";
      case UREG_EXHAUSTION: return "EXHAUSTION";
   }
   return "RANGE";
}

#endif // HITMAN_ULTRA_12_MARKETREGIME_MQH
//===== END 12_MarketRegime.mqh =====

//===== BEGIN MarketCycle.mqh =====
#ifndef HITMAN_ULTRA_MARKET_CYCLE_MQH
#define HITMAN_ULTRA_MARKET_CYCLE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — MARKET CYCLE ENGINE                                  |
//| Accumulation · Markup · Distribution · Markdown                  |
//+------------------------------------------------------------------+

enum ENUM_MARKET_CYCLE
{
   CYCLE_ACCUMULATION = 0,
   CYCLE_MARKUP,
   CYCLE_DISTRIBUTION,
   CYCLE_MARKDOWN,
   CYCLE_UNKNOWN
};

string UltraCycle_Name(const ENUM_MARKET_CYCLE c)
{
   if(c == CYCLE_ACCUMULATION) return "ACCUMULATION";
   if(c == CYCLE_MARKUP) return "MARKUP";
   if(c == CYCLE_DISTRIBUTION) return "DISTRIBUTION";
   if(c == CYCLE_MARKDOWN) return "MARKDOWN";
   return "UNKNOWN";
}

void UltraEngCycle(UltraSnap &u)
{
   ENUM_MARKET_CYCLE c = CYCLE_UNKNOWN;
   bool bullExt = u.st.externalBull;
   bool bearExt = u.st.externalBear;
   bool rangeLike = (u.regime == UREG_RANGE || u.regime == UREG_COMPRESSION || u.regime == UREG_ACCUMULATION);
   bool expand = (u.vol.expansion || u.regime == UREG_EXPANSION || u.regime == UREG_BREAKOUT);
   bool exhaust = u.trend.exhaustion || (u.regime == UREG_EXHAUSTION);

   if(bullExt && expand && !exhaust)
      c = CYCLE_MARKUP;
   else if(bearExt && expand && !exhaust)
      c = CYCLE_MARKDOWN;
   else if(bullExt && (exhaust || u.regime == UREG_DISTRIBUTION || u.ict.inPremium))
      c = CYCLE_DISTRIBUTION;
   else if(bearExt && (exhaust || u.regime == UREG_ACCUMULATION || u.ict.inDiscount))
      c = CYCLE_ACCUMULATION;
   else if(rangeLike && (u.liq.poolBuy || u.liq.equalLows || u.ict.inDiscount))
      c = CYCLE_ACCUMULATION;
   else if(rangeLike && (u.liq.poolSell || u.liq.equalHighs || u.ict.inPremium))
      c = CYCLE_DISTRIBUTION;
   else if(u.st.continuation && bullExt)
      c = CYCLE_MARKUP;
   else if(u.st.continuation && bearExt)
      c = CYCLE_MARKDOWN;

   u.st.cycle = (int)c;
   u.st.cycleName = UltraCycle_Name(c);
}

bool UltraCycle_SupportsBuy(const UltraSnap &u)
{
   return (u.st.cycle == (int)CYCLE_ACCUMULATION || u.st.cycle == (int)CYCLE_MARKUP ||
           u.st.cycle == (int)CYCLE_UNKNOWN);
}

bool UltraCycle_SupportsSell(const UltraSnap &u)
{
   return (u.st.cycle == (int)CYCLE_DISTRIBUTION || u.st.cycle == (int)CYCLE_MARKDOWN ||
           u.st.cycle == (int)CYCLE_UNKNOWN);
}

#endif
//===== END MarketCycle.mqh =====

//===== BEGIN 18_NewsIntelligence.mqh =====
#ifndef HITMAN_ULTRA_18_NEWSINTELLIGENCE_MQH
#define HITMAN_ULTRA_18_NEWSINTELLIGENCE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 18_NEWS_INTELLIGENCE                            |
//| Economic Calendar proxy · News Analysis · Volatility Analysis     |
//| Context Only · Trades Before / During / After News                |
//| NEVER hard-blocks                                                 |
//+------------------------------------------------------------------+

void UltraEngNews(const string s, UltraSnap &u)
{
   u.ctx.beforeNews = false;
   u.ctx.duringNews = false;
   u.ctx.afterNews  = false;
   u.ctx.newsPhase  = "NONE";
   if(!UltraNewsIntelEnabled) return;

   // Volatility / spread proxy for calendar impact (no external calendar required)
   u.ctx.newsVol = u.vol.expansion && u.vol.relative >= 1.45;
   u.ctx.highImpactProxy = (u.vol.relative >= 1.80);
   u.ctx.midImpactProxy  = (u.vol.relative >= 1.45 && u.vol.relative < 1.80);
   u.ctx.lowImpactProxy  = (u.vol.relative >= 1.20 && u.vol.relative < 1.45);
   u.ctx.spreadPts = UltraData_Spread(s);
   u.ctx.slipProxy = MathMax(0.0, u.ctx.spreadPts * 0.15);

   // Phase classification from relative vol + expansion state
   if(u.ctx.highImpactProxy && u.vol.expansion)
   {
      u.ctx.duringNews = true;
      u.ctx.newsPhase  = "DURING";
   }
   else if(u.ctx.midImpactProxy && !u.vol.compression)
   {
      u.ctx.beforeNews = true;
      u.ctx.newsPhase  = "BEFORE";
   }
   else if(u.vol.compression && u.vol.relative >= 1.10)
   {
      u.ctx.afterNews = true;
      u.ctx.newsPhase = "AFTER";
   }

   // Context only — trading continues before / during / after
}

#endif // HITMAN_ULTRA_18_NEWSINTELLIGENCE_MQH
//===== END 18_NewsIntelligence.mqh =====

//===== BEGIN 17_SessionIntelligence.mqh =====
#ifndef HITMAN_ULTRA_17_SESSIONINTELLIGENCE_MQH
#define HITMAN_ULTRA_17_SESSIONINTELLIGENCE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 17_SESSION_INTELLIGENCE                         |
//| Asian · London · New York · Overlap · Session Liquidity           |
//| Context Only · Trades 24/5 · NEVER blocks                         |
//+------------------------------------------------------------------+

void UltraEngSession(const string s, UltraSnap &u)
{
   u.ctx.session = "OFF";
   u.ctx.asia = u.ctx.london = u.ctx.newyork = u.ctx.overlap = false;
   u.ctx.killZone = false;
   u.ctx.sessionLiquidity = false;
   u.ctx.sessionConfidence = 0;
   u.ctx.sessionQuality = 0;
   if(!UltraSessionIntelEnabled) return;

   MqlDateTime t; TimeToStruct(TimeGMT(), t);
   int h = t.hour;
   u.ctx.asia    = (h >= 0 && h < 7);
   u.ctx.london  = (h >= 7 && h < 16);
   u.ctx.newyork = (h >= 12 && h < 21);
   u.ctx.overlap = (u.ctx.london && u.ctx.newyork);
   u.ctx.killZone = (u.ctx.london || u.ctx.newyork);
   u.ctx.sessionLiquidity = (u.ctx.overlap || u.ctx.killZone);

   if(u.ctx.overlap)        u.ctx.session = "LONDON/NY";
   else if(u.ctx.london)    u.ctx.session = "LONDON";
   else if(u.ctx.newyork)   u.ctx.session = "NEW YORK";
   else if(u.ctx.asia)      u.ctx.session = "ASIA";
   else                     u.ctx.session = "OTHER";

   u.ctx.sessionConfidence = u.ctx.overlap ? 90 : (u.ctx.killZone ? 75 : (u.ctx.asia ? 55 : 45));
   u.ctx.sessionQuality = u.ctx.sessionConfidence;
   // UltraTrade24x5 / context — never rejects trades
}

void UltraEngSessionNews(const string s, UltraSnap &u)
{
   UltraEngSession(s, u);
   UltraEngNews(s, u);
}

#endif // HITMAN_ULTRA_17_SESSIONINTELLIGENCE_MQH
//===== END 17_SessionIntelligence.mqh =====

//===== BEGIN 13_Precision.mqh =====
#ifndef HITMAN_ULTRA_13_PRECISION_MQH
#define HITMAN_ULTRA_13_PRECISION_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 13_PRECISION                                    |
//| Entry Precision · Exit Precision · Signal Validation ·            |
//| Trade Quality · Precision Score                                   |
//+------------------------------------------------------------------+

int UltraEntryPrecision(const UltraSnap &u)
{
   int e = 40;
   if(u.bos.confirmation >= 60) e += 12;
   if(u.liq.confirmedBuy || u.liq.confirmedSell) e += 12;
   if(u.fib.atBuyZone || u.fib.atSellZone) e += 10;
   if(u.ict.dispBuy || u.ict.dispSell) e += 10;
   if(u.ict.smConfluence) e += 8;
   if(u.mom.confirmation >= 50) e += 8;
   if(e > 100) e = 100;
   return e;
}

int UltraExitPrecision(const UltraSnap &u)
{
   int x = 45;
   if(u.vol.expansion) x += 10;
   if(u.fib.ext127 > 0.0 || u.fib.ext161 > 0.0) x += 10;
   if(u.trend.quality >= 60) x += 10;
   if(u.regime == UREG_STRONG_TREND || u.regime == UREG_EXPANSION) x += 10;
   if(u.regime == UREG_RANGE || u.regime == UREG_COMPRESSION) x -= 8;
   if(x < 0) x = 0; if(x > 100) x = 100;
   return x;
}

bool UltraSignalValidation(const UltraSnap &u, const bool buySide)
{
   if(buySide)
      return (u.bos.buy || u.choch.buy || u.liq.sweepBuy || u.fib.atBuyZone || u.ict.instZoneBuy);
   return (u.bos.sell || u.choch.sell || u.liq.sweepSell || u.fib.atSellZone || u.ict.instZoneSell);
}

int UltraTradeQuality(const UltraSnap &u)
{
   int q = (u.st.quality + u.bos.quality + u.fib.quality + u.trend.quality) / 4;
   if(u.ict.smConfluence) q += 8;
   if(u.liq.rejectionScore >= 60) q += 6;
   if(q > 100) q = 100;
   return q;
}

int UltraPrecisionScore(const UltraSnap &u)
{
   int entry = UltraEntryPrecision(u);
   int exitp = UltraExitPrecision(u);
   int tq    = UltraTradeQuality(u);
   int prec  = (entry + exitp + tq + u.bos.reliability + u.liq.rejectionScore) / 5;
   if(u.regime == UREG_RANGE || u.regime == UREG_COMPRESSION) prec -= 8;
   if(u.ict.smConfluence) prec += 6;
   if(prec < 0) prec = 0; if(prec > 100) prec = 100;
   return prec;
}

#endif // HITMAN_ULTRA_13_PRECISION_MQH
//===== END 13_Precision.mqh =====

//===== BEGIN 14_Probability.mqh =====
#ifndef HITMAN_ULTRA_14_PROBABILITY_MQH
#define HITMAN_ULTRA_14_PROBABILITY_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 14_PROBABILITY                                  |
//| Probability Score · Confidence Score · Success Estimation         |
//+------------------------------------------------------------------+

int UltraConfidenceScore(const UltraSnap &u, const int confluence)
{
   int c = confluence;
   if(u.trend.mtfVotesBuy >= 3 || u.trend.mtfVotesSell >= 3) c += 4;
   if(u.ctx.sessionLiquidity) c += 2;
   if(c < 0) c = 0; if(c > 100) c = 100;
   return c;
}

int UltraSuccessEstimation(const UltraSnap &u, const int confidence, const int precision)
{
   int base = (confidence + precision) / 2;
   int smiBoost = (int)MathRound(MathAbs(u.ind.smi) * 0.25);
   int memBoost = 0;
   if(g_UltraMem.trades >= 10 && g_UltraMem.winRate >= 55.0) memBoost = 4;
   int succ = base + smiBoost + memBoost;
   if(u.regime == UREG_EXHAUSTION || u.regime == UREG_REVERSAL) succ -= 4;
   if(succ < 0) succ = 0; if(succ > 100) succ = 100;
   return succ;
}

int UltraProbabilityScore(const UltraSnap &u, const int confidence, const int precision)
{
   return UltraSuccessEstimation(u, UltraConfidenceScore(u, confidence), precision);
}

int UltraRiskProbability(const int successProb)
{
   int r = 100 - successProb;
   if(r < 0) r = 0; if(r > 100) r = 100;
   return r;
}

#endif // HITMAN_ULTRA_14_PROBABILITY_MQH
//===== END 14_Probability.mqh =====

//===== BEGIN 15_Confluence.mqh =====
#ifndef HITMAN_ULTRA_15_CONFLUENCE_MQH
#define HITMAN_ULTRA_15_CONFLUENCE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 15_CONFLUENCE — Combines all engines → AI Confidence
//+------------------------------------------------------------------+
int UltraConfluenceBuy(const UltraSnap &u)
{
   // Base so live charts are never stuck at conf=0 when structure exists
   int sc = 18;
   if(u.st.quality >= 40) sc += 6;
   if(u.st.continuation || u.st.externalBull || u.st.internalBull) sc += 6;

   if(u.trend.htfBull) sc += 10; if(u.trend.macroBull) sc += 6; if(u.trend.bull) sc += 8;
   if(u.bos.buy) sc += 10; if(u.choch.buy) sc += 8;
   if(u.liq.sweepBuy) sc += 14; if(u.liq.stopHuntBuy) sc += 5;
   if(u.ict.dispBuy) sc += 10; if(u.ict.fvgBuy) sc += 6; if(u.ict.obBuy) sc += 6;
   if(u.ict.breakerBuy) sc += 4; if(u.ict.instZoneBuy) sc += 6;
   if(u.fib.atBuyZone) sc += 8; if(u.ict.inDiscount) sc += 5;
   if(u.mom.momBuy) sc += 4; if(u.ind.smi > 20) sc += 4; if(u.ind.ifi > 15) sc += 4;
   if(u.ind.meo >= 55) sc += 3;
   if(u.vol.expansion) sc += 3;
   if(UltraBoostKillZone && u.ctx.killZone) sc += 3;
   if(UltraBoostNewsVol && u.ctx.newsVol && u.ict.dispBuy) sc += 4;
   if(UltraSoftPreferFib && !u.fib.atBuyZone && !u.ict.inDiscount) sc -= 2;
   if(u.trend.mtfVotesBuy >= 3) sc += 5;
   if(sc < 0) sc = 0; if(sc > 100) sc = 100;
   return sc;
}
int UltraConfluenceSell(const UltraSnap &u)
{
   int sc = 18;
   if(u.st.quality >= 40) sc += 6;
   if(u.st.continuation || u.st.externalBear || u.st.internalBear) sc += 6;

   if(u.trend.htfBear) sc += 10; if(u.trend.macroBear) sc += 6; if(u.trend.bear) sc += 8;
   if(u.bos.sell) sc += 10; if(u.choch.sell) sc += 8;
   if(u.liq.sweepSell) sc += 14; if(u.liq.stopHuntSell) sc += 5;
   if(u.ict.dispSell) sc += 10; if(u.ict.fvgSell) sc += 6; if(u.ict.obSell) sc += 6;
   if(u.ict.breakerSell) sc += 4; if(u.ict.instZoneSell) sc += 6;
   if(u.fib.atSellZone) sc += 8; if(u.ict.inPremium) sc += 5;
   if(u.mom.momSell) sc += 4; if(u.ind.smi < -20) sc += 4; if(u.ind.ifi < -15) sc += 4;
   if(u.ind.meo >= 55) sc += 3;
   if(u.vol.expansion) sc += 3;
   if(UltraBoostKillZone && u.ctx.killZone) sc += 3;
   if(UltraBoostNewsVol && u.ctx.newsVol && u.ict.dispSell) sc += 4;
   if(UltraSoftPreferFib && !u.fib.atSellZone && !u.ict.inPremium) sc -= 2;
   if(u.trend.mtfVotesSell >= 3) sc += 5;
   if(sc < 0) sc = 0; if(sc > 100) sc = 100;
   return sc;
}

#endif // HITMAN_ULTRA_15_CONFLUENCE_MQH
//===== END 15_Confluence.mqh =====

//===== BEGIN 26_Diagnostics.mqh =====
#ifndef HITMAN_ULTRA_26_DIAGNOSTICS_MQH
#define HITMAN_ULTRA_26_DIAGNOSTICS_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 26_DIAGNOSTICS — Tick · Memory · Connection · Health
//+------------------------------------------------------------------+
void UltraEngDiagnostics(const string s, UltraSnap &u)
{
   u.diag.tickOK = (SymbolInfoDouble(s, SYMBOL_BID) > 0);
   u.diag.brokerOK = (AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) != 0);
   u.diag.connectionOK = (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
   u.diag.indicatorOK = (u.vol.atr > 0);
   u.diag.memoryOK = true;
   if(UltraMemoryEngineEnabled && g_UltraMem.trades > 100000) u.diag.memoryOK = false;
   u.diag.processSpeedMs = g_UltraCore.lastLatencyMs;
   bool ok = u.diag.tickOK && u.diag.brokerOK && u.diag.connectionOK && u.diag.indicatorOK && u.diag.memoryOK;
   if(ok) u.diag.health = "OK"; else u.diag.health = "DEGRADED";
   g_UltraCore.healthy = ok;
}

#endif // HITMAN_ULTRA_26_DIAGNOSTICS_MQH
//===== END 26_Diagnostics.mqh =====

//===== BEGIN 29_MarketMemory.mqh =====
#ifndef HITMAN_ULTRA_29_MARKETMEMORY_MQH
#define HITMAN_ULTRA_29_MARKETMEMORY_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 29_MARKET_MEMORY — L2 stores theses · patterns · behaviour
//+------------------------------------------------------------------+

struct UltraMemPattern
{
   string tag;
   int    wins;
   int    losses;
   int    lastConf;
   long   lastTs;
};

#define ULTRA_MEM_PAT_MAX 24
UltraMemPattern g_UltraMemPat[ULTRA_MEM_PAT_MAX];
int g_UltraMemPatN = 0;

int UltraMemory_FindPat(const string tag)
{
   for(int i = 0; i < g_UltraMemPatN; i++)
      if(g_UltraMemPat[i].tag == tag) return i;
   return -1;
}

void UltraMemory_NotePattern(const string tag, const int conf, const bool won)
{
   if(!UltraMarketMemoryEnabled) return;
   if(tag == "" || tag == "NONE") return;
   int idx = UltraMemory_FindPat(tag);
   if(idx < 0)
   {
      if(g_UltraMemPatN >= ULTRA_MEM_PAT_MAX) return;
      idx = g_UltraMemPatN++;
      g_UltraMemPat[idx].tag = tag;
      g_UltraMemPat[idx].wins = 0;
      g_UltraMemPat[idx].losses = 0;
   }
   if(won) g_UltraMemPat[idx].wins++;
   else g_UltraMemPat[idx].losses++;
   g_UltraMemPat[idx].lastConf = conf;
   g_UltraMemPat[idx].lastTs = (long)TimeCurrent();
}

void UltraMemoryUpdateFromStats()
{
   if(!UltraMarketMemoryEnabled || !UltraPerfEngineEnabled) return;
   // Soft sync from existing EA stats if available (bodies in Shell_B)
   g_UltraMem.winRate = GetWinRatePercent();
   g_UltraMem.profitFactor = GetProfitFactor();
   g_UltraMem.avgRR = GetAverageRR();
   g_UltraMem.lastSave = (long)TimeCurrent();
}

void UltraMemory_NoteDecision(const string tag, const int conf)
{
   if(!UltraMarketMemoryEnabled) return;
   UltraLogAI("memory note tag=" + tag + " conf=" + IntegerToString(conf));
   int idx = UltraMemory_FindPat(tag);
   if(idx < 0)
   {
      if(g_UltraMemPatN >= ULTRA_MEM_PAT_MAX) return;
      idx = g_UltraMemPatN++;
      g_UltraMemPat[idx].tag = tag;
      g_UltraMemPat[idx].wins = 0;
      g_UltraMemPat[idx].losses = 0;
   }
   g_UltraMemPat[idx].lastConf = conf;
   g_UltraMemPat[idx].lastTs = (long)TimeCurrent();
}

string UltraMemory_Dashboard()
{
   string t = "MEMORY: patterns=";
   t += IntegerToString(g_UltraMemPatN);
   t += " WR=";
   t += DoubleToString(g_UltraMem.winRate, 1);
   return t;
}

#endif // HITMAN_ULTRA_29_MARKETMEMORY_MQH
//===== END 29_MarketMemory.mqh =====

//===== BEGIN 39_EventEngine.mqh =====
#ifndef HITMAN_ULTRA_39_EVENTS_MQH
#define HITMAN_ULTRA_39_EVENTS_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 39_EVENT ENGINE — event-driven market + lifecycle    |
//+------------------------------------------------------------------+

enum ENUM_ULTRA_EVENT
{
   UEV_INIT = 0,
   UEV_TICK,
   UEV_TIMER,
   UEV_TRADE_TX,
   UEV_CHART,
   UEV_DEINIT,
   UEV_BOS,
   UEV_CHOCH,
   UEV_SWEEP,
   UEV_FIRE,
   UEV_WAIT
};

struct UltraEventStats
{
   ulong initCount;
   ulong tickCount;
   ulong timerCount;
   ulong tradeTxCount;
   ulong chartCount;
   ulong deinitCount;
   ulong bosCount;
   ulong chochCount;
   ulong sweepCount;
   ulong fireCount;
   ulong waitCount;
   datetime lastMarketEvent;
   string lastMarketTag;
};

UltraEventStats g_UltraEventStats;

void UltraEvent_Note(const ENUM_ULTRA_EVENT e)
{
   switch(e)
   {
      case UEV_INIT:     g_UltraEventStats.initCount++; break;
      case UEV_TICK:     g_UltraEventStats.tickCount++; break;
      case UEV_TIMER:    g_UltraEventStats.timerCount++; break;
      case UEV_TRADE_TX: g_UltraEventStats.tradeTxCount++; break;
      case UEV_CHART:    g_UltraEventStats.chartCount++; break;
      case UEV_DEINIT:   g_UltraEventStats.deinitCount++; break;
      case UEV_BOS:      g_UltraEventStats.bosCount++; break;
      case UEV_CHOCH:    g_UltraEventStats.chochCount++; break;
      case UEV_SWEEP:    g_UltraEventStats.sweepCount++; break;
      case UEV_FIRE:     g_UltraEventStats.fireCount++; break;
      case UEV_WAIT:     g_UltraEventStats.waitCount++; break;
   }
}

void UltraEvent_NoteMarket(const UltraSnap &u)
{
   bool edged = false;
   if(u.bos.buy || u.bos.sell)
   {
      UltraEvent_Note(UEV_BOS);
      g_UltraEventStats.lastMarketTag = "BOS";
      edged = true;
   }
   if(u.choch.buy || u.choch.sell)
   {
      UltraEvent_Note(UEV_CHOCH);
      g_UltraEventStats.lastMarketTag = "CHoCH";
      edged = true;
   }
   if(u.liq.sweepBuy || u.liq.sweepSell || u.liq.stopHuntBuy || u.liq.stopHuntSell)
   {
      UltraEvent_Note(UEV_SWEEP);
      g_UltraEventStats.lastMarketTag = "SWEEP";
      edged = true;
   }
   if(edged)
      g_UltraEventStats.lastMarketEvent = TimeCurrent();
}

void UltraEvent_OnBoot()
{
   UltraEvent_Note(UEV_INIT);
   UltraLog("EVENT boot — HITMAN AI event engine ready");
}

string UltraEvent_Summary()
{
   string t = "ticks=";
   t += IntegerToString((int)g_UltraEventStats.tickCount);
   t += " bos=";
   t += IntegerToString((int)g_UltraEventStats.bosCount);
   t += " choch=";
   t += IntegerToString((int)g_UltraEventStats.chochCount);
   t += " sweep=";
   t += IntegerToString((int)g_UltraEventStats.sweepCount);
   t += " fire=";
   t += IntegerToString((int)g_UltraEventStats.fireCount);
   return t;
}

string UltraEvent_Dashboard()
{
   string t = "EVENT: ";
   t += UltraEvent_Summary();
   if(StringLen(g_UltraEventStats.lastMarketTag) > 0)
   {
      t += " last=";
      t += g_UltraEventStats.lastMarketTag;
   }
   return t;
}

#endif
//===== END 39_EventEngine.mqh =====

//===== BEGIN 20_CapitalProtection.mqh =====
#ifndef HITMAN_ULTRA_20_CAPITALPROTECTION_MQH
#define HITMAN_ULTRA_20_CAPITALPROTECTION_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 20_CAPITAL_PROTECTION — Equity · Margin · Exposure · Sizing
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| 05. Capital Protection Engine                                    |
//| Equity · Margin · Exposure · Sizing bridge · Profit protection   |
//+------------------------------------------------------------------+
bool UltraCapitalOK(string &why)
{
   why = "";
   if(!UltraCapitalProtectEnabled) return true;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double fm = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(eq <= 0){ why = "bad equity"; return false; }
   if(fm / eq < 0.08){ why = "free margin < 8%"; return false; }
   if(EnforceOpenTradeCaps && MaxOpenTrades > 0 && CountOpenTrades() >= MaxOpenTrades)
   { why = "max open trades"; return false; }
   return true;
}


// Deep capital rules also live in Shell_B (RiskManagementOK / Drawdown / lots).

#endif // HITMAN_ULTRA_20_CAPITALPROTECTION_MQH
//===== END 20_CapitalProtection.mqh =====

//===== BEGIN 19_Execution.mqh =====
#ifndef HITMAN_ULTRA_19_EXECUTION_MQH
#define HITMAN_ULTRA_19_EXECUTION_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 19_EXECUTION — Fast exec · Retry · Fill · Sync · Broker compat
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| 04. Ultra Execution Engine                                       |
//| Fast exec · fill policy · retry · duplicate protect · sync       |
//| Bridges InstantExecution / ExecuteBuy / ExecuteSell (Shell_B)    |
//+------------------------------------------------------------------+

bool UltraExecReady(const string s, string &why)
{
   why = "";
   long tm = 0;
   if(!SymbolInfoInteger(s, SYMBOL_TRADE_MODE, tm) || tm == 0) { why = "symbol trade mode off"; return false; }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)) { why = "terminal blocked"; return false; }
   // fill policy / stops validated later in ExecuteBuy/Sell
   return true;
}



bool UltraExec_DuplicateBarGuard(const string s)
{
   datetime bar = iTime(s, UltraETF(), 0);
   if(bar <= 0) return false;
   if(g_UltraLastFireBar == bar) return true;
   return false;
}

void UltraExec_MarkFired(const string s)
{
   datetime bar = iTime(s, UltraETF(), 0);
   if(bar > 0) g_UltraLastFireBar = bar;
}

bool UltraExec_Ready(const string s, string &why)
{
   return UltraExecReady(s, why);
}

int UltraExec_OpenCountMagic()
{
   int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || !PositionSelectByTicket(t)) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      n++;
   }
   return n;
}

#endif // HITMAN_ULTRA_19_EXECUTION_MQH
//===== END 19_Execution.mqh =====

//===== BEGIN UltraMarketInput.mqh =====
#ifndef HITMAN_ULTRA_MARKET_INPUT_MQH
#define HITMAN_ULTRA_MARKET_INPUT_MQH
//+------------------------------------------------------------------+
//| HITMAN AI ULTRA X — LEVEL 1 ULTRA MARKET INPUT ENGINE            |
//| Tick · Price · Spread · Volume · Context · Session · News · Broker
//+------------------------------------------------------------------+

struct UltraMarketInput
{
   bool tickOK;
   bool priceOK;
   bool spreadOK;
   bool volumeOK;
   bool contextOK;
   bool sessionOK;
   bool newsOK;
   bool brokerOK;
   bool symbolOK;
   double bid, ask, spreadPts;
   long   tickVol;
   string session;
   string newsPhase;
   string broker;
   string detail;
};

UltraMarketInput g_UltraMarketInput;

bool UltraInput_Process(const string s, UltraMarketInput &in)
{
   in.tickOK = in.priceOK = in.spreadOK = in.volumeOK = false;
   in.contextOK = in.sessionOK = in.newsOK = in.brokerOK = in.symbolOK = false;
   in.bid = SymbolInfoDouble(s, SYMBOL_BID);
   in.ask = SymbolInfoDouble(s, SYMBOL_ASK);
   long spr = 0; SymbolInfoInteger(s, SYMBOL_SPREAD, spr);
   in.spreadPts = (double)spr;
   in.tickVol = iTickVolume(s, UltraETF(), 0);
   if(in.tickVol <= 0) in.tickVol = iVolume(s, UltraETF(), 0);
   in.session = "";
   in.newsPhase = "";
   in.broker = AccountInfoString(ACCOUNT_COMPANY);
   in.detail = "OK";

   long sel = 0;
   in.symbolOK = (s != "" && SymbolInfoInteger(s, SYMBOL_SELECT, sel) && sel != 0);
   in.priceOK = (in.bid > 0.0 && in.ask >= in.bid);
   in.tickOK = in.priceOK && (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
   in.spreadOK = (in.spreadPts >= 0.0);
   in.volumeOK = (in.tickVol >= 0);
   in.brokerOK = (AccountInfoInteger(ACCOUNT_LOGIN) != 0) &&
                 (TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) != 0);
   in.sessionOK = true;  // context only — never hard-block
   in.newsOK = true;     // context only — never hard-block
   in.contextOK = in.tickOK && in.priceOK && in.symbolOK;
   g_UltraMarketInput = in;
   return in.contextOK;
}

string UltraInput_Dashboard()
{
   string t = "INPUT: ";
   if(g_UltraMarketInput.contextOK) t += "OK"; else t += "FAIL";
   t += " spr=";
   t += DoubleToString(g_UltraMarketInput.spreadPts, 0);
   t += " vol=";
   t += IntegerToString((int)g_UltraMarketInput.tickVol);
   return t;
}

#endif
//===== END UltraMarketInput.mqh =====

//===== BEGIN 23_MultiTimeframe.mqh =====
#ifndef HITMAN_ULTRA_23_MULTITIMEFRAME_MQH
#define HITMAN_ULTRA_23_MULTITIMEFRAME_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 23_MULTI_TIMEFRAME — MN..M1 · Bias · Sync · Lock     |
//| Monthly · Weekly · Daily · H4 · H1 · M30 · M15 · M5 · M1         |
//+------------------------------------------------------------------+

ENUM_TIMEFRAMES UltraMTF_List(const int idx)
{
   switch(idx)
   {
      case 0: return PERIOD_MN1;
      case 1: return PERIOD_W1;
      case 2: return PERIOD_D1;
      case 3: return PERIOD_H4;
      case 4: return PERIOD_H1;
      case 5: return PERIOD_M30;
      case 6: return PERIOD_M15;
      case 7: return PERIOD_M5;
      case 8: return PERIOD_M1;
   }
   return PERIOD_CURRENT;
}

int UltraMTF_Count() { return 9; }

string UltraMTF_Label(const int idx)
{
   switch(idx)
   {
      case 0: return "MN";
      case 1: return "W1";
      case 2: return "D1";
      case 3: return "H4";
      case 4: return "H1";
      case 5: return "M30";
      case 6: return "M15";
      case 7: return "M5";
      case 8: return "M1";
   }
   return "?";
}

bool UltraMTF_Bull(const string s, const ENUM_TIMEFRAMES tf, const int smaPeriod=20)
{
   double sma = UltraSMA(s, tf, smaPeriod);
   if(sma <= 0.0) return false;
   return (iClose(s, tf, 1) > sma);
}

bool UltraMTF_Bear(const string s, const ENUM_TIMEFRAMES tf, const int smaPeriod=20)
{
   double sma = UltraSMA(s, tf, smaPeriod);
   if(sma <= 0.0) return false;
   return (iClose(s, tf, 1) < sma);
}

void UltraMTF_Vote(const string s, int &votesBuy, int &votesSell)
{
   votesBuy = 0; votesSell = 0;
   ENUM_TIMEFRAMES core[4] = {UltraTF_Month, UltraTF_Week, UltraTF_Macro, UltraTF_Bias};
   for(int i = 0; i < 4; i++)
   {
      if(UltraMTF_Bull(s, core[i])) votesBuy++;
      if(UltraMTF_Bear(s, core[i])) votesSell++;
   }
   if(UltraUseM30){ if(UltraMTF_Bull(s, PERIOD_M30)) votesBuy++; if(UltraMTF_Bear(s, PERIOD_M30)) votesSell++; }
   if(UltraUseM15){ if(UltraMTF_Bull(s, PERIOD_M15)) votesBuy++; if(UltraMTF_Bear(s, PERIOD_M15)) votesSell++; }
   if(UltraUseM5){  if(UltraMTF_Bull(s, PERIOD_M5))  votesBuy++; if(UltraMTF_Bear(s, PERIOD_M5))  votesSell++; }
   if(UltraUseM1Optional){ if(UltraMTF_Bull(s, PERIOD_M1)) votesBuy++; if(UltraMTF_Bear(s, PERIOD_M1)) votesSell++; }
}

double UltraMTF_WeightBias(const int votesBuy, const int votesSell)
{
   int d = votesBuy - votesSell;
   return MathMax(-1.0, MathMin(1.0, d / 6.0));
}

// Master trend from H4 (bias TF). Returns +1 buy, -1 sell, 0 unknown.
int UltraMTF_MasterDir(const string s)
{
   if(UltraMTF_Bull(s, UltraTF_Bias)) return 1;
   if(UltraMTF_Bear(s, UltraTF_Bias)) return -1;
   return 0;
}

// Timeframe synchronization: count agreement across MN→M5 ladder for side.
int UltraMTF_SyncAgree(const string s, const bool buySide, int &known)
{
   known = 0;
   int agree = 0;
   for(int i = 0; i < 8; i++) // MN..M5 (skip optional M1)
   {
      ENUM_TIMEFRAMES tf = UltraMTF_List(i);
      if(i == 5 && !UltraUseM30) continue;
      if(i == 6 && !UltraUseM15) continue;
      if(i == 7 && !UltraUseM5) continue;
      double sma = UltraSMA(s, tf, 20, 1);
      if(sma <= 0.0) continue;
      known++;
      bool bull = (iClose(s, tf, 1) > sma);
      bool bear = (iClose(s, tf, 1) < sma);
      if(buySide ? bull : bear) agree++;
   }
   return agree;
}

// No timeframe conflicts: LTF must not fight H4 master (strict) / soft allows mild mix.
bool UltraMTF_NoConflict(const string s, const bool buySide, string &why)
{
   why = "";
   int master = UltraMTF_MasterDir(s);
   if(master == 0) return true; // unknown master — fail-open
   if(buySide && master < 0)
   {
      why = "MTF conflict: H4 master SELL vs BUY";
      return false;
   }
   if(!buySide && master > 0)
   {
      why = "MTF conflict: H4 master BUY vs SELL";
      return false;
   }

   // Higher TF stack (MN/W1/D1) should not be strongly opposite in strict mode
   int htfOpp = 0;
   int htfKnown = 0;
   ENUM_TIMEFRAMES htf[3];
   htf[0] = PERIOD_MN1; htf[1] = PERIOD_W1; htf[2] = PERIOD_D1;
   for(int i = 0; i < 3; i++)
   {
      double sma = UltraSMA(s, htf[i], 20, 1);
      if(sma <= 0.0) continue;
      htfKnown++;
      bool bull = (iClose(s, htf[i], 1) > sma);
      bool bear = (iClose(s, htf[i], 1) < sma);
      if(buySide && bear) htfOpp++;
      if(!buySide && bull) htfOpp++;
   }
   if(!InstantQualityMode && UltraDisciplineStrict && htfKnown >= 2 && htfOpp >= 2)
   {
      why = "MTF conflict: higher TF stack against thesis";
      return false;
   }
   return true;
}

string UltraMTF_Dashboard(const string s)
{
   int known = 0;
   int ab = UltraMTF_SyncAgree(s, true, known);
   int k2 = 0;
   int asell = UltraMTF_SyncAgree(s, false, k2);
   string t = "MTF: BUY ";
   t += IntegerToString(ab);
   t += " SELL ";
   t += IntegerToString(asell);
   t += " master=";
   int m = UltraMTF_MasterDir(s);
   if(m > 0) t += "BUY";
   else if(m < 0) t += "SELL";
   else t += "-";
   return t;
}

#endif // HITMAN_ULTRA_23_MULTITIMEFRAME_MQH
//===== END 23_MultiTimeframe.mqh =====

//===== BEGIN 16_AI_Core.mqh =====
#ifndef HITMAN_ULTRA_16_AI_CORE_MQH
#define HITMAN_ULTRA_16_AI_CORE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 16_AI_CORE — Decision · Approval/Rejection · Controller · Strategies
//+------------------------------------------------------------------+

datetime g_UltraLastWaitBar = 0;
string   g_UltraLastWaitSym = "";

int UltraFireFloor()
{
   // InstantQualityMode: softer live floor so charts actually trade
   if(InstantQualityMode)
      return MathMin(UltraMinConfluence, 45);
   return UltraMinConfluence;
}

void UltraEngScores(UltraSnap &u, const bool buySide)
{
   int conf = buySide ? UltraConfluenceBuy(u) : UltraConfluenceSell(u);
   u.score.confluence = conf;
   u.score.confidence = conf;
   u.score.precision = UltraPrecisionScore(u);
   u.score.successProb = UltraProbabilityScore(u, conf, u.score.precision);
   u.score.riskProb = UltraRiskProbability(u.score.successProb);
   u.score.probability = u.score.successProb;
}

void UltraEngScoresBest(UltraSnap &u)
{
   int sb = UltraConfluenceBuy(u);
   int ss = UltraConfluenceSell(u);
   UltraEngScores(u, (sb >= ss));
}

void UltraResolveSides(UltraSignal &r, const int sb, const int ss)
{
   if(r.buy && r.sell)
   {
      if(sb >= ss) r.sell = false; else r.buy = false;
      r.score = MathMax(sb, ss);
   }
}

bool UltraPassScore(const int sc)
{
   int floor = UltraFireFloor();
   if(sc >= floor) return true;
   if(sc >= UltraInstantFireConf) return true;
   // Soft pass: close to floor in InstantQualityMode
   if(InstantQualityMode && sc >= floor - 8) return true;
   return false;
}

UltraSignal UltraStrat_FlashSweep(const UltraSnap &u)
{
   UltraSignal r; r.buy = r.sell = false; r.score = 0; r.tag = "FlashSweep"; r.reason = "";
   int sb = UltraConfluenceBuy(u), ss = UltraConfluenceSell(u);
   bool biasB = (u.trend.htfBull || u.trend.bull || u.trend.macroBull || u.trend.mtfVotesBuy >= u.trend.mtfVotesSell);
   bool biasS = (u.trend.htfBear || u.trend.bear || u.trend.macroBear || u.trend.mtfVotesSell > u.trend.mtfVotesBuy);
   bool b = (u.liq.sweepBuy || u.liq.stopHuntBuy) && (u.ict.dispBuy || u.mom.momBuy || u.bos.buy) && biasB;
   bool s = (u.liq.sweepSell || u.liq.stopHuntSell) && (u.ict.dispSell || u.mom.momSell || u.bos.sell) && biasS;
   if(b && UltraPassScore(sb)){ r.buy = true; r.score = sb; r.reason = "ULSE sweep+impulse+bias"; }
   if(s && UltraPassScore(ss)){ r.sell = true; r.score = ss; r.reason = "ULSE sweep+impulse+bias"; }
   UltraResolveSides(r, sb, ss);
   return r;
}

UltraSignal UltraStrat_ContSniper(const UltraSnap &u)
{
   UltraSignal r; r.buy = r.sell = false; r.score = 0; r.tag = "ContSniper"; r.reason = "";
   int sb = UltraConfluenceBuy(u), ss = UltraConfluenceSell(u);
   bool biasB = (u.trend.htfBull || u.trend.bull || u.trend.macroBull || u.st.externalBull || u.st.internalBull);
   bool biasS = (u.trend.htfBear || u.trend.bear || u.trend.macroBear || u.st.externalBear || u.st.internalBear);
   bool zoneB = (u.bos.buy || u.ict.obBuy || u.ict.fvgBuy || u.fib.atBuyZone || u.ict.instZoneBuy);
   bool zoneS = (u.bos.sell || u.ict.obSell || u.ict.fvgSell || u.fib.atSellZone || u.ict.instZoneSell);
   bool impB  = (u.ict.dispBuy || u.mom.momBuy || u.liq.sweepBuy || u.vol.expansion);
   bool impS  = (u.ict.dispSell || u.mom.momSell || u.liq.sweepSell || u.vol.expansion);
   bool b = biasB && zoneB && impB;
   bool s = biasS && zoneS && impS;
   // Instant: 2-of-3 stack is enough
   if(InstantQualityMode)
   {
      int eb = (biasB ? 1 : 0) + (zoneB ? 1 : 0) + (impB ? 1 : 0);
      int es = (biasS ? 1 : 0) + (zoneS ? 1 : 0) + (impS ? 1 : 0);
      b = (eb >= 2); s = (es >= 2);
   }
   if(b && UltraPassScore(sb)){ r.buy = true; r.score = sb; r.reason = "UBOSE cont+zone+impulse"; }
   if(s && UltraPassScore(ss)){ r.sell = true; r.score = ss; r.reason = "UBOSE cont+zone+impulse"; }
   UltraResolveSides(r, sb, ss);
   return r;
}

UltraSignal UltraStrat_RevSniper(const UltraSnap &u)
{
   UltraSignal r; r.buy = r.sell = false; r.score = 0; r.tag = "RevSniper"; r.reason = "";
   int sb = UltraConfluenceBuy(u), ss = UltraConfluenceSell(u);
   bool b = (u.liq.sweepBuy || u.liq.stopHuntBuy) &&
            (u.choch.buy || u.ict.dispBuy || u.bos.buy) &&
            (u.ict.obBuy || u.ict.fvgBuy || u.ict.inDiscount || u.fib.atBuyZone);
   bool s = (u.liq.sweepSell || u.liq.stopHuntSell) &&
            (u.choch.sell || u.ict.dispSell || u.bos.sell) &&
            (u.ict.obSell || u.ict.fvgSell || u.ict.inPremium || u.fib.atSellZone);
   if(b && UltraPassScore(sb)){ r.buy = true; r.score = sb + 2; r.reason = "UCHOCHE rev stack"; }
   if(s && UltraPassScore(ss)){ r.sell = true; r.score = ss + 2; r.reason = "UCHOCHE rev stack"; }
   UltraResolveSides(r, sb, ss);
   if(r.score > 100) r.score = 100;
   return r;
}

UltraSignal UltraStrat_FibSniper(const UltraSnap &u)
{
   UltraSignal r; r.buy = r.sell = false; r.score = 0; r.tag = "FibSniper"; r.reason = "";
   int sb = UltraConfluenceBuy(u), ss = UltraConfluenceSell(u);
   bool biasB = (u.trend.htfBull || u.trend.bull || u.trend.macroBull || u.mom.momBuy);
   bool biasS = (u.trend.htfBear || u.trend.bear || u.trend.macroBear || u.mom.momSell);
   bool b = u.fib.atBuyZone && biasB && (u.ict.dispBuy || u.mom.momBuy || u.ict.obBuy || u.liq.sweepBuy || u.bos.buy);
   bool s = u.fib.atSellZone && biasS && (u.ict.dispSell || u.mom.momSell || u.ict.obSell || u.liq.sweepSell || u.bos.sell);
   if(b && UltraPassScore(sb)){ r.buy = true; r.score = sb; r.reason = "UFIE fib zone"; }
   if(s && UltraPassScore(ss)){ r.sell = true; r.score = ss; r.reason = "UFIE fib zone"; }
   UltraResolveSides(r, sb, ss);
   return r;
}

UltraSignal UltraStrat_BreakImpulse(const UltraSnap &u)
{
   UltraSignal r; r.buy = r.sell = false; r.score = 0; r.tag = "BreakImpulse"; r.reason = "";
   int sb = UltraConfluenceBuy(u), ss = UltraConfluenceSell(u);
   bool b = u.bos.buy && (u.ict.dispBuy || u.mom.momBuy || u.vol.expansion) &&
            (u.trend.htfBull || u.trend.macroBull || u.trend.bull || u.st.externalBull);
   bool s = u.bos.sell && (u.ict.dispSell || u.mom.momSell || u.vol.expansion) &&
            (u.trend.htfBear || u.trend.macroBear || u.trend.bear || u.st.externalBear);
   if(b && UltraPassScore(sb)){ r.buy = true; r.score = sb; r.reason = "BOS+impulse+vol"; }
   if(s && UltraPassScore(ss)){ r.sell = true; r.score = ss; r.reason = "BOS+impulse+vol"; }
   UltraResolveSides(r, sb, ss);
   return r;
}

UltraSignal UltraStrat_InstZone(const UltraSnap &u)
{
   UltraSignal r; r.buy = r.sell = false; r.score = 0; r.tag = "InstZone"; r.reason = "";
   int sb = UltraConfluenceBuy(u), ss = UltraConfluenceSell(u);
   bool b = (u.ict.instZoneBuy || ((u.ict.obBuy || u.ict.fvgBuy) && u.ict.inDiscount)) &&
            (u.ict.smConfluence || u.fib.atBuyZone || u.liq.sweepBuy || u.bos.buy);
   bool s = (u.ict.instZoneSell || ((u.ict.obSell || u.ict.fvgSell) && u.ict.inPremium)) &&
            (u.ict.smConfluence || u.fib.atSellZone || u.liq.sweepSell || u.bos.sell);
   if(b && UltraPassScore(sb)){ r.buy = true; r.score = sb; r.reason = "institutional zone"; }
   if(s && UltraPassScore(ss)){ r.sell = true; r.score = ss; r.reason = "institutional zone"; }
   UltraResolveSides(r, sb, ss);
   return r;
}

bool Ultra_IsLiveTag(const string tag)
{
   return (tag == "FlashSweep" || tag == "ContSniper" || tag == "RevSniper" ||
           tag == "FibSniper" || tag == "BreakImpulse" || tag == "InstZone");
}

bool PRIME_IsLiveTag(const string tag)
{
   return Ultra_IsLiveTag(tag);
}

int UltraSymDir(const string s)
{
   bool b = false, sel = false;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || !PositionSelectByTicket(t)) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      if(PositionGetString(POSITION_SYMBOL) != s) continue;
      long ty = PositionGetInteger(POSITION_TYPE);
      if(ty == POSITION_TYPE_BUY) b = true;
      if(ty == POSITION_TYPE_SELL) sel = true;
   }
   if(b && sel) return 2;
   if(b) return 1;
   if(sel) return -1;
   return 0;
}

UltraSignal UltraPickBest(const UltraSnap &u)
{
   UltraSignal best; best.buy = best.sell = false; best.score = -1; best.tag = "NONE";
   best.reason = "no setup"; best.explanation = "";
   UltraSignal arr[6];
   int n = 0;
   if(UltraEnable_FlashSweep)   arr[n++] = UltraStrat_FlashSweep(u);
   if(UltraEnable_ContSniper)   arr[n++] = UltraStrat_ContSniper(u);
   if(UltraEnable_RevSniper)    arr[n++] = UltraStrat_RevSniper(u);
   if(UltraEnable_FibSniper)    arr[n++] = UltraStrat_FibSniper(u);
   if(UltraEnable_BreakImpulse) arr[n++] = UltraStrat_BreakImpulse(u);
   if(UltraEnable_InstZone)     arr[n++] = UltraStrat_InstZone(u);
   for(int i = 0; i < n; i++)
   {
      if(!(arr[i].buy || arr[i].sell)) continue;
      if(arr[i].score > best.score) best = arr[i];
   }
   if(best.score >= 0 && !UltraPassScore(best.score))
   {
      best.buy = best.sell = false; best.tag = "NONE";
      best.reason = StringFormat("below confluence (%d<%d)", best.score, UltraFireFloor());
   }
   return best;
}

// Master Blueprint explainable decision (BUY/SELL/WAIT + checklist)
string UltraBuildExplanation(const UltraSnap &u, const bool buySide, const bool approved, const string tag)
{
   bool structure = buySide
      ? (u.st.hh || u.st.hl || u.st.externalBull || u.st.internalBull || u.st.continuation)
      : (u.st.lh || u.st.ll || u.st.externalBear || u.st.internalBear || u.st.continuation);
   bool bosCh = buySide ? (u.bos.buy || u.choch.buy) : (u.bos.sell || u.choch.sell);
   bool liq   = buySide ? (u.liq.sweepBuy || u.liq.stopHuntBuy || u.liq.equalLows)
                        : (u.liq.sweepSell || u.liq.stopHuntSell || u.liq.equalHighs);
   bool trend = buySide ? (u.trend.bull || u.trend.htfBull || u.trend.macroBull)
                        : (u.trend.bear || u.trend.htfBear || u.trend.macroBear);
   bool mom   = buySide ? (u.mom.momBuy || u.mom.impulse || u.ict.dispBuy)
                        : (u.mom.momSell || u.mom.impulse || u.ict.dispSell);
   bool fib   = buySide ? u.fib.atBuyZone : u.fib.atSellZone;
   int passed = (structure?1:0)+(bosCh?1:0)+(liq?1:0)+(trend?1:0)+(mom?1:0)+(fib?1:0);

   string t = (approved ? tag : "NO TRADE");
   t += "\n"; if(structure) t += "[OK] Structure"; else t += "[X]  Structure";
   t += "\n"; if(bosCh) t += "[OK] BOS/CHoCH"; else t += "[X]  BOS/CHoCH";
   t += "\n"; if(liq) t += "[OK] Liquidity"; else t += "[X]  Liquidity";
   t += "\n"; if(fib) t += "[OK] Fibonacci"; else t += "[-]  Fibonacci";
   t += "\n"; if(trend) t += "[OK] Trend"; else t += "[X]  Trend";
   t += "\n"; if(mom) t += "[OK] Momentum"; else t += "[X]  Momentum";
   t += "\nConfidence = "; t += IntegerToString(u.score.confidence); t += "%";
   t += "\nPrecision  = "; t += IntegerToString(u.score.precision); t += "%";
   t += "\nProbability= "; t += IntegerToString(u.score.probability); t += "%";
   t += "\n";
   if(approved)
   {
      t += "Decision = ";
      if(buySide) t += "BUY"; else t += "SELL";
   }
   else
   {
      t += "Decision = WAIT | Reason = Insufficient Confluence (";
      t += IntegerToString(passed);
      t += "/6)";
   }
   return t;
}

void UltraClearSnap(UltraSnap &u)
{
   // Never ZeroMemory structs that contain string fields (MQL5 unsafe).
   UltraBOS bos; UltraCHoCH choch; UltraLiquidity liq;
   UltraFib fib; UltraInst ict; UltraTrend trend; UltraMomentum mom; UltraVolatility vol;
   UltraIndicators ind; UltraScores score;
   ZeroMemory(bos); ZeroMemory(choch); ZeroMemory(liq);
   ZeroMemory(fib); ZeroMemory(ict); ZeroMemory(trend); ZeroMemory(mom); ZeroMemory(vol);
   ZeroMemory(ind); ZeroMemory(score);

   // UltraStructure has string cycleName — clear manually
   u.st.hh = u.st.hl = u.st.lh = u.st.ll = false;
   u.st.swingHighOK = u.st.swingLowOK = false;
   u.st.internalBull = u.st.internalBear = false;
   u.st.externalBull = u.st.externalBear = false;
   u.st.continuation = u.st.reversal = false;
   u.st.strength = 0; u.st.quality = 0;
   u.st.swingHigh = 0; u.st.swingLow = 0;
   u.st.cycle = 4;
   u.st.cycleName = "UNKNOWN";

   u.bos = bos; u.choch = choch; u.liq = liq;
   u.fib = fib; u.ict = ict; u.trend = trend; u.mom = mom; u.vol = vol;
   u.ind = ind; u.score = score;
   u.regime = UREG_RANGE;
   u.buyBias = false; u.sellBias = false;
   u.ctx.session = "OFF";
   u.ctx.asia = u.ctx.london = u.ctx.newyork = u.ctx.overlap = false;
   u.ctx.killZone = false;
   u.ctx.sessionLiquidity = false;
   u.ctx.sessionConfidence = 0; u.ctx.sessionQuality = 0;
   u.ctx.newsVol = false;
   u.ctx.highImpactProxy = u.ctx.midImpactProxy = u.ctx.lowImpactProxy = false;
   u.ctx.beforeNews = u.ctx.duringNews = u.ctx.afterNews = false;
   u.ctx.newsPhase = "NONE";
   u.ctx.spreadPts = 0; u.ctx.slipProxy = 0;
   u.diag.tickOK = u.diag.brokerOK = u.diag.connectionOK = false;
   u.diag.indicatorOK = u.diag.memoryOK = false;
   u.diag.processSpeedMs = 0;
   u.diag.health = "INIT";
}

bool UltraBuildSnapshot(const string s, UltraSnap &u)
{
   long t0 = (long)GetTickCount();
   UltraClearSnap(u);
   if(!UltraCoreEnabled){ UltraSetError("core disabled"); return false; }
   if(!UltraConfigOK()){ UltraSetError("config invalid"); return false; }
   if(UltraDataEngineEnabled && !UltraValidateSymbol(s)){ UltraSetError("data/symbol invalid"); return false; }

   // LEVEL 1 — Market Input + LEVEL 2 — Data Core refresh
   UltraMarketInput in;
   if(!UltraInput_Process(s, in))
   {
      UltraSetError("market input invalid");
      return false;
   }
   UltraData_Refresh(s);
   if(!g_UltraDataCache.valid)
   {
      UltraSetError("data/price invalid");
      return false;
   }

   UltraEngVolatility(s, u);
   UltraEngStructure(s, u);
   UltraEngBOS(s, u);
   UltraEngCHoCH(s, u);
   UltraEngLiquidity(s, u);
   UltraEngFib(s, u);              // before institutional (zone uses fib)
   UltraEngInstitutional(s, u);
   UltraEngTrend(s, u);
   UltraEngMomentum(s, u);
   UltraEngRegime(u);
   UltraEngCycle(u);               // market cycle after regime/structure
   UltraEngSessionNews(s, u);
   UltraEngIndicators(s, u);
   UltraEngDiagnostics(s, u);
   UltraMemoryUpdateFromStats();
   UltraEngScoresBest(u);          // always fill conf/prec/prob for dashboard + wait logs
   UltraEvent_NoteMarket(u);       // event-driven market edges

   // propagate session/news context into input surface
   g_UltraMarketInput.session = u.ctx.session;
   g_UltraMarketInput.newsPhase = u.ctx.newsPhase;

   g_UltraCore.lastLatencyMs = (long)GetTickCount() - t0;
   g_UltraCore.lastCycleMs = (long)GetTickCount();
   g_UltraCore.dataOK = true;
   g_UltraCore.validated = true;
   return true;
}

// UltraAIDecide + EvaluateStrategySignals live in UFSE_FastSignalEngine.mqh
// (included after this file) so the Ultra Fast Signal Engine can wrap them.

#endif // HITMAN_ULTRA_16_AI_CORE_MQH
//===== END 16_AI_Core.mqh =====

//===== BEGIN DefenseLineEngine.mqh =====
#ifndef HITMAN_ULTRA_DEFENSE_LINE_ENGINE_MQH
#define HITMAN_ULTRA_DEFENSE_LINE_ENGINE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — DEFENSE LINE ENGINE v1.0                             |
//| Protect entries · block invalid trades · protect positions       |
//| Detect abnormal markets · preserve capital                       |
//+------------------------------------------------------------------+

datetime g_UltraDefenseLastEmergBar = 0;
datetime g_UltraDefenseLastLogBar   = 0;
string   g_UltraDefenseLastLogSym   = "";
bool     g_UltraDefenseWasConnected = true;

string UltraDefense_LevelName(const ENUM_DEFENSE_LEVEL lv)
{
   if(lv == DEF_GREEN)  return "GREEN";
   if(lv == DEF_YELLOW) return "YELLOW";
   return "RED";
}

string UltraDefense_ActionName(const ENUM_DEFENSE_ACTION a)
{
   if(a == DEF_ACT_EXECUTE)        return "EXECUTE";
   if(a == DEF_ACT_WAIT)           return "WAIT";
   if(a == DEF_ACT_DO_NOT_EXECUTE) return "DO NOT EXECUTE";
   return "NO TRADE";
}

void UltraDefense_ClearReport(UltraDefenseReport &r)
{
   r.valid = false;
   r.buySide = true;
   r.overall = DEF_GREEN;
   r.action = DEF_ACT_EXECUTE;
   r.allowEntry = true;
   r.allowExecute = true;
   r.summary = "";
   for(int i = 0; i <= 10; i++)
   {
      r.line[i].id = i;
      r.line[i].name = "";
      r.line[i].pass = true;
      r.line[i].level = DEF_GREEN;
      r.line[i].reason = "";
   }
}

void UltraDefense_SetLine(UltraDefenseReport &r, const int id, const string name,
                          const bool pass, const ENUM_DEFENSE_LEVEL failLevel,
                          const string reason)
{
   if(id < 1 || id > 10) return;
   r.line[id].id = id;
   r.line[id].name = name;
   r.line[id].pass = pass;
   if(pass)
   {
      r.line[id].level = DEF_GREEN;
      r.line[id].reason = "PASS";
   }
   else
   {
      r.line[id].level = failLevel;
      r.line[id].reason = reason;
   }
}

void UltraDefense_RaiseOverall(UltraDefenseReport &r, const ENUM_DEFENSE_LEVEL lv)
{
   if((int)lv > (int)r.overall)
      r.overall = lv;
}

bool UltraDefense_SoftMode()
{
   if(!UltraDefenseStrict && InstantQualityMode) return true;
   return (!UltraDefenseStrict);
}

//--------------------------------------------------------------------//
// LINE 1 — MARKET STRUCTURE DEFENSE  → fail = NO TRADE (RED)
//--------------------------------------------------------------------//
bool UltraDefense_Line1_Structure(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool valid = buySide
      ? (u.st.hh || u.st.hl || u.st.externalBull || u.st.internalBull || u.st.continuation)
      : (u.st.lh || u.st.ll || u.st.externalBear || u.st.internalBear || u.st.continuation);
   bool broken = u.bos.failed;
   bool cleanSwing = (u.st.swingHighOK || u.st.swingLowOK || u.st.quality >= 30 || u.st.strength >= 30);
   bool fakeBreak = (u.bos.failed && ((buySide && u.bos.sell) || (!buySide && u.bos.buy)));

   if(UltraDefense_SoftMode())
   {
      int n = (valid?1:0) + ((!broken)?1:0) + (cleanSwing?1:0) + ((!fakeBreak)?1:0);
      if(n >= 2) return true;
      why = "structure soft " + IntegerToString(n) + "/4";
      return false;
   }
   if(!valid){ why = "invalid structure"; return false; }
   if(broken && fakeBreak){ why = "broken / fake break"; return false; }
   if(!cleanSwing && u.st.quality < 20){ why = "dirty swing"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// LINE 2 — TREND DEFENSE  → fail = NO TRADE (RED)
//--------------------------------------------------------------------//
bool UltraDefense_Line2_Trend(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool master = buySide
      ? (u.trend.bull || u.trend.htfBull || u.trend.macroBull || u.trend.mtfVotesBuy > u.trend.mtfVotesSell)
      : (u.trend.bear || u.trend.htfBear || u.trend.macroBear || u.trend.mtfVotesSell > u.trend.mtfVotesBuy);
   bool strength = (u.trend.strength >= 25 || u.trend.quality >= 25 || UltraDefense_SoftMode());
   bool stable   = (u.trend.persistence >= 20 || u.trend.continuation || !u.trend.exhaustion || UltraDefense_SoftMode());

   if(UltraDefense_SoftMode())
   {
      int n = (master?1:0)+(strength?1:0)+(stable?1:0);
      if(n >= 1) return true;
      why = "trend soft 0/3";
      return false;
   }
   if(!master){ why = "master trend mismatch"; return false; }
   if(!strength){ why = "trend strength weak"; return false; }
   if(!stable){ why = "trend unstable"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// LINE 3 — LIQUIDITY DEFENSE  → fail = WAIT (YELLOW)
//--------------------------------------------------------------------//
bool UltraDefense_Line3_Liquidity(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool sweep = buySide ? (u.liq.sweepBuy || u.liq.equalLows) : (u.liq.sweepSell || u.liq.equalHighs);
   bool hunt  = buySide ? u.liq.stopHuntBuy : u.liq.stopHuntSell;
   bool grab  = buySide ? (u.liq.grabBuy || u.liq.poolBuy || u.liq.confirmedBuy)
                        : (u.liq.grabSell || u.liq.poolSell || u.liq.confirmedSell);
   if(sweep || hunt || grab) return true;
   if(UltraDefense_SoftMode() && (u.liq.quality >= 20 || u.ict.dispBuy || u.ict.dispSell))
      return true;
   why = "liquidity not confirmed";
   return false;
}

//--------------------------------------------------------------------//
// LINE 4 — BOS + CHoCH DEFENSE  → fail = NO TRADE (RED)
// Checklist: BOS Defense · CHoCH Defense (both evaluated)
//--------------------------------------------------------------------//
bool UltraDefense_Line4_BosChoch(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool bos = buySide ? u.bos.buy : u.bos.sell;
   bool choch = buySide ? u.choch.buy : u.choch.sell;
   bool bosOK = bos && (u.bos.confirmed || u.bos.strong || u.bos.score >= 30 || UltraDefense_SoftMode());
   bool chochOK = choch && (u.choch.majorC || u.choch.confidence >= 30 || u.choch.strength >= 30 || UltraDefense_SoftMode());
   bool confirmed = bosOK || chochOK;
   bool strong = (u.bos.strong || u.bos.score >= 40 || u.choch.majorC || u.ict.dispBuy || u.ict.dispSell);

   if(UltraDefense_SoftMode())
   {
      if(bos || choch || u.st.continuation) return true;
      why = "no BOS/CHoCH";
      return false;
   }
   if(!(bos || choch)){ why = "no BOS/CHoCH"; return false; }
   if(!confirmed && !strong){ why = "break not confirmed"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// Momentum Defense (feeds Line 5)
//--------------------------------------------------------------------//
bool UltraDefense_MomentumOK(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool mom = buySide ? (u.mom.momBuy || u.mom.impulse || u.mom.direction > 0)
                      : (u.mom.momSell || u.mom.impulse || u.mom.direction < 0);
   if(mom || u.mom.strength >= 25) return true;
   if(UltraDefense_SoftMode() && !u.mom.weakness) return true;
   why = "momentum against";
   return false;
}

//--------------------------------------------------------------------//
// Fibonacci Defense (feeds Line 5)
//--------------------------------------------------------------------//
bool UltraDefense_FibOK(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool zone = buySide ? (u.fib.atBuyZone || u.ict.inDiscount) : (u.fib.atSellZone || u.ict.inPremium);
   if(zone || u.fib.quality >= 25 || u.fib.zoneRank >= 1) return true;
   if(UltraDefense_SoftMode()) return true; // soft — fib preferred not required
   why = "fib zone miss";
   return false;
}

//--------------------------------------------------------------------//
// Risk Defense (feeds Line 6)
//--------------------------------------------------------------------//
bool UltraDefense_RiskOK(const UltraSnap &u, string &why)
{
   why = "";
   if(u.score.riskProb > 0 && u.score.riskProb >= 70 && !UltraDefense_SoftMode())
   { why = "risk probability high"; return false; }
   if(u.diag.health == "DEGRADED" && !UltraDefense_SoftMode())
   { why = "diag degraded risk"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// LINE 5 — PRECISION + MOMENTUM + FIB DEFENSE  → fail = WAIT (YELLOW)
//--------------------------------------------------------------------//
bool UltraDefense_Line5_Precision(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool zone = buySide
      ? (u.fib.atBuyZone || u.ict.obBuy || u.ict.fvgBuy || u.ict.instZoneBuy || u.ict.inDiscount)
      : (u.fib.atSellZone || u.ict.obSell || u.ict.fvgSell || u.ict.instZoneSell || u.ict.inPremium);
   bool rrOk = (u.score.precision >= UltraMinPrecision ||
                u.score.confidence >= UltraInstantFireConf ||
                (InstantQualityMode && u.score.precision >= UltraMinPrecision - 8));
   bool lowErr = (u.score.precision >= 30 || u.fib.quality >= 30 || zone);

   string mw = "", fw = "";
   bool momOK = UltraDefense_MomentumOK(u, buySide, mw);
   bool fibOK = UltraDefense_FibOK(u, buySide, fw);

   if(rrOk && (zone || lowErr || UltraDefense_SoftMode()) && (momOK || UltraDefense_SoftMode()) && (fibOK || UltraDefense_SoftMode()))
      return true;
   if(UltraDefense_SoftMode() && u.score.confidence >= UltraFireFloor() - 5) return true;
   if(!momOK){ why = mw; return false; }
   if(!fibOK){ why = fw; return false; }
   why = "precision / zone wait";
   return false;
}

//--------------------------------------------------------------------//
// LINE 6 — PROBABILITY + RISK DEFENSE  → fail = NO TRADE (RED)
//--------------------------------------------------------------------//
bool UltraDefense_Line6_Probability(const UltraSnap &u, string &why)
{
   why = "";
   string rw = "";
   if(!UltraDefense_RiskOK(u, rw))
   { why = rw; return false; }
   if(u.score.probability >= UltraMinProbability) return true;
   if(u.score.confidence >= UltraInstantFireConf) return true;
   if(InstantQualityMode && u.score.probability >= UltraMinProbability - 8) return true;
   why = "probability below threshold";
   return false;
}

//--------------------------------------------------------------------//
// LINE 7 — EXECUTION DEFENSE  → fail = DO NOT EXECUTE (RED)
//--------------------------------------------------------------------//
bool UltraDefense_Line7_Execution(const string s, string &why)
{
   why = "";
   if(!TerminalInfoInteger(TERMINAL_CONNECTED)){ why = "connection loss"; return false; }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)){ why = "terminal trade blocked"; return false; }
   if(!MQLInfoInteger(MQL_TRADE_ALLOWED)){ why = "EA trade disabled"; return false; }

   long tm = 0;
   if(!SymbolInfoInteger(s, SYMBOL_TRADE_MODE, tm)){ why = "symbol mode unavailable"; return false; }
   // trade mode 0 = disabled — compare as long to avoid enum convert errors
   if(tm == 0){ why = "symbol trade disabled"; return false; }

   double bid = SymbolInfoDouble(s, SYMBOL_BID);
   double ask = SymbolInfoDouble(s, SYMBOL_ASK);
   if(bid <= 0.0 || ask <= 0.0){ why = "price not fresh"; return false; }

   double volMin = SymbolInfoDouble(s, SYMBOL_VOLUME_MIN);
   double volMax = SymbolInfoDouble(s, SYMBOL_VOLUME_MAX);
   if(volMin <= 0.0 || (volMax > 0.0 && volMax < volMin)){ why = "invalid volume limits"; return false; }

   long stops = 0;
   if(!SymbolInfoInteger(s, SYMBOL_TRADE_STOPS_LEVEL, stops)){ why = "stops level unavailable"; return false; }
   if(stops < 0){ why = "invalid stops level"; return false; }

   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double fm = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(eq <= 0.0){ why = "invalid equity"; return false; }
   if(fm <= 0.0){ why = "no free margin"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// LINE 10 — AI DEFENSE (final confluence of required checks)
//--------------------------------------------------------------------//
bool UltraDefense_Line10_AI(const UltraDefenseReport &r, string &why)
{
   why = "";
   // Required hard lines: 1,2,4,6 + exec 7 when gated. Soft waits: 3,5.
   if(!r.line[1].pass){ why = "AI: structure"; return false; }
   if(!r.line[2].pass){ why = "AI: trend"; return false; }
   if(!r.line[4].pass){ why = "AI: BOS/CHoCH"; return false; }
   if(!r.line[6].pass){ why = "AI: probability"; return false; }
   if(UltraDefenseGateExec && !r.line[7].pass){ why = "AI: execution"; return false; }
   // Liquidity + Precision are WAIT lines — block entry until confirmed
   if(!r.line[3].pass){ why = "AI: liquidity wait"; return false; }
   if(!r.line[5].pass){ why = "AI: precision wait"; return false; }
   return true;
}

string UltraDefense_BuildSummary(const UltraDefenseReport &r)
{
   string t = "DEFENSE ";
   t += UltraDefense_LevelName(r.overall);
   t += " → ";
   t += UltraDefense_ActionName(r.action);
   t += " |";
   for(int i = 1; i <= 10; i++)
   {
      if(i == 8 || i == 9) continue; // position/emergency reported separately
      t += " L";
      t += IntegerToString(i);
      t += "=";
      if(r.line[i].pass) t += "OK";
      else
      {
         t += UltraDefense_LevelName(r.line[i].level);
         t += ":";
         t += r.line[i].reason;
      }
   }
   return t;
}

//--------------------------------------------------------------------//
// ENTRY + EXEC EVALUATION (Lines 1-7 + 10)
//--------------------------------------------------------------------//
bool UltraDefense_EvaluateEntry(const string s, const UltraSnap &u, const bool buySide,
                                UltraDefenseReport &r, string &why)
{
   UltraDefense_ClearReport(r);
   r.buySide = buySide;
   r.valid = true;
   why = "";

   if(!UltraDefenseEnabled || !UltraDefenseGateEntry)
   {
      r.overall = DEF_GREEN;
      r.action = DEF_ACT_EXECUTE;
      r.allowEntry = true;
      r.allowExecute = true;
      r.summary = "DEFENSE OFF";
      g_UltraDefenseLast = r;
      return true;
   }

   string w = "";
   bool p1 = UltraDefense_Line1_Structure(u, buySide, w);
   UltraDefense_SetLine(r, 1, "STRUCTURE", p1, DEF_RED, w);
   if(!p1) UltraDefense_RaiseOverall(r, DEF_RED);

   w = "";
   bool p2 = UltraDefense_Line2_Trend(u, buySide, w);
   UltraDefense_SetLine(r, 2, "TREND", p2, DEF_RED, w);
   if(!p2) UltraDefense_RaiseOverall(r, DEF_RED);

   w = "";
   bool p3 = UltraDefense_Line3_Liquidity(u, buySide, w);
   UltraDefense_SetLine(r, 3, "LIQUIDITY", p3, DEF_YELLOW, w);
   if(!p3) UltraDefense_RaiseOverall(r, DEF_YELLOW);

   w = "";
   bool p4 = UltraDefense_Line4_BosChoch(u, buySide, w);
   UltraDefense_SetLine(r, 4, "BOS_CHOCH", p4, DEF_RED, w);
   if(!p4) UltraDefense_RaiseOverall(r, DEF_RED);

   w = "";
   bool p5 = UltraDefense_Line5_Precision(u, buySide, w);
   UltraDefense_SetLine(r, 5, "PREC_MOM_FIB", p5, DEF_YELLOW, w);
   if(!p5) UltraDefense_RaiseOverall(r, DEF_YELLOW);

   w = "";
   bool p6 = UltraDefense_Line6_Probability(u, w);
   UltraDefense_SetLine(r, 6, "PROB_RISK", p6, DEF_RED, w);
   if(!p6) UltraDefense_RaiseOverall(r, DEF_RED);

   w = "";
   bool p7 = true;
   if(UltraDefenseGateExec)
      p7 = UltraDefense_Line7_Execution(s, w);
   UltraDefense_SetLine(r, 7, "EXECUTION", p7, DEF_RED, w);
   if(!p7) UltraDefense_RaiseOverall(r, DEF_RED);

   // Position + Emergency are runtime — mark GREEN here
   UltraDefense_SetLine(r, 8, "POSITION", true, DEF_GREEN, "runtime");
   UltraDefense_SetLine(r, 9, "EMERGENCY", true, DEF_GREEN, "runtime");

   w = "";
   bool p10 = UltraDefense_Line10_AI(r, w);
   UltraDefense_SetLine(r, 10, "AI", p10, DEF_RED, w);
   if(!p10) UltraDefense_RaiseOverall(r, DEF_RED);

   // Map overall → action
   r.allowEntry = false;
   r.allowExecute = false;
   if(!p7)
   {
      r.action = DEF_ACT_DO_NOT_EXECUTE;
      r.allowEntry = false;
      r.allowExecute = false;
   }
   else if(!p1 || !p2 || !p4 || !p6 || !p10)
   {
      // distinguish WAIT (yellow-only fails on 3/5) vs NO TRADE
      if(p1 && p2 && p4 && p6 && (!p3 || !p5))
      {
         r.action = DEF_ACT_WAIT;
         r.overall = DEF_YELLOW;
      }
      else
      {
         r.action = DEF_ACT_NO_TRADE;
         if(r.overall < DEF_RED) r.overall = DEF_RED;
      }
   }
   else if(!p3 || !p5)
   {
      r.action = DEF_ACT_WAIT;
      r.overall = DEF_YELLOW;
   }
   else
   {
      r.action = DEF_ACT_EXECUTE;
      r.overall = DEF_GREEN;
      r.allowEntry = true;
      r.allowExecute = true;
   }

   r.summary = UltraDefense_BuildSummary(r);
   g_UltraDefenseLast = r;

   if(r.allowEntry && r.allowExecute)
   {
      why = "";
      return true;
   }

   why = "DEFENSE ";
   why += UltraDefense_LevelName(r.overall);
   why += " ";
   why += UltraDefense_ActionName(r.action);
   why += " — ";
   // pick first failing line reason
   for(int i = 1; i <= 10; i++)
   {
      if(i == 8 || i == 9) continue;
      if(!r.line[i].pass)
      {
         why += "L";
         why += IntegerToString(i);
         why += " ";
         why += r.line[i].name;
         why += ": ";
         why += r.line[i].reason;
         break;
      }
   }
   return false;
}

//--------------------------------------------------------------------//
// LINE 8 — POSITION DEFENSE (open trades)
// Protect profit · BE · trail handoff · trend-change monitor
// Returns true if position was CLOSED by defense.
//--------------------------------------------------------------------//
bool UltraDefense_Line8_Position(const ulong ticket, const long type,
                                 const double openPrice, const double price,
                                 double &currentSL, double &currentTP,
                                 const int stateIndex)
{
   if(!UltraDefenseEnabled || !UltraDefensePosition) return false;
   if(!PositionSelectByTicket(ticket)) return false;

   const bool isBuy = (type == POSITION_TYPE_BUY);
   UltraSnap u = g_UltraLastSnap;

   // Trend change against open position → move to break-even (capital preserve)
   bool trendFlip = isBuy
      ? (u.trend.bear && (u.trend.htfBear || u.trend.macroBear) && !u.trend.bull)
      : (u.trend.bull && (u.trend.htfBull || u.trend.macroBull) && !u.trend.bear);

   bool bosAgainst = isBuy ? (u.bos.sell && (u.bos.confirmed || u.bos.strong))
                           : (u.bos.buy  && (u.bos.confirmed || u.bos.strong));

   if(trendFlip || bosAgainst)
   {
      bool needsBE = isBuy ? (currentSL < openPrice) : (currentSL > openPrice || currentSL <= 0.0);
      // only BE if price is at/through open (avoid impossible modify)
      bool atProfit = isBuy ? (price >= openPrice) : (price <= openPrice);
      if(needsBE && atProfit)
      {
         if(g_Trade.PositionModify(ticket, openPrice, currentTP))
         {
            currentSL = openPrice;
            if(UltraDefenseLog)
               Print("DEFENSE L8 POSITION: BE on trend/BOS flip ticket=", ticket);
         }
      }
   }

   // Optional hard close on adverse exhaustion flip
   if(UltraDefenseCloseOnFlip && trendFlip && bosAgainst && u.trend.exhaustion)
   {
      if(UltraDefenseLog)
         Print("DEFENSE L8 POSITION: request CLOSE adverse flip ticket=", ticket);
      // Sole close authority = Mission Control
      return UltraMission_ClosePosition(ticket, "DEFENSE L8 adverse flip", false);
   }

   g_UltraDefenseLast.line[8].id = 8;
   g_UltraDefenseLast.line[8].name = "POSITION";
   g_UltraDefenseLast.line[8].pass = true;
   g_UltraDefenseLast.line[8].level = DEF_GREEN;
   g_UltraDefenseLast.line[8].reason = "monitoring";
   return false;
}

//--------------------------------------------------------------------//
// LINE 9 — EMERGENCY DEFENSE (recover automatically)
//--------------------------------------------------------------------//
void UltraDefense_Line9_Emergency(const string s)
{
   if(!UltraDefenseEnabled || !UltraDefenseEmergency) return;

   datetime bar = iTime(s, UltraETF(), 0);
   bool connected = (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
   bool tradeCtxBusy = !((bool)TerminalInfoInteger(TERMINAL_TRADE_ALLOWED));
   bool badEquity = (AccountInfoDouble(ACCOUNT_EQUITY) <= 0.0);
   long tm = 0;
   bool modeOK = SymbolInfoInteger(s, SYMBOL_TRADE_MODE, tm);
   bool symbolErr = (!modeOK) || (tm == 0) || (SymbolInfoDouble(s, SYMBOL_BID) <= 0.0);
   bool invalidData = (Bars(s, UltraETF()) < 50);

   string why = "";
   bool needRecover = false;

   if(!connected)
   {
      why = "connection loss";
      needRecover = true;
      g_UltraDefenseWasConnected = false;
   }
   else if(!g_UltraDefenseWasConnected && connected)
   {
      why = "VPS/terminal reconnect";
      needRecover = true;
      g_UltraDefenseWasConnected = true;
   }
   else
      g_UltraDefenseWasConnected = connected;

   if(tradeCtxBusy){ why = "trade context busy/blocked"; needRecover = true; }
   if(badEquity){ why = "invalid account data"; needRecover = true; }
   if(symbolErr){ why = "symbol error"; needRecover = true; }
   if(invalidData){ why = "invalid market data"; needRecover = true; }

   g_UltraDefenseLast.line[9].id = 9;
   g_UltraDefenseLast.line[9].name = "EMERGENCY";
   if(needRecover)
   {
      g_UltraDefenseLast.line[9].pass = false;
      g_UltraDefenseLast.line[9].level = DEF_RED;
      g_UltraDefenseLast.line[9].reason = why;
      UltraRecover(why);
      if(UltraDefenseLog && bar != g_UltraDefenseLastEmergBar)
      {
         g_UltraDefenseLastEmergBar = bar;
         Print("DEFENSE L9 EMERGENCY recover: ", why, " on ", s);
      }
   }
   else
   {
      g_UltraDefenseLast.line[9].pass = true;
      g_UltraDefenseLast.line[9].level = DEF_GREEN;
      g_UltraDefenseLast.line[9].reason = "OK";
   }
}

void UltraDefense_MaybeLog(const string s, const UltraDefenseReport &r)
{
   if(!UltraDefenseLog) return;
   datetime bar = iTime(s, UltraETF(), 0);
   if(bar == g_UltraDefenseLastLogBar && s == g_UltraDefenseLastLogSym) return;
   if(r.overall == DEF_GREEN && r.allowEntry) return; // keep journal clean; fire path logs
   g_UltraDefenseLastLogBar = bar;
   g_UltraDefenseLastLogSym = s;
   Print(r.summary, " on ", s);
}

string UltraDefense_DashboardLine()
{
   if(!UltraDefenseEnabled) return "DEFENSE: OFF";
   UltraDefenseReport r = g_UltraDefenseLast;
   string t = "DEFENSE: ";
   t += UltraDefense_LevelName(r.overall);
   t += " ";
   t += UltraDefense_ActionName(r.action);
   return t;
}

#endif // HITMAN_ULTRA_DEFENSE_LINE_ENGINE_MQH
//===== END DefenseLineEngine.mqh =====

//===== BEGIN TradeEntryDiscipline.mqh =====
#ifndef HITMAN_ULTRA_TRADE_ENTRY_DISCIPLINE_MQH
#define HITMAN_ULTRA_TRADE_ENTRY_DISCIPLINE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — TRADE ENTRY DISCIPLINE ENGINE v1.0                   |
//| Irregular Trade Prevention System                                |
//| Never open random / emotional / duplicate / low-quality trades   |
//+------------------------------------------------------------------+

#define ULTRA_DISC_MAX 32

struct UltraDiscState
{
   string   symbol;
   int      lastDir;          // +1 buy, -1 sell, 0 none
   int      stableCount;
   datetime lastEvalBar;
   datetime lastFillTime;
   datetime lastFillBar;
   int      lastFillDir;
   string   lastFillTag;
   int      lastFillEpoch;
   string   lastThesis;
   bool     valid;
};

UltraDiscState g_UltraDisc[ULTRA_DISC_MAX];
int            g_UltraDiscN = 0;
string         g_UltraDiscLastSummary = "";

bool UltraDisc_Soft()
{
   if(UltraDisciplineStrict) return false;
   return true;
}

int UltraDisc_Find(const string s)
{
   for(int i = 0; i < g_UltraDiscN; i++)
      if(g_UltraDisc[i].symbol == s) return i;
   return -1;
}

int UltraDisc_Ensure(const string s)
{
   int idx = UltraDisc_Find(s);
   if(idx >= 0) return idx;
   if(g_UltraDiscN >= ULTRA_DISC_MAX) return 0;
   idx = g_UltraDiscN++;
   g_UltraDisc[idx].symbol = s;
   g_UltraDisc[idx].lastDir = 0;
   g_UltraDisc[idx].stableCount = 0;
   g_UltraDisc[idx].lastEvalBar = 0;
   g_UltraDisc[idx].lastFillTime = 0;
   g_UltraDisc[idx].lastFillBar = 0;
   g_UltraDisc[idx].lastFillDir = 0;
   g_UltraDisc[idx].lastFillTag = "";
   g_UltraDisc[idx].lastFillEpoch = 0;
   g_UltraDisc[idx].lastThesis = "";
   g_UltraDisc[idx].valid = true;
   return idx;
}

int UltraDisc_StructEpoch(const UltraSnap &u)
{
   int e = 0;
   if(u.st.hh) e += 1;
   if(u.st.hl) e += 2;
   if(u.st.lh) e += 4;
   if(u.st.ll) e += 8;
   if(u.st.externalBull) e += 16;
   if(u.st.externalBear) e += 32;
   if(u.bos.buy) e += 64;
   if(u.bos.sell) e += 128;
   if(u.bos.confirmed) e += 256;
   if(u.choch.buy) e += 512;
   if(u.choch.sell) e += 1024;
   if(u.liq.sweepBuy) e += 2048;
   if(u.liq.sweepSell) e += 4096;
   e += (u.st.quality / 10) * 8192;
   return e;
}

bool UltraDisc_HasOpenDir(const string s, const bool buySide)
{
   int d = UltraSymDir(s);
   if(buySide) return (d == 1 || d == 2);
   return (d == -1 || d == 2);
}

bool UltraDisc_TFBull(const string s, const ENUM_TIMEFRAMES tf)
{
   double sma = UltraSMA(s, tf, 20, 1);
   if(sma <= 0.0) return false;
   return (iClose(s, tf, 1) > sma);
}

bool UltraDisc_TFBear(const string s, const ENUM_TIMEFRAMES tf)
{
   double sma = UltraSMA(s, tf, 20, 1);
   if(sma <= 0.0) return false;
   return (iClose(s, tf, 1) < sma);
}

//--------------------------------------------------------------------//
// RULE #1 — ZERO IRREGULAR ENTRIES (multi-confirmation)
//--------------------------------------------------------------------//
bool UltraDisc_R1_MultiConfirm(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool structure = buySide
      ? (u.st.hh || u.st.hl || u.st.externalBull || u.st.internalBull || u.st.continuation)
      : (u.st.lh || u.st.ll || u.st.externalBear || u.st.internalBear || u.st.continuation);
   bool trend = buySide
      ? (u.trend.bull || u.trend.htfBull || u.trend.macroBull)
      : (u.trend.bear || u.trend.htfBear || u.trend.macroBear);
   bool bosCh = buySide ? (u.bos.buy || u.choch.buy) : (u.bos.sell || u.choch.sell);
   bool liq = buySide
      ? (u.liq.sweepBuy || u.liq.stopHuntBuy || u.liq.grabBuy || u.liq.equalLows)
      : (u.liq.sweepSell || u.liq.stopHuntSell || u.liq.grabSell || u.liq.equalHighs);
   bool fib = buySide ? (u.fib.atBuyZone || u.ict.inDiscount) : (u.fib.atSellZone || u.ict.inPremium);
   bool mom = buySide
      ? (u.mom.momBuy || u.mom.impulse || u.ict.dispBuy || u.ind.smi > 0)
      : (u.mom.momSell || u.mom.impulse || u.ict.dispSell || u.ind.smi < 0);

   int n = (structure?1:0)+(trend?1:0)+(bosCh?1:0)+(liq?1:0)+(fib?1:0)+(mom?1:0);
   int need = UltraDisc_Soft() ? 3 : 4;
   if(n >= need) return true;
   why = "R1 irregular: only " + IntegerToString(n) + "/" + IntegerToString(need) + " confirms";
   return false;
}

//--------------------------------------------------------------------//
// RULE #2 — TRADE THESIS VALIDATION
//--------------------------------------------------------------------//
bool UltraDisc_R2_Thesis(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   // Defense Lines already validate the stack; re-check score floors here
   if(u.score.confluence < UltraFireFloor() && u.score.confidence < UltraInstantFireConf)
   {
      if(!(InstantQualityMode && u.score.confidence >= UltraFireFloor() - 8))
      { why = "R2 thesis: confluence fail"; return false; }
   }
   if(u.score.precision < UltraMinPrecision && u.score.confidence < UltraInstantFireConf)
   {
      if(!(InstantQualityMode && u.score.precision >= UltraMinPrecision - 8))
      { why = "R2 thesis: precision fail"; return false; }
   }
   if(u.score.probability < UltraMinProbability && u.score.confidence < UltraInstantFireConf)
   {
      if(!(InstantQualityMode && u.score.probability >= UltraMinProbability - 8))
      { why = "R2 thesis: probability fail"; return false; }
   }
   // directional thesis must exist
   bool sideBias = buySide ? (u.trend.bull || u.bos.buy || u.choch.buy || u.st.continuation)
                           : (u.trend.bear || u.bos.sell || u.choch.sell || u.st.continuation);
   if(!sideBias && !UltraDisc_Soft())
   { why = "R2 thesis: side bias missing"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// RULE #3 — SIGNAL STABILITY (no flicker / one-tick)
//--------------------------------------------------------------------//
bool UltraDisc_R3_Stability(const int idx, const bool buySide, string &why)
{
   why = "";
   int dir = buySide ? 1 : -1;
   datetime bar = iTime(g_UltraDisc[idx].symbol, UltraETF(), 0);

   if(g_UltraDisc[idx].lastDir == dir)
      g_UltraDisc[idx].stableCount++;
   else
   {
      g_UltraDisc[idx].lastDir = dir;
      g_UltraDisc[idx].stableCount = 1;
   }
   g_UltraDisc[idx].lastEvalBar = bar;

   int need = UltraDisciplineStableEvals;
   if(need < 1) need = 1;
   if(UltraDisc_Soft() && InstantQualityMode && need > 2) need = 2;
   if(!UltraDisc_Soft() && need < 2) need = 2;

   if(g_UltraDisc[idx].stableCount >= need) return true;
   why = "R3 unstable signal " + IntegerToString(g_UltraDisc[idx].stableCount) + "/" + IntegerToString(need);
   return false;
}

//--------------------------------------------------------------------//
// RULE #4 — CONFIRMATION LOCK (ordered checklist)
//--------------------------------------------------------------------//
bool UltraDisc_R4_ConfirmLock(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   // Ordered chain: Structure → Trend → Liquidity → Momentum → Confluence → Precision → Probability
   bool structure = buySide
      ? (u.st.hh || u.st.hl || u.st.externalBull || u.st.internalBull || u.st.continuation)
      : (u.st.lh || u.st.ll || u.st.externalBear || u.st.internalBear || u.st.continuation);
   if(!structure){ why = "R4 lock: structure"; return false; }

   bool trend = buySide
      ? (u.trend.bull || u.trend.htfBull || u.trend.macroBull || u.trend.mtfVotesBuy >= u.trend.mtfVotesSell)
      : (u.trend.bear || u.trend.htfBear || u.trend.macroBear || u.trend.mtfVotesSell >= u.trend.mtfVotesBuy);
   if(!trend && !UltraDisc_Soft()){ why = "R4 lock: trend"; return false; }

   bool liq = buySide
      ? (u.liq.sweepBuy || u.liq.stopHuntBuy || u.liq.grabBuy || u.liq.equalLows || u.liq.quality >= 20)
      : (u.liq.sweepSell || u.liq.stopHuntSell || u.liq.grabSell || u.liq.equalHighs || u.liq.quality >= 20);
   if(!liq && !UltraDisc_Soft()){ why = "R4 lock: liquidity"; return false; }

   bool mom = buySide
      ? (u.mom.momBuy || u.mom.impulse || u.ict.dispBuy || u.ind.smi >= 0)
      : (u.mom.momSell || u.mom.impulse || u.ict.dispSell || u.ind.smi <= 0);
   if(!mom && !UltraDisc_Soft()){ why = "R4 lock: momentum"; return false; }

   if(u.score.confluence < 20 && u.score.confidence < 20)
   { why = "R4 lock: confluence"; return false; }
   if(u.score.precision < 20 && !UltraDisc_Soft())
   { why = "R4 lock: precision"; return false; }
   if(u.score.probability < 20 && !UltraDisc_Soft())
   { why = "R4 lock: probability"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// RULE #5 — MASTER TREND LOCK
//--------------------------------------------------------------------//
bool UltraDisc_R5_MasterTrend(const string s, const bool buySide, string &why)
{
   why = "";
   if(!UltraMasterTrendLock) return true;

   // H4 bias + D1 macro as master (no UFSE dependency — this module loads before UFSE)
   bool bull = UltraDisc_TFBull(s, UltraTF_Bias) || UltraDisc_TFBull(s, UltraTF_Macro);
   bool bear = UltraDisc_TFBear(s, UltraTF_Bias) || UltraDisc_TFBear(s, UltraTF_Macro);
   if(bull && bear) return true; // mixed → fail-open
   if(!bull && !bear) return true; // neutral → fail-open
   if(bull && !buySide){ why = "R5 master trend BUY-only"; return false; }
   if(bear && buySide){ why = "R5 master trend SELL-only"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// RULE #6 — TIMEFRAME AGREEMENT (H4→H1→M30→M15→M5)
//--------------------------------------------------------------------//
bool UltraDisc_R6_Timeframes(const string s, const bool buySide, string &why)
{
   why = "";
   ENUM_TIMEFRAMES tfs[5];
   tfs[0] = PERIOD_H4;
   tfs[1] = PERIOD_H1;
   tfs[2] = PERIOD_M30;
   tfs[3] = PERIOD_M15;
   tfs[4] = PERIOD_M5;

   int agree = 0;
   int known = 0;
   bool h4ok = false;
   bool h4known = false;

   for(int i = 0; i < 5; i++)
   {
      double sma = UltraSMA(s, tfs[i], 20, 1);
      if(sma <= 0.0) continue;
      known++;
      bool bull = (iClose(s, tfs[i], 1) > sma);
      bool bear = (iClose(s, tfs[i], 1) < sma);
      bool ok = buySide ? bull : bear;
      if(ok) agree++;
      if(i == 0)
      {
         h4known = true;
         h4ok = ok;
      }
   }

   if(known == 0) return true; // fail-open if no TF data

   int need = UltraDisciplineMTFMinAgree;
   if(need < 1) need = 1;
   if(need > 5) need = 5;
   if(UltraDisc_Soft() && need > 3) need = 3;

   if(!UltraDisc_Soft() && h4known && !h4ok)
   { why = "R6 TF hierarchy: H4 against thesis"; return false; }

   // Timeframe synchronization + no conflicts (MN→M5 / master lock)
   string cf = "";
   if(!UltraMTF_NoConflict(s, buySide, cf))
   {
      if(!UltraDisc_Soft())
      { why = cf; return false; }
      // soft: allow only if agreement already strong
      if(agree < need)
      { why = cf; return false; }
   }

   if(agree >= need) return true;
   why = "R6 TF agree " + IntegerToString(agree) + "/" + IntegerToString(need);
   return false;
}

//--------------------------------------------------------------------//
// RULE #7 — DUPLICATE PROTECTION
//--------------------------------------------------------------------//
bool UltraDisc_R7_Duplicate(const int idx, const bool buySide, const string tag, string &why)
{
   why = "";
   string s = g_UltraDisc[idx].symbol;
   datetime bar = iTime(s, UltraETF(), 0);
   int dir = buySide ? 1 : -1;

   // same direction already open
   if(UltraDisc_HasOpenDir(s, buySide))
   { why = "R7 duplicate: same direction open"; return false; }

   // same candle as last successful fill (same dir)
   if(g_UltraDisc[idx].lastFillBar > 0 && bar == g_UltraDisc[idx].lastFillBar &&
      g_UltraDisc[idx].lastFillDir == dir)
   { why = "R7 duplicate: same candle fill"; return false; }

   // same tag+dir filled moments ago (tick spam)
   if(g_UltraDisc[idx].lastFillTime > 0 &&
      g_UltraDisc[idx].lastFillDir == dir &&
      g_UltraDisc[idx].lastFillTag == tag &&
      (TimeCurrent() - g_UltraDisc[idx].lastFillTime) < 2)
   { why = "R7 duplicate: same tick/setup"; return false; }

   return true;
}

//--------------------------------------------------------------------//
// RULE #8 — ENTRY QUALITY CHECK
//--------------------------------------------------------------------//
bool UltraDisc_R8_Quality(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool location = buySide
      ? (u.fib.atBuyZone || u.ict.obBuy || u.ict.fvgBuy || u.ict.instZoneBuy || u.ict.inDiscount || UltraDisc_Soft())
      : (u.fib.atSellZone || u.ict.obSell || u.ict.fvgSell || u.ict.instZoneSell || u.ict.inPremium || UltraDisc_Soft());
   bool rr = (u.score.precision >= UltraMinPrecision || u.score.confidence >= UltraInstantFireConf ||
              (InstantQualityMode && u.score.precision >= UltraMinPrecision - 8));
   bool liqPos = buySide
      ? (u.liq.sweepBuy || u.liq.grabBuy || u.liq.stopHuntBuy || u.liq.quality >= 15 || UltraDisc_Soft())
      : (u.liq.sweepSell || u.liq.grabSell || u.liq.stopHuntSell || u.liq.quality >= 15 || UltraDisc_Soft());
   bool structure = (u.st.quality >= 20 || u.st.strength >= 20 || UltraDisc_Soft());
   bool trendAlign = buySide
      ? (u.trend.bull || u.trend.htfBull || u.trend.mtfVotesBuy >= u.trend.mtfVotesSell || UltraDisc_Soft())
      : (u.trend.bear || u.trend.htfBear || u.trend.mtfVotesSell >= u.trend.mtfVotesBuy || UltraDisc_Soft());

   if(location && rr && liqPos && structure && trendAlign) return true;
   why = "R8 entry quality incomplete";
   return false;
}

//--------------------------------------------------------------------//
// RULE #9 — BROKER VALIDATION
//--------------------------------------------------------------------//
bool UltraDisc_R9_Broker(const string s, string &why)
{
   why = "";
   string w = "";
   if(UltraDefenseEnabled)
   {
      if(!UltraDefense_Line7_Execution(s, w))
      { why = "R9 broker: " + w; return false; }
      return true;
   }
   if(!TerminalInfoInteger(TERMINAL_CONNECTED)){ why = "R9 connection"; return false; }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)){ why = "R9 trading blocked"; return false; }
   if(!MQLInfoInteger(MQL_TRADE_ALLOWED)){ why = "R9 EA disabled"; return false; }
   long tm = 0;
   if(!SymbolInfoInteger(s, SYMBOL_TRADE_MODE, tm) || tm == 0){ why = "R9 market closed/disabled"; return false; }
   double bid = SymbolInfoDouble(s, SYMBOL_BID);
   double ask = SymbolInfoDouble(s, SYMBOL_ASK);
   if(bid <= 0.0 || ask <= 0.0){ why = "R9 price not fresh"; return false; }
   if(AccountInfoDouble(ACCOUNT_MARGIN_FREE) <= 0.0){ why = "R9 no margin"; return false; }
   double vmin = SymbolInfoDouble(s, SYMBOL_VOLUME_MIN);
   if(vmin <= 0.0){ why = "R9 invalid volume"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// RULE #11 — TRADE COOL-DOWN (structure / BOS / CHoCH / trade done)
//--------------------------------------------------------------------//
bool UltraDisc_R11_Cooldown(const int idx, const UltraSnap &u, const bool buySide, const string tag, string &why)
{
   why = "";
   string s = g_UltraDisc[idx].symbol;
   int dir = buySide ? 1 : -1;

   // trade completed ⇒ unlock
   if(!UltraDisc_HasOpenDir(s, buySide))
   {
      if(!UltraDisciplineNeedNewStruct) return true;
      // strict optional: need new structure epoch vs last fill
      if(g_UltraDisc[idx].lastFillDir != dir || g_UltraDisc[idx].lastFillTime <= 0)
         return true;
      int epoch = UltraDisc_StructEpoch(u);
      if(epoch != g_UltraDisc[idx].lastFillEpoch) return true;
      // also accept tag change as new setup
      if(tag != g_UltraDisc[idx].lastFillTag && StringLen(tag) > 0) return true;
      why = "R11 cooldown: waiting new structure/BOS/CHoCH";
      return false;
   }

   // still open — blocked (also covered by R7)
   why = "R11 cooldown: trade still open";
   return false;
}

//--------------------------------------------------------------------//
// RULE #12 — EXPLAINABLE THESIS
//--------------------------------------------------------------------//
string UltraDisc_BuildThesis(const UltraSnap &u, const bool buySide, const string tag)
{
   string side = "SELL";
   if(buySide) side = "BUY";
   string t = "THESIS ";
   t += side;
   t += " [";
   t += tag;
   t += "] conf=";
   t += IntegerToString(u.score.confidence);
   t += " prec=";
   t += IntegerToString(u.score.precision);
   t += " prob=";
   t += IntegerToString(u.score.probability);
   t += " conj=";
   t += IntegerToString(u.score.confluence);
   t += " | trend=";
   t += IntegerToString(u.trend.strength);
   t += " bos=";
   if(buySide) { if(u.bos.buy) t += "Y"; else t += "N"; }
   else { if(u.bos.sell) t += "Y"; else t += "N"; }
   t += " choch=";
   if(buySide) { if(u.choch.buy) t += "Y"; else t += "N"; }
   else { if(u.choch.sell) t += "Y"; else t += "N"; }
   t += " liq=";
   if(buySide) { if(u.liq.sweepBuy || u.liq.grabBuy) t += "Y"; else t += "N"; }
   else { if(u.liq.sweepSell || u.liq.grabSell) t += "Y"; else t += "N"; }
   t += " fib=";
   if(buySide) { if(u.fib.atBuyZone) t += "Y"; else t += "N"; }
   else { if(u.fib.atSellZone) t += "Y"; else t += "N"; }
   t += " mom=";
   if(buySide) { if(u.mom.momBuy || u.mom.impulse) t += "Y"; else t += "N"; }
   else { if(u.mom.momSell || u.mom.impulse) t += "Y"; else t += "N"; }
   return t;
}

bool UltraDisc_R12_Explainable(const UltraSnap &u, const bool buySide, const string tag, string &thesis, string &why)
{
   why = "";
   thesis = UltraDisc_BuildThesis(u, buySide, tag);
   if(tag == "" || tag == "NONE")
   { why = "R12 no strategy tag"; return false; }
   if(u.score.confidence <= 0 && u.score.confluence <= 0)
   { why = "R12 empty score thesis"; return false; }
   if(StringLen(thesis) < 20)
   { why = "R12 incomplete thesis"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// RULE #10 — SUPREME AI APPROVAL (all required rules)
//--------------------------------------------------------------------//
bool UltraDiscipline_AllowEntry(const string s, const UltraSnap &u, const UltraSignal &sig, string &why)
{
   why = "";
   g_UltraDiscLastSummary = "DISCIPLINE OFF";
   if(!UltraDisciplineEnabled) return true;

   if(!(sig.buy || sig.sell) || sig.tag == "NONE")
   { why = "DISCIPLINE: no signal"; return false; }

   bool buySide = sig.buy;
   int idx = UltraDisc_Ensure(s);
   string w = "";
   string summary = "DISCIPLINE";

   // R1
   if(!UltraDisc_R1_MultiConfirm(u, buySide, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R2
   w = ""; if(!UltraDisc_R2_Thesis(u, buySide, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R3
   w = ""; if(!UltraDisc_R3_Stability(idx, buySide, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R4
   w = ""; if(!UltraDisc_R4_ConfirmLock(u, buySide, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R5
   w = ""; if(!UltraDisc_R5_MasterTrend(s, buySide, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R6
   w = ""; if(!UltraDisc_R6_Timeframes(s, buySide, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R7
   w = ""; if(!UltraDisc_R7_Duplicate(idx, buySide, sig.tag, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R8
   w = ""; if(!UltraDisc_R8_Quality(u, buySide, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R9
   w = ""; if(!UltraDisc_R9_Broker(s, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R11
   w = ""; if(!UltraDisc_R11_Cooldown(idx, u, buySide, sig.tag, w)) { why = w; g_UltraDiscLastSummary = w; return false; }
   // R12
   string thesis = "";
   w = ""; if(!UltraDisc_R12_Explainable(u, buySide, sig.tag, thesis, w)) { why = w; g_UltraDiscLastSummary = w; return false; }

   g_UltraDisc[idx].lastThesis = thesis;
   summary = "DISCIPLINE PASS | ";
   summary += thesis;
   g_UltraDiscLastSummary = summary;

   if(UltraDisciplineLog)
      Print(summary, " on ", s);

   return true;
}

void UltraDiscipline_OnFill(const string s, const bool buySide, const string tag, const UltraSnap &u)
{
   int idx = UltraDisc_Ensure(s);
   g_UltraDisc[idx].lastFillTime = TimeCurrent();
   g_UltraDisc[idx].lastFillBar = iTime(s, UltraETF(), 0);
   g_UltraDisc[idx].lastFillDir = buySide ? 1 : -1;
   g_UltraDisc[idx].lastFillTag = tag;
   g_UltraDisc[idx].lastFillEpoch = UltraDisc_StructEpoch(u);
   // reset stability so next trade must re-confirm
   g_UltraDisc[idx].stableCount = 0;
   g_UltraDisc[idx].lastDir = 0;
}

string UltraDiscipline_DashboardLine()
{
   if(!UltraDisciplineEnabled) return "DISCIPLINE: OFF";
   if(StringLen(g_UltraDiscLastSummary) == 0) return "DISCIPLINE: READY";
   // keep dashboard short
   if(StringFind(g_UltraDiscLastSummary, "PASS") >= 0) return "DISCIPLINE: PASS";
   return "DISCIPLINE: WAIT";
}

#endif // HITMAN_ULTRA_TRADE_ENTRY_DISCIPLINE_MQH
//===== END TradeEntryDiscipline.mqh =====

//===== BEGIN DynamicWeights.mqh =====
#ifndef HITMAN_ULTRA_DYNAMIC_WEIGHTS_MQH
#define HITMAN_ULTRA_DYNAMIC_WEIGHTS_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 5 DYNAMIC WEIGHT ENGINE                        |
//| Regime-based module weights (soft, neutral by default)           |
//+------------------------------------------------------------------+

struct UltraDynWeights
{
   double structure;
   double trend;
   double bos;
   double choch;
   double liquidity;
   double fibonacci;
   double institutional;
   double momentum;
   double volatility;
   double regime;
   double session;
   double news;
   double precision;
   double probability;
   double risk;
   double execution;
};

void UltraWeights_Neutral(UltraDynWeights &w)
{
   w.structure = w.trend = w.bos = w.choch = w.liquidity = 1.0;
   w.fibonacci = w.institutional = w.momentum = w.volatility = 1.0;
   w.regime = w.session = w.news = 1.0;
   w.precision = w.probability = w.risk = w.execution = 1.0;
}

void UltraWeights_FromRegime(const ENUM_ULTRA_REGIME r, UltraDynWeights &w)
{
   UltraWeights_Neutral(w);
   if(!UltraUpgradeEnabled || !UltraDynWeightsEnabled) return;

   // Soft boosts only (±0.15) so InstantQuality is not frozen
   if(r == UREG_STRONG_TREND || r == UREG_HEALTHY_TREND || r == UREG_WEAK_TREND || r == UREG_BREAKOUT)
   {
      w.trend = 1.15; w.bos = 1.12; w.momentum = 1.12; w.structure = 0.95;
   }
   else if(r == UREG_RANGE || r == UREG_ACCUMULATION || r == UREG_DISTRIBUTION || r == UREG_COMPRESSION)
   {
      w.structure = 1.15; w.liquidity = 1.12; w.precision = 1.12; w.trend = 0.95;
   }
   else if(r == UREG_EXPANSION || r == UREG_REVERSAL || r == UREG_EXHAUSTION)
   {
      w.volatility = 1.15; w.risk = 1.15; w.probability = 1.08; w.momentum = 0.95;
   }
}

int UltraWeights_Apply(const int raw, const double weight)
{
   double v = (double)raw * weight;
   int out = (int)MathRound(v);
   if(out < 0) out = 0;
   if(out > 100) out = 100;
   // Soft mode: clamp movement vs raw to ±5
   if(!UltraUpgradeStrict)
   {
      int lo = raw - 5; if(lo < 0) lo = 0;
      int hi = raw + 5; if(hi > 100) hi = 100;
      if(out < lo) out = lo;
      if(out > hi) out = hi;
   }
   return out;
}

#endif
//===== END DynamicWeights.mqh =====

//===== BEGIN UltraScoringMachine2.mqh =====
#ifndef HITMAN_ULTRA_USM2_MQH
#define HITMAN_ULTRA_USM2_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 4 ULTRA SCORING MACHINE 2.0                    |
//| Component scores → Final AI Confidence + Trade Score             |
//+------------------------------------------------------------------+

struct UltraUSM2Scores
{
   int structure, trend, bos, choch, liquidity, fibonacci, institutional;
   int momentum, volatility, regime, session, news, precision, probability;
   int risk, execution;
   int confidence;   // Final AI Confidence 0-100
   int tradeScore;   // Final Trade Score 0-100
   string grade;     // LEGENDARY..IGNORE
};

string UltraUSM2_Grade(const double finalScore)
{
   if(finalScore >= 98.0) return "LEGENDARY";
   if(finalScore >= 95.0) return "ELITE";
   if(finalScore >= 90.0) return "INSTITUTIONAL";
   if(finalScore >= 85.0) return "PROFESSIONAL";
   if(finalScore >= 80.0) return "STRONG";
   if(finalScore >= 75.0) return "WATCHLIST";
   return "IGNORE";
}

int UltraUSM2_Clamp(const int v)
{
   if(v < 0) return 0;
   if(v > 100) return 100;
   return v;
}

int UltraUSM2_ComponentStructure(const UltraSnap &u, const bool buySide)
{
   int sc = 20;
   if(buySide)
   {
      if(u.st.hh || u.st.hl) sc += 20;
      if(u.st.externalBull || u.st.internalBull) sc += 15;
      if(u.st.continuation) sc += 10;
   }
   else
   {
      if(u.st.lh || u.st.ll) sc += 20;
      if(u.st.externalBear || u.st.internalBear) sc += 15;
      if(u.st.continuation) sc += 10;
   }
   sc += u.st.quality / 4;
   sc += u.st.strength / 5;
   if(u.st.swingHighOK || u.st.swingLowOK) sc += 8;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentTrend(const UltraSnap &u, const bool buySide)
{
   int sc = 15;
   if(buySide)
   {
      if(u.trend.bull) sc += 20; if(u.trend.htfBull) sc += 15; if(u.trend.macroBull) sc += 12;
      sc += u.trend.mtfVotesBuy * 4;
   }
   else
   {
      if(u.trend.bear) sc += 20; if(u.trend.htfBear) sc += 15; if(u.trend.macroBear) sc += 12;
      sc += u.trend.mtfVotesSell * 4;
   }
   sc += u.trend.strength / 4;
   sc += u.trend.persistence / 5;
   if(u.trend.exhaustion) sc -= 10;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentBOS(const UltraSnap &u, const bool buySide)
{
   int sc = 10;
   bool hit = buySide ? u.bos.buy : u.bos.sell;
   if(hit) sc += 35;
   if(u.bos.confirmed) sc += 15;
   if(u.bos.strong) sc += 20;
   if(u.bos.weak) sc += 5;
   if(u.bos.failed) sc -= 25;
   sc += u.bos.score / 5;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentCHoCH(const UltraSnap &u, const bool buySide)
{
   int sc = 10;
   bool hit = buySide ? u.choch.buy : u.choch.sell;
   if(hit) sc += 35;
   if(u.choch.majorC) sc += 20;
   if(u.choch.minorC) sc += 8;
   if(u.choch.internalC) sc += 8;
   if(u.choch.externalC) sc += 10;
   sc += u.choch.confidence / 5;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentLiquidity(const UltraSnap &u, const bool buySide)
{
   int sc = 10;
   if(buySide)
   {
      if(u.liq.sweepBuy) sc += 30; if(u.liq.stopHuntBuy) sc += 15;
      if(u.liq.grabBuy) sc += 15; if(u.liq.equalLows) sc += 10;
      if(u.liq.confirmedBuy) sc += 10;
   }
   else
   {
      if(u.liq.sweepSell) sc += 30; if(u.liq.stopHuntSell) sc += 15;
      if(u.liq.grabSell) sc += 15; if(u.liq.equalHighs) sc += 10;
      if(u.liq.confirmedSell) sc += 10;
   }
   sc += (int)(u.liq.quality / 4.0);
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentFib(const UltraSnap &u, const bool buySide)
{
   int sc = 15;
   if(buySide && u.fib.atBuyZone) sc += 35;
   if(!buySide && u.fib.atSellZone) sc += 35;
   if(u.fib.impulseOK) sc += 15;
   sc += u.fib.quality / 4;
   sc += u.fib.confluence / 5;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentInst(const UltraSnap &u, const bool buySide)
{
   int sc = 10;
   if(buySide)
   {
      if(u.ict.obBuy) sc += 18; if(u.ict.breakerBuy) sc += 12;
      if(u.ict.fvgBuy) sc += 15; if(u.ict.instZoneBuy) sc += 18;
      if(u.ict.inDiscount) sc += 12; if(u.ict.dispBuy) sc += 15;
   }
   else
   {
      if(u.ict.obSell) sc += 18; if(u.ict.breakerSell) sc += 12;
      if(u.ict.fvgSell) sc += 15; if(u.ict.instZoneSell) sc += 18;
      if(u.ict.inPremium) sc += 12; if(u.ict.dispSell) sc += 15;
   }
   if(u.ict.smConfluence) sc += 10;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentMom(const UltraSnap &u, const bool buySide)
{
   int sc = 15;
   if(buySide){ if(u.mom.momBuy) sc += 25; if(u.ind.smi > 0) sc += 15; }
   else { if(u.mom.momSell) sc += 25; if(u.ind.smi < 0) sc += 15; }
   if(u.mom.impulse) sc += 20;
   sc += u.mom.strength / 4;
   sc += u.mom.acceleration / 5;
   if(u.mom.weakness) sc -= 12;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentVol(const UltraSnap &u)
{
   int sc = 40;
   if(u.vol.expansion) sc += 25;
   if(u.vol.compression) sc += 10;
   sc += (int)MathMin(25.0, u.vol.relative * 20.0);
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentRegime(const UltraSnap &u)
{
   int sc = 40;
   if(u.regime == UREG_STRONG_TREND || u.regime == UREG_HEALTHY_TREND) sc = 80;
   else if(u.regime == UREG_BREAKOUT || u.regime == UREG_EXPANSION) sc = 70;
   else if(u.regime == UREG_WEAK_TREND) sc = 60;
   else if(u.regime == UREG_RANGE || u.regime == UREG_COMPRESSION) sc = 45;
   else if(u.regime == UREG_REVERSAL || u.regime == UREG_EXHAUSTION) sc = 35;
   return sc;
}

int UltraUSM2_ComponentSession(const UltraSnap &u)
{
   int sc = 35;
   if(u.ctx.sessionLiquidity) sc += 25;
   if(u.ctx.killZone) sc += 15;
   if(u.ctx.overlap) sc += 15;
   sc += u.ctx.sessionQuality / 4;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentNews(const UltraSnap &u)
{
   int sc = 55;
   // context only — never hard-block; mild adjustment
   if(u.ctx.newsVol) sc += 10;
   if(u.ctx.duringNews) sc -= 8;
   if(u.ctx.spreadPts > 30) sc -= 10;
   return UltraUSM2_Clamp(sc);
}

int UltraUSM2_ComponentRisk(const UltraSnap &u)
{
   int sc = 100 - UltraUSM2_Clamp(u.score.riskProb);
   if(sc < 20) sc = 20;
   return sc;
}

int UltraUSM2_ComponentExec(const string s)
{
   string why = "";
   if(UltraDefense_Line7_Execution(s, why)) return 85;
   return 25;
}

void UltraUSM2_Score(const string s, UltraSnap &u, const bool buySide, UltraUSM2Scores &out)
{
   UltraDynWeights w;
   UltraWeights_FromRegime(u.regime, w);

   out.structure = UltraWeights_Apply(UltraUSM2_ComponentStructure(u, buySide), w.structure);
   out.trend = UltraWeights_Apply(UltraUSM2_ComponentTrend(u, buySide), w.trend);
   out.bos = UltraWeights_Apply(UltraUSM2_ComponentBOS(u, buySide), w.bos);
   out.choch = UltraWeights_Apply(UltraUSM2_ComponentCHoCH(u, buySide), w.choch);
   out.liquidity = UltraWeights_Apply(UltraUSM2_ComponentLiquidity(u, buySide), w.liquidity);
   out.fibonacci = UltraWeights_Apply(UltraUSM2_ComponentFib(u, buySide), w.fibonacci);
   out.institutional = UltraWeights_Apply(UltraUSM2_ComponentInst(u, buySide), w.institutional);
   out.momentum = UltraWeights_Apply(UltraUSM2_ComponentMom(u, buySide), w.momentum);
   out.volatility = UltraWeights_Apply(UltraUSM2_ComponentVol(u), w.volatility);
   out.regime = UltraWeights_Apply(UltraUSM2_ComponentRegime(u), w.regime);
   out.session = UltraWeights_Apply(UltraUSM2_ComponentSession(u), w.session);
   out.news = UltraWeights_Apply(UltraUSM2_ComponentNews(u), w.news);

   // precision/probability from existing engines, then weight
   int prec = UltraPrecisionScore(u);
   int confLegacy = buySide ? UltraConfluenceBuy(u) : UltraConfluenceSell(u);
   int prob = UltraProbabilityScore(u, confLegacy, prec);
   out.precision = UltraWeights_Apply(prec, w.precision);
   out.probability = UltraWeights_Apply(prob, w.probability);
   out.risk = UltraWeights_Apply(UltraUSM2_ComponentRisk(u), w.risk);
   out.execution = UltraWeights_Apply(UltraUSM2_ComponentExec(s), w.execution);

   // Weighted blend → confidence
   double conf =
      out.structure * 0.10 + out.trend * 0.12 + out.bos * 0.10 + out.choch * 0.08 +
      out.liquidity * 0.10 + out.fibonacci * 0.06 + out.institutional * 0.08 +
      out.momentum * 0.08 + out.volatility * 0.04 + out.regime * 0.04 +
      out.session * 0.03 + out.news * 0.02 + out.precision * 0.07 + out.probability * 0.08;
   out.confidence = UltraUSM2_Clamp((int)MathRound(conf));

   double tradeBlend =
      out.confidence * 0.55 + out.precision * 0.20 + out.probability * 0.15 +
      out.execution * 0.05 + out.risk * 0.05;
   out.tradeScore = UltraUSM2_Clamp((int)MathRound(tradeBlend));
   out.grade = UltraUSM2_Grade((double)out.tradeScore);

   // Write back into snap scores (USM2 owns final confidence when enabled)
   u.score.confluence = out.confidence;
   u.score.confidence = out.confidence;
   u.score.precision = out.precision;
   u.score.probability = out.probability;
   u.score.successProb = out.probability;
   u.score.riskProb = UltraUSM2_Clamp(100 - out.probability);
}

string UltraUSM2_LogLine(const UltraUSM2Scores &o)
{
   string t = "USM2 conf=";
   t += IntegerToString(o.confidence);
   t += " trade=";
   t += IntegerToString(o.tradeScore);
   t += " grade=";
   t += o.grade;
   t += " ST="; t += IntegerToString(o.structure);
   t += " TR="; t += IntegerToString(o.trend);
   t += " BOS="; t += IntegerToString(o.bos);
   t += " CH="; t += IntegerToString(o.choch);
   t += " LQ="; t += IntegerToString(o.liquidity);
   return t;
}

UltraUSM2Scores g_UltraUSM2Last;

#endif
//===== END UltraScoringMachine2.mqh =====

//===== BEGIN SignalEvolution.mqh =====
#ifndef HITMAN_ULTRA_SIGNAL_EVOLUTION_MQH
#define HITMAN_ULTRA_SIGNAL_EVOLUTION_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 3 SIGNAL EVOLUTION ENGINE                      |
//| Improvement / weakening / correction / true reversal / stability |
//+------------------------------------------------------------------+

enum ENUM_SIGNAL_EVOLUTION
{
   SEVO_IMPROVING = 0,
   SEVO_STABLE,
   SEVO_WEAKENING,
   SEVO_CORRECTION,
   SEVO_REVERSAL,
   SEVO_UNKNOWN
};

struct UltraSignalEvo
{
   ENUM_SIGNAL_EVOLUTION state;
   int stability;      // 0-100
   int deltaConf;      // confidence change
   string label;
};

int g_Evo_PrevConf = 0;
int g_Evo_PrevDir = 0;
datetime g_Evo_PrevBar = 0;

string UltraEvo_Name(const ENUM_SIGNAL_EVOLUTION e)
{
   if(e == SEVO_IMPROVING) return "IMPROVING";
   if(e == SEVO_STABLE) return "STABLE";
   if(e == SEVO_WEAKENING) return "WEAKENING";
   if(e == SEVO_CORRECTION) return "CORRECTION";
   if(e == SEVO_REVERSAL) return "REVERSAL";
   return "UNKNOWN";
}

string g_Evo_PrevSym = "";

UltraSignalEvo UltraEvo_Evaluate(const string s, const UltraSnap &u, const bool buySide)
{
   UltraSignalEvo e;
   e.state = SEVO_UNKNOWN;
   e.stability = 50;
   e.deltaConf = 0;
   e.label = "UNKNOWN";
   if(!UltraUpgradeEnabled || !UltraSignalEvoEnabled) { e.state = SEVO_STABLE; e.label = "STABLE"; return e; }

   int dir = buySide ? 1 : -1;
   int conf = u.score.confidence;
   datetime bar = iTime(s, UltraETF(), 0);
   if(bar <= 0) bar = TimeCurrent();
   e.deltaConf = conf - g_Evo_PrevConf;

   bool against = buySide
      ? (u.bos.sell && u.bos.confirmed) || (u.choch.sell && u.choch.majorC)
      : (u.bos.buy && u.bos.confirmed) || (u.choch.buy && u.choch.majorC);
   bool softPull = buySide
      ? (u.mom.weakness || u.ind.smi < 0) && !against
      : (u.mom.weakness || u.ind.smi > 0) && !against;

   if(against && u.trend.exhaustion)
      e.state = SEVO_REVERSAL;
   else if(softPull)
      e.state = SEVO_CORRECTION;
   else if(e.deltaConf >= 5 && g_Evo_PrevDir == dir)
      e.state = SEVO_IMPROVING;
   else if(e.deltaConf <= -8)
      e.state = SEVO_WEAKENING;
   else
      e.state = SEVO_STABLE;

   e.stability = UltraUSM2_Clamp(60 + e.deltaConf);
   if(e.state == SEVO_REVERSAL) e.stability = 15;
   if(e.state == SEVO_CORRECTION) e.stability = 45;
   e.label = UltraEvo_Name(e.state);

   if(bar != g_Evo_PrevBar || s != g_Evo_PrevSym)
   {
      g_Evo_PrevConf = conf;
      g_Evo_PrevDir = dir;
      g_Evo_PrevBar = bar;
      g_Evo_PrevSym = s;
   }
   return e;
}

#endif
//===== END SignalEvolution.mqh =====

//===== BEGIN TradeThesis.mqh =====
#ifndef HITMAN_ULTRA_TRADE_THESIS_MQH
#define HITMAN_ULTRA_TRADE_THESIS_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 11 TRADE THESIS ENGINE                         |
//| Store entry thesis · revalidate each new candle                  |
//+------------------------------------------------------------------+

#define ULTRA_THESIS_MAX 64

struct UltraTradeThesis
{
   ulong    ticket;
   string   symbol;
   bool     isBuy;
   string   tag;
   string   reason;          // Entry Reason
   string   marketState;
   string   structureState;
   string   trendState;
   string   bosState;        // BOS at entry
   string   chochState;      // CHoCH at entry
   string   liquidityState;
   string   fibState;        // Fibonacci at entry
   string   momentumState;
   string   riskState;
   string   confidenceState;
   double   entryPrice;
   datetime entryTime;
   int      conf, prec, prob;
   int      trendStr, structQ, bosScore, chochConf;
   bool     hadLiq, hadFib, hadMom;
   bool     hadBos, hadChoch;
   int      epoch;
   datetime openBar;
   datetime lastCheckBar;
   bool     valid;
   bool     stillValid;
   string   status;
};

UltraTradeThesis g_Thesis[ULTRA_THESIS_MAX];
int g_ThesisN = 0;

int UltraThesis_Find(const ulong ticket)
{
   for(int i = 0; i < g_ThesisN; i++)
      if(g_Thesis[i].ticket == ticket && g_Thesis[i].valid) return i;
   return -1;
}

int UltraThesis_Alloc()
{
   for(int i = 0; i < g_ThesisN; i++)
      if(!g_Thesis[i].valid) return i;
   if(g_ThesisN >= ULTRA_THESIS_MAX) return 0;
   return g_ThesisN++;
}

void UltraThesis_Store(const ulong ticket, const string s, const bool isBuy,
                       const string tag, const UltraSnap &u, const string reason)
{
   if(!UltraUpgradeEnabled || !UltraThesisEnabled) return;
   if(ticket == 0) return;
   int idx = UltraThesis_Find(ticket);
   if(idx < 0) idx = UltraThesis_Alloc();

   g_Thesis[idx].ticket = ticket;
   g_Thesis[idx].symbol = s;
   g_Thesis[idx].isBuy = isBuy;
   g_Thesis[idx].tag = tag;
   g_Thesis[idx].reason = reason;
   // Complete thesis state snapshot (Level 5 ULTRA TRADE THESIS)
   g_Thesis[idx].marketState = UltraRegimeName(u.regime);
   if(StringLen(u.st.cycleName) > 0)
   {
      g_Thesis[idx].marketState += "/";
      g_Thesis[idx].marketState += u.st.cycleName;
   }
   if(isBuy)
   {
      if(u.st.externalBull) g_Thesis[idx].structureState = "EXT_BULL";
      else if(u.st.internalBull) g_Thesis[idx].structureState = "INT_BULL";
      else g_Thesis[idx].structureState = "MIXED";
      if(u.trend.bull || u.trend.htfBull) g_Thesis[idx].trendState = "BULL";
      else g_Thesis[idx].trendState = "WEAK";
      if(u.liq.sweepBuy || u.liq.grabBuy) g_Thesis[idx].liquidityState = "SWEEP/GRAB";
      else g_Thesis[idx].liquidityState = "NONE";
      if(u.mom.momBuy || u.mom.impulse) g_Thesis[idx].momentumState = "IMPULSE";
      else if(u.mom.weakness) g_Thesis[idx].momentumState = "WEAK";
      else g_Thesis[idx].momentumState = "NEUTRAL";
   }
   else
   {
      if(u.st.externalBear) g_Thesis[idx].structureState = "EXT_BEAR";
      else if(u.st.internalBear) g_Thesis[idx].structureState = "INT_BEAR";
      else g_Thesis[idx].structureState = "MIXED";
      if(u.trend.bear || u.trend.htfBear) g_Thesis[idx].trendState = "BEAR";
      else g_Thesis[idx].trendState = "WEAK";
      if(u.liq.sweepSell || u.liq.grabSell) g_Thesis[idx].liquidityState = "SWEEP/GRAB";
      else g_Thesis[idx].liquidityState = "NONE";
      if(u.mom.momSell || u.mom.impulse) g_Thesis[idx].momentumState = "IMPULSE";
      else if(u.mom.weakness) g_Thesis[idx].momentumState = "WEAK";
      else g_Thesis[idx].momentumState = "NEUTRAL";
   }
   if(u.score.riskProb >= 70) g_Thesis[idx].riskState = "HIGH";
   else g_Thesis[idx].riskState = "OK";
   g_Thesis[idx].confidenceState = IntegerToString(u.score.confidence);

   // BOS / CHoCH / Fib memory at entry
   if(isBuy)
   {
      if(u.bos.buy) g_Thesis[idx].bosState = u.bos.strong ? "BUY_STRONG" : "BUY";
      else g_Thesis[idx].bosState = "NONE";
      if(u.choch.buy) g_Thesis[idx].chochState = u.choch.majorC ? "BUY_MAJOR" : "BUY";
      else g_Thesis[idx].chochState = "NONE";
      if(u.fib.atBuyZone) g_Thesis[idx].fibState = "BUY_ZONE";
      else g_Thesis[idx].fibState = "NONE";
   }
   else
   {
      if(u.bos.sell) g_Thesis[idx].bosState = u.bos.strong ? "SELL_STRONG" : "SELL";
      else g_Thesis[idx].bosState = "NONE";
      if(u.choch.sell) g_Thesis[idx].chochState = u.choch.majorC ? "SELL_MAJOR" : "SELL";
      else g_Thesis[idx].chochState = "NONE";
      if(u.fib.atSellZone) g_Thesis[idx].fibState = "SELL_ZONE";
      else g_Thesis[idx].fibState = "NONE";
   }
   g_Thesis[idx].hadBos = isBuy ? u.bos.buy : u.bos.sell;
   g_Thesis[idx].hadChoch = isBuy ? u.choch.buy : u.choch.sell;

   g_Thesis[idx].entryPrice = isBuy ? SymbolInfoDouble(s, SYMBOL_ASK) : SymbolInfoDouble(s, SYMBOL_BID);
   if(PositionSelectByTicket(ticket))
      g_Thesis[idx].entryPrice = PositionGetDouble(POSITION_PRICE_OPEN);
   g_Thesis[idx].entryTime = TimeCurrent();
   if(PositionSelectByTicket(ticket))
      g_Thesis[idx].entryTime = (datetime)PositionGetInteger(POSITION_TIME);

   g_Thesis[idx].conf = u.score.confidence;
   g_Thesis[idx].prec = u.score.precision;
   g_Thesis[idx].prob = u.score.probability;
   g_Thesis[idx].trendStr = u.trend.strength;
   g_Thesis[idx].structQ = u.st.quality;
   g_Thesis[idx].bosScore = u.bos.score;
   g_Thesis[idx].chochConf = u.choch.confidence;
   g_Thesis[idx].hadLiq = isBuy ? (u.liq.sweepBuy || u.liq.grabBuy) : (u.liq.sweepSell || u.liq.grabSell);
   g_Thesis[idx].hadFib = isBuy ? u.fib.atBuyZone : u.fib.atSellZone;
   g_Thesis[idx].hadMom = isBuy ? (u.mom.momBuy || u.mom.impulse) : (u.mom.momSell || u.mom.impulse);
   g_Thesis[idx].epoch = UltraDisc_StructEpoch(u);
   g_Thesis[idx].openBar = iTime(s, UltraETF(), 0);
   g_Thesis[idx].lastCheckBar = 0;
   g_Thesis[idx].valid = true;
   g_Thesis[idx].stillValid = true;
   g_Thesis[idx].status = "ACTIVE";

   // Market memory note
   UltraMemory_NoteDecision(tag, u.score.confidence);
   if(UltraUpgradeLog)
   {
      string t = "THESIS STORE ticket=";
      t += IntegerToString((int)ticket);
      t += " ";
      if(isBuy) t += "BUY"; else t += "SELL";
      t += " ["; t += tag; t += "] conf=";
      t += IntegerToString(u.score.confidence);
      UltraLogTrade(t);
   }
}

void UltraThesis_StoreLatest(const string s, const bool isBuy, const string tag,
                             const UltraSnap &u, const string reason)
{
   if(!UltraUpgradeEnabled || !UltraThesisEnabled) return;
   ulong best = 0;
   datetime newest = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || !PositionSelectByTicket(t)) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      if(PositionGetString(POSITION_SYMBOL) != s) continue;
      long ty = PositionGetInteger(POSITION_TYPE);
      if(isBuy && ty != POSITION_TYPE_BUY) continue;
      if(!isBuy && ty != POSITION_TYPE_SELL) continue;
      datetime ot = (datetime)PositionGetInteger(POSITION_TIME);
      if(ot >= newest){ newest = ot; best = t; }
   }
   if(best != 0)
      UltraThesis_Store(best, s, isBuy, tag, u, reason);
}

bool UltraThesis_Revalidate(const ulong ticket, const UltraSnap &u, string &why)
{
   why = "";
   if(!UltraUpgradeEnabled || !UltraThesisEnabled) return true;
   int idx = UltraThesis_Find(ticket);
   if(idx < 0) return true; // fail-open

   datetime bar = iTime(g_Thesis[idx].symbol, UltraETF(), 0);
   if(bar == g_Thesis[idx].lastCheckBar) return g_Thesis[idx].stillValid;
   g_Thesis[idx].lastCheckBar = bar;

   bool isBuy = g_Thesis[idx].isBuy;
   // Ask: is original thesis still valid?
   bool trendOK = isBuy
      ? (u.trend.bull || u.trend.htfBull || u.trend.macroBull || (!UltraUpgradeStrict && !u.trend.bear))
      : (u.trend.bear || u.trend.htfBear || u.trend.macroBear || (!UltraUpgradeStrict && !u.trend.bull));
   bool structOK = (u.st.quality >= 15 || u.st.continuation || UltraUSM2_Clamp(u.st.strength) >= 15);
   bool hardInvalid = isBuy
      ? ((u.bos.sell && u.bos.confirmed && u.bos.strong && u.trend.exhaustion) ||
         (u.choch.sell && u.choch.majorC && u.trend.exhaustion && u.bos.sell))
      : ((u.bos.buy && u.bos.confirmed && u.bos.strong && u.trend.exhaustion) ||
         (u.choch.buy && u.choch.majorC && u.trend.exhaustion && u.bos.buy));

   // Soft: never invalidate on a single structure flicker
   if(!UltraUpgradeStrict && hardInvalid)
   {
      // require both BOS strong + major CHoCH against
      hardInvalid = isBuy
         ? (u.bos.sell && u.bos.confirmed && u.bos.strong && u.choch.sell && u.choch.majorC && u.trend.exhaustion)
         : (u.bos.buy && u.bos.confirmed && u.bos.strong && u.choch.buy && u.choch.majorC && u.trend.exhaustion);
   }
   if(hardInvalid)
   {
      g_Thesis[idx].stillValid = false;
      g_Thesis[idx].status = "INVALIDATED";
      why = "thesis invalidated by confirmed adverse break";
      return false;
   }
   if(!trendOK && UltraUpgradeStrict)
   {
      g_Thesis[idx].stillValid = false;
      g_Thesis[idx].status = "TREND_BROKEN";
      why = "thesis trend broken";
      return false;
   }

   g_Thesis[idx].stillValid = true;
   g_Thesis[idx].status = "VALID";
   return true;
}

void UltraThesis_Clear(const ulong ticket)
{
   int idx = UltraThesis_Find(ticket);
   if(idx < 0) return;
   g_Thesis[idx].valid = false;
   g_Thesis[idx].status = "CLOSED";
}

string UltraThesis_Dashboard()
{
   int active = 0;
   for(int i = 0; i < g_ThesisN; i++)
      if(g_Thesis[i].valid) active++;
   string t = "THESIS: ";
   t += IntegerToString(active);
   t += " active";
   return t;
}

#endif
//===== END TradeThesis.mqh =====

//===== BEGIN CorrectionDetector.mqh =====
#ifndef HITMAN_ULTRA_CORRECTION_MQH
#define HITMAN_ULTRA_CORRECTION_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 13 CORRECTION DETECTOR                         |
//| Healthy pullback vs major reversal                               |
//+------------------------------------------------------------------+

enum ENUM_CORR_STATE
{
   CORR_PULLBACK = 0,
   CORR_CONTINUATION,
   CORR_LIQ_GRAB,
   CORR_RETEST,
   CORR_REVERSAL,
   CORR_UNKNOWN
};

struct UltraCorrection
{
   ENUM_CORR_STATE state;
   string label;
   bool isHealthy;
};

string UltraCorr_Name(const ENUM_CORR_STATE s)
{
   if(s == CORR_PULLBACK) return "PULLBACK";
   if(s == CORR_CONTINUATION) return "CONTINUATION";
   if(s == CORR_LIQ_GRAB) return "LIQ_GRAB";
   if(s == CORR_RETEST) return "RETEST";
   if(s == CORR_REVERSAL) return "REVERSAL";
   return "UNKNOWN";
}

UltraCorrection UltraCorr_Detect(const UltraSnap &u, const bool isBuy)
{
   UltraCorrection c;
   c.state = CORR_UNKNOWN;
   c.label = "UNKNOWN";
   c.isHealthy = true;
   if(!UltraUpgradeEnabled || !UltraCorrectionEnabled)
   { c.state = CORR_PULLBACK; c.label = "PULLBACK"; return c; }

   bool adverseBos = isBuy ? (u.bos.sell && u.bos.confirmed) : (u.bos.buy && u.bos.confirmed);
   bool adverseCh  = isBuy ? (u.choch.sell && u.choch.majorC) : (u.choch.buy && u.choch.majorC);
   bool liqGrab = isBuy ? (u.liq.sweepBuy || u.liq.stopHuntBuy) : (u.liq.sweepSell || u.liq.stopHuntSell);
   bool cont = u.st.continuation || (isBuy ? u.trend.bull : u.trend.bear);
   bool softMomLoss = u.mom.weakness && !adverseBos && !adverseCh;

   // True reversal = confirmed adverse BOS + major CHoCH + exhaustion (soft)
   // Soft mode refuses to call REVERSAL on a single BOS flicker.
   bool trueReversal = false;
   if(UltraUpgradeStrict)
      trueReversal = (adverseBos || adverseCh) && u.trend.exhaustion;
   else
      trueReversal = adverseBos && adverseCh && u.trend.exhaustion;

   if(trueReversal)
   {
      c.state = CORR_REVERSAL;
      c.isHealthy = false;
   }
   else if(liqGrab && !adverseBos)
      c.state = CORR_LIQ_GRAB;
   else if(cont && softMomLoss)
      c.state = CORR_PULLBACK;
   else if(cont)
      c.state = CORR_CONTINUATION;
   else if(isBuy ? u.fib.atBuyZone : u.fib.atSellZone)
      c.state = CORR_RETEST;
   else if(adverseBos || adverseCh)
   {
      // Single adverse break without full stack → treat as pullback, not exit
      c.state = CORR_PULLBACK;
      c.isHealthy = true;
   }
   else
   {
      c.state = CORR_UNKNOWN;
      c.isHealthy = true;
   }
   c.label = UltraCorr_Name(c.state);
   return c;
}

#endif
//===== END CorrectionDetector.mqh =====

//===== BEGIN HoldScore.mqh =====
#ifndef HITMAN_ULTRA_HOLD_SCORE_MQH
#define HITMAN_ULTRA_HOLD_SCORE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 12 HOLD SCORE ENGINE                           |
//| Soft default: never EXIT on temporary score dips / UNKNOWN noise |
//+------------------------------------------------------------------+

enum ENUM_HOLD_ACTION
{
   HOLD_HOLD = 0,
   HOLD_MANAGE,
   HOLD_EXIT
};

struct UltraHoldScore
{
   int trend, structure, momentum, liquidity, risk, thesis;
   int total;
   ENUM_HOLD_ACTION action;
   string label;
};

UltraHoldScore g_UltraHoldLast;

string UltraHold_ActionName(const ENUM_HOLD_ACTION a)
{
   if(a == HOLD_HOLD) return "HOLD";
   if(a == HOLD_MANAGE) return "MANAGE";
   return "EXIT";
}

UltraHoldScore UltraHold_Evaluate(const UltraSnap &u, const bool isBuy, const bool thesisValid,
                                  const UltraCorrection &corr)
{
   UltraHoldScore h;
   h.trend = UltraUSM2_ComponentTrend(u, isBuy);
   h.structure = UltraUSM2_ComponentStructure(u, isBuy);
   h.momentum = UltraUSM2_ComponentMom(u, isBuy);
   h.liquidity = UltraUSM2_ComponentLiquidity(u, isBuy);
   h.risk = UltraUSM2_ComponentRisk(u);
   h.thesis = thesisValid ? 80 : 20;
   if(corr.state == CORR_REVERSAL) h.thesis = 10;
   if(corr.state == CORR_PULLBACK || corr.state == CORR_LIQ_GRAB || corr.state == CORR_RETEST ||
      corr.state == CORR_CONTINUATION || corr.state == CORR_UNKNOWN)
   {
      if(h.thesis < 60) h.thesis = 60; // healthy / unknown noise → do not punish thesis
   }

   h.total = (h.trend + h.structure + h.momentum + h.liquidity + h.risk + h.thesis) / 6;

   if(!UltraUpgradeEnabled || !UltraHoldScoreEnabled)
   {
      h.action = HOLD_MANAGE;
      h.label = "MANAGE";
      g_UltraHoldLast = h;
      return h;
   }

   // Soft InstantQuality path: EXIT only on confirmed thesis death + reversal
   if(!UltraUpgradeStrict)
   {
      if(!thesisValid && corr.state == CORR_REVERSAL)
         h.action = HOLD_EXIT;
      else if(h.total >= 55 && corr.isHealthy)
         h.action = HOLD_HOLD;
      else
         h.action = HOLD_MANAGE; // low score / pullback → manage, never force-close
   }
   else
   {
      if((!thesisValid && corr.state == CORR_REVERSAL) || (corr.state == CORR_REVERSAL && h.total < 30))
         h.action = HOLD_EXIT;
      else if(h.total >= 65 && corr.isHealthy)
         h.action = HOLD_HOLD;
      else
         h.action = HOLD_MANAGE;
   }

   h.label = UltraHold_ActionName(h.action);
   g_UltraHoldLast = h;
   return h;
}

string UltraHold_Dashboard()
{
   string t = "HOLD: ";
   t += g_UltraHoldLast.label;
   t += " ";
   t += IntegerToString(g_UltraHoldLast.total);
   return t;
}

#endif
//===== END HoldScore.mqh =====

//===== BEGIN SmartExit.mqh =====
#ifndef HITMAN_ULTRA_SMART_EXIT_MQH
#define HITMAN_ULTRA_SMART_EXIT_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — SMART EXIT — decision only (Mission executes close)  |
//| Exit only when original idea failed OR risk requires exit        |
//+------------------------------------------------------------------+

enum ENUM_SMART_EXIT
{
   SX_NONE = 0,
   SX_BE,
   SX_TIGHTEN,
   SX_CLOSE
};

struct UltraSmartExit
{
   ENUM_SMART_EXIT action;
   string reason;
};

UltraSmartExit UltraSmartExit_Decide(const UltraHoldScore &hold, const UltraCorrection &corr,
                                     const bool thesisValid, const bool riskForced)
{
   UltraSmartExit x;
   x.action = SX_NONE;
   x.reason = "";

   if(!UltraUpgradeEnabled || !UltraSmartExitEnabled)
      return x;

   if(riskForced)
   {
      x.action = SX_CLOSE;
      x.reason = "risk management rule";
      return x;
   }

   // Never close on healthy correction / noise
   if(corr.state == CORR_PULLBACK || corr.state == CORR_CONTINUATION ||
      corr.state == CORR_LIQ_GRAB || corr.state == CORR_RETEST || corr.state == CORR_UNKNOWN)
   {
      x.action = SX_BE;
      x.reason = "healthy correction — do not close";
      return x;
   }

   // CLOSE suggestion only if hold says EXIT and thesis invalid + true reversal
   // (Mission Control still runs multi-confirm ValidateExit before closing)
   if(hold.action == HOLD_EXIT && !thesisValid && corr.state == CORR_REVERSAL)
   {
      x.action = SX_CLOSE;
      x.reason = "trade thesis failed + true reversal";
      return x;
   }

   if(hold.action == HOLD_MANAGE || hold.action == HOLD_EXIT)
   {
      x.action = SX_BE;
      x.reason = "manage / protect — keep holding";
   }
   return x;
}

#endif
//===== END SmartExit.mqh =====

//===== BEGIN SystemHealth.mqh =====
#ifndef HITMAN_ULTRA_SYSTEM_HEALTH_MQH
#define HITMAN_ULTRA_SYSTEM_HEALTH_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 15/16/17 SELF-DIAG · PERF · SYSTEM HEALTH      |
//+------------------------------------------------------------------+

struct UltraSystemHealth
{
   bool connected;
   bool tradeAllowed;
   bool dataOK;
   bool brokerOK;
   bool execOK;
   bool memoryOK;
   long latencyMs;
   string status;   // GREEN / YELLOW / RED
   string detail;
};

UltraSystemHealth g_UltraSysHealth;

void UltraSysHealth_Reset()
{
   g_UltraSysHealth.connected = true;
   g_UltraSysHealth.tradeAllowed = true;
   g_UltraSysHealth.dataOK = true;
   g_UltraSysHealth.brokerOK = true;
   g_UltraSysHealth.execOK = true;
   g_UltraSysHealth.memoryOK = true;
   g_UltraSysHealth.latencyMs = 0;
   g_UltraSysHealth.status = "GREEN";
   g_UltraSysHealth.detail = "OK";
}

bool UltraSystemHealth_Update(const string s)
{
   UltraSysHealth_Reset();
   if(!UltraUpgradeEnabled || !UltraSystemHealthEnabled) return true;

   g_UltraSysHealth.connected = (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
   g_UltraSysHealth.tradeAllowed =
      (bool)TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) &&
      (MQLInfoInteger(MQL_TRADE_ALLOWED) != 0);
   g_UltraSysHealth.dataOK = (Bars(s, UltraETF()) >= 50) && (SymbolInfoDouble(s, SYMBOL_BID) > 0.0);

   long tm = 0;
   bool modeOK = SymbolInfoInteger(s, SYMBOL_TRADE_MODE, tm);
   g_UltraSysHealth.brokerOK = modeOK && (tm != 0);

   string why = "";
   g_UltraSysHealth.execOK = UltraDefense_Line7_Execution(s, why);
   // Same overflow gate as UltraEngDiagnostics (UltraMemoryEngineEnabled)
   g_UltraSysHealth.memoryOK = !(UltraMemoryEngineEnabled && g_UltraMem.trades > 100000);
   g_UltraSysHealth.latencyMs = g_UltraCore.lastLatencyMs;

   bool hardFail = (!g_UltraSysHealth.connected || !g_UltraSysHealth.tradeAllowed ||
                    !g_UltraSysHealth.dataOK || !g_UltraSysHealth.brokerOK);

   if(hardFail)
   {
      g_UltraSysHealth.status = "RED";
      if(!g_UltraSysHealth.connected) g_UltraSysHealth.detail = "connection";
      else if(!g_UltraSysHealth.tradeAllowed) g_UltraSysHealth.detail = "trade blocked";
      else if(!g_UltraSysHealth.dataOK) g_UltraSysHealth.detail = "data error";
      else g_UltraSysHealth.detail = "broker/symbol";
      // self-diagnostic recovery attempt
      UltraRecover(g_UltraSysHealth.detail);
      return false;
   }

   if(!g_UltraSysHealth.execOK || g_UltraSysHealth.latencyMs > 500)
   {
      g_UltraSysHealth.status = "YELLOW";
      g_UltraSysHealth.detail = !g_UltraSysHealth.execOK ? why : "latency";
      return true; // soft — do not hard-block entries
   }

   g_UltraSysHealth.status = "GREEN";
   g_UltraSysHealth.detail = "OK";
   return true;
}

string UltraSystemHealth_Dashboard()
{
   string t = "HEALTH: ";
   t += g_UltraSysHealth.status;
   t += " ";
   t += g_UltraSysHealth.detail;
   return t;
}

#endif
//===== END SystemHealth.mqh =====

//===== BEGIN MasterAIBrain.mqh =====
#ifndef HITMAN_ULTRA_MASTER_AI_BRAIN_MQH
#define HITMAN_ULTRA_MASTER_AI_BRAIN_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — MASTER AI BRAIN                                      |
//| Final decision surface: BUY · SELL · WAIT only                   |
//+------------------------------------------------------------------+

struct UltraBrainDecision
{
   ENUM_SUPREME_DECISION decision;
   int confidence;
   int tradeScore;
   string grade;
   string thesis;
   string reason;
   bool explainable;
   bool consistent;
};

UltraBrainDecision g_UltraBrainLast;

void UltraBrain_Clear()
{
   g_UltraBrainLast.decision = SUP_WAIT;
   g_UltraBrainLast.confidence = 0;
   g_UltraBrainLast.tradeScore = 0;
   g_UltraBrainLast.grade = "IGNORE";
   g_UltraBrainLast.thesis = "";
   g_UltraBrainLast.reason = "WAIT";
   g_UltraBrainLast.explainable = false;
   g_UltraBrainLast.consistent = true;
}

void UltraBrain_Publish(const bool approved, const bool buySide, const UltraSnap &u,
                        const string thesis, const string why)
{
   UltraBrain_Clear();
   g_UltraBrainLast.confidence = u.score.confidence;
   if(g_UltraUSM2Last.tradeScore > 0)
      g_UltraBrainLast.tradeScore = g_UltraUSM2Last.tradeScore;
   else
      g_UltraBrainLast.tradeScore = u.score.confidence;
   g_UltraBrainLast.grade = g_UltraUSM2Last.grade;
   g_UltraBrainLast.thesis = thesis;
   g_UltraBrainLast.explainable = (StringLen(thesis) > 0 || StringLen(why) > 0);
   g_UltraBrainLast.consistent = true;

   if(!approved)
   {
      g_UltraBrainLast.decision = SUP_WAIT;
      g_UltraBrainLast.reason = why;
      if(StringLen(g_UltraBrainLast.reason) == 0) g_UltraBrainLast.reason = "WAIT";
      return;
   }

   g_UltraBrainLast.decision = buySide ? SUP_BUY : SUP_SELL;
   g_UltraBrainLast.reason = "APPROVED";
}

string UltraBrain_Name()
{
   if(g_UltraBrainLast.decision == SUP_BUY) return "BUY";
   if(g_UltraBrainLast.decision == SUP_SELL) return "SELL";
   if(g_UltraBrainLast.decision == SUP_HOLD) return "HOLD";
   if(g_UltraBrainLast.decision == SUP_MANAGE) return "MANAGE";
   if(g_UltraBrainLast.decision == SUP_EXIT) return "EXIT";
   return "WAIT";
}

string UltraBrain_Dashboard()
{
   string t = "BRAIN: ";
   t += UltraBrain_Name();
   t += " conf=";
   t += IntegerToString(g_UltraBrainLast.confidence);
   t += " score=";
   t += IntegerToString(g_UltraBrainLast.tradeScore);
   if(StringLen(g_UltraBrainLast.grade) > 0)
   {
      t += " ";
      t += g_UltraBrainLast.grade;
   }
   return t;
}

#endif
//===== END MasterAIBrain.mqh =====

//===== BEGIN SupremeCommand.mqh =====
#ifndef HITMAN_ULTRA_SUPREME_COMMAND_MQH
#define HITMAN_ULTRA_SUPREME_COMMAND_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 1 / 20 SUPREME COMMAND + FINAL AI DECISION     |
//| Global coordinator · mission manager · trade approval authority  |
//+------------------------------------------------------------------+

struct UltraSupremeDecision
{
   ENUM_SUPREME_DECISION decision;
   int confidence;
   int tradeScore;
   string grade;
   string thesis;
   string evo;
   string reason;
   bool approved;
};

UltraSupremeDecision g_UltraSupremeLast;

string UltraSupreme_Name(const ENUM_SUPREME_DECISION d)
{
   if(d == SUP_BUY) return "BUY";
   if(d == SUP_SELL) return "SELL";
   if(d == SUP_HOLD) return "HOLD";
   if(d == SUP_MANAGE) return "MANAGE";
   if(d == SUP_EXIT) return "EXIT";
   return "WAIT";
}

// Final approval authority — consumes existing gates; does not re-stack them.
bool UltraSupreme_FinalizeEntry(const string s, UltraSnap &u, UltraSignal &sig, string &why)
{
   why = "";
   UltraSupremeDecision d;
   d.decision = SUP_WAIT;
   d.confidence = u.score.confidence;
   d.tradeScore = u.score.confidence;
   d.grade = "IGNORE";
   d.thesis = "";
   d.evo = "STABLE";
   d.reason = "";
   d.approved = false;

   if(!UltraUpgradeEnabled || !UltraSupremeEnabled)
   {
      d.approved = (sig.buy || sig.sell);
      if(sig.buy) d.decision = SUP_BUY;
      else if(sig.sell) d.decision = SUP_SELL;
      d.reason = "supreme off — pass-through";
      g_UltraSupremeLast = d;
      UltraBrain_Publish(d.approved, sig.buy, u, "", d.reason);
      return d.approved;
   }

   // System health hard gate (RED only)
   if(!UltraSystemHealth_Update(s))
   {
      why = "SUPREME: health RED ";
      why += g_UltraSysHealth.detail;
      d.reason = why;
      g_UltraSupremeLast = d;
      UltraBrain_Publish(false, false, u, "", why);
      return false;
   }

   if(!(sig.buy || sig.sell) || sig.tag == "NONE")
   {
      why = "SUPREME: no candidate";
      d.reason = why;
      g_UltraSupremeLast = d;
      UltraBrain_Publish(false, false, u, "", why);
      return false;
   }

   bool buySide = sig.buy;

   // One trade = one thesis (same symbol + same direction only; MaxOpen may allow more)
   if(UltraThesisEnabled)
   {
      for(int ti = 0; ti < g_ThesisN; ti++)
      {
         if(!g_Thesis[ti].valid) continue;
         if(g_Thesis[ti].symbol != s) continue;
         if(g_Thesis[ti].isBuy != buySide) continue;
         why = "SUPREME: thesis already active same direction";
         d.reason = why;
         g_UltraSupremeLast = d;
         UltraBrain_Publish(false, buySide, u, "", why);
         return false;
      }
   }

   // USM2 scoring (Level 4) + dynamic weights (Level 5)
   UltraUSM2Scores usm;
   if(UltraUSM2Enabled)
   {
      UltraUSM2_Score(s, u, buySide, usm);
      g_UltraUSM2Last = usm;
      d.confidence = usm.confidence;
      d.tradeScore = usm.tradeScore;
      d.grade = usm.grade;
   }
   else
   {
      d.confidence = u.score.confidence;
      d.tradeScore = u.score.confidence;
      d.grade = UltraUSM2_Grade((double)d.tradeScore);
   }

   // Signal evolution (Level 3)
   UltraSignalEvo evo = UltraEvo_Evaluate(s, u, buySide);
   d.evo = evo.label;
   if(evo.state == SEVO_REVERSAL)
   {
      why = "SUPREME: signal evolution REVERSAL";
      d.reason = why;
      g_UltraSupremeLast = d;
      UltraBrain_Publish(false, buySide, u, "", why);
      return false;
   }

   // Soft floor on trade score
   int floor = UltraFireFloor();
   if(InstantQualityMode) floor = MathMin(floor, 45);
   if(d.tradeScore < floor && d.confidence < UltraInstantFireConf)
   {
      if(!(InstantQualityMode && d.tradeScore >= floor - 8))
      {
         why = "SUPREME: trade score low ";
         why += IntegerToString(d.tradeScore);
         d.reason = why;
         g_UltraSupremeLast = d;
         UltraBrain_Publish(false, buySide, u, "", why);
         return false;
      }
   }

   // Ignore grade only in strict mode
   if(UltraUpgradeStrict && d.grade == "IGNORE")
   {
      why = "SUPREME: grade IGNORE";
      d.reason = why;
      g_UltraSupremeLast = d;
      UltraBrain_Publish(false, buySide, u, "", why);
      return false;
   }

   // Build / attach thesis text (Level 11 entry side)
   // Memory note is recorded once on fill via UltraThesis_Store (avoid duplicate notes).
   string thesis = UltraDisc_BuildThesis(u, buySide, sig.tag);
   d.thesis = thesis;

   d.decision = buySide ? SUP_BUY : SUP_SELL;
   d.approved = true;
   d.reason = "APPROVED";
   g_UltraSupremeLast = d;
   UltraBrain_Publish(true, buySide, u, thesis, "APPROVED");

   if(UltraUpgradeLog)
   {
      string t = "SUPREME ";
      t += UltraSupreme_Name(d.decision);
      t += " conf="; t += IntegerToString(d.confidence);
      t += " score="; t += IntegerToString(d.tradeScore);
      t += " grade="; t += d.grade;
      t += " evo="; t += d.evo;
      UltraLogAI(t);
   }
   return true;
}

// Open-position command: HOLD / MANAGE / EXIT via hold+correction+smart exit
ENUM_SMART_EXIT UltraSupreme_ManagePosition(const ulong ticket, const string s, const bool isBuy,
                                            const UltraSnap &u, string &why)
{
   why = "";
   if(!UltraUpgradeEnabled) return SX_NONE;

   string tw = "";
   bool thesisOK = UltraThesis_Revalidate(ticket, u, tw);
   UltraCorrection corr = UltraCorr_Detect(u, isBuy);
   UltraHoldScore hold = UltraHold_Evaluate(u, isBuy, thesisOK, corr);
   UltraSmartExit sx = UltraSmartExit_Decide(hold, corr, thesisOK, false);
   why = sx.reason;
   if(StringLen(why) == 0)
   {
      why = "hold=";
      why += hold.label;
      why += " corr=";
      why += corr.label;
   }
   return sx.action;
}

string UltraSupreme_Dashboard()
{
   string t = "SUPREME: ";
   t += UltraSupreme_Name(g_UltraSupremeLast.decision);
   t += " ";
   t += g_UltraSupremeLast.grade;
   t += " conf=";
   t += IntegerToString(g_UltraSupremeLast.confidence);
   return t;
}

#endif
//===== END SupremeCommand.mqh =====

//===== BEGIN MissionControl.mqh =====
#ifndef HITMAN_ULTRA_MISSION_CONTROL_MQH
#define HITMAN_ULTRA_MISSION_CONTROL_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — LEVEL 8 MISSION CONTROL (SOLE CLOSE AUTHORITY)       |
//| EXIT & HOLD FIX LIST — only this module may close trades         |
//| Approves: BUY · SELL · WAIT · HOLD · MANAGE · EXIT               |
//+------------------------------------------------------------------+

#define ULTRA_POSLOCK_MAX 64

struct UltraMissionState
{
   ENUM_SUPREME_DECISION command;
   string reason;
   int confidence;
   int tradeScore;
   string grade;
   string thesis;
   ulong ticket;
   datetime ts;
};

struct UltraPosLock
{
   ulong    ticket;
   string   symbol;
   bool     isBuy;
   bool     active;
   string   status;      // HOLD / MANAGE / EXIT
   int      holdScore;
   string   thesisTag;
   datetime openTime;
   datetime lastEvalBar;
   bool     decidedThisCycle; // one decision per evaluation
};

struct UltraExitValidation
{
   bool thesisBroken;
   bool structureChanged;
   bool masterTrendChanged;
   bool riskRule;
   bool healthyCorrection;
   bool trueReversal;
   bool allowClose;
   string reason;
};

UltraMissionState g_UltraMissionLast;
UltraPosLock      g_UltraPosLock[ULTRA_POSLOCK_MAX];
int               g_UltraPosLockN = 0;
datetime          g_UltraMissionCycleBar = 0;
bool              g_UltraMissionClosedThisCycle = false;
bool              g_UltraMissionOpenedThisCycle = false;

//--------------------------------------------------------------------//
void UltraMission_Init()
{
   g_UltraMissionLast.command = SUP_WAIT;
   g_UltraMissionLast.reason = "INIT";
   g_UltraMissionLast.confidence = 0;
   g_UltraMissionLast.tradeScore = 0;
   g_UltraMissionLast.grade = "";
   g_UltraMissionLast.thesis = "";
   g_UltraMissionLast.ticket = 0;
   g_UltraMissionLast.ts = 0;
   g_UltraPosLockN = 0;
   g_UltraMissionCycleBar = 0;
   g_UltraMissionClosedThisCycle = false;
   g_UltraMissionOpenedThisCycle = false;
}

void UltraMission_NewCycle(const string s)
{
   datetime bar = iTime(s, UltraETF(), 0);
   if(bar != g_UltraMissionCycleBar)
   {
      g_UltraMissionCycleBar = bar;
      g_UltraMissionClosedThisCycle = false;
      g_UltraMissionOpenedThisCycle = false;
      for(int i = 0; i < g_UltraPosLockN; i++)
         g_UltraPosLock[i].decidedThisCycle = false;
   }
}

string UltraMission_Name(const ENUM_SUPREME_DECISION c)
{
   if(c == SUP_BUY) return "BUY";
   if(c == SUP_SELL) return "SELL";
   if(c == SUP_WAIT) return "WAIT";
   if(c == SUP_HOLD) return "HOLD";
   if(c == SUP_MANAGE) return "MANAGE";
   if(c == SUP_EXIT) return "EXIT";
   return "WAIT";
}

void UltraMission_Set(const ENUM_SUPREME_DECISION c, const string reason,
                      const int conf, const int score, const string grade,
                      const string thesis, const ulong ticket)
{
   g_UltraMissionLast.command = c;
   g_UltraMissionLast.reason = reason;
   g_UltraMissionLast.confidence = conf;
   g_UltraMissionLast.tradeScore = score;
   g_UltraMissionLast.grade = grade;
   g_UltraMissionLast.thesis = thesis;
   g_UltraMissionLast.ticket = ticket;
   g_UltraMissionLast.ts = TimeCurrent();
}

void UltraMission_Log(const string action, const ulong ticket, const string why)
{
   string t = "MISSION ";
   t += action;
   t += " ticket=";
   t += IntegerToString((int)ticket);
   t += " | ";
   t += why;
   UltraLogTrade(t);
   if(UltraUpgradeLog || EnableVerboseLogging)
      Print(t);
}

//--------------------------------------------------------------------//
// POSITION LOCK — one thesis / hold status per ticket
//--------------------------------------------------------------------//
int UltraPosLock_Find(const ulong ticket)
{
   for(int i = 0; i < g_UltraPosLockN; i++)
      if(g_UltraPosLock[i].active && g_UltraPosLock[i].ticket == ticket) return i;
   return -1;
}

int UltraPosLock_Alloc()
{
   for(int i = 0; i < g_UltraPosLockN; i++)
      if(!g_UltraPosLock[i].active) return i;
   if(g_UltraPosLockN >= ULTRA_POSLOCK_MAX) return 0;
   return g_UltraPosLockN++;
}

void UltraPosLock_Register(const ulong ticket, const string s, const bool isBuy, const string tag)
{
   if(ticket == 0) return;
   int idx = UltraPosLock_Find(ticket);
   if(idx < 0) idx = UltraPosLock_Alloc();
   g_UltraPosLock[idx].ticket = ticket;
   g_UltraPosLock[idx].symbol = s;
   g_UltraPosLock[idx].isBuy = isBuy;
   g_UltraPosLock[idx].active = true;
   g_UltraPosLock[idx].status = "HOLD";
   g_UltraPosLock[idx].holdScore = 0;
   g_UltraPosLock[idx].thesisTag = tag;
   g_UltraPosLock[idx].openTime = TimeCurrent();
   g_UltraPosLock[idx].lastEvalBar = 0;
   g_UltraPosLock[idx].decidedThisCycle = false;
   UltraMission_Log("LOCK", ticket, tag);
}

void UltraPosLock_Clear(const ulong ticket)
{
   int idx = UltraPosLock_Find(ticket);
   if(idx < 0) return;
   g_UltraPosLock[idx].active = false;
   g_UltraPosLock[idx].status = "CLOSED";
}

void UltraPosLock_Update(const ulong ticket, const string status, const int holdScore)
{
   int idx = UltraPosLock_Find(ticket);
   if(idx < 0) return;
   g_UltraPosLock[idx].status = status;
   g_UltraPosLock[idx].holdScore = holdScore;
}

//--------------------------------------------------------------------//
// EXIT VALIDATION ENGINE — multi-confirm before close
//--------------------------------------------------------------------//
UltraExitValidation UltraMission_ValidateExit(const ulong ticket, const string s,
                                              const bool isBuy, const UltraSnap &u,
                                              const bool riskForced)
{
   UltraExitValidation v;
   v.thesisBroken = false;
   v.structureChanged = false;
   v.masterTrendChanged = false;
   v.riskRule = riskForced;
   v.healthyCorrection = false;
   v.trueReversal = false;
   v.allowClose = false;
   v.reason = "";

   string tw = "";
   bool thesisOK = UltraThesis_Revalidate(ticket, u, tw);
   v.thesisBroken = !thesisOK;

   UltraCorrection corr = UltraCorr_Detect(u, isBuy);
   v.healthyCorrection = corr.isHealthy &&
      (corr.state == CORR_PULLBACK || corr.state == CORR_CONTINUATION ||
       corr.state == CORR_LIQ_GRAB || corr.state == CORR_RETEST || corr.state == CORR_UNKNOWN);
   v.trueReversal = (corr.state == CORR_REVERSAL);

   // Structure changed against position
   v.structureChanged = isBuy
      ? ((u.bos.sell && u.bos.confirmed && u.bos.strong) || (u.choch.sell && u.choch.majorC) || u.st.externalBear)
      : ((u.bos.buy && u.bos.confirmed && u.bos.strong) || (u.choch.buy && u.choch.majorC) || u.st.externalBull);

   // Master trend changed (H4 bias)
   int master = UltraMTF_MasterDir(s);
   v.masterTrendChanged = isBuy ? (master < 0) : (master > 0);

   // IGNORE noise — healthy correction never allows close
   if(v.healthyCorrection && !v.riskRule)
   {
      v.allowClose = false;
      v.reason = "KEEP HOLDING — healthy correction / market noise";
      return v;
   }

   if(v.riskRule)
   {
      v.allowClose = true;
      v.reason = "RISK RULE requires exit";
      return v;
   }

   // Rule #10: Thesis Invalid AND Structure Changed AND Master Trend Changed
   if(v.thesisBroken && v.structureChanged && v.masterTrendChanged && v.trueReversal)
   {
      v.allowClose = true;
      v.reason = "EXIT CONFIRMED — thesis+structure+master trend+reversal";
      return v;
   }

   // Soft InstantQuality: still require at least thesis broken + true reversal + structure
   if(!UltraUpgradeStrict)
   {
      if(v.thesisBroken && v.trueReversal && v.structureChanged)
      {
         v.allowClose = true;
         v.reason = "EXIT CONFIRMED — thesis invalid + structure + reversal";
         return v;
      }
      v.allowClose = false;
      v.reason = "KEEP HOLDING — exit confirmations incomplete";
      return v;
   }

   // Strict: thesis broken + (structure or master) + reversal
   if(v.thesisBroken && v.trueReversal && (v.structureChanged || v.masterTrendChanged))
   {
      v.allowClose = true;
      v.reason = "EXIT CONFIRMED (strict)";
      return v;
   }

   v.allowClose = false;
   v.reason = "KEEP HOLDING — thesis still valid or noise";
   return v;
}

//--------------------------------------------------------------------//
// SOLE CLOSE AUTHORITY
//--------------------------------------------------------------------//
bool UltraMission_ClosePosition(const ulong ticket, const string whyIn, const bool riskForced)
{
   if(ticket == 0) return false;
   if(!PositionSelectByTicket(ticket)) return false;

   string s = PositionGetString(POSITION_SYMBOL);
   bool isBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
   UltraMission_NewCycle(s);

   // One decision per evaluation — block close→open flip-flop same cycle
   int lk = UltraPosLock_Find(ticket);
   if(lk >= 0 && g_UltraPosLock[lk].decidedThisCycle && !riskForced)
   {
      UltraMission_Log("HOLD", ticket, "one decision per cycle — close blocked");
      return false;
   }

   UltraSnap u = g_UltraLastSnap;
   // Use core snapshot only (UFSE is assembled after Mission Control)
   UltraBuildSnapshot(s, u);

   UltraExitValidation v = UltraMission_ValidateExit(ticket, s, isBuy, u, riskForced);
   if(!v.allowClose)
   {
      UltraMission_Set(SUP_HOLD, v.reason, u.score.confidence, g_UltraHoldLast.total, "HOLD", "", ticket);
      UltraPosLock_Update(ticket, "HOLD", g_UltraHoldLast.total);
      UltraMission_Log("HOLD", ticket, v.reason);
      if(lk >= 0) g_UltraPosLock[lk].decidedThisCycle = true;
      return false;
   }

   string why = whyIn;
   if(StringLen(why) == 0) why = v.reason;
   else
   {
      why += " | ";
      why += v.reason;
   }

   UltraMission_Set(SUP_EXIT, why, u.score.confidence, g_UltraHoldLast.total, "EXIT", "", ticket);
   UltraMission_Log("CLOSE", ticket, why);

   bool ok = g_Trade.PositionClose(ticket);
   if(ok)
   {
      g_UltraMissionClosedThisCycle = true;
      UltraThesis_Clear(ticket);
      UltraPosLock_Clear(ticket);
      if(lk >= 0) g_UltraPosLock[lk].decidedThisCycle = true;
   }
   else
   {
      UltraMission_Log("CLOSE_FAIL", ticket, g_Trade.ResultRetcodeDescription());
   }
   return ok;
}

bool UltraMission_ClosePartial(const ulong ticket, const double volume, const string why)
{
   if(ticket == 0 || volume <= 0.0) return false;
   if(!PositionSelectByTicket(ticket)) return false;
   UltraMission_Log("PARTIAL", ticket, why);
   UltraMission_Set(SUP_MANAGE, why, 0, 0, "PARTIAL", "", ticket);
   return g_Trade.PositionClosePartial(ticket, volume);
}

// Mark that an entry filled this cycle (blocks immediate reopen after close)
void UltraMission_NoteOpen(const ulong ticket, const string s, const bool isBuy, const string tag)
{
   UltraMission_NewCycle(s);
   g_UltraMissionOpenedThisCycle = true;
   UltraPosLock_Register(ticket, s, isBuy, tag);
   UltraMission_Log("OPEN", ticket, tag);
}

// Block new entries if we already closed this cycle (anti flip-flop)
bool UltraMission_AllowNewEntry(const string s)
{
   UltraMission_NewCycle(s);
   if(g_UltraMissionClosedThisCycle && !UltraUpgradeStrict)
   {
      UltraMission_Log("WAIT", 0, "one decision per cycle — open blocked after close");
      return false;
   }
   return true;
}

//--------------------------------------------------------------------//
bool UltraMission_ApproveEntry(const string s, UltraSnap &u, UltraSignal &sig, string &why)
{
   if(!UltraMission_AllowNewEntry(s))
   {
      why = "MISSION: one decision per cycle";
      UltraMission_Set(SUP_WAIT, why, u.score.confidence, u.score.confidence, "WAIT", "", 0);
      return false;
   }

   bool ok = UltraSupreme_FinalizeEntry(s, u, sig, why);
   if(ok)
   {
      ENUM_SUPREME_DECISION c = sig.buy ? SUP_BUY : SUP_SELL;
      UltraMission_Set(c, g_UltraSupremeLast.reason, g_UltraSupremeLast.confidence,
                       g_UltraSupremeLast.tradeScore, g_UltraSupremeLast.grade,
                       g_UltraSupremeLast.thesis, 0);
      UltraMission_Log(UltraMission_Name(c), 0, g_UltraSupremeLast.reason);
   }
   else
   {
      UltraMission_Set(SUP_WAIT, why, u.score.confidence, u.score.confidence, "IGNORE", "", 0);
   }
   return ok;
}

// Open-position command — never closes here; Shell must call UltraMission_ClosePosition
ENUM_SUPREME_DECISION UltraMission_PositionCommand(const ulong ticket, const string s,
                                                   const bool isBuy, const UltraSnap &u,
                                                   string &why)
{
   why = "";
   UltraMission_NewCycle(s);

   UltraExitValidation v = UltraMission_ValidateExit(ticket, s, isBuy, u, false);
   UltraHoldScore hold = UltraHold_Evaluate(u, isBuy, !v.thesisBroken, UltraCorr_Detect(u, isBuy));
   UltraSmartExit sx = UltraSmartExit_Decide(hold, UltraCorr_Detect(u, isBuy), !v.thesisBroken, false);

   ENUM_SUPREME_DECISION cmd = SUP_HOLD;
   if(v.allowClose && sx.action == SX_CLOSE)
   {
      cmd = SUP_EXIT;
      why = v.reason;
   }
   else if(v.healthyCorrection || sx.action == SX_BE || sx.action == SX_TIGHTEN || hold.action == HOLD_MANAGE)
   {
      cmd = SUP_MANAGE;
      why = v.healthyCorrection ? "healthy correction — manage/protect" : sx.reason;
      if(StringLen(why) == 0) why = "MANAGE";
   }
   else
   {
      cmd = SUP_HOLD;
      why = "ULTRA HOLD — thesis/structure/trend valid";
   }

   UltraMission_Set(cmd, why, u.score.confidence, hold.total, hold.label, "", ticket);
   UltraPosLock_Update(ticket, UltraMission_Name(cmd), hold.total);
   UltraMission_Log(UltraMission_Name(cmd), ticket, why);
   return cmd;
}

ENUM_SMART_EXIT UltraMission_ToSmartExit(const ENUM_SUPREME_DECISION cmd)
{
   if(cmd == SUP_EXIT) return SX_CLOSE;
   if(cmd == SUP_MANAGE) return SX_BE;
   return SX_NONE;
}

string UltraMission_Dashboard()
{
   string t = "MISSION: ";
   t += UltraMission_Name(g_UltraMissionLast.command);
   t += " ";
   t += g_UltraMissionLast.reason;
   return t;
}

#endif
//===== END MissionControl.mqh =====

//===== BEGIN UFSE_FastSignalEngine.mqh =====
#ifndef HITMAN_ULTRA_UFSE_MQH
#define HITMAN_ULTRA_UFSE_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — ULTRA FAST SIGNAL ENGINE v1.0                         |
//| Real-time scanner · Event-driven cache · Priority · Locks · Debug |
//+------------------------------------------------------------------+

#define UFSE_MAX_SYM 48

struct UltraTickScan
{
   double   bid;
   double   ask;
   double   last;
   long     tickVol;
   double   spread;
   int      dir;          // +1 up / -1 down / 0 flat
   double   speed;        // approx ticks/sec
   datetime t;
   bool     valid;
};

struct UltraSymUFSE
{
   string        symbol;
   UltraTickScan tick;
   UltraSnap     snap;
   bool          snapValid;
   datetime      barTime;
   double        cacheBid;
   double        cacheAsk;
   bool          dirtyCritical;   // tick/structure/BOS/CHoCH class
   bool          dirtyMedium;     // fib/vol/session class
   int           masterTrend;     // +1 BUY / -1 SELL / 0 none
   bool          signalLocked;
   bool          lockedIsBuy;
   datetime      lockBar;
   bool          prevBosBuy, prevBosSell;
   bool          prevChochBuy, prevChochSell;
   bool          prevSweepBuy, prevSweepSell;
   datetime      lastEvalBar;
   string        lastDebug;
   ulong         tickCount;
   ulong         cacheHits;
   ulong         fullRebuilds;
};

UltraSymUFSE g_UFSE[UFSE_MAX_SYM];
int          g_UFSE_N = 0;
datetime     g_UFSE_SpeedWindowStart = 0;
int          g_UFSE_SpeedTickCount = 0;

//--------------------------------------------------------------------//
// Inputs (also listed in 31_Inputs via shared names below)           //
//--------------------------------------------------------------------//
// UltraFastSignalEnabled, UltraMasterTrendLock, UltraSignalLock,
// UltraUFSE_ExplainLog — declared in 31_Inputs.mqh (input bool; function name differs)

int UltraUFSE_Find(const string s)
{
   for(int i = 0; i < g_UFSE_N; i++)
      if(g_UFSE[i].symbol == s) return i;
   return -1;
}

int UltraUFSE_Ensure(const string s)
{
   int idx = UltraUFSE_Find(s);
   if(idx >= 0) return idx;
   if(g_UFSE_N >= UFSE_MAX_SYM) return 0;
   idx = g_UFSE_N++;
   UltraSymUFSE z;
   z.symbol = s;
   z.snapValid = false;
   z.barTime = 0;
   z.cacheBid = z.cacheAsk = 0;
   z.dirtyCritical = true;
   z.dirtyMedium = true;
   z.masterTrend = 0;
   z.signalLocked = false;
   z.lockedIsBuy = false;
   z.lockBar = 0;
   z.prevBosBuy = z.prevBosSell = false;
   z.prevChochBuy = z.prevChochSell = false;
   z.prevSweepBuy = z.prevSweepSell = false;
   z.lastEvalBar = 0;
   z.lastDebug = "";
   z.tickCount = z.cacheHits = z.fullRebuilds = 0;
   UltraTickScan blank; blank.bid=blank.ask=blank.last=blank.spread=blank.speed=0; blank.tickVol=0; blank.dir=0; blank.t=0; blank.valid=false;
   z.tick = blank;
   // snap left uninitialized until first build (avoid ZeroMemory on string fields)
   g_UFSE[idx] = z;
   g_UFSE[idx].symbol = s;
   return idx;
}

//--------------------------------------------------------------------//
// 1. REAL-TIME MARKET SCANNER                                        //
//--------------------------------------------------------------------//
void UltraUFSE_ScanTick(const int idx)
{
   if(idx < 0 || idx >= g_UFSE_N) return;
   string s = g_UFSE[idx].symbol;
   UltraTickScan prev = g_UFSE[idx].tick;

   UltraTickScan t;
   t.bid = SymbolInfoDouble(s, SYMBOL_BID);
   t.ask = SymbolInfoDouble(s, SYMBOL_ASK);
   t.last = SymbolInfoDouble(s, SYMBOL_LAST);
   if(t.last <= 0.0) t.last = t.bid;
   t.tickVol = (long)iTickVolume(s, UltraETF(), 0);
   if(t.tickVol <= 0) t.tickVol = (long)iVolume(s, UltraETF(), 0);
   long spr = 0; SymbolInfoInteger(s, SYMBOL_SPREAD, spr);
   t.spread = (double)spr;
   t.t = TimeCurrent();
   t.dir = 0;
   if(prev.valid)
   {
      if(t.bid > prev.bid) t.dir = 1;
      else if(t.bid < prev.bid) t.dir = -1;
   }
   // tick speed: rolling 1s window
   if(g_UFSE_SpeedWindowStart <= 0 || t.t != g_UFSE_SpeedWindowStart)
   {
      if(g_UFSE_SpeedWindowStart > 0 && t.t > g_UFSE_SpeedWindowStart)
         t.speed = (double)g_UFSE_SpeedTickCount / MathMax(1.0, (double)(t.t - g_UFSE_SpeedWindowStart));
      else
         t.speed = (double)g_UFSE_SpeedTickCount;
      g_UFSE_SpeedWindowStart = t.t;
      g_UFSE_SpeedTickCount = 1;
   }
   else
   {
      g_UFSE_SpeedTickCount++;
      t.speed = (double)g_UFSE_SpeedTickCount;
   }
   t.valid = (t.bid > 0.0 && t.ask > 0.0);
   g_UFSE[idx].tick = t;
   g_UFSE[idx].tickCount++;

   // feed shared data cache
   g_UltraDataCache.symbol = s;
   g_UltraDataCache.bid = t.bid;
   g_UltraDataCache.ask = t.ask;
   g_UltraDataCache.spreadPts = t.spread;
   g_UltraDataCache.barTime = iTime(s, UltraETF(), 0);
   g_UltraDataCache.valid = t.valid;
}

//--------------------------------------------------------------------//
// 2/4/5. EVENT FLAGS + PRIORITY                                      //
//--------------------------------------------------------------------//
void UltraUFSE_UpdateDirty(const int idx)
{
   if(idx < 0 || idx >= g_UFSE_N) return;
   string s = g_UFSE[idx].symbol;
   datetime bar = iTime(s, UltraETF(), 0);
   double bid = g_UFSE[idx].tick.bid;
   double ask = g_UFSE[idx].tick.ask;

   bool newBar = (bar > 0 && bar != g_UFSE[idx].barTime);
   bool priceChanged = (bid != g_UFSE[idx].cacheBid || ask != g_UFSE[idx].cacheAsk);
   bool bigMove = false;
   double pt = SymbolInfoDouble(s, SYMBOL_POINT);
   if(pt > 0.0 && g_UFSE[idx].cacheBid > 0.0)
      bigMove = (MathAbs(bid - g_UFSE[idx].cacheBid) >= pt * 8.0);

   // Critical: new bar / structure-class move
   g_UFSE[idx].dirtyCritical = (!g_UFSE[idx].snapValid) || newBar || bigMove;
   // Medium: any price change without new bar
   g_UFSE[idx].dirtyMedium = priceChanged && !newBar;
}

bool UltraUFSE_CacheFresh(const int idx)
{
   if(idx < 0 || idx >= g_UFSE_N) return false;
   if(!g_UFSE[idx].snapValid) return false;
   if(g_UFSE[idx].dirtyCritical) return false;
   // unchanged bid/ask + same bar → cache hit
   if(!g_UFSE[idx].dirtyMedium &&
      g_UFSE[idx].tick.bid == g_UFSE[idx].cacheBid &&
      g_UFSE[idx].tick.ask == g_UFSE[idx].cacheAsk)
      return true;
   return false;
}

//--------------------------------------------------------------------//
// 7. MULTI-TIMEFRAME CACHE (master trend from HTF)                   //
//--------------------------------------------------------------------//
int UltraUFSE_CalcMasterTrend(const UltraSnap &u)
{
   int score = 0;
   if(u.trend.monthBull) score++; if(u.trend.monthBear) score--;
   if(u.trend.weekBull)  score++; if(u.trend.weekBear)  score--;
   if(u.trend.macroBull) score++; if(u.trend.macroBear) score--;
   if(u.trend.htfBull)   score++; if(u.trend.htfBear)   score--;
   if(score > 0) return 1;
   if(score < 0) return -1;
   // fallback to votes
   if(u.trend.mtfVotesBuy > u.trend.mtfVotesSell) return 1;
   if(u.trend.mtfVotesSell > u.trend.mtfVotesBuy) return -1;
   return 0;
}

//--------------------------------------------------------------------//
// 8. EARLY SETUP DETECTION (event edges)                             //
//--------------------------------------------------------------------//
bool UltraUFSE_DetectEarlyEdge(const int idx, const UltraSnap &u)
{
   if(idx < 0 || idx >= g_UFSE_N) return false;
   if(u.bos.buy && !g_UFSE[idx].prevBosBuy) return true;
   if(u.bos.sell && !g_UFSE[idx].prevBosSell) return true;
   if(u.choch.buy && !g_UFSE[idx].prevChochBuy) return true;
   if(u.choch.sell && !g_UFSE[idx].prevChochSell) return true;
   if(u.liq.sweepBuy && !g_UFSE[idx].prevSweepBuy) return true;
   if(u.liq.sweepSell && !g_UFSE[idx].prevSweepSell) return true;
   return false;
}

void UltraUFSE_CommitEarlyFlags(const int idx, const UltraSnap &u)
{
   if(idx < 0 || idx >= g_UFSE_N) return;
   g_UFSE[idx].prevBosBuy = u.bos.buy;
   g_UFSE[idx].prevBosSell = u.bos.sell;
   g_UFSE[idx].prevChochBuy = u.choch.buy;
   g_UFSE[idx].prevChochSell = u.choch.sell;
   g_UFSE[idx].prevSweepBuy = u.liq.sweepBuy;
   g_UFSE[idx].prevSweepSell = u.liq.sweepSell;
}

bool UltraUFSE_EarlyEvent(const int idx, const UltraSnap &u)
{
   bool edge = UltraUFSE_DetectEarlyEdge(idx, u);
   UltraUFSE_CommitEarlyFlags(idx, u);
   return edge;
}

//--------------------------------------------------------------------//
// 11. SIGNAL LOCK                                                    //
//--------------------------------------------------------------------//
void UltraUFSE_Lock(const int idx, const bool isBuy)
{
   if(idx < 0 || idx >= g_UFSE_N) return;
   g_UFSE[idx].signalLocked = true;
   g_UFSE[idx].lockedIsBuy = isBuy;
   g_UFSE[idx].lockBar = iTime(g_UFSE[idx].symbol, UltraETF(), 0);
}

void UltraUFSE_Unlock(const int idx)
{
   if(idx < 0 || idx >= g_UFSE_N) return;
   g_UFSE[idx].signalLocked = false;
   g_UFSE[idx].lockBar = 0;
}

void UltraUFSE_MaybeUnlock(const int idx, const UltraSnap &u)
{
   if(idx < 0 || idx >= g_UFSE_N) return;
   if(!g_UFSE[idx].signalLocked) return;

   if(UltraSymDir(g_UFSE[idx].symbol) == 0)
   {
      bool fresh = UltraUFSE_DetectEarlyEdge(idx, u);
      if(fresh)
         UltraUFSE_Unlock(idx);
      int mt = UltraUFSE_CalcMasterTrend(u);
      if(mt != 0 && ((g_UFSE[idx].lockedIsBuy && mt < 0) || (!g_UFSE[idx].lockedIsBuy && mt > 0)))
         UltraUFSE_Unlock(idx);
   }
}

bool UltraUFSE_LockBlocks(const int idx, const bool wantBuy)
{
   if(idx < 0 || idx >= g_UFSE_N) return false;
   if(!UltraSignalLockEnabled) return false;
   if(!g_UFSE[idx].signalLocked) return false;
   // block duplicate same-direction while locked; allow opposite only after unlock
   if(g_UFSE[idx].lockedIsBuy == wantBuy) return true;
   return true; // while locked, block all new entries until unlock rules fire
}

//--------------------------------------------------------------------//
// 12. MASTER TREND LOCK                                              //
//--------------------------------------------------------------------//
bool UltraUFSE_MasterAllows(const int idx, const bool wantBuy, string &why)
{
   why = "";
   if(!UltraMasterTrendLock) return true;
   if(idx < 0 || idx >= g_UFSE_N) return true;
   int mt = g_UFSE[idx].masterTrend;
   if(mt == 0) return true; // no clear master — allow (InstantQuality)
   if(wantBuy && mt < 0){ why = "master trend SELL lock"; return false; }
   if(!wantBuy && mt > 0){ why = "master trend BUY lock"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// 10. EXECUTION READINESS                                            //
//--------------------------------------------------------------------//
bool UltraUFSE_ExecReady(const string s, string &why)
{
   why = "";
   if(!TerminalInfoInteger(TERMINAL_CONNECTED)){ why = "terminal disconnected"; return false; }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)){ why = "trading not allowed"; return false; }
   if(!MQLInfoInteger(MQL_TRADE_ALLOWED)){ why = "EA trading disabled"; return false; }
   long tm = 0;
   if(!SymbolInfoInteger(s, SYMBOL_TRADE_MODE, tm)){ why = "symbol mode unavailable"; return false; }
   if(tm == 0){ why = "symbol trade disabled"; return false; }
   double bid = SymbolInfoDouble(s, SYMBOL_BID);
   double ask = SymbolInfoDouble(s, SYMBOL_ASK);
   if(bid <= 0.0 || ask <= 0.0){ why = "price not fresh"; return false; }
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double fm = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(eq <= 0.0){ why = "bad equity"; return false; }
   if(fm <= 0.0){ why = "no free margin"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// 13. ENTRY TRIGGER                                                  //
//--------------------------------------------------------------------//
bool UltraUFSE_EntryTrigger(const UltraSnap &u, const bool buySide, string &why)
{
   why = "";
   bool structure = buySide
      ? (u.st.hh || u.st.hl || u.st.externalBull || u.st.internalBull || u.st.continuation)
      : (u.st.lh || u.st.ll || u.st.externalBear || u.st.internalBear || u.st.continuation);
   bool bosCh = buySide ? (u.bos.buy || u.choch.buy) : (u.bos.sell || u.choch.sell);
   bool liq   = buySide ? (u.liq.sweepBuy || u.liq.stopHuntBuy || u.liq.grabBuy || u.liq.equalLows)
                        : (u.liq.sweepSell || u.liq.stopHuntSell || u.liq.grabSell || u.liq.equalHighs);
   bool mom   = buySide ? (u.mom.momBuy || u.mom.impulse || u.ict.dispBuy || u.ind.smi > 0)
                        : (u.mom.momSell || u.mom.impulse || u.ict.dispSell || u.ind.smi < 0);
   bool trend = buySide ? (u.trend.bull || u.trend.htfBull || u.trend.macroBull)
                        : (u.trend.bear || u.trend.htfBear || u.trend.macroBear);

   if(InstantQualityMode)
   {
      int n = (structure?1:0)+(bosCh?1:0)+(liq?1:0)+(mom?1:0)+(trend?1:0);
      if(n < 3){ why = "entry trigger soft fail "+IntegerToString(n)+"/5"; return false; }
   }
   else
   {
      if(!trend){ why = "master/trend fail"; return false; }
      if(!structure){ why = "structure fail"; return false; }
      if(!bosCh){ why = "BOS/CHoCH fail"; return false; }
      if(!liq){ why = "liquidity fail"; return false; }
      if(!mom){ why = "momentum fail"; return false; }
   }
   if(u.score.precision < UltraMinPrecision && u.score.confidence < UltraInstantFireConf)
   { why = "precision threshold"; return false; }
   if(u.score.probability < UltraMinProbability && u.score.confidence < UltraInstantFireConf)
   { why = "probability threshold"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// 9. SMART SIGNAL FILTER                                             //
//--------------------------------------------------------------------//
bool UltraUFSE_SmartFilter(const int idx, const bool buySide, const UltraSnap &u, string &why)
{
   why = "";
   if(idx < 0 || idx >= g_UFSE_N) return true;
   datetime bar = iTime(g_UFSE[idx].symbol, UltraETF(), 0);
   // same-candle duplicate
   if(bar > 0 && bar == g_UFSE[idx].lastEvalBar && g_UFSE[idx].signalLocked)
   { why = "same-candle duplicate"; return false; }
   // weak structure
   if(u.st.quality < 25 && !InstantQualityMode)
   { why = "weak structure"; return false; }
   // low confidence
   if(!UltraPassScore(u.score.confidence) && u.score.confidence < UltraInstantFireConf)
   { why = "low-confidence setup"; return false; }
   if(UltraUFSE_LockBlocks(idx, buySide))
   { why = "signal lock"; return false; }
   return true;
}

//--------------------------------------------------------------------//
// 15. DEBUG OUTPUT                                                   //
//--------------------------------------------------------------------//
string UltraUFSE_DebugExplain(const UltraSnap &u, const bool buySide, const bool approved)
{
   bool structure = buySide
      ? (u.st.hh || u.st.hl || u.st.externalBull || u.st.internalBull || u.st.continuation)
      : (u.st.lh || u.st.ll || u.st.externalBear || u.st.internalBear || u.st.continuation);
   bool bos   = buySide ? u.bos.buy : u.bos.sell;
   bool choch = buySide ? u.choch.buy : u.choch.sell;
   bool liq   = buySide ? (u.liq.sweepBuy || u.liq.stopHuntBuy || u.liq.equalLows)
                        : (u.liq.sweepSell || u.liq.stopHuntSell || u.liq.equalHighs);
   bool mom   = buySide ? (u.mom.momBuy || u.mom.impulse || u.ict.dispBuy)
                        : (u.mom.momSell || u.mom.impulse || u.ict.dispSell);
   bool trend = buySide ? (u.trend.bull || u.trend.htfBull || u.trend.macroBull)
                        : (u.trend.bear || u.trend.htfBear || u.trend.macroBear);

   string head = "NO TRADE";
   if(approved)
   {
      if(buySide) head = "BUY SIGNAL";
      else head = "SELL SIGNAL";
   }

   string t = head;
   t += "\nTrend ........ "; if(trend) t += "PASS"; else t += "FAIL";
   t += "\nStructure .... "; if(structure) t += "PASS"; else t += "FAIL";
   t += "\nBOS .......... "; if(bos) t += "PASS"; else t += "FAIL";
   t += "\nCHoCH ........ "; if(choch) t += "PASS"; else t += "FAIL";
   t += "\nLiquidity .... "; if(liq) t += "PASS"; else t += "FAIL";
   t += "\nMomentum ..... "; if(mom) t += "PASS"; else t += "FAIL";
   t += "\n\nConfidence ... "; t += IntegerToString(u.score.confidence); t += "%";
   t += "\nPrecision .... "; t += IntegerToString(u.score.precision); t += "%";
   t += "\nProbability .. "; t += IntegerToString(u.score.probability); t += "%";
   t += "\n\nDecision ..... ";
   if(approved){ if(buySide) t += "BUY"; else t += "SELL"; }
   else t += "WAIT";
   return t;
}

//--------------------------------------------------------------------//
// PIPELINE: Tick → Data → (cached) engines → Decision helpers        //
//--------------------------------------------------------------------//
bool UltraUFSE_BuildSnapshot(const string s, UltraSnap &u, bool &fromCache)
{
   fromCache = false;
   int idx = UltraUFSE_Ensure(s);
   UltraUFSE_ScanTick(idx);
   UltraUFSE_UpdateDirty(idx);

   if(!UltraFastSignalEnabled)
      return UltraBuildSnapshot(s, u);

   if(UltraUFSE_CacheFresh(idx))
   {
      u = g_UFSE[idx].snap;
      fromCache = true;
      g_UFSE[idx].cacheHits++;
      UltraUFSE_MaybeUnlock(idx, u);
      return true;
   }

   // Full rebuild (critical or medium price change)
   if(!UltraBuildSnapshot(s, u))
   {
      g_UFSE[idx].snapValid = false;
      return false;
   }

   g_UFSE[idx].snap = u;
   g_UFSE[idx].snapValid = true;
   g_UFSE[idx].barTime = iTime(s, UltraETF(), 0);
   g_UFSE[idx].cacheBid = g_UFSE[idx].tick.bid;
   g_UFSE[idx].cacheAsk = g_UFSE[idx].tick.ask;
   g_UFSE[idx].dirtyCritical = false;
   g_UFSE[idx].dirtyMedium = false;
   g_UFSE[idx].masterTrend = UltraUFSE_CalcMasterTrend(u);
   g_UFSE[idx].fullRebuilds++;
   UltraUFSE_EarlyEvent(idx, u);
   UltraUFSE_MaybeUnlock(idx, u);
   return true;
}

string UltraUFSE_Stats(const string s)
{
   int idx = UltraUFSE_Find(s);
   if(idx < 0) return "UFSE n/a";
   string master = "FLAT";
   if(g_UFSE[idx].masterTrend > 0) master = "BUY";
   else if(g_UFSE[idx].masterTrend < 0) master = "SELL";
   string lock = "N";
   if(g_UFSE[idx].signalLocked) lock = "Y";
   string t = "ticks=";
   t += IntegerToString((int)g_UFSE[idx].tickCount);
   t += " hits=";
   t += IntegerToString((int)g_UFSE[idx].cacheHits);
   t += " rebuilds=";
   t += IntegerToString((int)g_UFSE[idx].fullRebuilds);
   t += " master=";
   t += master;
   t += " lock=";
   t += lock;
   t += " spd=";
   t += DoubleToString(g_UFSE[idx].tick.speed, 1);
   return t;
}

//--------------------------------------------------------------------//
// LIVE DECISION + EVALUATE (wired to Ultra Fast Signal Engine)       //
//--------------------------------------------------------------------//
bool UltraAIDecide(const string s, UltraSnap &u, UltraSignal &sig, string &why)
{
   why = "";
   sig.buy = sig.sell = false; sig.tag = "NONE"; sig.reason = ""; sig.score = 0; sig.explanation = "";

   string capWhy = "";
   if(!UltraCapitalOK(capWhy)){ why = "capital: " + capWhy; return false; }
   string exWhy = "";
   if(UltraFastSignalEnabled)
   {
      if(!UltraUFSE_ExecReady(s, exWhy)){ why = "exec: " + exWhy; return false; }
   }
   else
   {
      if(!UltraExecReady(s, exWhy)){ why = "exec: " + exWhy; return false; }
   }

   sig = UltraPickBest(u);
   if(!(sig.buy || sig.sell) || sig.tag == "NONE")
   {
      why = "no strategy: " + sig.reason;
      return false;
   }

   UltraEngScores(u, sig.buy);
   int floor = UltraFireFloor();
   if(u.score.confidence < floor && u.score.confidence < UltraInstantFireConf &&
      !(InstantQualityMode && u.score.confidence >= floor - 8))
   { why = "confidence low"; return false; }
   if(u.score.precision < UltraMinPrecision && u.score.confidence < UltraInstantFireConf)
   { why = "precision low"; return false; }
   if(u.score.probability < UltraMinProbability && u.score.confidence < UltraInstantFireConf)
   { why = "probability low"; return false; }

   // DEFENSE LINE ENGINE v1.0 — Lines 1-7 + 10 (GREEN / YELLOW / RED)
   if(UltraDefenseEnabled && UltraDefenseGateEntry)
   {
      UltraDefenseReport defR;
      string defWhy = "";
      if(!UltraDefense_EvaluateEntry(s, u, sig.buy, defR, defWhy))
      {
         why = defWhy;
         UltraDefense_MaybeLog(s, defR);
         return false;
      }
   }

   if(UltraFastSignalEnabled)
   {
      int idx = UltraUFSE_Ensure(s);
      string mtWhy = "";
      if(!UltraUFSE_MasterAllows(idx, sig.buy, mtWhy))
      { why = mtWhy; return false; }

      if(UltraUFSE_EntryTriggerGate)
      {
         string trWhy = "";
         if(!UltraUFSE_EntryTrigger(u, sig.buy, trWhy))
         { why = trWhy; return false; }
      }

      string fWhy = "";
      if(!UltraUFSE_SmartFilter(idx, sig.buy, u, fWhy))
      { why = fWhy; return false; }
   }

   if(UltraBlockOppositeSameSym)
   {
      int d = UltraSymDir(s);
      if(sig.buy && d < 0){ why = "opposite SELL open"; return false; }
      if(sig.sell && d > 0){ why = "opposite BUY open"; return false; }
   }

   // TRADE ENTRY DISCIPLINE ENGINE v1.0 — Rules #1-#12 (irregular trade prevention)
   if(UltraDisciplineEnabled)
   {
      string discWhy = "";
      if(!UltraDiscipline_AllowEntry(s, u, sig, discWhy))
      {
         why = discWhy;
         return false;
      }
      // attach explainable thesis onto signal reason trail
      int didx = UltraDisc_Find(s);
      if(didx >= 0 && StringLen(g_UltraDisc[didx].lastThesis) > 0)
      {
         if(StringLen(sig.reason) > 0) sig.reason = sig.reason + " | ";
         sig.reason = sig.reason + g_UltraDisc[didx].lastThesis;
      }
   }

   // ULTRA X — LEVEL 8 MISSION CONTROL (sole entry authority)
   if(UltraUpgradeEnabled && UltraSupremeEnabled)
   {
      string supWhy = "";
      if(!UltraMission_ApproveEntry(s, u, sig, supWhy))
      {
         if(StringLen(supWhy) > 0) why = supWhy;
         else why = "MISSION WAIT";
         return false;
      }
   }
   return true;
}

void EvaluateStrategySignals(bool &buySignal, bool &sellSignal, string &strategyTag)
{
   buySignal = false;
   sellSignal = false;
   strategyTag = "";

   UltraSnap snap;
   bool fromCache = false;
   bool built = false;
   if(UltraFastSignalEnabled)
      built = UltraUFSE_BuildSnapshot(BrokerSymbol, snap, fromCache);
   else
      built = UltraBuildSnapshot(BrokerSymbol, snap);

   if(!built)
   {
      if(EnableVerboseLogging)
         Print("ULTRA snapshot failed: ", g_UltraCore.lastError, " on ", BrokerSymbol);
      g_UltraLastSnap = snap;
      return;
   }

   UltraSignal best;
   string why = "";
   if(!UltraAIDecide(BrokerSymbol, snap, best, why))
   {
      g_UltraLastSnap = snap;
      bool leanBuy = (UltraConfluenceBuy(snap) >= UltraConfluenceSell(snap));
      best.explanation = UltraUFSE_DebugExplain(snap, leanBuy, false);
      g_UltraLastSignal = best;
      datetime bar = iTime(BrokerSymbol, UltraETF(), 0);
      bool logIt = (EnableVerboseLogging || ContStruct_LogDetail || UltraUFSE_ExplainLog) &&
                   (bar != g_UltraLastWaitBar || BrokerSymbol != g_UltraLastWaitSym);
      if(logIt)
      {
         g_UltraLastWaitBar = bar;
         g_UltraLastWaitSym = BrokerSymbol;
         UltraEvent_Note(UEV_WAIT);
         string cacheTag = "REBUILD";
         if(fromCache) cacheTag = "HIT";
         Print("ULTRA wait [", why, "] conf=", snap.score.confidence,
               " prec=", snap.score.precision, " prob=", snap.score.probability,
               " regime=", UltraRegimeName(snap.regime),
               " cache=", cacheTag,
               " ", UltraUFSE_Stats(BrokerSymbol),
               " on ", BrokerSymbol);
         if(UltraUFSE_ExplainLog)
            Print(best.explanation);
      }
      return;
   }

   buySignal = best.buy;
   sellSignal = best.sell;
   strategyTag = best.tag;
   best.explanation = UltraUFSE_DebugExplain(snap, best.buy, true);
   g_UltraLastSnap = snap;
   g_UltraLastSignal = best;

   if(UltraFastSignalEnabled)
   {
      int idx = UltraUFSE_Ensure(BrokerSymbol);
      UltraUFSE_Lock(idx, best.buy);
      g_UFSE[idx].lastEvalBar = iTime(BrokerSymbol, UltraETF(), 0);
   }
   UltraExec_MarkFired(BrokerSymbol);
   UltraEvent_Note(UEV_FIRE);

   string sideTag = "SELL";
   if(best.buy) sideTag = "BUY";
   string cacheTag2 = "REBUILD";
   if(fromCache) cacheTag2 = "HIT";
   Print("ULTRA FIRE ", sideTag, " [", best.tag, "] conf=", snap.score.confidence,
         " prec=", snap.score.precision, " prob=", snap.score.probability,
         " ", best.reason, " SMI=", DoubleToString(snap.ind.smi, 1),
         " session=", snap.ctx.session,
         " cache=", cacheTag2,
         " ", UltraUFSE_Stats(BrokerSymbol),
         " on ", BrokerSymbol);
   if(UltraUFSE_ExplainLog)
      Print(best.explanation);
}

#endif // HITMAN_ULTRA_UFSE_MQH
//===== END UFSE_FastSignalEngine.mqh =====

//===== BEGIN 21_TradeManagement.mqh =====
#ifndef HITMAN_ULTRA_21_TRADEMANAGEMENT_MQH
#define HITMAN_ULTRA_21_TRADEMANAGEMENT_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 21_TRADE_MANAGEMENT                             |
//| Ultra Long Holding · Dynamic SL · Dynamic TP · Break-even ·       |
//| Adaptive Trailing Stop · Intelligent Exit                         |
//|                                                                   |
//| Deep TP1/TP2/TP3 + BE + trail + hold live in Shell_B:             |
//|   ManageOpenTrades / ApplyProfitLockSL / GetTradeDistances        |
//+------------------------------------------------------------------+

bool UltraTM_HasOpenOnSymbol(const string s)
{
   return (UltraSymDir(s) != 0);
}

bool UltraTM_UltraLongHoldingEnabled()
{
   // Shell_B holds ultra-long management path; bridge flag for dashboard/status
   return true;
}

bool UltraTM_DynamicStopsActive()
{
   return true; // Shell_B dynamic SL/TP path
}

bool UltraTM_BreakEvenActive()
{
   return true; // Shell_B BE path
}

bool UltraTM_AdaptiveTrailActive()
{
   return true; // Shell_B adaptive trailing path
}

bool UltraTM_IntelligentExitActive()
{
   return true; // Shell_B intelligent exit / profit lock
}

string UltraTM_ModuleStatus()
{
   return "UltraLong+DynSL/TP+BE+Trail+IntelExit via Shell_B ManageOpenTrades";
}

#endif // HITMAN_ULTRA_21_TRADEMANAGEMENT_MQH
//===== END 21_TradeManagement.mqh =====

//===== BEGIN 22_MultiSymbol.mqh =====
#ifndef HITMAN_ULTRA_22_MULTISYMBOL_MQH
#define HITMAN_ULTRA_22_MULTISYMBOL_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 22_MULTI_SYMBOL — Scanner · Sync · Independent analysis
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| 06. Ultra Multi Symbol Engine                                    |
//| Scanner · Sync · Independent analysis · Symbol statistics        |
//+------------------------------------------------------------------+

int UltraMulti_SymbolCount()
{
   return ArraySize(MultiSymbolList);
}

string UltraMulti_SymbolAt(const int idx)
{
   if(idx < 0 || idx >= ArraySize(MultiSymbolList)) return "";
   return MultiSymbolList[idx];
}

bool UltraMulti_IsTracked(const string s)
{
   return (GetSymbolIndex(s) >= 0);
}

void UltraMulti_ScanSummary(string &out)
{
   out = "symbols=" + IntegerToString(UltraMulti_SymbolCount());
   if(EnableMultiSymbolTrading)
      out += " multi=ON timer=" + IntegerToString(MultiSymbolTimerSeconds) + "s";
   else
      out += " multi=OFF primary=" + BrokerSymbol;
}

bool UltraMulti_AnalyzeSymbol(const string s, UltraSnap &u)
{
   if(!UltraMulti_IsTracked(s) && s != BrokerSymbol && s != _Symbol)
      return false;
   return UltraBuildSnapshot(s, u);
}

#endif // HITMAN_ULTRA_22_MULTISYMBOL_MQH
//===== END 22_MultiSymbol.mqh =====

//===== BEGIN 25_Statistics.mqh =====
#ifndef HITMAN_ULTRA_25_STATISTICS_MQH
#define HITMAN_ULTRA_25_STATISTICS_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 25_STATISTICS — WR · PF · Expectancy · RR · Reports
//+------------------------------------------------------------------+

void UltraStats_Refresh()
{
   UltraMemoryUpdateFromStats();
}

double UltraStats_WinRate(){ return g_UltraMem.winRate; }
double UltraStats_ProfitFactor(){ return g_UltraMem.profitFactor; }
double UltraStats_AvgRR(){ return g_UltraMem.avgRR; }

string UltraStats_Report()
{
   return "WR=" + DoubleToString(g_UltraMem.winRate, 1) +
          "% PF=" + DoubleToString(g_UltraMem.profitFactor, 2) +
          " RR=" + DoubleToString(g_UltraMem.avgRR, 2);
}

#endif // HITMAN_ULTRA_25_STATISTICS_MQH
//===== END 25_Statistics.mqh =====

//===== BEGIN 37_Optimization.mqh =====
#ifndef HITMAN_ULTRA_37_OPT_MQH
#define HITMAN_ULTRA_37_OPT_MQH
//+------------------------------------------------------------------+
//| 37_Optimization — cache · event cadence · resource monitoring    |
//+------------------------------------------------------------------+

struct UltraPerfOpt
{
   long lastTickMs;
   long lastHeavyMs;
   ulong cycleCount;
   bool skipHeavy;
   long peakLatencyMs;
   long lastLatencyMs;
};

UltraPerfOpt g_UltraPerfOpt;

void UltraOpt_OnTickStart()
{
   g_UltraPerfOpt.lastTickMs = (long)GetTickCount();
   g_UltraPerfOpt.cycleCount++;
}

bool UltraOpt_ShouldSkipHeavy(const int minIntervalMs=50)
{
   long now = (long)GetTickCount();
   if(g_UltraPerfOpt.lastHeavyMs > 0 && (now - g_UltraPerfOpt.lastHeavyMs) < minIntervalMs)
   {
      g_UltraPerfOpt.skipHeavy = true;
      return true;
   }
   g_UltraPerfOpt.skipHeavy = false;
   g_UltraPerfOpt.lastHeavyMs = now;
   return false;
}

void UltraOpt_MarkHeavyDone()
{
   g_UltraPerfOpt.lastHeavyMs = (long)GetTickCount();
}

void UltraOpt_NoteLatency(const long ms)
{
   g_UltraPerfOpt.lastLatencyMs = ms;
   if(ms > g_UltraPerfOpt.peakLatencyMs)
      g_UltraPerfOpt.peakLatencyMs = ms;
}

// Lightweight resource monitor (tick budget / latency / cycle pressure)
string UltraResource_Monitor()
{
   long lat = g_UltraCore.lastLatencyMs;
   UltraOpt_NoteLatency(lat);
   string t = "RES: lat=";
   t += IntegerToString((int)lat);
   t += "ms peak=";
   t += IntegerToString((int)g_UltraPerfOpt.peakLatencyMs);
   t += "ms cycles=";
   t += IntegerToString((int)g_UltraPerfOpt.cycleCount);
   if(lat > 500) t += " WARN";
   else t += " OK";
   return t;
}

string UltraOpt_Summary()
{
   string t = "cycles=";
   t += IntegerToString((int)g_UltraPerfOpt.cycleCount);
   t += " skipHeavy=";
   if(g_UltraPerfOpt.skipHeavy) t += "Y"; else t += "N";
   return t;
}

#endif
//===== END 37_Optimization.mqh =====

//===== BEGIN 24_Dashboard.mqh =====
#ifndef HITMAN_ULTRA_24_DASHBOARD_MQH
#define HITMAN_ULTRA_24_DASHBOARD_MQH
//+------------------------------------------------------------------+
//| HITMAN AI — 24_DASHBOARD — Master · Regime · Thesis · Hold · Risk
//+------------------------------------------------------------------+
string UltraDashboardText(const string s)
{
   UltraSnap u = g_UltraLastSnap;
   UltraSignal sig = g_UltraLastSignal;
   string dir = "-";
   if(sig.buy) dir = "BUY";
   else if(sig.sell) dir = "SELL";
   if(g_UltraBrainLast.decision == SUP_BUY) dir = "BUY";
   else if(g_UltraBrainLast.decision == SUP_SELL) dir = "SELL";
   else if(g_UltraBrainLast.decision == SUP_WAIT && !(sig.buy || sig.sell)) dir = "WAIT";

   string bos = "-";
   if(u.bos.buy) bos = "BUY";
   else if(u.bos.sell) bos = "SELL";
   if(u.bos.strong) bos += " STRONG";
   else if(u.bos.weak) bos += " WEAK";
   if(u.bos.failed) bos += " FAILED";

   string choch = "-";
   if(u.choch.buy) choch = "BUY";
   else if(u.choch.sell) choch = "SELL";

   string sweep = "-";
   if(u.liq.sweepBuy) sweep = "BUY";
   else if(u.liq.sweepSell) sweep = "SELL";

   string vol = "NORMAL";
   if(u.vol.expansion) vol = "EXPAND";
   else if(u.vol.compression) vol = "COMPRESS";

   string master = "-";
   int md = UltraMTF_MasterDir(s);
   if(md > 0) master = "BUY";
   else if(md < 0) master = "SELL";

   string explain = sig.explanation;
   if(StringLen(explain) == 0)
   {
      bool leanBuy = (dir != "SELL");
      bool approved = (dir == "BUY" || dir == "SELL");
      explain = UltraUFSE_DebugExplain(u, leanBuy, approved);
   }

   string t = "======= HITMAN AI =======\n";
   t += "BUILD: HA_ULTRA_93 MASTER | Comment: HITMAN AI\n";
   t += "Symbol: "; t += s;
   t += " | TF: "; t += EnumToString(UltraETF());
   t += "\n"; t += UltraBrain_Dashboard();
   t += "\n"; t += UltraMission_Dashboard();
   t += "\n"; t += UltraInput_Dashboard();
   t += " | "; t += UltraData_Dashboard();
   t += "\nMaster Trend: "; t += master;
   t += " | Regime: "; t += UltraRegimeName(u.regime);
   t += " | Cycle: "; t += u.st.cycleName;
   t += "\nOpen Trades: "; t += IntegerToString(CountOpenTrades());
   t += " / "; t += IntegerToString(MaxOpenTrades);
   t += "\nAI Conf: "; t += IntegerToString(u.score.confidence);
   t += " | Prec: "; t += IntegerToString(u.score.precision);
   t += " | Prob: "; t += IntegerToString(u.score.probability);
   t += "\n"; t += UltraThesis_Dashboard();
   t += " | "; t += UltraHold_Dashboard();
   t += "\n"; t += UltraMTF_Dashboard(s);
   t += "\nSession: "; t += u.ctx.session;
   t += " | LiqWin: "; if(u.ctx.sessionLiquidity) t += "Y"; else t += "N";
   t += " | Qual: "; t += IntegerToString(u.ctx.sessionQuality);
   t += " | News: "; t += u.ctx.newsPhase;
   t += " | (never blocks)";
   t += "\nTrend votes B/S: "; t += IntegerToString(u.trend.mtfVotesBuy);
   t += "/"; t += IntegerToString(u.trend.mtfVotesSell);
   t += " | Str: "; t += IntegerToString(u.trend.strength);
   t += "\nBOS: "; t += bos;
   t += " CHoCH: "; t += choch;
   t += " Sweep: "; t += sweep;
   t += "\nFib zone B/S: "; if(u.fib.atBuyZone) t += "Y"; else t += "N";
   t += "/"; if(u.fib.atSellZone) t += "Y"; else t += "N";
   t += " | InstLiq B/S: "; if(u.ict.institutionalLiqBuy) t += "Y"; else t += "N";
   t += "/"; if(u.ict.institutionalLiqSell) t += "Y"; else t += "N";
   t += "\nSMI: "; t += DoubleToString(u.ind.smi, 1);
   t += " | MEO: "; t += DoubleToString(u.ind.meo, 1);
   t += " | IFI: "; t += DoubleToString(u.ind.ifi, 1);
   t += "\nVol: "; t += vol;
   long dig = 0; SymbolInfoInteger(s, SYMBOL_DIGITS, dig);
   t += " ATR="; t += DoubleToString(u.vol.atr, (int)dig);
   t += "\nExec: "; if(u.diag.brokerOK && u.diag.connectionOK) t += "READY"; else t += "CHECK";
   t += " | Risk: "; if(u.score.riskProb < 70) t += "OK"; else t += "HIGH";
   t += " | Capital: "; if(g_UltraCore.healthy) t += "OK"; else t += "CHECK";
   t += "\n"; t += UltraSystemHealth_Dashboard();
   t += " | "; t += UltraResource_Monitor();
   t += "\nWR: "; t += DoubleToString(g_UltraMem.winRate, 1); t += "%";
   t += " PF: "; t += DoubleToString(g_UltraMem.profitFactor, 2);
   t += " RR: "; t += DoubleToString(g_UltraMem.avgRR, 2);
   t += "\nSignal: "; t += dir; t += " ["; t += sig.tag; t += "] "; t += sig.reason;
   t += "\n"; t += UltraDefense_DashboardLine();
   t += " | "; t += UltraDiscipline_DashboardLine();
   t += "\n"; t += UltraSupreme_Dashboard();
   t += " | "; t += UltraMemory_Dashboard();
   if(UltraUSM2Enabled && g_UltraUSM2Last.tradeScore > 0)
   {
      t += "\nUSM2: conf="; t += IntegerToString(g_UltraUSM2Last.confidence);
      t += " score="; t += IntegerToString(g_UltraUSM2Last.tradeScore);
      t += " "; t += g_UltraUSM2Last.grade;
      t += " evo="; t += g_UltraSupremeLast.evo;
   }
   t += "\nUFSE: "; t += UltraUFSE_Stats(s);
   t += "\n"; t += UltraEvent_Dashboard();
   t += "\n---- EXPLAIN ----\n"; t += explain;
   t += "\n===============================";
   return t;
}

void CreateDashboard()
{
   if(!EnableDashboard && !UltraDashboardEnabled)
      return;
   Comment(UltraDashboardText(BrokerSymbol));
}

#endif // HITMAN_ULTRA_24_DASHBOARD_MQH
//===== END 24_Dashboard.mqh =====

//===== BEGIN 32_BrokerCompatibility.mqh =====
#ifndef HITMAN_ULTRA_32_BROKERCOMPAT_MQH
#define HITMAN_ULTRA_32_BROKERCOMPAT_MQH
//+------------------------------------------------------------------+
//| 32_BrokerCompatibility — fill/exec modes · stops · freeze · caps |
//+------------------------------------------------------------------+

struct UltraBrokerCaps
{
   string company;
   long   login;
   int    stopsLevel;
   int    freezeLevel;
   int    fillingMode;
   bool   fillFOK;
   bool   fillIOC;
   bool   fillRETURN;
   bool   tradeAllowed;
   bool   valid;
};

UltraBrokerCaps g_UltraBrokerCaps;

void UltraBroker_ClearCaps(UltraBrokerCaps &c)
{
   c.company = "";
   c.login = 0;
   c.stopsLevel = 0;
   c.freezeLevel = 0;
   c.fillingMode = 0;
   c.fillFOK = c.fillIOC = c.fillRETURN = false;
   c.tradeAllowed = false;
   c.valid = false;
}

bool UltraBroker_Detect(const string s, UltraBrokerCaps &c)
{
   UltraBroker_ClearCaps(c);
   c.company = AccountInfoString(ACCOUNT_COMPANY);
   c.login   = AccountInfoInteger(ACCOUNT_LOGIN);
   long stopsLevel = 0, freezeLevel = 0, fillingMode = 0;
   SymbolInfoInteger(s, SYMBOL_TRADE_STOPS_LEVEL, stopsLevel);
   SymbolInfoInteger(s, SYMBOL_TRADE_FREEZE_LEVEL, freezeLevel);
   SymbolInfoInteger(s, SYMBOL_FILLING_MODE, fillingMode);
   c.stopsLevel  = (int)stopsLevel;
   c.freezeLevel = (int)freezeLevel;
   c.fillingMode = (int)fillingMode;
   c.fillFOK    = ((c.fillingMode & SYMBOL_FILLING_FOK) != 0);
   c.fillIOC    = ((c.fillingMode & SYMBOL_FILLING_IOC) != 0);
   c.fillRETURN = true;
   long tmMode = 0;
   SymbolInfoInteger(s, SYMBOL_TRADE_MODE, tmMode);
   c.tradeAllowed = (tmMode != 0);
   c.valid = (SymbolInfoDouble(s, SYMBOL_BID) > 0.0);
   g_UltraBrokerCaps = c;
   return c.valid;
}

ENUM_ORDER_TYPE_FILLING UltraBroker_PickFilling(const string s)
{
   UltraBrokerCaps c;
   UltraBroker_Detect(s, c);
   if(c.fillFOK) return ORDER_FILLING_FOK;
   if(c.fillIOC) return ORDER_FILLING_IOC;
   return ORDER_FILLING_RETURN;
}

bool UltraBroker_StopsOK(const string s, const double price, const double sl, const double tp, string &why)
{
   why = "";
   long stops = 0;
   SymbolInfoInteger(s, SYMBOL_TRADE_STOPS_LEVEL, stops);
   double point = SymbolInfoDouble(s, SYMBOL_POINT);
   if(point <= 0){ why = "bad point"; return false; }
   double minDist = stops * point;
   if(sl > 0 && MathAbs(price - sl) < minDist){ why = "SL inside stops level"; return false; }
   if(tp > 0 && MathAbs(price - tp) < minDist){ why = "TP inside stops level"; return false; }
   return true;
}

bool UltraBroker_FreezeOK(const string s, const double price, const double sl, const double tp, string &why)
{
   why = "";
   long freeze = 0;
   SymbolInfoInteger(s, SYMBOL_TRADE_FREEZE_LEVEL, freeze);
   double point = SymbolInfoDouble(s, SYMBOL_POINT);
   if(freeze <= 0 || point <= 0) return true;
   double minDist = freeze * point;
   if(sl > 0 && MathAbs(price - sl) < minDist){ why = "SL inside freeze level"; return false; }
   if(tp > 0 && MathAbs(price - tp) < minDist){ why = "TP inside freeze level"; return false; }
   return true;
}

string UltraBroker_Summary(const string s)
{
   UltraBrokerCaps c; UltraBroker_Detect(s, c);
   string t = c.company;
   t += " stops="; t += IntegerToString(c.stopsLevel);
   t += " freeze="; t += IntegerToString(c.freezeLevel);
   t += " FOK=";
   if(c.fillFOK) t += "Y"; else t += "N";
   t += " IOC=";
   if(c.fillIOC) t += "Y"; else t += "N";
   return t;
}

#endif
//===== END 32_BrokerCompatibility.mqh =====

//===== BEGIN 36_BrokerHealth.mqh =====
#ifndef HITMAN_ULTRA_36_BROKERHEALTH_MQH
#define HITMAN_ULTRA_36_BROKERHEALTH_MQH
//+------------------------------------------------------------------+
//| 36_BrokerHealth — connection · permissions · market · symbols    |
//+------------------------------------------------------------------+

struct UltraBrokerHealth
{
   bool connected;
   bool tradeAllowed;
   bool terminalTrade;
   bool marketOpen;      // soft: has quotes
   bool symbolOK;
   long pingMs;          // TerminalInfoInteger TERMINAL_PING approx if available
   string status;
};

UltraBrokerHealth g_UltraBrokerHealth;

void UltraHealth_Update(const string s)
{
   g_UltraBrokerHealth.connected = (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
   g_UltraBrokerHealth.terminalTrade = (bool)TerminalInfoInteger(TERMINAL_TRADE_ALLOWED);
   g_UltraBrokerHealth.tradeAllowed = (AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) != 0);
   long sel = 0;
   SymbolInfoInteger(s, SYMBOL_SELECT, sel);
   g_UltraBrokerHealth.symbolOK = (sel != 0);
   double bid = SymbolInfoDouble(s, SYMBOL_BID);
   g_UltraBrokerHealth.marketOpen = (bid > 0.0);
   g_UltraBrokerHealth.pingMs = 0; // broker RTT probe reserved
   if(!g_UltraBrokerHealth.connected) g_UltraBrokerHealth.status = "DISCONNECTED";
   else if(!g_UltraBrokerHealth.terminalTrade || !g_UltraBrokerHealth.tradeAllowed) g_UltraBrokerHealth.status = "TRADE_BLOCKED";
   else if(!g_UltraBrokerHealth.symbolOK) g_UltraBrokerHealth.status = "SYMBOL_BAD";
   else if(!g_UltraBrokerHealth.marketOpen) g_UltraBrokerHealth.status = "NO_QUOTES";
   else g_UltraBrokerHealth.status = "OK";
}

bool UltraHealth_OK(const string s)
{
   UltraHealth_Update(s);
   return (g_UltraBrokerHealth.status == "OK");
}

string UltraHealth_Summary(const string s)
{
   UltraHealth_Update(s);
   return g_UltraBrokerHealth.status + " pingMs=" + IntegerToString((int)g_UltraBrokerHealth.pingMs);
}

#endif
//===== END 36_BrokerHealth.mqh =====

//===== BEGIN 33_OrderManagement.mqh =====
#ifndef HITMAN_ULTRA_33_ORDERMGMT_MQH
#define HITMAN_ULTRA_33_ORDERMGMT_MQH
//+------------------------------------------------------------------+
//| 33_OrderManagement — market/pending · modify · cancel · partial  |
//| Deep market open path remains ExecuteBuy/Sell in Shell_B.        |
//+------------------------------------------------------------------+

bool UltraOrder_IsOurs(const ulong ticket)
{
   if(!OrderSelect(ticket)) return false;
   return (OrderGetInteger(ORDER_MAGIC) == MagicNumber);
}

int UltraOrder_CountPendingOurs()
{
   int n = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      ulong t = OrderGetTicket(i);
      if(t == 0) continue;
      if(!OrderSelect(t)) continue;
      if(OrderGetInteger(ORDER_MAGIC) != MagicNumber) continue;
      n++;
   }
   return n;
}

bool UltraOrder_Cancel(const ulong ticket, string &why)
{
   why = "";
   if(!UltraOrder_IsOurs(ticket)){ why = "not our order"; return false; }
   MqlTradeRequest req; MqlTradeResult res;
   ZeroMemory(req); ZeroMemory(res);
   req.action = TRADE_ACTION_REMOVE;
   req.order  = ticket;
   if(!OrderSend(req, res))
   {
      why = "OrderSend remove failed " + IntegerToString((int)res.retcode);
      return false;
   }
   return (res.retcode == TRADE_RETCODE_DONE || res.retcode == TRADE_RETCODE_PLACED);
}

bool UltraOrder_DuplicateProtect(const string s, const bool buy)
{
   // Block same-direction pending spam on symbol
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      ulong t = OrderGetTicket(i);
      if(t == 0 || !OrderSelect(t)) continue;
      if(OrderGetInteger(ORDER_MAGIC) != MagicNumber) continue;
      if(OrderGetString(ORDER_SYMBOL) != s) continue;
      long typ = OrderGetInteger(ORDER_TYPE);
      bool isBuy = (typ == ORDER_TYPE_BUY_LIMIT || typ == ORDER_TYPE_BUY_STOP || typ == ORDER_TYPE_BUY_STOP_LIMIT);
      bool isSell= (typ == ORDER_TYPE_SELL_LIMIT || typ == ORDER_TYPE_SELL_STOP || typ == ORDER_TYPE_SELL_STOP_LIMIT);
      if(buy && isBuy) return true;
      if(!buy && isSell) return true;
   }
   return UltraExec_DuplicateBarGuard(s);
}

string UltraOrder_ModuleStatus()
{
   return "pendingOurs=" + IntegerToString(UltraOrder_CountPendingOurs()) +
          " | market opens via Shell_B ExecuteBuy/Sell";
}

#endif
//===== END 33_OrderManagement.mqh =====

//===== BEGIN 34_PositionManagement.mqh =====
#ifndef HITMAN_ULTRA_34_POSMGMT_MQH
#define HITMAN_ULTRA_34_POSMGMT_MQH
//+------------------------------------------------------------------+
//| 34_PositionManagement — track · sync · monitor · stats           |
//+------------------------------------------------------------------+

struct UltraPosInfo
{
   ulong  ticket;
   string symbol;
   long   type;
   double volume;
   double profit;
   double sl;
   double tp;
   string comment;
};

int UltraPos_CountMagic()
{
   int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || !PositionSelectByTicket(t)) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      n++;
   }
   return n;
}

int UltraPos_CountSymbol(const string s)
{
   int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || !PositionSelectByTicket(t)) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      if(PositionGetString(POSITION_SYMBOL) != s) continue;
      n++;
   }
   return n;
}

bool UltraPos_Get(const ulong ticket, UltraPosInfo &p)
{
   p.ticket=0; p.symbol=""; p.type=0; p.volume=0; p.profit=0; p.sl=0; p.tp=0; p.comment="";
   if(!PositionSelectByTicket(ticket)) return false;
   if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) return false;
   p.ticket  = ticket;
   p.symbol  = PositionGetString(POSITION_SYMBOL);
   p.type    = PositionGetInteger(POSITION_TYPE);
   p.volume  = PositionGetDouble(POSITION_VOLUME);
   p.profit  = PositionGetDouble(POSITION_PROFIT);
   p.sl      = PositionGetDouble(POSITION_SL);
   p.tp      = PositionGetDouble(POSITION_TP);
   p.comment = PositionGetString(POSITION_COMMENT);
   return true;
}

double UltraPos_TotalProfitMagic()
{
   double sum = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || !PositionSelectByTicket(t)) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      sum += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
   }
   return sum;
}

string UltraPos_Summary()
{
   return "open=" + IntegerToString(UltraPos_CountMagic()) +
          " pnl=" + DoubleToString(UltraPos_TotalProfitMagic(), 2);
}

#endif
//===== END 34_PositionManagement.mqh =====

//===== BEGIN 35_SignalEngine.mqh =====
#ifndef HITMAN_ULTRA_35_SIGNAL_MQH
#define HITMAN_ULTRA_35_SIGNAL_MQH
//+------------------------------------------------------------------+
//| 35_SignalEngine — Master Blueprint BUY/SELL checklist            |
//| BUY:  Structure · BOS|CHoCH · Liquidity · Trend · Momentum ·     |
//|       Precision · Confidence                                     |
//| SELL: same on bearish side                                       |
//+------------------------------------------------------------------+

struct UltraRawSignal
{
   bool   buy;
   bool   sell;
   int    score;
   string tag;
   string reason;
   string explanation;
   bool   valid;
};

struct UltraSignalChecklist
{
   bool structure;
   bool bosOrChoch;
   bool liquidity;
   bool trend;
   bool momentum;
   bool precisionOK;
   bool confidenceOK;
   int  passed;
};

UltraSignalChecklist UltraSignal_EvalSide(const UltraSnap &u, const bool buySide)
{
   UltraSignalChecklist c;
   if(buySide)
   {
      c.structure  = (u.st.hh || u.st.hl || u.st.externalBull || u.st.internalBull || u.st.continuation);
      c.bosOrChoch = (u.bos.buy || u.choch.buy);
      c.liquidity  = (u.liq.sweepBuy || u.liq.stopHuntBuy || u.liq.grabBuy || u.liq.equalLows);
      c.trend      = (u.trend.bull || u.trend.htfBull || u.trend.macroBull || u.trend.mtfVotesBuy >= u.trend.mtfVotesSell);
      c.momentum   = (u.mom.momBuy || u.mom.impulse || u.ict.dispBuy || u.ind.smi > 0);
   }
   else
   {
      c.structure  = (u.st.lh || u.st.ll || u.st.externalBear || u.st.internalBear || u.st.continuation);
      c.bosOrChoch = (u.bos.sell || u.choch.sell);
      c.liquidity  = (u.liq.sweepSell || u.liq.stopHuntSell || u.liq.grabSell || u.liq.equalHighs);
      c.trend      = (u.trend.bear || u.trend.htfBear || u.trend.macroBear || u.trend.mtfVotesSell > u.trend.mtfVotesBuy);
      c.momentum   = (u.mom.momSell || u.mom.impulse || u.ict.dispSell || u.ind.smi < 0);
   }
   c.precisionOK  = (u.score.precision >= UltraMinPrecision || u.score.confidence >= UltraInstantFireConf);
   c.confidenceOK = (u.score.confidence >= UltraFireFloor() || u.score.confidence >= UltraInstantFireConf ||
                     (InstantQualityMode && u.score.confidence >= UltraFireFloor() - 8));
   c.passed = (c.structure?1:0)+(c.bosOrChoch?1:0)+(c.liquidity?1:0)+(c.trend?1:0)+
              (c.momentum?1:0)+(c.precisionOK?1:0)+(c.confidenceOK?1:0);
   return c;
}

// Soft checklist note: live fire stays UltraAIDecide; this API adds explain + formal gates
string UltraSignal_Explain(const UltraSnap &u, const bool buySide, const bool approved, const string decision)
{
   return UltraBuildExplanation(u, buySide, approved, decision);
}

bool UltraSignal_ChecklistPass(const UltraSnap &u, const bool buySide)
{
   UltraSignalChecklist c = UltraSignal_EvalSide(u, buySide);
   if(InstantQualityMode)
      return (c.passed >= 4 && c.confidenceOK);
   return (c.structure && c.bosOrChoch && c.trend && c.confidenceOK &&
           (c.liquidity || c.momentum) && c.precisionOK);
}

UltraRawSignal UltraSignal_Generate(const string s)
{
   UltraRawSignal out;
   out.buy = out.sell = false; out.score = 0; out.tag = "NONE";
   out.reason = ""; out.explanation = ""; out.valid = false;

   UltraSnap snap;
   if(!UltraBuildSnapshot(s, snap))
   {
      out.reason = "snapshot fail";
      out.explanation = "Decision = WAIT | Reason = snapshot fail";
      return out;
   }

   UltraSignal best;
   string why = "";
   if(!UltraAIDecide(s, snap, best, why))
   {
      bool leanBuy = (UltraConfluenceBuy(snap) >= UltraConfluenceSell(snap));
      out.reason = why;
      out.score = snap.score.confidence;
      out.explanation = UltraSignal_Explain(snap, leanBuy, false, "NO TRADE");
      return out;
   }

   if(!UltraSignal_ChecklistPass(snap, best.buy))
   {
      out.reason = "checklist incomplete";
      out.score = snap.score.confidence;
      out.explanation = UltraSignal_Explain(snap, best.buy, false, "NO TRADE");
      return out;
   }

   out.buy = best.buy; out.sell = best.sell;
   out.score = best.score; out.tag = best.tag; out.reason = best.reason;
   out.explanation = UltraSignal_Explain(snap, best.buy, true, best.tag);
   out.valid = (out.buy || out.sell);
   return out;
}

bool UltraSignal_Filter(const UltraRawSignal &sig, const int minScore)
{
   if(!sig.valid) return false;
   if(!(sig.buy || sig.sell)) return false;
   if(sig.score < minScore) return false;
   return true;
}

bool UltraSignal_Validate(const string s, const UltraRawSignal &sig, string &why)
{
   why = "";
   if(!UltraSignal_Filter(sig, UltraFireFloor()) && sig.score < UltraInstantFireConf)
   { why = "score filter"; return false; }
   if(UltraBlockOppositeSameSym)
   {
      int d = UltraSymDir(s);
      if(sig.buy && d < 0){ why = "opposite sell open"; return false; }
      if(sig.sell && d > 0){ why = "opposite buy open"; return false; }
   }
   return true;
}

#endif // HITMAN_ULTRA_35_SIGNAL_MQH
//===== END 35_SignalEngine.mqh =====

//===== BEGIN 38_Backtesting.mqh =====
#ifndef HITMAN_ULTRA_38_BACKTEST_MQH
#define HITMAN_ULTRA_38_BACKTEST_MQH
//+------------------------------------------------------------------+
//| 38_Backtesting — tester detection · stats · walk-forward hooks   |
//+------------------------------------------------------------------+

bool UltraBT_IsTester()
{
   return (bool)MQLInfoInteger(MQL_TESTER);
}

bool UltraBT_IsOptimization()
{
   return (bool)MQLInfoInteger(MQL_OPTIMIZATION);
}

bool UltraBT_IsVisual()
{
   return (bool)MQLInfoInteger(MQL_VISUAL_MODE);
}

string UltraBT_ModeName()
{
   if(UltraBT_IsOptimization()) return "OPTIMIZATION";
   if(UltraBT_IsTester())
   {
      if(UltraBT_IsVisual()) return "TESTER_VISUAL";
      return "TESTER";
   }
   return "LIVE";
}

void UltraBT_LogStats()
{
   if(!UltraBT_IsTester()) return;
   UltraStats_Refresh();
   UltraLogPerf("BT " + UltraBT_ModeName() + " " + UltraStats_Report());
}

// Walk-forward placeholder hooks (fill during optimization campaigns)
datetime g_UltraBT_WF_Start = 0;
datetime g_UltraBT_WF_End   = 0;

void UltraBT_SetWalkForwardWindow(const datetime from, const datetime to)
{
   g_UltraBT_WF_Start = from;
   g_UltraBT_WF_End = to;
}

bool UltraBT_InWalkForwardWindow(const datetime t)
{
   if(g_UltraBT_WF_Start <= 0 || g_UltraBT_WF_End <= 0) return true;
   return (t >= g_UltraBT_WF_Start && t <= g_UltraBT_WF_End);
}

#endif
//===== END 38_Backtesting.mqh =====

//===== BEGIN 40_DebugTools.mqh =====
#ifndef HITMAN_ULTRA_40_DEBUG_MQH
#define HITMAN_ULTRA_40_DEBUG_MQH
//+------------------------------------------------------------------+
//| 40_DebugTools — asserts · timers · diagnostic helpers           |
//+------------------------------------------------------------------+


long g_UltraDebugTimerStart = 0;

void UltraDebug_Msg(const string msg)
{
   if(!UltraDebugEnabled) return;
   Print("ULTRA-DEBUG| ", msg);
}

void UltraDebug_Assert(const bool cond, const string msg)
{
   if(cond) return;
   UltraSetError("ASSERT " + msg);
   if(UltraDebugEnabled) Print("ULTRA-ASSERT FAILED| ", msg);
}

void UltraDebug_TimerStart()
{
   g_UltraDebugTimerStart = (long)GetTickCount();
}

long UltraDebug_TimerElapsedMs()
{
   if(g_UltraDebugTimerStart <= 0) return 0;
   return (long)GetTickCount() - g_UltraDebugTimerStart;
}

void UltraDebug_DumpSnapshot(const string s)
{
   if(!UltraDebugEnabled) return;
   UltraSnap u;
   if(!UltraBuildSnapshot(s, u))
   {
      UltraDebug_Msg("snapshot fail " + g_UltraCore.lastError);
      return;
   }
   UltraDebug_Msg("regime=" + UltraRegimeName(u.regime) +
                  " conf=" + IntegerToString(u.score.confidence) +
                  " prec=" + IntegerToString(u.score.precision) +
                  " session=" + u.ctx.session +
                  " SMI=" + DoubleToString(u.ind.smi, 1));
}

string UltraDebug_ModuleStatus()
{
   if(UltraDebugEnabled) return "DEBUG ON";
   return "DEBUG OFF";
}

#endif
//===== END 40_DebugTools.mqh =====

//===== BEGIN Shell_B_TradeSystem.mqh =====
#ifndef HITMAN_ULTRA_SHELL_B_MQH
#define HITMAN_ULTRA_SHELL_B_MQH
//+------------------------------------------------------------------+
//| Shell B — Trade system / management / events (post-Ultra)        |
//+------------------------------------------------------------------+

int OnInit()
{
   if(StringCompare(TradeComment, "HITMAN AI") != 0)
   {
      Print("HITMAN AI INIT FAILED: TradeComment input must be exactly HITMAN AI");
      return(INIT_PARAMETERS_INCORRECT);
   }

   g_Trade.SetExpertMagicNumber(MagicNumber);

   BrokerSymbol = DetectBrokerSymbol(_Symbol);
   PrimarySymbol = BrokerSymbol;

   // Must run before indicator initialization - InitializeSymbols() builds
   // MultiSymbolList (via BuildMultiSymbolList at its end), and every
   // indicator handle array below is sized/indexed against that list.
   InitializeSymbols();

   ResizePerSymbolTrackingArrays();

   if(!InitializeIndicators())
   {
      Print("Indicator initialization failed.");
      return(INIT_FAILED);
   }

   if(!InitializeMarketFilters())
   {
      Print("Market Filter initialization failed.");
      return(INIT_FAILED);
   }

   InitializeRiskEngine();

   ApplyChartTheme();

   RestoreTradeStates();

   RestoreTradeStatistics();

   RestoreSignalStatistics();

   RestoreStrategyPerformance();

   // TRADEUNBLOCK53: wipe stuck PeakEquity GV so a re-enabled DD shield
   // starts from current equity (was permanently blocking at ~50%+ DD).
   if(ResetPeakEquityOnInit)
      ResetPeakEquityToCurrent();

   CreateChartBackground();

   if(EnableMultiSymbolTrading)
   {
      EventSetTimer(MultiSymbolTimerSeconds);
      Print("Multi-symbol timer started (", MultiSymbolTimerSeconds, "s interval).");
   }

   Print("HITMAN AI Loaded BUILD_ID=HA_ULTRA_93 MaxOpen=", MaxOpenTrades);
   UltraCoreInit();
   UltraSystemController_Boot();
   UltraEvent_OnBoot();
   UltraOpt_OnTickStart();
   UltraMission_Init();
   {
      ENUM_TIMEFRAMES etf = (EntryTF == PERIOD_CURRENT) ? (ENUM_TIMEFRAMES)Period() : EntryTF;
      Print("OK93 ENTRY TF=", EnumToString(etf),
            " (EntryTF input=", EnumToString(EntryTF),
            ") — change the chart timeframe to change trading TF, or set EntryTF input");
   }
   Print("HITMAN MASTER BLUEPRINT: modules 00-40 + UFSE v1.0 + DEFENSE LINE v1.0 | HITMAN AI live path");
   Print("UFSE: FastSignal=", UltraYN(UltraFastSignalEnabled),
         " MasterTrendLock=", UltraYN(UltraMasterTrendLock),
         " SignalLock=", UltraYN(UltraSignalLockEnabled),
         " EntryTrigger=", UltraYN(UltraUFSE_EntryTriggerGate),
         " ExplainLog=", UltraYN(UltraUFSE_ExplainLog));
   Print("DEFENSE LINE ENGINE: Enabled=", UltraYN(UltraDefenseEnabled),
         " Strict=", UltraYN(UltraDefenseStrict),
         " GateEntry=", UltraYN(UltraDefenseGateEntry),
         " GateExec=", UltraYN(UltraDefenseGateExec),
         " Position=", UltraYN(UltraDefensePosition),
         " Emergency=", UltraYN(UltraDefenseEmergency));
   Print("TRADE ENTRY DISCIPLINE: Enabled=", UltraYN(UltraDisciplineEnabled),
         " Strict=", UltraYN(UltraDisciplineStrict),
         " StableEvals=", UltraDisciplineStableEvals,
         " MTFMinAgree=", UltraDisciplineMTFMinAgree,
         " NeedNewStruct=", UltraYN(UltraDisciplineNeedNewStruct));
   Print("ULTRA UPGRADE PACK: Enabled=", UltraYN(UltraUpgradeEnabled),
         " Strict=", UltraYN(UltraUpgradeStrict),
         " Supreme=", UltraYN(UltraSupremeEnabled),
         " USM2=", UltraYN(UltraUSM2Enabled),
         " Weights=", UltraYN(UltraDynWeightsEnabled),
         " Thesis=", UltraYN(UltraThesisEnabled),
         " SmartExit=", UltraYN(UltraSmartExitEnabled));
   if(EnableAPEXStrategy || EnableContFallback || EnableLCSStrategy)
      Print("OK93 WARNING: old APEX/ContFallback/LCS input ON — evaluators STUBBED; ULTRA only fires");
   Print("INSTANT OPEN + QUALITY PREFER MODE=", UltraYN(InstantQualityMode));
   Print("QUALITY SELECT: IDP_Hard=", UltraYN(IDP_HardGate), " MinPulse=", IDP_MinAbsPulse,
         " ContScore=", ContStruct_MinScore, " ADX=", UltraYN(ContStruct_RequireTrendADX),
         " SkipRange=", UltraYN(ContStruct_SkipRanging));
   Print("INSTANT EXEC: TradeCD=", TradeCooldownMinutes, " AttemptCD=", AttemptCooldownSeconds,
         " ContCD=", ContFallbackCooldownMinutes,
         " TickDetect=", UltraYN(EnableTickLevelSignalDetection),
         " NeverBlock=", UltraYN(NeverBlockValidSniperEntry),
         " UltraAggro=", UltraYN(UltraAggressiveFire));
   Print("CRITICAL: SOURCE must be HITMAN_AI");
   Print("INSTANT QUALITY81: ANYTIME + STRONG/QUALITY + IDP CORE | AntiScalp=", UltraYN(EnableAntiScalpMode),
         " HardBlock=", UltraYN(APEX_SessionHardBlock), " (must be false)",
         " NewsAware=", UltraYN(EnableNewsAwareness),
         " IDP=", UltraYN(EnableIDPConfluence),
         " SpreadAlwaysAllow | MaxOpen=", MaxOpenTrades,
         " Lot=", LotSize);
   Print("APEX ", EnumToString(APEX_BiasTF), "/", EnumToString(APEX_EntryTF),
         " | ContFallback cooldown=", ContFallbackCooldownMinutes, "m hold=", ContFallbackMinimumHoldBars,
         " | DD shield=", UltraYN(EnableDrawdownProtection));
   Print("STRONG QUALITY Cont: ADX=", UltraYN(ContStruct_RequireTrendADX),
         " SkipRange=", UltraYN(ContStruct_SkipRanging),
         " MinScore=", ContStruct_MinScore,
         " TwoBarBOS=", UltraYN(ContStruct_RequireTwoBarBOS),
         " ZoneOrDisp=", UltraYN(ContStruct_ZoneOrDisplacement),
         " CF_Cooldown=", ContFallbackCooldownMinutes);
   Print("ANYTIME: SessionHardBlock=", UltraYN(APEX_SessionHardBlock),
         " | SessionDetect=", UltraYN(EnableSessionDetect),
         " | Spread/News never hard-block | ContFallback=", UltraYN(EnableContFallback));
   Print("IDP BUILT-IN CORE: Enable=", UltraYN(EnableIDPConfluence),
         " HardGate=", UltraYN(IDP_HardGate),
         " RequireStrong=", UltraYN(IDP_RequireStrong),
         " MinAbs=", IDP_MinAbsPulse,
         " StrongAbs=", IDP_StrongAbsPulse,
         " Shift=", IDP_PulseShift,
         " ATR=", IDP_ATR_Period,
         " EMA=", IDP_EMA_Period);
   Print("IDP: pulse computed INSIDE EA (no iCustom) - chart SNIPER_IDP optional visual only");
   UpdateNewsAwareness();
   {
      string sn="", sd=""; bool a=false,b=false,c=false,d=false; int h=-1;
      DetectMarketSession(sn, sd, a, b, c, d, h);
      Print("SESSION DETECT ON LOAD: ", sd);
   }
   AnalyzeLiveMarket(true);
   Print("MARKET: ", LiveMarketSummary());
   if(PrintPathStatsOnInit)
      PrintStrategyPerformanceReport();

   return(INIT_SUCCEEDED);
}

// Sizes every per-symbol tracking array to match MultiSymbolList, with
// safe defaults (no cooldown active, no handles yet).
void ResizePerSymbolTrackingArrays()
{
   int n = ArraySize(MultiSymbolList);

   ArrayResize(LastTradeTimeArr, n);
   ArrayResize(LastAttemptTimeArr, n);
   ArrayResize(LastTradeWasLossArr, n);
   ArrayResize(LastLossCloseTimeArr, n);
   ArrayResize(EMAHandles, n);
   ArrayResize(ADXHandles, n);
   ArrayResize(ATRHandlesArr, n);
   ArrayResize(FilterATRHandles, n);
   ArrayResize(HTFEMAHandlesArr, n);
   ArrayResize(RSIHandlesArr, n);
   ArrayResize(BBHandlesArr, n);
   ArrayResize(FastEMAHandlesArr, n);
   ArrayResize(SlowEMAHandlesArr, n);

   ArrayResize(LastEntryEvalBarTimeArr, n);
   ArrayResize(ConsecutiveLossesPerSymbolArr, n);
   ArrayResize(ConsecutiveWinsPerSymbolArr, n);
   ArrayResize(CHoCH_LastBarTimeArr, n);
   ArrayResize(CHoCH_LastBullTrendArr, n);
   ArrayResize(CHoCH_StateInitializedArr, n);
   ArrayResize(DiagLastBarTimeArr, n);
   ArrayResize(LastBOSTrueBarTimeArr, n);
   ArrayResize(LastCHoCHTrueBarTimeArr, n);
   ArrayResize(LastCHoCHWasBullArr, n);
   ArrayResize(LastSweepTrueBarTimeArr, n);
   ArrayResize(CHoCH_CacheCycleArr, n);
   ArrayResize(CHoCH_CacheResultArr, n);
   ArrayResize(RSI_CacheCycleArr, n);
   ArrayResize(RSI_CacheValueArr, n);
   ArrayResize(BB_CacheCycleArr, n);
   ArrayResize(BB_CacheUpperArr, n);
   ArrayResize(BB_CacheLowerArr, n);
   ArrayResize(BB_CacheMidArr, n);

   ArrayResize(OB_Bull_BarTimeArr, n);
   ArrayResize(OB_Bull_TopArr, n);
   ArrayResize(OB_Bull_BottomArr, n);
   ArrayResize(OB_Bull_ActiveArr, n);
   ArrayResize(OB_Bull_MitigatedArr, n);
   ArrayResize(OB_Bear_BarTimeArr, n);
   ArrayResize(OB_Bear_TopArr, n);
   ArrayResize(OB_Bear_BottomArr, n);
   ArrayResize(OB_Bear_ActiveArr, n);
   ArrayResize(OB_Bear_MitigatedArr, n);
   ArrayResize(OB_LastProcessedBarTimeArr, n);

   ArrayResize(FVG_Bull_BarTimeArr, n);
   ArrayResize(FVG_Bull_TopArr, n);
   ArrayResize(FVG_Bull_BottomArr, n);
   ArrayResize(FVG_Bull_ActiveArr, n);
   ArrayResize(FVG_Bull_FilledPctArr, n);
   ArrayResize(FVG_Bear_BarTimeArr, n);
   ArrayResize(FVG_Bear_TopArr, n);
   ArrayResize(FVG_Bear_BottomArr, n);
   ArrayResize(FVG_Bear_ActiveArr, n);
   ArrayResize(FVG_Bear_FilledPctArr, n);
   ArrayResize(FVG_LastProcessedBarTimeArr, n);

   ArrayResize(SwingHighCacheCycleArr, n);
   ArrayResize(SwingHighCacheArr, n);
   ArrayResize(SwingLowCacheCycleArr, n);
   ArrayResize(SwingLowCacheArr, n);
   ArrayResize(BOS_CacheCycleArr, n);
   ArrayResize(BOS_CacheResultArr, n);
   ArrayResize(LastApprovedBuyBarTimeArr, n);
   ArrayResize(LastApprovedSellBarTimeArr, n);
   ArrayResize(RegimeLastStateArr, n);

   for(int i = 0; i < n; i++)
   {
      LastTradeTimeArr[i]     = 0;
      LastAttemptTimeArr[i]   = 0;
      LastTradeWasLossArr[i]  = false;
      LastLossCloseTimeArr[i] = 0;
      EMAHandles[i]           = INVALID_HANDLE;
      ADXHandles[i]           = INVALID_HANDLE;
      ATRHandlesArr[i]        = INVALID_HANDLE;
      FilterATRHandles[i]     = INVALID_HANDLE;
      HTFEMAHandlesArr[i]     = INVALID_HANDLE;
      RSIHandlesArr[i]        = INVALID_HANDLE;
      BBHandlesArr[i]         = INVALID_HANDLE;
      FastEMAHandlesArr[i]    = INVALID_HANDLE;
      SlowEMAHandlesArr[i]    = INVALID_HANDLE;

      LastEntryEvalBarTimeArr[i]    = 0;
      ConsecutiveLossesPerSymbolArr[i] = 0;
      ConsecutiveWinsPerSymbolArr[i]   = 0;
      CHoCH_LastBarTimeArr[i]       = 0;
      CHoCH_LastBullTrendArr[i]     = false;
      CHoCH_StateInitializedArr[i]  = false;
      DiagLastBarTimeArr[i]         = 0;
      LastBOSTrueBarTimeArr[i]      = 0;
      LastCHoCHTrueBarTimeArr[i]    = 0;
      LastCHoCHWasBullArr[i]        = false;
      LastSweepTrueBarTimeArr[i]    = 0;
      CHoCH_CacheCycleArr[i]        = -1;
      CHoCH_CacheResultArr[i]       = false;
      RSI_CacheCycleArr[i]          = -1;
      RSI_CacheValueArr[i]          = EMPTY_VALUE;
      BB_CacheCycleArr[i]           = -1;

      OB_Bull_ActiveArr[i]     = false;
      OB_Bull_MitigatedArr[i]  = false;
      OB_Bull_BarTimeArr[i]    = 0;
      OB_Bear_ActiveArr[i]     = false;
      OB_Bear_MitigatedArr[i]  = false;
      OB_Bear_BarTimeArr[i]    = 0;
      OB_LastProcessedBarTimeArr[i] = 0;

      FVG_Bull_ActiveArr[i]    = false;
      FVG_Bull_FilledPctArr[i] = 0.0;
      FVG_Bull_BarTimeArr[i]   = 0;
      FVG_Bear_ActiveArr[i]    = false;
      FVG_Bear_FilledPctArr[i] = 0.0;
      FVG_Bear_BarTimeArr[i]   = 0;
      FVG_LastProcessedBarTimeArr[i] = 0;

      SwingHighCacheCycleArr[i] = -1;
      SwingHighCacheArr[i]      = EMPTY_VALUE;
      SwingLowCacheCycleArr[i]  = -1;
      SwingLowCacheArr[i]       = EMPTY_VALUE;
      BOS_CacheCycleArr[i]    = -1;
      BOS_CacheResultArr[i]   = false;
      LastApprovedBuyBarTimeArr[i]  = 0;
      LastApprovedSellBarTimeArr[i] = 0;
      RegimeLastStateArr[i]   = -1;
   }
}

input group "WATERMARK"

// FIX: the first version of this watermark used a hand-built 32-bit BMP
// with a real per-pixel alpha channel. In theory MT5 supports that for
// bitmap loader did not render that hand-built alpha data at all (the
// object showed up completely invisible on your chart, not just faint).
// Rather than keep chasing an unverified alpha format, the fade is now
// baked directly into a plain, standard 24-bit BMP (blended against solid
// white, since ApplyChartTheme() below fixes the chart background to
// white anyway) - this is the well-supported, guaranteed-to-render path.
// The visual result is identical to a true translucent watermark as long
// as the chart background stays white; if you ever change
// ChartThemeBackground away from white, this image would need
// re-blending against the new color to keep looking faded rather than
// showing a slightly mismatched box.
//
// Place chart_background.bmp in <Data Folder>\MQL5\Images\ before
// compiling this .mq5 (File > Open Data Folder in MT5 to find it).
//
// Sizing fits the image's native 2:3 aspect ratio (520x780) into a box
// scaled off chart height, so it's never stretched/squashed out of shape -
// only scaled and (optionally) nudged from dead-center.

input double WatermarkScalePercent = 55.0; // size of the watermark as a % of chart height, aspect-ratio preserved
input int    WatermarkOffsetX      = 0;    // pixels to shift from dead-center horizontally (+right / -left)
input int    WatermarkOffsetY      = 0;    // pixels to shift from dead-center vertically (+down / -up)

#define WATERMARK_IMG_W 520
#define WATERMARK_IMG_H 780

//+------------------------------------------------------------------+
//| Create Centered Watermark (real alpha-channel 32-bit BMP)         |
//+------------------------------------------------------------------+
void CreateChartBackground()
{
   // Watermark disabled - no BMP resource required for compile/run.
   return;
}

//======================== CHART EVENT ==============================//

void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   // Keep the background image filling the chart if the window is resized.
   if(id == CHARTEVENT_CHART_CHANGE)
      CreateChartBackground();
}

//======================== DEINIT ===================================//

void OnDeinit(const int reason)
{
   for(int i = 0; i < ArraySize(MultiSymbolList); i++)
   {
      if(i < ArraySize(EMAHandles) && EMAHandles[i] != INVALID_HANDLE)
         IndicatorRelease(EMAHandles[i]);

      if(i < ArraySize(ADXHandles) && ADXHandles[i] != INVALID_HANDLE)
         IndicatorRelease(ADXHandles[i]);

      if(i < ArraySize(ATRHandlesArr) && ATRHandlesArr[i] != INVALID_HANDLE)
         IndicatorRelease(ATRHandlesArr[i]);

      if(i < ArraySize(FilterATRHandles) && FilterATRHandles[i] != INVALID_HANDLE)
         IndicatorRelease(FilterATRHandles[i]);

      if(i < ArraySize(HTFEMAHandlesArr) && HTFEMAHandlesArr[i] != INVALID_HANDLE)
         IndicatorRelease(HTFEMAHandlesArr[i]);

      if(i < ArraySize(RSIHandlesArr) && RSIHandlesArr[i] != INVALID_HANDLE)
         IndicatorRelease(RSIHandlesArr[i]);

      if(i < ArraySize(BBHandlesArr) && BBHandlesArr[i] != INVALID_HANDLE)
         IndicatorRelease(BBHandlesArr[i]);

      if(i < ArraySize(FastEMAHandlesArr) && FastEMAHandlesArr[i] != INVALID_HANDLE)
         IndicatorRelease(FastEMAHandlesArr[i]);

      if(i < ArraySize(SlowEMAHandlesArr) && SlowEMAHandlesArr[i] != INVALID_HANDLE)
         IndicatorRelease(SlowEMAHandlesArr[i]);
   }

   if(EnableMultiSymbolTrading)
      EventKillTimer();

    ObjectDelete(0, BG_OBJECT_NAME);
}

//======================== TRADE TRANSACTION =========================//
// Fires whenever a deal/order/position changes. Used here specifically to
// catch the moment a position belonging to this EA (matching symbol +
// magic number) actually CLOSES, so we can tell whether it was a win or
// loss - which drives both the post-loss cooldown and the trade
// statistics tracked in Part 18.

//================ SIGNAL SNAPSHOT TRACKING (loss/signal diagnosis) ===//
// FIX/UPGRADE: RecordTradeStatistic() below tracks WHETHER a trade won or
// lost, but nothing tracked WHY - which specific signals (BOS, FVG, order
// block, MTF confluence, volatility expansion...) were actually present
// when that trade opened. Without that, there's no way to tell whether a
// losing streak means "the strategy doesn't work" or "one specific signal
// keeps producing bad entries while the others are fine." This captures a
// snapshot of every signal's state at the moment of entry, then on close
// reports it alongside the win/loss result and tallies each signal's own
// win rate over time - so it becomes possible to actually see which
// signals are earning their place in the score and which aren't.
//
// In-memory only (not persisted across restart) - this is a diagnostic
// aid, not something safety-critical like TP1 tracking, so losing the
// snapshot table on a restart is an acceptable tradeoff against not
// bloating the GlobalVariable store further.

// Declared here (rather than down in Part 15's Market Regime Detection
// section, where the related input/function live) because MQL5 needs a
// type fully declared before it's used as a struct field - SignalSnapshot
// below needs MarketRegime to already exist.
enum MarketRegime
{
   REGIME_TRENDING,
   REGIME_RANGING
};

// OK70: clean live-market snapshot used by diagnostics + wait reasons
struct LiveMarketAnalysis
{
   bool     valid;
   bool     bull;
   bool     bear;
   bool     trendStrong;
   MarketRegime regime;
   bool     bosBuy;
   bool     bosSell;
   bool     zoneBuy;
   bool     zoneSell;
   bool     nearBuy;
   bool     nearSell;
   bool     dispBuy;
   bool     dispSell;
   bool     contBuyOK;
   bool     contSellOK;
   string   contBuyDetail;
   string   contSellDetail;
   string   session;
   string   sessionName;   // LONDON / NEWYORK / LONDON+NY / ASIA / OFF
   bool     inLondon;
   bool     inNewYork;
   bool     inAsia;
   bool     inOverlap;
   int      sessionHour;
   string   news;
   string   apexBuy;
   string   apexSell;
   string   bias;
   string   summary;
   datetime barTime;
};
LiveMarketAnalysis g_LiveMkt;
ulong              g_LiveMktCycle = 0;
string             g_LastSessionNameLogged = "";

struct SignalSnapshot
{
   ulong  ticket;
   bool   isBuy;
   int    score;
   int    requiredScore;
   bool   trendOK;
   bool   htfOK;
   bool   confluenceOK;
   bool   mtfConfluenceOK;
   bool   bosPresent;
   bool   chochPresent;
   bool   sweepPresent;
   bool   fvgPresent;
   bool   obPresent;
   bool   volExpanding;
   MarketRegime regime;
};

SignalSnapshot SignalSnapshots[];

// PRISM structure snapshot — MUST be declared before CapturePendingSignalSnapshot().
struct PRISMStructureSnapshot
{
   int  rec;
   bool bos;
   bool choch;
   bool sweep;
   bool ob;
   bool fvg;
   bool trend;
   bool trendStrong;
   bool htfConfirms;
};

PRISMStructureSnapshot PRISM_GetStructureSnapshot(bool buy, int recency = -1);
string PRISMGetTradeGrade(bool buy, const string strategyTag);
int CalculatePRISMScore(bool buy);
int EffectiveMinimumMPIScore();
void MarkContFallbackFillIfNeeded(); // OK64 anti-scalp fill stamp (defined near ContFallback)
void UpdateNewsAwareness(); // OK65 news know/log (no block)
void AnalyzeLiveMarket(const bool force = false); // OK70 clean market read
string LiveMarketSummary();
void PrintLiveMarketAnalysis();
bool ContStruct_HasQualityBOS(const bool buy);
bool ContStruct_GetFreshZone(const bool buy, double &zTop, double &zBot, string &kind);
bool ContStruct_PriceNearZone(const bool buy, const double zTop, const double zBot);
bool ContStruct_HasDisplacement(const bool buy);
bool ContFallbackBestStructureOK(const bool buy, string &detail); // body later (helpers still call it)

int FindSignalSnapshot(ulong ticket)
{
   for(int i = 0; i < ArraySize(SignalSnapshots); i++)
      if(SignalSnapshots[i].ticket == ticket)
         return i;
   return -1;
}

void RemoveSignalSnapshot(int index)
{
   int last = ArraySize(SignalSnapshots) - 1;

   for(int j = index; j < last; j++)
      SignalSnapshots[j] = SignalSnapshots[j + 1];

   ArrayResize(SignalSnapshots, last);
}

// Per-signal win/loss tallies - persisted (same mechanism as the aggregate
// trade stats) so "which signals actually work" survives a restart too.
double SigStat_BOS_Win=0, SigStat_BOS_Loss=0;
double SigStat_CHoCH_Win=0, SigStat_CHoCH_Loss=0;
double SigStat_Sweep_Win=0, SigStat_Sweep_Loss=0;
double SigStat_FVG_Win=0, SigStat_FVG_Loss=0;
double SigStat_OB_Win=0, SigStat_OB_Loss=0;
double SigStat_MTF_Win=0, SigStat_MTF_Loss=0;
double SigStat_VolExp_Win=0, SigStat_VolExp_Loss=0;

string SigStatsGVPrefix()
{
   return "HitmanAI_" + IntegerToString(MagicNumber) + "_SigStats_";
}

void SaveSignalStatistics()
{
   string p = SigStatsGVPrefix();
   GlobalVariableSet(p+"bos_w", SigStat_BOS_Win);   GlobalVariableSet(p+"bos_l", SigStat_BOS_Loss);
   GlobalVariableSet(p+"choch_w", SigStat_CHoCH_Win); GlobalVariableSet(p+"choch_l", SigStat_CHoCH_Loss);
   GlobalVariableSet(p+"sweep_w", SigStat_Sweep_Win); GlobalVariableSet(p+"sweep_l", SigStat_Sweep_Loss);
   GlobalVariableSet(p+"fvg_w", SigStat_FVG_Win);   GlobalVariableSet(p+"fvg_l", SigStat_FVG_Loss);
   GlobalVariableSet(p+"ob_w", SigStat_OB_Win);     GlobalVariableSet(p+"ob_l", SigStat_OB_Loss);
   GlobalVariableSet(p+"mtf_w", SigStat_MTF_Win);   GlobalVariableSet(p+"mtf_l", SigStat_MTF_Loss);
   GlobalVariableSet(p+"vol_w", SigStat_VolExp_Win);GlobalVariableSet(p+"vol_l", SigStat_VolExp_Loss);
}

void RestoreSignalStatistics()
{
   string p = SigStatsGVPrefix();
   if(!GlobalVariableCheck(p+"bos_w")) return;

   SigStat_BOS_Win=GlobalVariableGet(p+"bos_w");     SigStat_BOS_Loss=GlobalVariableGet(p+"bos_l");
   SigStat_CHoCH_Win=GlobalVariableGet(p+"choch_w"); SigStat_CHoCH_Loss=GlobalVariableGet(p+"choch_l");
   SigStat_Sweep_Win=GlobalVariableGet(p+"sweep_w"); SigStat_Sweep_Loss=GlobalVariableGet(p+"sweep_l");
   SigStat_FVG_Win=GlobalVariableGet(p+"fvg_w");     SigStat_FVG_Loss=GlobalVariableGet(p+"fvg_l");
   SigStat_OB_Win=GlobalVariableGet(p+"ob_w");       SigStat_OB_Loss=GlobalVariableGet(p+"ob_l");
   SigStat_MTF_Win=GlobalVariableGet(p+"mtf_w");     SigStat_MTF_Loss=GlobalVariableGet(p+"mtf_l");
   SigStat_VolExp_Win=GlobalVariableGet(p+"vol_w");  SigStat_VolExp_Loss=GlobalVariableGet(p+"vol_l");
}

// FIX: a signal with 1 win and 0 losses used to report as a supposedly
// meaningful "100% win rate" - statistically worthless at that sample
// size but easy to over-trust reading it off the Journal. Returns -2
// (distinct from -1's "no data yet") once there IS data but not enough of
// it to mean anything; PrintSignalPerformanceReport() below reports that
// distinctly instead of stating a number.
input int MinSignalSampleSize = 20;

double SignalWinRate(double wins, double losses)
{
   double total = wins + losses;
   if(total <= 0) return -1; // no data yet
   if(total < MinSignalSampleSize) return -2; // some data, not enough to trust yet
   return (wins/total)*100.0;
}

string FormatSignalWinRate(double r, double wins, double losses)
{
   if(r == -1) return "no data";
   if(r == -2) return "insufficient sample (" + IntegerToString((int)(wins+losses)) + "/" + IntegerToString(MinSignalSampleSize) + " needed)";
   return DoubleToString(r,1) + "% win";
}

//================ ADAPTIVE AI WEIGHTING (NEW) =========================//
// FIX/UPGRADE: SigStat_BOS_Win/Loss, SigStat_CHoCH_Win/Loss, etc. (above)
// were being tracked and printed in the signal review report, but nothing
// ever fed that information BACK into CalculateTradeScore() - a
// confirmation type that has empirically been a coin flip (or worse) on
// this instrument scored exactly the same flat weight as one that's been
// reliably right. This closes that loop: once a signal type has a large
// enough sample (MinSignalSampleSize), its score contribution is scaled by
// a multiplier derived from its actual live win rate - better than 50%
// scores above face value (up to a capped bonus), worse than 50% scores
// below face value (down to a capped discount). Before the sample is large
// enough, the multiplier is a neutral 1.0 - no distortion from noise-level
// sample sizes. This is opt-outable; with it off, scoring behaves exactly
// as before (flat weights).

input group "ADAPTIVE AI WEIGHTING"

input bool   EnableAdaptiveWeighting     = true;
input double AdaptiveWeightMinMultiplier = 0.6; // floor - even a poorly-performing confirmation still contributes something, never zeroed out entirely
input double AdaptiveWeightMaxMultiplier = 1.4; // ceiling - caps how much a strong performer can be over-weighted, so one lucky streak can't dominate the score

double SignalWeightMultiplier(double wins, double losses)
{
   if(!EnableAdaptiveWeighting)
      return 1.0;

   double winRate = SignalWinRate(wins, losses); // -1 no data, -2 insufficient sample, else 0-100

   if(winRate < 0.0)
      return 1.0; // not enough data yet - stay neutral rather than guess

   // Map win rate linearly: 50% win rate -> 1.0x (neutral), scaling toward
   // the min/max multipliers as win rate moves toward 0% or 100%.
   double normalized = (winRate - 50.0) / 50.0; // -1.0 .. +1.0
   double multiplier;

   if(normalized >= 0.0)
      multiplier = 1.0 + normalized * (AdaptiveWeightMaxMultiplier - 1.0);
   else
      multiplier = 1.0 + normalized * (1.0 - AdaptiveWeightMinMultiplier);

   return MathMax(AdaptiveWeightMinMultiplier, MathMin(AdaptiveWeightMaxMultiplier, multiplier));
}

// Called from OnTradeTransaction when a position closes. Looks up the
// snapshot captured at entry, prints a full breakdown against the actual
// result, and tallies each present signal's win/loss count.
void ReportSignalOutcome(ulong ticket, bool wasWin, double profit)
{
   int idx = FindSignalSnapshot(ticket);

   if(idx < 0)
   {
      Print("No signal snapshot for closed ticket ", ticket, " (opened before this feature, or restart occurred).");
      return;
   }

   SignalSnapshot s = SignalSnapshots[idx];

   Print("=== SIGNAL REVIEW | ticket ", ticket, " | ", wasWin ? "WIN" : "LOSS",
         " (", DoubleToString(profit,2), ") ===");
   Print("Score: ", s.score, "/", s.requiredScore, " | Regime: ", EnumToString(s.regime));
   Print("Trend:", s.trendOK, " HTF:", s.htfOK, " Confluence:", s.confluenceOK, " MTF:", s.mtfConfluenceOK);
   Print("BOS:", s.bosPresent, " CHoCH:", s.chochPresent, " Sweep:", s.sweepPresent,
         " FVG:", s.fvgPresent, " OB:", s.obPresent, " VolExpansion:", s.volExpanding);

   if(s.bosPresent)      { if(wasWin) SigStat_BOS_Win++;   else SigStat_BOS_Loss++; }
   if(s.chochPresent)    { if(wasWin) SigStat_CHoCH_Win++; else SigStat_CHoCH_Loss++; }
   if(s.sweepPresent)    { if(wasWin) SigStat_Sweep_Win++; else SigStat_Sweep_Loss++; }
   if(s.fvgPresent)      { if(wasWin) SigStat_FVG_Win++;   else SigStat_FVG_Loss++; }
   if(s.obPresent)       { if(wasWin) SigStat_OB_Win++;    else SigStat_OB_Loss++; }
   if(s.mtfConfluenceOK) { if(wasWin) SigStat_MTF_Win++;   else SigStat_MTF_Loss++; }
   if(s.volExpanding)    { if(wasWin) SigStat_VolExp_Win++;else SigStat_VolExp_Loss++; }

   SaveSignalStatistics();

   RemoveSignalSnapshot(idx);
}

//+------------------------------------------------------------------+
//|      PART 15i - PER-STRATEGY PERFORMANCE TRACKING (NEW)          |
//+------------------------------------------------------------------+
// ADDED to directly answer "strategy vs validation": you now have nine
// selectable strategies and zero real trade history behind any of them.
// This is the missing measurement layer - every closed trade is
// attributed to the SPECIFIC strategy (tag) that produced it, tracked
// and persisted separately, with the same MinSignalSampleSize gating
// already used for the BOS/CHoCH/etc signal stats above (so a strategy
// with 2 trades reports "insufficient sample," not a fake 100%/0% rate).
// This is what actually lets you tell, once you have real volume, which
// of these nine is worth keeping - rather than adding more strategies
// being mistaken for adding more evidence.

#define STRATEGY_TAG_COUNT 15
string g_StrategyTagNames[STRATEGY_TAG_COUNT] = {
   "APEX", "ContFallback", "LCS",
   "SMC", "MeanReversion", "VolBreakout", "TrendFollow",
   "TrendPullback", "LiquiditySweep", "FVG+OB", "VolBreakout(Spec)", "SpecCompliant",
   "InstantTrend", "ContSniper", "RevSniper"
};
double g_StrategyTagWins[STRATEGY_TAG_COUNT];
double g_StrategyTagLosses[STRATEGY_TAG_COUNT];

int FindStrategyTagIndex(string tag)
{
   for(int i = 0; i < STRATEGY_TAG_COUNT; i++)
      if(g_StrategyTagNames[i] == tag)
         return i;

   return -1;
}

string StrategyStatsGVPrefix()
{
   return "SniperAI_" + IntegerToString(MagicNumber) + "_StratStats_";
}

void SaveStrategyPerformance()
{
   string p = StrategyStatsGVPrefix();

   for(int i = 0; i < STRATEGY_TAG_COUNT; i++)
   {
      GlobalVariableSet(p + g_StrategyTagNames[i] + "_w", g_StrategyTagWins[i]);
      GlobalVariableSet(p + g_StrategyTagNames[i] + "_l", g_StrategyTagLosses[i]);
   }
}

void RestoreStrategyPerformance()
{
   string p = StrategyStatsGVPrefix();

   for(int i = 0; i < STRATEGY_TAG_COUNT; i++)
   {
      g_StrategyTagWins[i]   = GlobalVariableCheck(p + g_StrategyTagNames[i] + "_w") ? GlobalVariableGet(p + g_StrategyTagNames[i] + "_w") : 0.0;
      g_StrategyTagLosses[i] = GlobalVariableCheck(p + g_StrategyTagNames[i] + "_l") ? GlobalVariableGet(p + g_StrategyTagNames[i] + "_l") : 0.0;
   }
}

// Called from OnTradeTransaction right after a position closes - looks up
// which strategy produced this specific ticket (via TradeStates[], Part 6)
// and tallies the result. If the ticket's TradeState was already pruned
// or never had a tag (e.g. a position opened before this feature, or one
// restored after a restart, since strategyTag isn't currently persisted
// to disk the way TP1/TP2 prices are), it's silently skipped - a known,
// documented gap rather than attributing a result to the wrong strategy.
void RecordStrategyPerformance(ulong positionTicket, bool wasWin)
{
   int stateIdx = FindTradeState(positionTicket);

   if(stateIdx < 0)
      return;

   string tag = TradeStates[stateIdx].strategyTag;

   if(tag == "")
      return;

   int tagIdx = FindStrategyTagIndex(tag);

   if(tagIdx < 0)
      return; // unrecognized tag - shouldn't happen unless g_StrategyTagNames is out of sync with strategyTag values used elsewhere

   if(wasWin)
      g_StrategyTagWins[tagIdx]++;
   else
      g_StrategyTagLosses[tagIdx]++;

   SaveStrategyPerformance();
}

void PrintStrategyPerformanceReport()
{
   Print("==== PER-STRATEGY PERFORMANCE (FULL UPGRADE) ====");

   // Focus on live PRISM tags first
   string liveTags[3] = {"APEX", "ContFallback", "LCS"};
   for(int t = 0; t < 3; t++)
   {
      int i = FindStrategyTagIndex(liveTags[t]);
      if(i < 0) continue;
      double r = SignalWinRate(g_StrategyTagWins[i], g_StrategyTagLosses[i]);
      Print(liveTags[t], ": ", FormatSignalWinRate(r, g_StrategyTagWins[i], g_StrategyTagLosses[i]),
            " (", (int)g_StrategyTagWins[i], "W/", (int)g_StrategyTagLosses[i], "L)",
            " rankBase=", PathBasePriority(liveTags[t]));
   }

   Print("=================================================");
}

// Prints a full per-signal win-rate breakdown on demand (e.g. call from
// DebugSignals(), or manually via script) so it's easy to see at a glance
// which signals are actually correlating with wins over time.
void PrintSignalPerformanceReport()
{
   Print("==== SIGNAL PERFORMANCE (all-time) ====");

   double r;

   r = SignalWinRate(SigStat_BOS_Win, SigStat_BOS_Loss);
   Print("BOS: ", FormatSignalWinRate(r, SigStat_BOS_Win, SigStat_BOS_Loss), " (", (int)SigStat_BOS_Win, "W/", (int)SigStat_BOS_Loss, "L)");

   r = SignalWinRate(SigStat_CHoCH_Win, SigStat_CHoCH_Loss);
   Print("CHoCH: ", FormatSignalWinRate(r, SigStat_CHoCH_Win, SigStat_CHoCH_Loss), " (", (int)SigStat_CHoCH_Win, "W/", (int)SigStat_CHoCH_Loss, "L)");

   r = SignalWinRate(SigStat_Sweep_Win, SigStat_Sweep_Loss);
   Print("Liquidity Sweep: ", FormatSignalWinRate(r, SigStat_Sweep_Win, SigStat_Sweep_Loss), " (", (int)SigStat_Sweep_Win, "W/", (int)SigStat_Sweep_Loss, "L)");

   r = SignalWinRate(SigStat_FVG_Win, SigStat_FVG_Loss);
   Print("FVG: ", FormatSignalWinRate(r, SigStat_FVG_Win, SigStat_FVG_Loss), " (", (int)SigStat_FVG_Win, "W/", (int)SigStat_FVG_Loss, "L)");

   r = SignalWinRate(SigStat_OB_Win, SigStat_OB_Loss);
   Print("Order Block: ", FormatSignalWinRate(r, SigStat_OB_Win, SigStat_OB_Loss), " (", (int)SigStat_OB_Win, "W/", (int)SigStat_OB_Loss, "L)");

   r = SignalWinRate(SigStat_MTF_Win, SigStat_MTF_Loss);
   Print("MTF Confluence: ", FormatSignalWinRate(r, SigStat_MTF_Win, SigStat_MTF_Loss), " (", (int)SigStat_MTF_Win, "W/", (int)SigStat_MTF_Loss, "L)");

   r = SignalWinRate(SigStat_VolExp_Win, SigStat_VolExp_Loss);
   Print("Vol Expansion: ", FormatSignalWinRate(r, SigStat_VolExp_Win, SigStat_VolExp_Loss), " (", (int)SigStat_VolExp_Win, "W/", (int)SigStat_VolExp_Loss, "L)");

   Print("========================================");

   PrintStrategyPerformanceReport();
}

void OnTradeTransaction(const MqlTradeTransaction &trans,
                         const MqlTradeRequest &request,
                         const MqlTradeResult &result)
{
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD)
      return;

   if(!HistoryDealSelect(trans.deal))
      return;

   long dealMagic  = HistoryDealGetInteger(trans.deal, DEAL_MAGIC);
   string dealSym  = HistoryDealGetString(trans.deal, DEAL_SYMBOL);
   long dealEntry  = HistoryDealGetInteger(trans.deal, DEAL_ENTRY);

   if(dealMagic != MagicNumber)
      return;

   // FIX: this used to compare dealSym against the global BrokerSymbol -
   // which in multi-symbol mode is whatever symbol the last trading-cycle
   // iteration happened to leave it as, not necessarily the symbol this
   // deal actually belongs to. Look up the deal's own symbol directly
   // instead, so loss tracking updates the correct symbol's slot
   // regardless of what BrokerSymbol currently points to.
   int dealSymIdx = GetSymbolIndex(dealSym);

   if(dealSymIdx < 0)
      return; // deal belongs to a symbol this EA instance isn't tracking

   // DEAL_ENTRY_OUT (or OUT_BY) means this deal closed some or all of a
   // position - that's the only case relevant to win/loss tracking. Entry
   // deals (DEAL_ENTRY_IN) are trade opens, not closes.
   if(dealEntry != DEAL_ENTRY_OUT && dealEntry != DEAL_ENTRY_OUT_BY)
      return;

   double profit = HistoryDealGetDouble(trans.deal, DEAL_PROFIT)
                  + HistoryDealGetDouble(trans.deal, DEAL_SWAP)
                  + HistoryDealGetDouble(trans.deal, DEAL_COMMISSION);

   if(profit < 0)
   {
      LastTradeWasLossArr[dealSymIdx]  = true;
      LastLossCloseTimeArr[dealSymIdx] = TimeCurrent();
      Print("Trade closed at a loss on ", dealSym, " (", DoubleToString(profit,2), ") - post-loss cooldown engaged.");
   }
   else
   {
      LastTradeWasLossArr[dealSymIdx] = false;
   }

   // FIX: GetEffectiveMinimumScore() (Part 15) used to read the single
   // GLOBAL Stat_ConsecutiveLosses counter - meaning a losing streak on
   // BTCUSD raised the score bar for EURUSD signals too, and vice versa,
   // even though the two have nothing to do with each other. Tracked
   // per-symbol here (index-matched to MultiSymbolList like everything
   // else per-symbol in this file) so each symbol's adaptive scoring
   // penalty only reacts to that symbol's own recent results.
   if(dealSymIdx < ArraySize(ConsecutiveLossesPerSymbolArr))
   {
      if(profit < 0)
      {
         ConsecutiveLossesPerSymbolArr[dealSymIdx]++;
         ConsecutiveWinsPerSymbolArr[dealSymIdx] = 0;
      }
      else
      {
         ConsecutiveWinsPerSymbolArr[dealSymIdx]++;
         ConsecutiveLossesPerSymbolArr[dealSymIdx] = 0;
      }
   }

   RecordTradeStatistic(profit);
   ReportSignalOutcome(trans.position, profit >= 0, profit);
   RecordStrategyPerformance(trans.position, profit >= 0);
}

// FIX: EventSetTimer() was being called in OnInit whenever
// EnableMultiSymbolTrading was on, but no OnTimer() existed anywhere to
// catch those events - and OnTick() never looped over MultiSymbolList
// either. The result: turning on multi-symbol trading built all the
// per-symbol indicator handles and tracking arrays, but never actually
// evaluated or traded any symbol beyond the chart's own. This is what
// actually makes it work: RunTradingCycle() runs the full
// manage-then-evaluate sequence for one symbol; OnTick() drives the
// primary/chart symbol in real time (as it always did); OnTimer() drives
// every OTHER symbol in MultiSymbolList on a schedule, since MT5 only
// delivers OnTick() for the symbol the chart is actually showing - there's
// no way to get real-time ticks for a symbol nothing is charting.

void RunTradingCycle(string symbol)
{
   // HARDEN: never manage/execute on an empty symbol handle
   if(symbol == NULL || StringLen(symbol) == 0)
      return;

   BrokerSymbol = symbol;

   // DEFENSE LINE 9 — EMERGENCY (connection / data / symbol recover)
   UltraDefense_Line9_Emergency(symbol);

   // ULTRA UPGRADE — System Health (L15-17); RED blocks entry path only
   if(UltraUpgradeEnabled && UltraSystemHealthEnabled)
   {
      if(!UltraSystemHealth_Update(symbol))
      {
         ManageOpenTrades(); // still protect open positions
         return;
      }
   }

   ManageOpenTrades();

   if(TradingAllowed)
      InstantExecution();
}

void OnTimer()
{
   if(!EnableMultiSymbolTrading)
      return;

   for(int i = 0; i < ArraySize(MultiSymbolList); i++)
   {
      if(MultiSymbolList[i] == PrimarySymbol)
         continue; // already handled every tick by OnTick() below

      RunTradingCycle(MultiSymbolList[i]);
   }

   BrokerSymbol = PrimarySymbol; // restore before the dashboard next reads it
}

void OnTick()
{
   RunTradingCycle(PrimarySymbol);

   UpdateDashboard();
}
//+------------------------------------------------------------------+
//|                 Sniper AI - Part 2                       |
//|                    Indicator Engine                              |
//+------------------------------------------------------------------+

//======================== INDICATOR INPUTS =========================//

input group "INDICATORS"

input int EMA_Period = 200;
input int ADX_Period = 14;
input int ATR_Period = 14;

input double ADX_Minimum = 18.0; // aggressive sniper: strong enough trend, not ultra-strict 25

input group "SIGNAL STABILITY"

// FIX: GetEMA()/GetADX()/GetATR() used to read buffer index 0, which is
// the CURRENTLY FORMING bar - its EMA/ADX value keeps changing tick to
// tick until that bar actually closes. That meant TrendBullish/Bearish
// (and everything built on top of them: StrongBuySetup, StrongSellSetup,
// the dashboard, trend-exit) could flip its answer mid-bar and "repaint" -
// the same live signal could read differently a few seconds apart with no
// new closed data, purely because the forming candle moved. With this on,
// every trend/strength read used for decisions comes from the last fully
// CLOSED bar (index 1) instead - the same principle already applied to
// GetRecentHigh()/GetRecentLow()'s confirmed-swing logic. Off reverts to
// the original (faster-reacting but repaint-prone) behavior.
input bool UseClosedBarConfirmation = false; // CHANGED per request for instant execution: false = evaluate off the live/forming bar (index 0) instead of waiting for it to close (index 1), combined with EnableTickLevelSignalDetection (already on by default) so every tick gets a fresh read. Tradeoff: a signal can appear and then disappear again before that bar actually closes, since it's reading unfinished price action - this is normal for "instant" reaction, not a bug.

int SignalBarIndex()
{
   return UseClosedBarConfirmation ? 1 : 0;
}

//======================== INDICATOR CACHE (perf) ====================//
// FIX: GetEMA(), GetADX(), and GetATR() each independently called
// UpdateIndicators(), which does 3 CopyBuffer() calls - so a single
// decision path (e.g. TrendBullish() -> GetEMA() -> GetEMASlope() ->
// TrendStrong() -> GetADX()) could trigger the same CopyBuffer() work
// several times over for the same symbol on the same tick. This caches
// the result per (symbol, trading cycle) - g_CycleCounter increments once
// per RunTradingCycle() call (Part 1), so every read within that same
// cycle for that symbol reuses the already-copied buffers instead of
// re-fetching identical data from the terminal.
ulong g_CycleCounter = 0;
long  IndicatorCacheCycleArr[];

//======================== INITIALIZE ===============================//

bool InitializeIndicators()
{
   // UPGRADE: creates one full set of indicator handles PER SYMBOL in
   // MultiSymbolList, not just for BrokerSymbol. In single-symbol mode
   // (EnableMultiSymbolTrading = false) MultiSymbolList only contains the
   // chart's own symbol, so this loop runs once and behaves exactly like
   // the original single-handle version did.

   ArrayResize(IndicatorCacheCycleArr, ArraySize(MultiSymbolList));

   for(int i = 0; i < ArraySize(MultiSymbolList); i++)
   {
      IndicatorCacheCycleArr[i] = -1;

      string sym = MultiSymbolList[i];

      EMAHandles[i] = iMA(sym, TrendTF, EMA_Period, 0, MODE_EMA, PRICE_CLOSE);

      if(EMAHandles[i] == INVALID_HANDLE)
      {
         Print("Failed to create EMA Handle for ", sym);
         return false;
      }

      ADXHandles[i] = iADX(sym, TrendTF, ADX_Period);

      if(ADXHandles[i] == INVALID_HANDLE)
      {
         Print("Failed to create ADX Handle for ", sym);
         return false;
      }

      ATRHandlesArr[i] = iATR(sym, EntryTF, ATR_Period);

      if(ATRHandlesArr[i] == INVALID_HANDLE)
      {
         Print("Failed to create ATR Handle for ", sym);
         return false;
      }

      HTFEMAHandlesArr[i] = iMA(sym, HigherTimeframe, EMA_Period, 0, MODE_EMA, PRICE_CLOSE);

      if(HTFEMAHandlesArr[i] == INVALID_HANDLE)
      {
         Print("Failed to create HTF EMA Handle for ", sym);
         return false;
      }

      // RSI removed from PRISM stack (user request) — no iRSI handle.
      // Dead mean-reversion helpers can still read BB; GetRSI() returns empty.
      RSIHandlesArr[i] = INVALID_HANDLE;
      // OK91: DELETED old indicators — BB / FastEMA / SlowEMA no longer created.
      // Signal path uses PRIME price-action engines (structure/liq/ICT/Fib/vol).
      BBHandlesArr[i] = INVALID_HANDLE;
      FastEMAHandlesArr[i] = INVALID_HANDLE;
      SlowEMAHandlesArr[i] = INVALID_HANDLE;
   }

   ArraySetAsSeries(EMABuffer, true);
   ArraySetAsSeries(ADXBuffer, true);
   ArraySetAsSeries(ATRBuffer, true);
   ArraySetAsSeries(HTF_EMABuffer, true);

   Print("Indicators initialized successfully for ", ArraySize(MultiSymbolList), " symbol(s).");

   return true;
}

//======================== UPDATE ==================================//

bool UpdateIndicators()
{
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0)
   {
      Print("Indicator lookup failed - symbol not in MultiSymbolList: ", BrokerSymbol);
      return false;
   }

   // Cache hit - already refreshed this trading cycle for this symbol.
   if(idx < ArraySize(IndicatorCacheCycleArr) && IndicatorCacheCycleArr[idx] == (long)g_CycleCounter)
      return true;

   // FIX: previously a handle going INVALID_HANDLE at runtime (e.g. a
   // symbol briefly dropped and re-added, or a terminal hiccup) meant this
   // symbol was silently dead until the EA was manually removed and
   // re-attached - Print() and return false, forever. This attempts a
   // one-time recreation of any invalid handle for this symbol before
   // giving up, so a transient handle loss can self-heal instead of
   // requiring manual intervention.
   if(EMAHandles[idx] == INVALID_HANDLE)
      EMAHandles[idx] = iMA(BrokerSymbol, TrendTF, EMA_Period, 0, MODE_EMA, PRICE_CLOSE);

   if(ADXHandles[idx] == INVALID_HANDLE)
      ADXHandles[idx] = iADX(BrokerSymbol, TrendTF, ADX_Period);

   if(ATRHandlesArr[idx] == INVALID_HANDLE)
      ATRHandlesArr[idx] = iATR(BrokerSymbol, EntryTF, ATR_Period);

   if(EMAHandles[idx] == INVALID_HANDLE ||
      ADXHandles[idx] == INVALID_HANDLE ||
      ATRHandlesArr[idx] == INVALID_HANDLE)
   {
      Print("Indicator handle invalid for ", BrokerSymbol, " and could not be recreated.");
      return false;
   }

   // Wait until enough bars are loaded
   if(Bars(BrokerSymbol, TrendTF) < EMA_Period + 10)
      return false;

   if(Bars(BrokerSymbol, EntryTF) < ATR_Period + 10)
      return false;

   // FIX: Bars() only reports how many candles exist in the terminal's
   // history for that timeframe - it says nothing about whether the
   // indicator itself has actually finished calculating over them yet
   // (e.g. right after a handle is (re)created, or during a fast history
   // backfill). BarsCalculated() is the real readiness signal; without
   // this, CopyBuffer() succeeding could still be reading from an
   // indicator that hasn't caught up to all the requested bars.
   if(BarsCalculated(EMAHandles[idx]) < 4 || BarsCalculated(ADXHandles[idx]) < 4 ||
      BarsCalculated(ATRHandlesArr[idx]) < 4)
      return false;

   ResetLastError();

   // 4 bars fetched (not 3): index 0 = forming bar, index 1 = last closed
   // bar (what SignalBarIndex() points decisions at by default), index 3
   // used by the slope calc below as "2 closed bars back" from index 1.
   if(CopyBuffer(EMAHandles[idx],0,0,4,EMABuffer) < 4)
   {
      Print("EMA CopyBuffer Error: ",GetLastError());
      return false;
   }

   if(CopyBuffer(ADXHandles[idx],0,0,4,ADXBuffer) < 4)
   {
      Print("ADX CopyBuffer Error: ",GetLastError());
      return false;
   }

   if(CopyBuffer(ATRHandlesArr[idx],0,0,4,ATRBuffer) < 4)
   {
      Print("ATR CopyBuffer Error: ",GetLastError());
      return false;
   }

   IndicatorCacheCycleArr[idx] = (long)g_CycleCounter;

   return true;
}

//======================== HELPERS =================================//

double GetEMA()
{
   if(!UpdateIndicators())
      return EMPTY_VALUE;

   return EMABuffer[SignalBarIndex()];
}


double GetADX()
{
   if(!UpdateIndicators())
      return EMPTY_VALUE;

   return ADXBuffer[SignalBarIndex()];
}


double GetATR()
{
   if(!UpdateIndicators())
      return 0.0;

   double v = ATRBuffer[SignalBarIndex()];
   // HARDEN: EMPTY_VALUE is >0 and would inflate stops/trails — treat as unavailable
   if(!MathIsValidNumber(v) || v == EMPTY_VALUE || v <= 0.0)
      return 0.0;
   return v;
}


// FIX/UPGRADE - SMARTER TREND DETECTION: price above the EMA doesn't
// necessarily mean an uptrend - price can sit above a flat or even
// slightly declining EMA during chop, which used to count as "bullish"
// just as confidently as a genuine trending move. This adds a slope
// check: the EMA itself has to actually be rising (comparing its current
// value against a few bars back, reusing the buffer already copied by
// UpdateIndicators) for the trend to count as bullish, and falling for
// bearish. Off by default is not an option here since it's a correctness
// improvement, but it's still togglable in case the extra requirement
// ever needs to be disabled for testing.

input bool EnableSmarterTrendDetection = false; // CHANGED per request: this added a second, stricter AND-condition on top of price-vs-EMA (EMA slope also had to agree), which was quietly stacking with the score/confluence gates below to block valid setups. false = trend is just price vs EMA again.

double GetEMASlope()
{
   if(!UpdateIndicators())
      return 0.0;

   // Compares SignalBarIndex() (last closed bar by default) against 2
   // bars further back - a short, responsive, non-repainting slope
   // reading without needing a separate indicator or buffer.
   int b = SignalBarIndex();
   return EMABuffer[b] - EMABuffer[b + 2];
}

bool TrendBullish()
{
   double ema = GetEMA();

   if(ema == EMPTY_VALUE)
      return false;

   bool priceAboveEMA = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID) > ema;

   if(!EnableSmarterTrendDetection)
      return priceAboveEMA;

   return priceAboveEMA && (GetEMASlope() > 0.0);
}


bool TrendBearish()
{
   double ema = GetEMA();

   if(ema == EMPTY_VALUE)
      return false;

   bool priceBelowEMA = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID) < ema;

   if(!EnableSmarterTrendDetection)
      return priceBelowEMA;

   return priceBelowEMA && (GetEMASlope() < 0.0);
}


bool TrendStrong()
{
   if(!UseADX)
      return true;

   return GetADX() >= ADX_Minimum;
}


//======================== HTF TREND ================================//

double GetHTF_EMA()
{
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0 || HTFEMAHandlesArr[idx] == INVALID_HANDLE)
      return EMPTY_VALUE;

   // FIX: was CopyBuffer(...,0,1,HTF_EMABuffer) reading only index 0 - the
   // currently forming HIGHER TIMEFRAME bar. On, say, H4 confirmation for
   // an M15 entry timeframe, that forming H4 bar's EMA can still be
   // changing for hours, so HTF confirmation could silently flip well
   // after a trade was already opened based on it. Now fetches 2 bars and
   // uses SignalBarIndex() the same way GetEMA() does, so HTF confirmation
   // is anchored to the last CLOSED H4 bar by default.
   int need = SignalBarIndex() + 1;

   if(CopyBuffer(HTFEMAHandlesArr[idx], 0, 0, need, HTF_EMABuffer) < need)
      return EMPTY_VALUE;

   return HTF_EMABuffer[SignalBarIndex()];
}

// FIX: HTFTrendBullish()/HTFTrendBearish() used to both return TRUE when
// HTF data wasn't ready - meaning a missing/not-yet-loaded HTF read could
// approve EITHER direction with no real confirmation behind it at all
// (the opposite of what "confirmation" is supposed to guarantee). Default
// behavior now fails CLOSED (blocks the trade) when HTF data isn't ready;
// HTFFailSafeAllowsTrade lets you restore the old fail-open behavior if
// you'd rather not wait on HTF data during startup/history loading.
input bool HTFFailSafeAllowsTrade = false;

bool HTFTrendBullish()
{
   double htfEma = GetHTF_EMA();

   if(htfEma == EMPTY_VALUE)
      return HTFFailSafeAllowsTrade;

   return SymbolInfoDouble(BrokerSymbol, SYMBOL_BID) > htfEma;
}

bool HTFTrendBearish()
{
   double htfEma = GetHTF_EMA();

   if(htfEma == EMPTY_VALUE)
      return HTFFailSafeAllowsTrade;

   return SymbolInfoDouble(BrokerSymbol, SYMBOL_BID) < htfEma;
}

bool HTFConfirms(bool buy)
{
   if(!EnableHTFConfirmation)
      return true;

   return buy ? HTFTrendBullish() : HTFTrendBearish();
}
//+------------------------------------------------------------------+
//|                 Sniper AI - Part 3                       |
//|                     Market Scanner                               |
//+------------------------------------------------------------------+

//====================== BROKER SYMBOL ==============================//

string DetectBrokerSymbol(string symbol)
{
   if(SymbolSelect(symbol,true))
      return(symbol);

   return(_Symbol);
}

//====================== TREND =====================================//

bool IsBullTrend()
{
   if(!UseEMA)
      return(true);

   return(TrendBullish());
}

bool IsBearTrend()
{
   if(!UseEMA)
      return(true);

   return(TrendBearish());
}

//+------------------------------------------------------------------+
//|                 Sniper AI - Part 4                       |
//|              Decision Tree & Score Engine                        |
//+------------------------------------------------------------------+

// NOTE: An earlier, simpler scoring system (ScoreTrend/ScoreADX/ScoreATR/
// ScoreSpread/ScoreMarket -> CalculateScore -> BuySignal/SellSignal) used
// to live here. It was never called by anything in the execution path -
// StrongBuySetup()/StrongSellSetup() (Part 15) is the scoring system that
// actually gates trades - so the dead duplicate has been removed.
//+------------------------------------------------------------------+
//|                 Sniper AI - Part 5                       |
//|                     Professional Risk Engine                     |
//+------------------------------------------------------------------+

input group "RISK ENGINE"

// ALLTRADE56: period-loss shields OFF by default (same philosophy as drawdown OFF).
// Turn any Enable* back on if you want hard stops after a bad day/week/month.
input bool   EnableDailyLossProtection = false; // OFF: was hard-blocking all symbols after 5% day
input double MaxDailyLossPercent = 5.0;
input double MaxDrawdownPercent  = 20.0;

//=============================================================//
// Peak-Equity Drawdown (FIX - real high-water-mark tracking)
//=============================================================//
// FIX: the old GetCurrentDrawdown() compared current BALANCE against
// current EQUITY - that's a snapshot of open floating P/L, not drawdown.
// A profitable account can absolutely have a genuine 15% peak-to-trough
// drawdown along the way while this old calculation reads 0%, because
// balance itself only moves when a trade closes - it was structurally
// incapable of seeing the thing "max drawdown protection" is supposed to
// protect against. This tracks the account's actual highest-ever equity
// (persisted via GlobalVariable so a restart doesn't forget it and quietly
// re-arm protection at whatever the current balance happens to be) and
// measures drawdown from THAT peak, which is what "max drawdown" means
// everywhere outside this file too.

string PeakEquityGVName()
{
   return "HitmanAI_" + IntegerToString(MagicNumber) + "_PeakEquity";
}

double GetPeakEquity()
{
   string key = PeakEquityGVName();
   double currentEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(!MathIsValidNumber(currentEquity) || currentEquity <= 0.0)
      return 0.0;

   if(!GlobalVariableCheck(key))
   {
      GlobalVariableSet(key, currentEquity);
      return currentEquity;
   }

   double peak = GlobalVariableGet(key);
   if(!MathIsValidNumber(peak) || peak <= 0.0)
   {
      peak = currentEquity;
      GlobalVariableSet(key, peak);
      return peak;
   }

   if(currentEquity > peak)
   {
      peak = currentEquity;
      GlobalVariableSet(key, peak);
   }

   return peak;
}

double GetCurrentDrawdown()
{
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double peak   = GetPeakEquity();

   if(peak <= 0.0)
      return 0.0;

   double dd = ((peak - equity) / peak) * 100.0;

   return (dd > 0.0) ? dd : 0.0;
}

//=============================================================//
// Drawdown Protection
//=============================================================//

// TRADEUNBLOCK (OK53): drawdown protection is OFF by default.
// Live Journals showed PeakEquity GV stuck (~50%+ DD vs MaxDrawdownPercent=20)
// which hard-blocked ALL new entries via RiskManagementOK → DrawdownProtection.
// With shield off, this EA will not halt new entries or emergency-flat on peak DD.
// MaxDailyLossPercent / weekly / monthly (separate inputs) still apply unless disabled.
// Set EnableDrawdownProtection=true if you want the peak-equity safety net again.
// ResetPeakEquityOnInit=true clears the stuck GV on attach so re-enabling starts clean.

input bool EnableDrawdownProtection = false;  // OFF: was blocking all entries when PeakEquity stuck

input bool EnableEmergencyCloseOnDrawdown = true;

// Clear HitmanAI_<Magic>_PeakEquity on every OnInit and seed from current equity.
// Needed when shield is re-enabled after a deep drawdown so trading is not permanently dead.
input bool ResetPeakEquityOnInit = true;  // TRADEUNBLOCK: wipe stuck peak equity GV on attach

bool DrawdownEmergencyCloseTriggered = false;

// After emergency close, no new trade for MaxDrawdownCooldownMinutes
// regardless of how quickly equity recovers. Position management unaffected.
// (Only relevant if EnableDrawdownProtection is turned back on.)
input int MaxDrawdownCooldownMinutes = 5;

datetime DrawdownEmergencyCloseTime = 0;
datetime g_LastDrawdownBlockPrint = 0;

void ResetPeakEquityToCurrent()
{
   string key = PeakEquityGVName();
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(!MathIsValidNumber(equity) || equity <= 0.0)
      return;

   double oldPeak = 0.0;
   if(GlobalVariableCheck(key))
      oldPeak = GlobalVariableGet(key);

   GlobalVariableSet(key, equity);
   Print("TRADEUNBLOCK: PeakEquity reset ", DoubleToString(oldPeak, 2),
         " → ", DoubleToString(equity, 2), " (GV ", key, ")");
}

bool DrawdownProtection()
{
   if(!EnableDrawdownProtection)
      return true;

   double dd = GetCurrentDrawdown();

   if(dd >= MaxDrawdownPercent)
   {
      // Rate-limit: one print per 60s (was flooding Experts every FinalTradeCheck)
      if(TimeCurrent() - g_LastDrawdownBlockPrint >= 60)
      {
         g_LastDrawdownBlockPrint = TimeCurrent();
         Print("Trading blocked: Max drawdown from peak equity reached (", DoubleToString(dd,2),
               "%). Fix: Inputs → EnableDrawdownProtection=false OR ResetPeakEquityOnInit=true + re-attach.");
      }

      if(EnableEmergencyCloseOnDrawdown && !DrawdownEmergencyCloseTriggered)
      {
         Print("Max drawdown breached for the first time - closing all open positions for this EA.");
         CloseAllEAPositions();
         DrawdownEmergencyCloseTriggered = true;
         DrawdownEmergencyCloseTime = TimeCurrent();
      }

      return false;
   }

   // Mandatory cooldown after the emergency close, independent of how
   // quickly equity recovers above the re-arm threshold below.
   if(DrawdownEmergencyCloseTriggered && DrawdownEmergencyCloseTime > 0)
   {
      if(TimeCurrent() - DrawdownEmergencyCloseTime < MaxDrawdownCooldownMinutes * 60)
      {
         if(EnableVerboseLogging)
            Print("Trading blocked: post-drawdown cooldown active (", MaxDrawdownCooldownMinutes, " min).");
         return false;
      }
   }

   // Re-arm once drawdown has recovered comfortably below the limit AND
   // the mandatory cooldown above has elapsed, so a later, genuinely new
   // breach can trigger the emergency close again instead of it being a
   // one-time-ever event for the life of the chart.
   if(DrawdownEmergencyCloseTriggered && dd < MaxDrawdownPercent * 0.5)
      DrawdownEmergencyCloseTriggered = false;

   return true;
}

//=============================================================//
// Daily Loss Protection (real - tracks the day's opening balance)
//=============================================================//

void UpdateDailyReferenceBalance()
{
   MqlDateTime now;
   TimeToStruct(TimeCurrent(), now);

   now.hour = 0;
   now.min  = 0;
   now.sec  = 0;

   datetime today = StructToTime(now);

   if(today != DailyTrackedDay)
   {
      DailyTrackedDay   = today;
      DailyStartBalance = AccountInfoDouble(ACCOUNT_BALANCE);
      DailyLossCloseTriggered = false; // new day - re-arm the emergency close for the new session
   }
}

// FIX - THIS IS THE ACTUAL PROBLEM BEHIND THE 18%+ DAILY LOSS SEEN IN
// TESTING: DailyLossProtection() below only ever blocked NEW trades once
// the limit was hit. It never touched positions that were ALREADY open -
// so once the 5% threshold was crossed, new entries stopped, but existing
// open positions kept losing on their own with nothing stopping them,
// dragging the account down to 18%+ before those positions individually
// hit their own stops. A "daily loss limit" that only stops new trades
// isn't actually a loss limit - it's just a new-trade filter. This adds a
// real emergency close: the first time the limit is breached each day,
// every open position belonging to this EA gets closed immediately.

input bool EnableEmergencyCloseOnDailyLoss = true;

bool DailyLossCloseTriggered = false;

void CloseAllEAPositions()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);

      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;

      if(UltraMission_ClosePosition(ticket, "EMERGENCY CloseAllEAPositions", true))
         Print("Emergency close: closed ticket ", ticket);
      else
         Print("Emergency close FAILED/held on ticket ", ticket);
   }
}

bool DailyLossProtection()
{
   if(!EnableDailyLossProtection || MaxDailyLossPercent <= 0.0)
      return true;

   UpdateDailyReferenceBalance();

   if(DailyStartBalance <= 0.0)
      return true;

   double equity = AccountInfoDouble(ACCOUNT_EQUITY);

   double dailyLossPercent = ((DailyStartBalance - equity) / DailyStartBalance) * 100.0;

   if(dailyLossPercent >= MaxDailyLossPercent)
   {
      Print("Trading blocked: Daily loss limit reached (", DoubleToString(dailyLossPercent,2), "%)");

      if(EnableEmergencyCloseOnDailyLoss && !DailyLossCloseTriggered)
      {
         Print("Daily loss limit breached for the first time today - closing all open positions for this EA.");
         CloseAllEAPositions();
         DailyLossCloseTriggered = true;
      }

      return false;
   }

   return true;
}

//=============================================================//
// Weekly / Monthly Loss Protection
// (same pattern as Daily Loss Protection above - reference balance
// stamped at the start of the period, emergency close via the shared
// CloseAllEAPositions() the first time the limit is breached each
// period, re-armed automatically when a new period starts. No separate
// engine - this reuses the exact same mechanism as the daily check.)
//=============================================================//

input bool   EnableWeeklyLossProtection        = false; // ALLTRADE56: OFF
input double MaxWeeklyLossPercent              = 10.0;
input bool   EnableEmergencyCloseOnWeeklyLoss  = true;

input bool   EnableMonthlyLossProtection       = false; // ALLTRADE56: OFF
input double MaxMonthlyLossPercent             = 15.0;
input bool   EnableEmergencyCloseOnMonthlyLoss = true;

bool WeeklyLossCloseTriggered  = false;
bool MonthlyLossCloseTriggered = false;

// Monday 00:00 (broker time) of the current week.
void UpdateWeeklyReferenceBalance()
{
   MqlDateTime now;
   TimeToStruct(TimeCurrent(), now);

   now.hour = 0;
   now.min  = 0;
   now.sec  = 0;

   datetime today = StructToTime(now);

   // day_of_week: 0=Sunday...6=Saturday. Treat Monday as the start of the
   // week regardless of which day the EA happens to (re)start on.
   int daysSinceMonday = (now.day_of_week == 0) ? 6 : (now.day_of_week - 1);

   datetime weekStart = today - (datetime)(daysSinceMonday * 86400);

   if(weekStart != WeeklyTrackedWeekStart)
   {
      WeeklyTrackedWeekStart  = weekStart;
      WeeklyStartBalance      = AccountInfoDouble(ACCOUNT_BALANCE);
      WeeklyLossCloseTriggered = false; // new week - re-arm
   }
}

void UpdateMonthlyReferenceBalance()
{
   MqlDateTime now;
   TimeToStruct(TimeCurrent(), now);

   now.day  = 1;
   now.hour = 0;
   now.min  = 0;
   now.sec  = 0;

   datetime monthStart = StructToTime(now);

   if(monthStart != MonthlyTrackedMonthStart)
   {
      MonthlyTrackedMonthStart  = monthStart;
      MonthlyStartBalance       = AccountInfoDouble(ACCOUNT_BALANCE);
      MonthlyLossCloseTriggered = false; // new month - re-arm
   }
}

bool WeeklyLossProtection()
{
   if(!EnableWeeklyLossProtection || MaxWeeklyLossPercent <= 0.0)
      return true;

   UpdateWeeklyReferenceBalance();

   if(WeeklyStartBalance <= 0.0)
      return true;

   double equity = AccountInfoDouble(ACCOUNT_EQUITY);

   double weeklyLossPercent = ((WeeklyStartBalance - equity) / WeeklyStartBalance) * 100.0;

   if(weeklyLossPercent >= MaxWeeklyLossPercent)
   {
      Print("Trading blocked: Weekly loss limit reached (", DoubleToString(weeklyLossPercent,2), "%)");

      if(EnableEmergencyCloseOnWeeklyLoss && !WeeklyLossCloseTriggered)
      {
         Print("Weekly loss limit breached for the first time this week - closing all open positions for this EA.");
         CloseAllEAPositions();
         WeeklyLossCloseTriggered = true;
      }

      return false;
   }

   return true;
}

bool MonthlyLossProtection()
{
   if(!EnableMonthlyLossProtection || MaxMonthlyLossPercent <= 0.0)
      return true;

   UpdateMonthlyReferenceBalance();

   if(MonthlyStartBalance <= 0.0)
      return true;

   double equity = AccountInfoDouble(ACCOUNT_EQUITY);

   double monthlyLossPercent = ((MonthlyStartBalance - equity) / MonthlyStartBalance) * 100.0;

   if(monthlyLossPercent >= MaxMonthlyLossPercent)
   {
      Print("Trading blocked: Monthly loss limit reached (", DoubleToString(monthlyLossPercent,2), "%)");

      if(EnableEmergencyCloseOnMonthlyLoss && !MonthlyLossCloseTriggered)
      {
         Print("Monthly loss limit breached for the first time this month - closing all open positions for this EA.");
         CloseAllEAPositions();
         MonthlyLossCloseTriggered = true;
      }

      return false;
   }

   return true;
}

//=============================================================//
// Maximum Trades
// (uses CountOpenTrades() from Part 9 - one counting function,
//  not two slightly-different duplicates)
//=============================================================//

bool MaxTradesProtection()
{
   // OPENCAPS47: adjustable — EnforceOpenTradeCaps=false or MaxOpenTrades=0 → unlimited
   if(!EnforceOpenTradeCaps || MaxOpenTrades <= 0)
      return true;

   int openNow = CountOpenTrades();
   if(openNow >= MaxOpenTrades)
   {
      if(EnableVerboseLogging)
         Print("Trading blocked: per-symbol open cap (", openNow, "/", MaxOpenTrades,
               ") on ", BrokerSymbol);
      return false;
   }
   return true;
}

//=============================================================//
// Portfolio-wide exposure caps (NEW)
//=============================================================//
// FIX: MaxOpenTrades only ever capped trades on the CURRENT symbol - in
// multi-symbol mode, that means 3 trades on EURUSD, 3 on GBPUSD, 3 on
// XAUUSD, etc. simultaneously, with no account-wide ceiling at all, and no
// awareness that EURUSD+GBPUSD+USDJPY all carry correlated USD exposure.
// This adds two portfolio-level checks on top of (not instead of) the
// existing per-symbol cap: a hard cap on total EA positions across every
// symbol, and a cap on how many open positions can share the same
// currency (either side of the pair) - catching the "three different
// pairs, one hidden USD bet" case that a pure trade-count limit misses.

// PORTFOLIO RISK helpers — caps live in "OPEN TRADES CAPS" Inputs (top).
// MaxOpenTrades / MaxTotalOpenTradesAllSymbols / MaxOpenTradesPerCurrency
// are adjustable there (0 = unlimited). EnforceOpenTradeCaps is the master.

int CountTotalOpenTradesAllSymbols()
{
   int total = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);

      if(ticket == 0)
         continue;
      if(!PositionSelectByTicket(ticket))
         continue;

      if(PositionGetInteger(POSITION_MAGIC) == MagicNumber &&
         PositionGetDouble(POSITION_VOLUME) <= IgnoreTradesAboveLots)
      {
         total++;
      }
   }

   return total;
}

// Counts how many currently-open EA positions share a currency with the
// CANDIDATE symbol (BrokerSymbol) - both the base and quote 3-letter code
// are checked against every open position's own symbol, so EURUSD and
// USDJPY both count toward "USD exposure" even though neither is USDUSD.
// Extracted from IsNonScalpSymbol() so the same keyword check can be run
// against ANY symbol (e.g. a position's own symbol), not just the current
// BrokerSymbol. IsNonScalpSymbol() below is now a thin wrapper over this.
bool SymbolMatchesNonScalpKeywords(string symbol)
{
   string keywords[];
   int count = StringSplit(NonScalpSymbolKeywords, ',', keywords);

   string symUpper = symbol;
   StringToUpper(symUpper);

   for(int i = 0; i < count; i++)
   {
      string keyword = keywords[i];
      StringTrimLeft(keyword);
      StringTrimRight(keyword);
      StringToUpper(keyword);

      if(keyword == "")
         continue;

      if(StringFind(symUpper, keyword) >= 0)
         return true;
   }

   return false;
}

int CountOpenTradesSharingCurrency(string candidateSymbol)
{
   // FIX: BTCUSD's quote currency is "USD" - textually identical to every
   // USD-quoted forex pair (EURUSD, GBPUSD, USDJPY, AUDUSD, USDCAD) and
   // XAUUSD. If crypto positions (matched by NonScalpSymbolKeywords, e.g.
   // BTC/ETH) already occupy their own per-symbol trade slots, this cap
   // was counting THOSE as "USD exposure" too - meaning a few open BTCUSD
   // trades could fill up MaxOpenTradesPerCurrency and silently block
   // every forex pair from ever opening, since they all share that same
   // USD bucket with something that isn't actually the same kind of macro
   // USD exposure a forex pair represents. Crypto symbols are now
   // excluded from this grouping entirely - on both sides: a crypto
   // candidate never counts forex positions toward its own currency cap,
   // and a crypto position never counts toward a forex candidate's cap.
   if(SymbolMatchesNonScalpKeywords(candidateSymbol))
      return 0; // crypto symbols are governed by MaxOpenTrades/MaxTotalOpenTradesAllSymbols only, not currency grouping

   string baseCcy  = StringSubstr(candidateSymbol, 0, 3);
   string quoteCcy = StringSubstr(candidateSymbol, 3, 3);

   int total = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);

      if(ticket == 0)
         continue;
      if(!PositionSelectByTicket(ticket))
         continue;

      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;

      if(PositionGetDouble(POSITION_VOLUME) > IgnoreTradesAboveLots)
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);

      if(SymbolMatchesNonScalpKeywords(posSymbol))
         continue; // a crypto position never counts toward a forex candidate's currency exposure

      string posBase  = StringSubstr(posSymbol, 0, 3);
      string posQuote = StringSubstr(posSymbol, 3, 3);

      if(posBase == baseCcy || posBase == quoteCcy || posQuote == baseCcy || posQuote == quoteCcy)
         total++;
   }

   return total;
}

bool PortfolioExposureOK()
{
   // OPENCAPS47: master off → skip account/currency open-trade caps
   if(!EnforceOpenTradeCaps)
      return true;

   if(MaxTotalOpenTradesAllSymbols > 0 && CountTotalOpenTradesAllSymbols() >= MaxTotalOpenTradesAllSymbols)
   {
      if(EnableVerboseLogging)
         Print("Trading blocked: account-wide open trade cap reached (",
               CountTotalOpenTradesAllSymbols(), "/", MaxTotalOpenTradesAllSymbols, ")");
      return false;
   }

   if(MaxOpenTradesPerCurrency > 0 && CountOpenTradesSharingCurrency(BrokerSymbol) >= MaxOpenTradesPerCurrency)
   {
      if(EnableVerboseLogging)
         Print("Trading blocked: currency exposure cap reached for ", BrokerSymbol,
               " (cap=", MaxOpenTradesPerCurrency, ")");
      return false;
   }

   return true;
}

//=============================================================//
// Calculate Lot Size
//=============================================================//

input group "LOT SIZING (advanced)"

// LotSize / UseFixedLot / RiskPercent / MaxLotSizeHardCap are in
// TRADE SIZE & LIMITS at the top. CalculateLotSize() now always honors them.
// SymbolRiskOverrides scales RiskPercent per symbol when UseFixedLot=false.

input string SymbolRiskOverrides = "";

double GetSymbolRiskMultiplier(string symbol)
{
   if(StringLen(SymbolRiskOverrides) == 0)
      return 1.0;

   string pairs[];
   int pairCount = StringSplit(SymbolRiskOverrides, ',', pairs);

   for(int i = 0; i < pairCount; i++)
   {
      string kv[];
      int kvCount = StringSplit(pairs[i], ':', kv);

      if(kvCount != 2)
         continue;

      string sym = kv[0];
      StringTrimLeft(sym);
      StringTrimRight(sym);

      // Match by substring so "XAUUSD" matches broker-suffixed
      // "XAUUSD.m" too, same tolerance already used elsewhere in this
      // file for symbol matching (see NonScalpSymbolKeywords).
      if(StringFind(symbol, sym) >= 0)
      {
         double mult = StringToDouble(kv[1]);
         return (mult > 0.0) ? mult : 1.0;
      }
   }

   return 1.0;
}

double CalculateRiskBasedLot(double slDistance)
{
   double lot = LotSize;

   if(!UseFixedLot)
   {
      if(slDistance <= 0.0)
         return LotSize; // can't derive risk-based size without a stop distance - fail safe

      double tickValue = SymbolInfoDouble(BrokerSymbol, SYMBOL_TRADE_TICK_VALUE);
      double tickSize  = SymbolInfoDouble(BrokerSymbol, SYMBOL_TRADE_TICK_SIZE);

      if(tickValue <= 0.0 || tickSize <= 0.0)
         return LotSize; // can't price the risk on this symbol - fail safe

      double equity     = AccountInfoDouble(ACCOUNT_EQUITY);
      double effectiveRiskPercent = RiskPercent * GetSymbolRiskMultiplier(BrokerSymbol);
      double riskMoney   = equity * (effectiveRiskPercent / 100.0);
      double lossPerLot  = (slDistance / tickSize) * tickValue;

      if(lossPerLot <= 0.0)
         return LotSize;

      lot = riskMoney / lossPerLot;
   }

   double minLot  = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_STEP);

   if(lotStep > 0.0)
      lot = MathFloor(lot / lotStep) * lotStep;

   if(lot < minLot) lot = minLot;
   if(maxLot > 0.0 && lot > maxLot) lot = maxLot;
   if(lot > MaxLotSizeHardCap) lot = MaxLotSizeHardCap;

   return NormalizeLotVolume(lot);
}

double NormalizeLotVolume(double lot)
{
   double lotStep = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_STEP);
   int digits = 2;
   if(lotStep > 0.0 && lotStep < 1.0)
   {
      digits = 0;
      double step = lotStep;
      while(digits < 8 && MathAbs(step - MathRound(step)) > 1e-12)
      {
         step *= 10.0;
         digits++;
      }
   }
   return NormalizeDouble(lot, digits);
}

double CalculateLotSize(double slDistance = 0.0)
{
   // Adjustable sizing: UseFixedLot=true -> LotSize input.
   // UseFixedLot=false -> RiskPercent of equity vs SL distance.
   if(!UseFixedLot)
      return CalculateRiskBasedLot(slDistance);

   double minLot  = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_STEP);

   double lot = LotSize;

   if(lotStep > 0.0)
      lot = MathFloor(lot / lotStep) * lotStep;

   if(lot < minLot)
      lot = minLot;
   if(maxLot > 0.0 && lot > maxLot)
      lot = maxLot;
   if(lot > MaxLotSizeHardCap)
      lot = MaxLotSizeHardCap;

   return NormalizeLotVolume(lot);
}

//=============================================================//
// Margin Availability Check
//=============================================================//
// FIX: neither ExecuteBuy() nor ExecuteSell() checked whether the account
// actually had enough free margin before sending the order - they relied
// entirely on the broker rejecting it after the fact. This uses
// OrderCalcMargin() to work out the margin the trade would actually
// require and compares it against ACCOUNT_MARGIN_FREE (with a small
// safety buffer) before ever calling g_Trade.Buy()/g_Trade.Sell(), so a
// margin shortfall is caught and logged cleanly instead of surfacing as a
// generic broker-side rejection.

input double MarginSafetyBufferPercent = 10.0; // require this much extra free margin headroom beyond the calculated requirement

bool HasSufficientMargin(ENUM_ORDER_TYPE orderType, double lot, double price)
{
   double requiredMargin = 0.0;

   if(!OrderCalcMargin(orderType, BrokerSymbol, lot, price, requiredMargin))
   {
      Print("OrderCalcMargin failed - proceeding without a pre-trade margin check (error ", GetLastError(), ")");
      return true; // fail open - don't block trading just because the margin calc call itself failed
   }

   double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double requiredWithBuffer = requiredMargin * (1.0 + MarginSafetyBufferPercent / 100.0);

   if(freeMargin < requiredWithBuffer)
   {
      Print("Trade blocked: insufficient free margin. Required (with buffer): ",
            DoubleToString(requiredWithBuffer,2), ", Free: ", DoubleToString(freeMargin,2));
      return false;
   }

   return true;
}

//=============================================================//
// Margin Level Protection
//=============================================================//
// FIX: HasSufficientMargin() (Part 5) checks whether THIS trade's own
// margin requirement fits in free margin, but nothing checked the
// account's overall MARGIN LEVEL - a thin cushion across already-open
// positions where one more trade could tip the account toward a margin
// call even if this specific trade's own requirement technically fits.

input double MinMarginLevelPercent = 0.0; // ALLTRADE56: 0=off — was 200% blocking accounts with open risk

bool MarginLevelProtection()
{
   if(MinMarginLevelPercent <= 0.0)
      return true;

   double usedMargin = AccountInfoDouble(ACCOUNT_MARGIN);

   if(usedMargin <= 0.0)
      return true; // no open exposure yet - nothing to protect against

   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double marginLevel = (equity / usedMargin) * 100.0;

   if(marginLevel < MinMarginLevelPercent)
   {
      Print("Trading blocked: margin level too low (", DoubleToString(marginLevel,1), "%)");
      return false;
   }

   return true;
}

//=============================================================//
// Master Risk Check
//=============================================================//

bool RiskManagementOK()
{
   if(!DrawdownProtection())
      return false;

   if(!DailyLossProtection())
      return false;

   if(!WeeklyLossProtection())
      return false;

   if(!MonthlyLossProtection())
      return false;

   if(!MaxTradesProtection())
      return false;

   if(!MarginLevelProtection())
      return false;

   if(!PortfolioExposureOK())
      return false;

   return true;
}
//+------------------------------------------------------------------+
//|              PART 6 - EXECUTION ENGINE                            |
//+------------------------------------------------------------------+

input group "LOGGING"

// FIX: the EA printed a running commentary on almost every tick/bar
// ("Instant Execution Running", "FINAL CHECK PASSED", every blocked
// reason, etc.) which floods the Experts/Journal tab and adds needless
// overhead on long unattended runs. Off by default now - trade opens/
// closes, errors, and emergency actions always print regardless of this
// setting (those are the ones you actually need in the log); routine
// per-tick/per-bar status chatter only prints when this is turned on.
input bool EnableVerboseLogging = false;

//================ INPUT SETTINGS ===================================//

input double StopLossPoints   = 500;
input double TakeProfitPoints = 1000;
input int    SlippagePoints   = 20;
input int TradeCooldownMinutes = 0;   // OK79 aggressive instant (NeverBlock bypasses anyway)
input int AttemptCooldownSeconds = 1;  // OK79 aggressive instant retry

// #12 Broker filling / slippage profiles (per instrument class)
input group "SLIPPAGE PROFILES (#12)"
input bool   EnableSlippageProfiles     = true;   // use FX/Gold/Crypto deviation presets
input int    ForexSlippagePoints        = 20;     // majors / crosses
input int    GoldSlippagePoints         = 80;     // XAU / XAG style
input int    CryptoSlippagePoints       = 150;    // BTC/ETH when NonScalp match
input double NonScalpSlippageMultiplier = 5.0;    // fallback if profiles OFF (legacy)

int GetEffectiveSlippagePoints()
{
   if(EnableSlippageProfiles)
   {
      if(IsNonScalpSymbol())
         return MathMax(1, CryptoSlippagePoints);
      string sym = BrokerSymbol;
      StringToUpper(sym);
      if(StringFind(sym, "XAU") >= 0 || StringFind(sym, "GOLD") >= 0 ||
         StringFind(sym, "XAG") >= 0 || StringFind(sym, "SILVER") >= 0)
         return MathMax(1, GoldSlippagePoints);
      return MathMax(1, ForexSlippagePoints);
   }

   // Legacy path
   if(IsNonScalpSymbol())
      return (int)MathRound(SlippagePoints * NonScalpSlippageMultiplier);

   return MathMax(1, SlippagePoints);
}

input group "NON-SCALP SYMBOL OVERRIDE"

// FIX: EntryTF, the cooldown, and the ATR stop multiplier apply the same
// way to every symbol - but BTCUSD moves so many real dollars even on a
// short timeframe that trading it on the same cadence as forex naturally
// produces scalp-style behavior (quick in, quick out on small wiggles).
// Symbols matching NonScalpSymbolKeywords get a wider stop distance and a
// longer minimum wait between trades, so they hold for real moves instead
// of reacting to short-term noise. Other symbols (XAUUSD, forex pairs)
// are completely unaffected - only the matched symbol gets this treatment.

input string NonScalpSymbolKeywords   = "BTC,ETH";
input double NonScalpSLMultiplierBoost = 2.0;   // multiplies SL_ATR_Multiplier for matched symbols - wider stop, wider TP1/TP2 (they scale off SL distance)
input int    NonScalpCooldownMinutes   = 0;    // 0 with Ultra aggro — BTC/ETH use MaxOpenTrades, not idle wait
input int    NonScalpMinimumHoldBars   = 80;    // bars (on EntryTF) before trend-exit/trailing can act on matched symbols (vs MinimumHoldBars for everything else) - 80 x M15 = ~20 hours

// FIX - THIS IS WHY BTCUSD KEPT CLOSING TRADES: once holdPeriodOK became
// true, EnableTrendExit checked ADX on every tick and closed the position
// the instant ADX dipped below TrendExitADXLevel (20) - even briefly. BTC's
// ADX crosses that kind of threshold often without the underlying trend
// actually being over, so positions were getting closed out on ADX noise
// rather than a genuine trend reversal - the exact opposite of "don't
// scalp BTC." Disabled by default for matched symbols; SL/TP1/TP2/trailing
// still fully protect the trade, this only removes the ADX-based early exit.
input bool NonScalpDisableTrendExit = true;

// FIX: this used to duplicate the exact same keyword-matching logic that
// now lives in SymbolMatchesNonScalpKeywords() (defined earlier, next to
// CountOpenTradesSharingCurrency which also needs to run this check
// against arbitrary symbols, not just BrokerSymbol). Kept as a thin
// wrapper so every existing call site (GetTradeDistances, CooldownFinished,
// ManageOpenTrades, NewsTradingAllowed, etc.) is untouched.
bool IsNonScalpSymbol()
{
   return SymbolMatchesNonScalpKeywords(BrokerSymbol);
}

input group "DYNAMIC STOPS & SNIPER TARGETS"

// FIX: StopLossPoints/TakeProfitPoints above are a flat "points" distance,
// tuned for forex-style pricing. That's what was leaving BTCUSD trades
// with no SL/TP at all - 500 points on a symbol where SYMBOL_POINT is tiny
// relative to a $60,000+ price is a fraction of a dollar, which brokers
// reject as an invalid/too-close stop. ATR scales to whatever the
// instrument is actually doing right now, in real price terms, so the
// same settings work sanely on XAUUSD, BTCUSD, or EURUSD alike.

input bool   UseDynamicStops        = true;   // ATR-based SL/TP instead of fixed points
input double SL_ATR_Multiplier      = 2.0;    // stop-loss distance = ATR x this
input double TP1_RR_Ratio           = 1.5;    // CHANGED from 1.0 - at 1.0, a TP1-only win (50% of position at 1R) only nets +0.5R while a full loss costs -1R, meaning even a 50% win rate loses money. At 1.5, a TP1-only win nets +0.75R - still less than a full loss, but the gap is smaller. See TP1_ClosePercent below for the other lever on this same tradeoff.
input double TP2_RR_Ratio           = 2.5;    // TP2 distance = SL distance x this (final target, set as broker TP)
input double TP1_ClosePercent       = 50.0;   // % of the position closed when TP1 is hit
input bool   MoveSLToBreakEvenAtTP1 = true;   // fallback: move remaining SL to entry if SecureProfitOnTPHit=false

input group "AGGRESSIVE PROFIT LADDER"
// SURE ladder (aggressive):
// TP1 hit → SL locks INTO profit → remainder MUST run to TP2
// TP2 hit → SL locks further → remainder MUST run to TP3 / trail
// Broker TP opens at TP3 (far) so the broker cannot close the trade at TP2
// before the EA locks profit and advances the ladder.

input bool   AggressiveProfitLadder   = true;  // master ladder switch (forced on when ForceSureProfitLadder)
input bool   ForceSureProfitLadder    = true;  // overrides UseFixedTradeManagement — ladder ALWAYS active
input bool   SecureProfitOnTPHit      = true;  // move SL INTO profit (not just breakeven) when a TP hits
input double LockProfitAtTP1_Fraction = 0.80;  // lock 80% of TP1 move as secured profit (aggressive)
input double LockProfitAtTP2_Fraction = 0.85;  // lock ~85% of TP2 move (near/above TP1) when TP2 hits
input double LockProfitBufferATR      = 0.05;  // small ATR buffer so locked SL is not glued to exact wick
input bool   ExtendTPAfterLock        = true;  // after TP1 → broker TP=TP3; after TP2 → TP3 or trail(0)
input bool   DetectTPByBarTouch       = true;  // count TP hit if bar high/low touched level (sure detect)
input double AggressiveTrailATRMult   = 1.5;   // tight ATR trail after TP1 locks profit
input bool   BrokerTPStartsAtTP3      = true;  // open with far TP3 so EA owns TP1/TP2 ladder steps

input group "MARKET DEFENSE ENGINE"
// Defends open trades against the market flipping, chopping, or trapping.
// Runs every tick in ManageOpenTrades — can lock BE, tighten SL, or close.

input bool   EnableMarketDefense            = true;  // master defense switch
input bool   DefenseCloseOnHardReversal     = false; // OFF — was closing runners on soft opposite stacks
input bool   DefenseLockBEOnAdverseSweep    = true;  // wrong-side sweep vs our trade → lock BE
input bool   DefenseTightenOnChop           = true;  // IMCE manipulation/chop while in profit → BE
input bool   DefenseCloseOnTrapAgainst      = false; // OFF — fake-breakout closes were too aggressive
input bool   DefenseRetraceLockFromPeak     = true;  // retrace from MFE → lock portion of peak profit
input double DefenseRetraceATR              = 0.70;  // ATR retrace from peak that triggers lock
input double DefenseRetraceLockFraction     = 0.50;  // lock this fraction of peak favorable move
input bool   DefenseRequireInProfitToClose  = true;  // if hard-reversal re-enabled, only close when green
input bool   DefenseLogActions              = true;  // print DEFEND actions to Experts

// #7 mid-path BE before TP1 (lighter than full close)
input bool   DefensePreTP1AdverseBE         = true;  // lock BE pre-TP1 on adverse move (wick pressure)
input double DefensePreTP1AdverseATR        = 0.55;  // adverse ATR from entry that arms pre-TP1 BE
input bool   DefensePreTP1RequireProfitTiny = false; // if true, only BE when back near flat/green

// #8 MAE hard cut before TP1
input bool   DefenseMAE_StopEnabled         = false; // OFF — MAE hard-cut closed too many positions
input double DefenseMAE_ATR                 = 2.50;  // only if MAE stop re-enabled (was 1.25)

//================ TRADE STATE TRACKING (for TP1/TP2/TP3) ============//
// MT5 positions only carry one SL and one TP natively - there's no built-in
// concept of "close half here, let the rest run to a further target." This
// struct/array is what makes that possible: at the moment a trade is opened,
// its TP1/TP2/TP3 levels and original volume are recorded here so
// ManageOpenTrades() can recognize "price just reached this position's
// TP1/TP2" and act once each, while the broker-side TP field tracks
// whichever target is currently active for the remaining volume.

struct TradeState
{
   ulong  ticket;
   double tp1Price;
   double tp2Price;
   double tp3Price;
   bool   isBuy;
   bool   tp1Taken;
   bool   tp2Taken; // UPGRADE: TP2 scale-out / TP3 runner activation flag
   string strategyTag; // NEW - which strategy (SMC/MeanReversion/TrendPullback/etc) actually produced this trade, for per-strategy performance tracking (Part 15i)
   double peakFavorable; // DEFEND: best favorable price excursion from entry (absolute price)
   double peakAdverse;   // AUDITOK52: max adverse distance from entry (sticky arm for pre-TP1 BE)
};

// NEW - set right before ExecuteBuy()/ExecuteSell() is called in
// InstantExecution(), read by RegisterTradeState() below so each trade's
// originating strategy is recorded without threading an extra parameter
// through the whole execution call chain.
string g_PendingStrategyTag = "";


TradeState TradeStates[];

// FIX: the in-memory array alone loses all TP1/TP2 tracking if the EA is
// removed/re-attached, the terminal restarts, or the platform crashes -
// any position already open at that point would just run to its
// broker-side TP with no further scale-out ever happening. MT5's
// GlobalVariable store is written to disk and survives all of that, so
// every state change is mirrored there and RestoreTradeStates() (called
// from OnInit) rebuilds the in-memory table from it on startup.

string TradeStateGVPrefix()
{
   return "HitmanAI_" + IntegerToString(MagicNumber) + "_TP1_";
}

void PersistTradeState(int index)
{
   // HARDEN: never index TradeStates out of range
   if(index < 0 || index >= ArraySize(TradeStates))
      return;
   if(TradeStates[index].ticket == 0)
      return;

   string prefix = TradeStateGVPrefix() + IntegerToString(TradeStates[index].ticket);

   GlobalVariableSet(prefix + "_tp1",    TradeStates[index].tp1Price);
   GlobalVariableSet(prefix + "_tp2",    TradeStates[index].tp2Price);
   GlobalVariableSet(prefix + "_tp3",    TradeStates[index].tp3Price);
   GlobalVariableSet(prefix + "_buy",    TradeStates[index].isBuy    ? 1.0 : 0.0);
   GlobalVariableSet(prefix + "_taken",  TradeStates[index].tp1Taken ? 1.0 : 0.0);
   GlobalVariableSet(prefix + "_taken2", TradeStates[index].tp2Taken ? 1.0 : 0.0);
   GlobalVariableSet(prefix + "_mfe",    TradeStates[index].peakFavorable);
   GlobalVariableSet(prefix + "_mae",    TradeStates[index].peakAdverse);
}

void DeleteTradeStateGlobals(ulong ticket)
{
   if(ticket == 0)
      return;

   string prefix = TradeStateGVPrefix() + IntegerToString(ticket);

   GlobalVariableDel(prefix + "_tp1");
   GlobalVariableDel(prefix + "_tp2");
   GlobalVariableDel(prefix + "_tp3");
   GlobalVariableDel(prefix + "_buy");
   GlobalVariableDel(prefix + "_taken");
   GlobalVariableDel(prefix + "_taken2");
   GlobalVariableDel(prefix + "_mfe");
   GlobalVariableDel(prefix + "_mae");
}

void RegisterTradeState(ulong ticket, double tp1Price, double tp2Price, double tp3Price, bool isBuy)
{
   // HARDEN: never register unresolved ticket 0 (pollutes GV namespace _TP1_0_*)
   if(ticket == 0)
   {
      Print("HARDEN: RegisterTradeState skipped — ticket is 0");
      return;
   }

   int n = ArraySize(TradeStates);
   ArrayResize(TradeStates, n + 1);

   TradeStates[n].ticket      = ticket;
   TradeStates[n].tp1Price    = tp1Price;
   TradeStates[n].tp2Price    = tp2Price;
   TradeStates[n].tp3Price    = tp3Price;
   TradeStates[n].isBuy       = isBuy;
   TradeStates[n].tp1Taken    = false;
   TradeStates[n].tp2Taken    = false;
   TradeStates[n].strategyTag = g_PendingStrategyTag;
   TradeStates[n].peakFavorable = 0.0;
   TradeStates[n].peakAdverse = 0.0;

   PersistTradeState(n);
}

// Rebuilds TradeStates[] from GlobalVariables for every currently-open
// position belonging to this EA (matching magic number). Call once from
// OnInit so a restart doesn't silently drop TP1/TP2 tracking for trades
// that were already open.
void RestoreTradeStates()
{
   ArrayResize(TradeStates, 0);

   string prefix = TradeStateGVPrefix();

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);

      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      // MT5 position tickets are globally unique across all symbols in the
      // account, so no symbol filter is needed here - the magic number
      // check below is sufficient on its own (see FIX note from the
      // multi-symbol persistence bug fixed earlier in this file).

      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;

      string tp1Key    = prefix + IntegerToString(ticket) + "_tp1";
      string tp2Key    = prefix + IntegerToString(ticket) + "_tp2";
      string tp3Key    = prefix + IntegerToString(ticket) + "_tp3";
      string buyKey    = prefix + IntegerToString(ticket) + "_buy";
      string takenKey  = prefix + IntegerToString(ticket) + "_taken";
      string taken2Key = prefix + IntegerToString(ticket) + "_taken2";

      if(!GlobalVariableCheck(tp1Key))
         continue; // no persisted TP1 data for this position - opened before this feature, or state was lost

      int n = ArraySize(TradeStates);
      ArrayResize(TradeStates, n + 1);

      TradeStates[n].ticket   = ticket;
      TradeStates[n].tp1Price = GlobalVariableGet(tp1Key);
      TradeStates[n].tp2Price = GlobalVariableCheck(tp2Key) ? GlobalVariableGet(tp2Key) : 0.0;
      TradeStates[n].tp3Price = GlobalVariableCheck(tp3Key) ? GlobalVariableGet(tp3Key) : 0.0;
      TradeStates[n].isBuy    = (GlobalVariableGet(buyKey) > 0.5);
      TradeStates[n].tp1Taken = (GlobalVariableGet(takenKey) > 0.5);
      TradeStates[n].tp2Taken = GlobalVariableCheck(taken2Key) ? (GlobalVariableGet(taken2Key) > 0.5) : false;
      string mfeKey = prefix + IntegerToString(ticket) + "_mfe";
      string maeKey = prefix + IntegerToString(ticket) + "_mae";
      TradeStates[n].peakFavorable = GlobalVariableCheck(mfeKey) ? GlobalVariableGet(mfeKey) : 0.0;
      TradeStates[n].peakAdverse   = GlobalVariableCheck(maeKey) ? GlobalVariableGet(maeKey) : 0.0;
      TradeStates[n].strategyTag = "";

      // HARDEN: discard corrupt GV prices so ladder/defense cannot use NaN
      if(!MathIsValidNumber(TradeStates[n].tp1Price) || TradeStates[n].tp1Price <= 0.0)
      {
         ArrayResize(TradeStates, n); // drop this slot
         continue;
      }
      if(!MathIsValidNumber(TradeStates[n].tp2Price) || TradeStates[n].tp2Price < 0.0)
         TradeStates[n].tp2Price = 0.0;
      if(!MathIsValidNumber(TradeStates[n].tp3Price) || TradeStates[n].tp3Price < 0.0)
         TradeStates[n].tp3Price = 0.0;
      if(!MathIsValidNumber(TradeStates[n].peakFavorable) || TradeStates[n].peakFavorable < 0.0)
         TradeStates[n].peakFavorable = 0.0;
      if(!MathIsValidNumber(TradeStates[n].peakAdverse) || TradeStates[n].peakAdverse < 0.0)
         TradeStates[n].peakAdverse = 0.0;
   }

   Print("Restored ", ArraySize(TradeStates), " TP1 trade state(s) from persistent storage.");
}

int FindTradeState(ulong ticket)
{
   for(int i = 0; i < ArraySize(TradeStates); i++)
      if(TradeStates[i].ticket == ticket)
         return i;

   return -1;
}

// Drops entries for tickets that are no longer open (closed/hit their
// full TP), so this array doesn't grow forever over a long-running EA.
// Also clears their persisted GlobalVariables so closed trades don't
// leave stale entries behind on disk.
void PruneTradeStates()
{
   for(int i = ArraySize(TradeStates) - 1; i >= 0; i--)
   {
      if(!PositionSelectByTicket(TradeStates[i].ticket))
      {
         DeleteTradeStateGlobals(TradeStates[i].ticket);

         for(int j = i; j < ArraySize(TradeStates) - 1; j++)
            TradeStates[j] = TradeStates[j + 1];

         ArrayResize(TradeStates, ArraySize(TradeStates) - 1);
      }
   }
}

input group "TP3 / RUNNER MODE"

// UPGRADE: previously the whole remaining position (after TP1) closed in
// one shot at TP2 - there was no concept of a "runner" that keeps going
// for an outsized move. This adds a second scale-out at TP2 (mirroring the
// TP1 mechanism, same minimum-lot fallback behavior) and, for whatever's
// left after that, either lets it trail with no fixed cap (if EnableTrailing
// is on) or gives it one more real target, TP3, so it's never left
// completely unmanaged.

input double TP2_ClosePercent = 50.0;   // % of the REMAINING (post-TP1) position closed at TP2
input double TP3_RR_Ratio     = 4.0;    // TP3 distance = SL distance x this - used as the runner's target when trailing is off
input bool   EnableTP3Runner  = true;   // if false, TP2 behaves like a normal final target (old behavior) instead of releasing a runner

// Works out the SL/TP1/TP2/TP3 price distances for a new g_Trade. Falls back
// to the original fixed-points behavior if UseDynamicStops is off, so
// nothing changes for anyone who preferred the old behavior.
void GetTradeDistances(double &slDistance, double &tp1Distance, double &tp2Distance, double &tp3Distance)
{
   double point = SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT);

   if(UseDynamicStops)
   {
      double atr = GetFilterATR();

      if(atr <= 0.0)
      {
         // ATR not ready yet - fail safe to the fixed-points distance
         // rather than opening with no usable distance at all.
         slDistance = StopLossPoints * point;
      }
      else
      {
         slDistance = atr * SL_ATR_Multiplier;
      }
   }
   else
   {
      slDistance = StopLossPoints * point;
   }

   // Widen the stop for symbols matched by NonScalpSymbolKeywords (BTC/ETH
   // by default) - TP1/TP2/TP3 scale off slDistance below, so this widens
   // the whole trade proportionally, not just the stop-loss.
   if(IsNonScalpSymbol())
      slDistance = slDistance * NonScalpSLMultiplierBoost;

   // OK64: ContFallback / APEX get wider SL so they cannot behave like scalps
   if(EnableAntiScalpMode && ContFallbackSL_ATR_Boost > 1.0 &&
      (g_PendingStrategyTag == "ContFallback" || g_PendingStrategyTag == "APEX" || g_PendingStrategyTag == "LCS" || PRIME_IsLiveTag(g_PendingStrategyTag)))
      slDistance = slDistance * ContFallbackSL_ATR_Boost;

   tp1Distance = slDistance * TP1_RR_Ratio;
   tp2Distance = slDistance * TP2_RR_Ratio;
   tp3Distance = slDistance * TP3_RR_Ratio;
}

bool ProfitLadderActive()
{
   return (ForceSureProfitLadder || (AggressiveProfitLadder && !UseFixedTradeManagement));
}

// Broker TP must start at far TP3 so the broker cannot full-close at TP2
// before the EA locks SL and advances TP1 → TP2 → TP3.
double InitialBrokerTP(const bool isBuy, const double entry,
                       const double tp2Distance, const double tp3Distance,
                       const double tp2Price, const double tp3Price)
{
   if(ForceSureProfitLadder || (AggressiveProfitLadder && BrokerTPStartsAtTP3))
   {
      if(tp3Price > 0.0)
         return tp3Price;
      return isBuy ? (entry + tp3Distance) : (entry - tp3Distance);
   }
   if(tp2Price > 0.0)
      return tp2Price;
   return isBuy ? (entry + tp2Distance) : (entry - tp2Distance);
}

// HARDEN: iHigh/iLow return 0 on failure — never treat as a real touch.
bool SafeBarTouchedHigh(const int bar, const double level)
{
   double hi = iHigh(BrokerSymbol, EntryTF, bar);
   if(!MathIsValidNumber(hi) || hi <= 0.0 || hi == EMPTY_VALUE)
      return false;
   return (hi >= level);
}

bool SafeBarTouchedLow(const int bar, const double level)
{
   double lo = iLow(BrokerSymbol, EntryTF, bar);
   if(!MathIsValidNumber(lo) || lo <= 0.0 || lo == EMPTY_VALUE)
      return false;
   return (lo <= level);
}

// BUGFIX40: never credit pre-entry bar wicks as TP hits (was firing TP1/TP2
// instantly on new trades when prior bar already swept the level).
// barsHeld==0 (same bar as entry): live price only.
// barsHeld>=1: may use forming bar 0 wick.
// barsHeld>=2: may also use completed bar 1 wick.
bool LevelTouchedForTP(const bool isBuy, const double level, const double price, const int barsHeld)
{
   if(!MathIsValidNumber(level) || !MathIsValidNumber(price) || level <= 0.0 || price <= 0.0)
      return false;

   if(isBuy)
   {
      if(price >= level)
         return true;
      if(!DetectTPByBarTouch)
         return false;
      if(barsHeld >= 1 && SafeBarTouchedHigh(0, level))
         return true;
      if(barsHeld >= 2 && SafeBarTouchedHigh(1, level))
         return true;
      return false;
   }

   if(price <= level)
      return true;
   if(!DetectTPByBarTouch)
      return false;
   if(barsHeld >= 1 && SafeBarTouchedLow(0, level))
      return true;
   if(barsHeld >= 2 && SafeBarTouchedLow(1, level))
      return true;
   return false;
}

//================ NORMALIZE PRICE ===================================//

double NormalizeTradePrice(double price)
{
   int digits = UltraSymDigits(BrokerSymbol);

   double tickSize = SymbolInfoDouble(BrokerSymbol, SYMBOL_TRADE_TICK_SIZE);

   // Rounding to the right number of decimal places is not enough for
   // symbols like BTCUSD, where the broker's real price increment
   // (tick size) is coarser than the decimal digits suggest - e.g. digits=2
   // lets 63295.71 look "valid" even though the broker only accepts
   // multiples of 1.00 or 0.50. Snap to the tick grid first, then to digits.
   if(tickSize > 0.0)
      price = MathRound(price / tickSize) * tickSize;

   return NormalizeDouble(price, digits);
}


//================ CHECK STOPS ======================================//

bool CheckTradeStops(double entry,double &sl,double &tp)
{
   double point =
      SymbolInfoDouble(BrokerSymbol,SYMBOL_POINT);

   if(point <= 0)
      return false;

   long stopLevel =
      UltraSymStopsLevel(BrokerSymbol);

   long freezeLevel =
      UltraSymFreezeLevel(BrokerSymbol);

   double minimumDistance =
      MathMax((double)stopLevel,(double)freezeLevel) * point;

   // FIX: the flat "100 points" floor used to apply unconditionally,
   // before the ATR-scaled floor even had a chance to matter - a forex-
   // scale assumption baked in regardless of what the broker or the
   // instrument's real volatility actually called for. Now it's only used
   // as a last-resort fallback when ATR data isn't available at all;
   // when it is, the ATR-scaled floor below is what actually governs the
   // minimum distance, since that adapts to what the instrument is really
   // doing in price terms rather than an arbitrary point count.
   double atrFloor = GetFilterATR() * 0.05;

   if(atrFloor > 0.0)
   {
      if(atrFloor > minimumDistance)
         minimumDistance = atrFloor;
   }
   else if(minimumDistance < 100 * point)
   {
      minimumDistance = 100 * point;
   }

   if(sl < entry)
   {
      if((entry - sl) < minimumDistance)
         sl = entry - minimumDistance;
   }
   else
   {
      if((sl - entry) < minimumDistance)
         sl = entry + minimumDistance;
   }

   if(tp > entry)
   {
      if((tp - entry) < minimumDistance)
         tp = entry + minimumDistance;
   }
   else
   {
      if((entry - tp) < minimumDistance)
         tp = entry - minimumDistance;
   }

   sl = NormalizeTradePrice(sl);
   tp = NormalizeTradePrice(tp);

   return true;
}

//================ POSITION TICKET RESOLUTION =========================//
// FIX: RegisterTradeState()/RecordSignalSnapshot() used to be called with
// g_Trade.ResultOrder() - the ORDER ticket. On many account/broker setups
// the POSITION ticket (what PositionSelectByTicket/PruneTradeStates/
// FindTradeState actually look up by) is not guaranteed to equal the order
// ticket. The officially correct way to resolve "which position did this
// order create" is the order's own ORDER_POSITION_ID field in history.
// Falls back to the order ticket itself only if that lookup fails, which
// is still better than nothing.

ulong ResolvePositionTicket(ulong orderTicket)
{
   // AUDITFIX49: ensure history is loaded before HistoryOrderSelect
   if(orderTicket == 0)
      return 0;

   datetime from = TimeCurrent() - 86400;
   datetime to   = TimeCurrent() + 60;
   if(!HistorySelect(from, to))
      HistorySelect(0, TimeCurrent() + 60);

   if(HistoryOrderSelect(orderTicket))
   {
      ulong posId = (ulong)HistoryOrderGetInteger(orderTicket, ORDER_POSITION_ID);

      if(posId != 0)
         return posId;
   }

   return orderTicket;
}

//================ PENDING SIGNAL SNAPSHOT (fix #6) ===================//
// FIX: RecordSignalSnapshot() used to be called AFTER the trade already
// executed, and recalculated CalculateTradeScore()/every signal flag fresh
// at that point - by which time price/indicators may have already ticked
// forward from the moment StrongBuySetup()/StrongSellSetup() actually
// approved the g_Trade. That meant the score saved for post-trade signal
// review could quietly differ from the score that actually triggered the
// entry. StrongBuySetup()/StrongSellSetup() now capture the exact snapshot
// at the moment of the decision (Part 15) into this pending slot;
// RecordSignalSnapshot() (called after a successful fill) just stamps the
// real ticket onto that already-captured data instead of recomputing it.

SignalSnapshot PendingSignalSnapshot;
bool PendingSignalSnapshotValid = false;

void CapturePendingSignalSnapshot(bool buy, string strategyTag = "")
{
   PRISMStructureSnapshot s = PRISM_GetStructureSnapshot(buy);

   PendingSignalSnapshot.ticket          = 0;
   PendingSignalSnapshot.isBuy           = buy;
   PendingSignalSnapshot.score           = CalculatePRISMScore(buy);
   PendingSignalSnapshot.requiredScore   = EffectiveMinimumMPIScore();
   PendingSignalSnapshot.trendOK         = s.trend;
   PendingSignalSnapshot.htfOK           = s.htfConfirms;
   PendingSignalSnapshot.confluenceOK    = HasStructureConfluence(buy);
   PendingSignalSnapshot.mtfConfluenceOK = HasHTFStructureConfluence(buy);
   PendingSignalSnapshot.bosPresent      = s.bos;
   PendingSignalSnapshot.chochPresent    = s.choch;
   PendingSignalSnapshot.sweepPresent    = s.sweep;
   PendingSignalSnapshot.fvgPresent      = s.fvg;
   PendingSignalSnapshot.obPresent       = s.ob;
   PendingSignalSnapshot.volExpanding    = IsVolatilityExpanding();
   PendingSignalSnapshot.regime          = GetMarketRegime();

   PendingSignalSnapshotValid = true;

   if(EnableBeastMode && strategyTag != "" && (EnableVerboseLogging || EnableSetupLogging))
      Print("BEAST snapshot: ", strategyTag, " grade=", PRISMGetTradeGrade(buy, strategyTag),
            " MPI=", PendingSignalSnapshot.score);
}

void RecordSignalSnapshot(ulong ticket, bool buy)
{
   // HARDEN: never snapshot unresolved tickets
   if(ticket == 0)
      return;

   int n = ArraySize(SignalSnapshots);
   ArrayResize(SignalSnapshots, n + 1);

   if(PendingSignalSnapshotValid && PendingSignalSnapshot.isBuy == buy)
   {
      SignalSnapshots[n] = PendingSignalSnapshot;
      SignalSnapshots[n].ticket = ticket;
   }
   else
   {
      // No pending snapshot available (shouldn't normally happen) - fall
      // back to recomputing fresh, same as the original behavior.
      SignalSnapshots[n].ticket          = ticket;
      SignalSnapshots[n].isBuy           = buy;
      SignalSnapshots[n].score           = CalculateTradeScore(buy);
      SignalSnapshots[n].requiredScore   = GetEffectiveMinimumScore();
      SignalSnapshots[n].trendOK         = buy ? IsBullTrend() : IsBearTrend();
      SignalSnapshots[n].htfOK           = HTFConfirms(buy);
      SignalSnapshots[n].confluenceOK    = HasStructureConfluence(buy);
      SignalSnapshots[n].mtfConfluenceOK = HasHTFStructureConfluence(buy);
      SignalSnapshots[n].bosPresent      = DetectBOS();
      SignalSnapshots[n].chochPresent    = DetectCHoCH();
      SignalSnapshots[n].sweepPresent    = DetectLiquiditySweep();
      SignalSnapshots[n].fvgPresent      = buy ? DetectBullishFVG() : DetectBearishFVG();
      SignalSnapshots[n].obPresent       = buy ? DetectBullishOrderBlock() : DetectBearishOrderBlock();
      SignalSnapshots[n].volExpanding    = IsVolatilityExpanding();
      SignalSnapshots[n].regime          = GetMarketRegime();
   }

   PendingSignalSnapshotValid = false;
}

//================ EXECUTE BUY ======================================//

//================ DYNAMIC FILLING MODE (broker compatibility) =====//
// FIX: CTrade does not automatically detect which order-filling mode a
// given symbol/broker actually supports - left unset, it defaults to
// ORDER_FILLING_FOK, which plenty of brokers (especially ECN/exchange-
// execution ones) reject outright ("Unsupported filling mode"), silently
// failing every single order. This reads the symbol's real supported
// modes (SYMBOL_FILLING_MODE) and picks the best match each time a trade
// is about to be placed, instead of assuming one fixed mode works
// everywhere.

void ConfigureFillingMode(string symbol)
{
   long fillingModes = UltraSymFillingMode(symbol);

   if((fillingModes & SYMBOL_FILLING_FOK) != 0)
      g_Trade.SetTypeFilling(ORDER_FILLING_FOK);
   else if((fillingModes & SYMBOL_FILLING_IOC) != 0)
      g_Trade.SetTypeFilling(ORDER_FILLING_IOC);
   else
      g_Trade.SetTypeFilling(ORDER_FILLING_RETURN); // safest fallback - supported almost everywhere
}

// BROKER RESPONSE CLASSIFICATION (this pass): the retry loop below already
// handled requotes/price-changes well, but treated every OTHER retcode as
// one undifferentiated "other error" bucket that just fell through to the
// no-stops fallback. Some retcodes are worth a fresh retry (transient
// connection/timeout hiccups); some mean the order is fundamentally
// unplaceable right now and retrying (or attempting the no-stops fallback)
// is pointless and just wastes time while conditions keep moving. This
// gives each case a clear, distinct log message so failures are easy to
// diagnose from the Journal instead of all looking like the same generic
// "BUY FAILED".
bool IsTransientOrderRetcode(uint retcode)
{
   return (retcode == TRADE_RETCODE_REQUOTE ||
           retcode == TRADE_RETCODE_PRICE_OFF ||
           retcode == TRADE_RETCODE_PRICE_CHANGED ||
           retcode == TRADE_RETCODE_TIMEOUT ||
           retcode == TRADE_RETCODE_CONNECTION);
}

bool IsFatalOrderRetcode(uint retcode)
{
   return (retcode == TRADE_RETCODE_NO_MONEY ||
           retcode == TRADE_RETCODE_MARKET_CLOSED ||
           retcode == TRADE_RETCODE_TRADE_DISABLED ||
           retcode == TRADE_RETCODE_INVALID_VOLUME ||
           retcode == TRADE_RETCODE_CLIENT_DISABLES_AT ||
           retcode == TRADE_RETCODE_SERVER_DISABLES_AT);
}

string DescribeOrderRetcode(uint retcode, string desc)
{
   if(retcode == TRADE_RETCODE_NO_MONEY)        return "insufficient free margin - not retrying.";
   if(retcode == TRADE_RETCODE_MARKET_CLOSED)   return "market closed for this symbol - not retrying.";
   if(retcode == TRADE_RETCODE_TRADE_DISABLED)  return "trading disabled for this symbol/account - not retrying.";
   if(retcode == TRADE_RETCODE_INVALID_VOLUME)  return "broker rejected the lot size as invalid - not retrying.";
   if(retcode == TRADE_RETCODE_CLIENT_DISABLES_AT) return "AutoTrading disabled on the client terminal - not retrying.";
   if(retcode == TRADE_RETCODE_SERVER_DISABLES_AT) return "AutoTrading disabled by the broker server - not retrying.";
   return desc;
}

bool ExecuteBuy()
{
   int symIdx = GetSymbolIndex(BrokerSymbol);

   if(symIdx < 0)
   {
      Print("ExecuteBuy: symbol not in tracking list: ", BrokerSymbol);
      return false;
   }

   ConfigureFillingMode(BrokerSymbol);

   // Stops repeated failed attempts from firing on every single tick
   // (was previously only gated by TradeCooldownMinutes, which only starts
   // counting after a *successful* trade - so a persistently-failing
   // attempt, e.g. invalid stops, would retry every tick with no limit).
   if(TimeCurrent() - LastAttemptTimeArr[symIdx] < AttemptCooldownSeconds)
   {
      if(EnableVerboseLogging || EnableSetupLogging)
         Print("BUY aborted: attempt cooldown (", AttemptCooldownSeconds, "s) on ", BrokerSymbol);
      return false;
   }

   if(!RiskManagementOK())
      return false;

   if(!TradeProtectionOK())
      return false;

   // Sanity: direction still agrees — skip abort in UltraAggressiveFire
   // (path+engines already approved; price can wick without flipping EMA).
   // Live gate is EvaluateStrategySignals (APEX → ContFallback only).
   if(!IsBullTrend() && !(UltraAggressiveFire || NeverBlockValidSniperEntry))
   {
      if(EnableVerboseLogging)
         Print("BUY aborted: trend no longer bullish at execution time.");
      return false;
   }

   double ask = SymbolInfoDouble(BrokerSymbol,SYMBOL_ASK);
   double point = SymbolInfoDouble(BrokerSymbol,SYMBOL_POINT);

   if(ask <= 0 || point <= 0)
   {
      Print("Invalid market price.");
      return false;
   }

   double sl = 0.0;
   double tp = 0.0;
   double tp1Price = 0.0;
   double tp2Price = 0.0;
   double tp3Price = 0.0;

   double slDistance, tp1Distance, tp2Distance, tp3Distance;
   GetTradeDistances(slDistance, tp1Distance, tp2Distance, tp3Distance);

   sl = ask - slDistance;
   // APEX/LCS structural SL beyond sweep extreme (wider/safer wins)
   if(APEX_UseSweepSL && g_PendingStrategyTag == "APEX" && g_APEX_InvalidationPrice > 0.0)
   {
      double apexSL = g_APEX_InvalidationPrice;
      if(apexSL < ask)
      {
         if(apexSL < sl)
            sl = apexSL;
         Print("APEX BUY SL → sweep invalidation ", DoubleToString(sl, UltraSymDigits(BrokerSymbol)),
               " on ", BrokerSymbol);
      }
   }
   else if(LCS_UseSweepSL && g_PendingStrategyTag == "LCS" && g_LCS_InvalidationPrice > 0.0)
   {
      double lcsSL = g_LCS_InvalidationPrice;
      if(lcsSL < ask)
      {
         if(lcsSL < sl)
            sl = lcsSL;
         Print("LCS BUY SL → sweep invalidation ", DoubleToString(sl, UltraSymDigits(BrokerSymbol)),
               " on ", BrokerSymbol);
      }
   }
   tp1Price = ask + tp1Distance; // soft TP1 — EA locks SL here then runs to TP2
   tp2Price = ask + tp2Distance;
   tp3Price = ask + tp3Distance;
   // Far broker TP (TP3) so ladder is not cut short by a full close at TP2
   tp = InitialBrokerTP(true, ask, tp2Distance, tp3Distance, tp2Price, tp3Price);

   if(!CheckTradeStops(ask,sl,tp))
   {
      Print("Failed to validate BUY stops.");
      return false;
   }

   // FIX: if CheckTradeStops() above widened sl to meet the broker's
   // minimum stop distance (or the ATR floor), tp1Price/tp2Price/tp3Price
   // above were already computed from the ORIGINAL, pre-widening
   // slDistance - silently breaking the intended R:R ratio in exactly the
   // case where a broker's stop rules forced a wider stop than the ATR
   // math called for. Recomputed here proportionally from the actual
   // final sl distance, so TP1/TP2/TP3 always reflect the real risk being
   // taken, not the originally-planned one.
   double actualSLDistance = ask - sl;

   if(MathAbs(actualSLDistance - slDistance) > SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT))
   {
      tp1Price = ask + actualSLDistance * TP1_RR_Ratio;
      tp2Price = ask + actualSLDistance * TP2_RR_Ratio;
      tp3Price = ask + actualSLDistance * TP3_RR_Ratio;
      tp = InitialBrokerTP(true, ask, actualSLDistance * TP2_RR_Ratio,
                          actualSLDistance * TP3_RR_Ratio, tp2Price, tp3Price);
      CheckTradeStops(ask, sl, tp); // re-validate the adjusted tp against broker minimums too
   }

   double lot = CalculateLotSize(actualSLDistance);

   if(lot <= 0)
   {
      Print("Invalid lot size.");
      return false;
   }

   // FIX #9: check free margin BEFORE sending, instead of relying on the
   // broker to reject an under-margined order after the fact.
   if(!HasSufficientMargin(ORDER_TYPE_BUY, lot, ask))
      return false;

   LastAttemptTimeArr[symIdx] = TimeCurrent();

   g_Trade.SetExpertMagicNumber(MagicNumber);
   g_Trade.SetDeviationInPoints(GetEffectiveSlippagePoints());

   // FIX #8: no retry existed for transient execution errors like requotes
   // or the price moving between our snapshot above and the send. This
   // retries a few times, re-pulling the live price and recomputing
   // sl/tp/tp1/tp2/tp3 off it each time, instead of giving up on the very
   // first requote.
   const int MAX_SEND_RETRIES = 3;
   bool result = false;

   for(int attempt = 1; attempt <= MAX_SEND_RETRIES; attempt++)
   {
      // Quick re-validation immediately before sending (fix #5 from the
      // signal-detection review): a signal confirmed a moment ago can
      // stop being valid by the time we actually place the order,
      // especially across retries after a requote. Re-check the cheap,
      // fast-changing gates (spread widened, terminal disabled trading)
      // right here rather than trusting the state from earlier in the
      // function.
      ResetLastError();

      result = g_Trade.Buy(lot, BrokerSymbol, 0.0, sl, tp, TradeComment);

      if(result)
         break;

      uint retcode = g_Trade.ResultRetcode();

      if(IsTransientOrderRetcode(retcode))
      {
         if(EnableVerboseLogging)
            Print("BUY transient error (", retcode, ") attempt ", attempt, "/", MAX_SEND_RETRIES, " - refreshing price and retrying.");

         Sleep(200);

         ask = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);

         if(ask <= 0)
            break;

         sl = ask - slDistance;
         tp1Price = ask + tp1Distance;
         tp2Price = ask + tp2Distance;
         tp3Price = ask + tp3Distance;
         tp = InitialBrokerTP(true, ask, tp2Distance, tp3Distance, tp2Price, tp3Price);

         CheckTradeStops(ask, sl, tp);
         continue;
      }

      if(IsFatalOrderRetcode(retcode))
      {
         Print("BUY FAILED (fatal) | Retcode: ", retcode, " | ", DescribeOrderRetcode(retcode, g_Trade.ResultRetcodeDescription()));
         return false; // no point trying the no-stops fallback either - the order itself is unplaceable right now
      }

      break; // any other error - fall through to the no-stops fallback / failure logging below
   }

   if(result)
   {
      Print("BUY executed successfully.");
      ulong posTicket = ResolvePositionTicket(g_Trade.ResultOrder());
      LastTradeTimeArr[symIdx] = TimeCurrent();
      MarkContFallbackFillIfNeeded();
      RegisterTradeState(posTicket, tp1Price, tp2Price, tp3Price, true);
      RecordSignalSnapshot(posTicket, true);
      return true;
   }

   // Fallback: some brokers/symbols (commonly crypto CFDs) reject SL/TP
   // attached to a market order outright, even when the prices themselves
   // are valid. Retry with no stops, then attach them via PositionModify
   // once the position exists.
   if(g_Trade.ResultRetcode() == TRADE_RETCODE_INVALID_STOPS)
   {
      if(EnableVerboseLogging)
         Print("BUY retry: opening without stops, will attach SL/TP after fill.");

      ResetLastError();

      bool openedNoStops = g_Trade.Buy(lot, BrokerSymbol, 0.0, 0.0, 0.0, TradeComment);

      if(openedNoStops)
      {
         ulong newTicket = ResolvePositionTicket(g_Trade.ResultOrder());
         bool stopsAttached = false;

         if(newTicket == 0)
         {
            Print("HARDEN: BUY no-stops fill but ticket unresolved — abort attach");
            return false;
         }

         if(PositionSelectByTicket(newTicket))
         {
            if(g_Trade.PositionModify(newTicket, sl, tp))
            {
               stopsAttached = true;
            }
            else
            {
               // FIX: previously this just logged a failure and left the
               // position open with NO SL/TP at all - an unprotected
               // position is a worse outcome than no position. Retry once
               // more with the broker's minimum-distance stops
               // recalculated off the current price, and if that still
               // fails, close the position immediately rather than leave
               // risk unmanaged.
               Print("BUY opened without stops, first attach attempt failed: ",
                     g_Trade.ResultRetcodeDescription(), " - retrying with recalculated stops.");

               double curPrice = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);
               double retrySL = curPrice - slDistance;
               // SAFE42: far TP3 so sure ladder is not cut at TP2
               double retryTP1 = curPrice + slDistance * TP1_RR_Ratio;
               double retryTP2 = curPrice + slDistance * TP2_RR_Ratio;
               double retryTP3 = curPrice + slDistance * TP3_RR_Ratio;
               double retryTP = InitialBrokerTP(true, curPrice, slDistance * TP2_RR_Ratio,
                                               slDistance * TP3_RR_Ratio, retryTP2, retryTP3);
               CheckTradeStops(curPrice, retrySL, retryTP);

               if(g_Trade.PositionModify(newTicket, retrySL, retryTP))
               {
                  stopsAttached = true;
                  sl = retrySL; tp = retryTP;
                  tp1Price = retryTP1; tp2Price = retryTP2; tp3Price = retryTP3;
               }
            }
         }

         if(!stopsAttached)
         {
            Print("BUY: could not attach SL/TP after fallback - closing the unprotected position for safety (ticket ", newTicket, ").");
            UltraMission_ClosePosition(newTicket, "EXEC cleanup invalid stops", true);
            return false;
         }

         Print("BUY executed successfully (no-stops fallback).");
         LastTradeTimeArr[symIdx] = TimeCurrent();
         MarkContFallbackFillIfNeeded();
         RegisterTradeState(newTicket, tp1Price, tp2Price, tp3Price, true);
         RecordSignalSnapshot(newTicket, true);
         return true;
      }
   }

   Print(
      "BUY FAILED | Retcode: ",
      g_Trade.ResultRetcode(),
      " | ",
      g_Trade.ResultRetcodeDescription()
   );

   return false;
}
//================ EXECUTE SELL =====================================//

bool ExecuteSell()
{
   int symIdx = GetSymbolIndex(BrokerSymbol);

   if(symIdx < 0)
   {
      Print("ExecuteSell: symbol not in tracking list: ", BrokerSymbol);
      return false;
   }

   ConfigureFillingMode(BrokerSymbol);

   if(TimeCurrent() - LastAttemptTimeArr[symIdx] < AttemptCooldownSeconds)
   {
      if(EnableVerboseLogging || EnableSetupLogging)
         Print("SELL aborted: attempt cooldown (", AttemptCooldownSeconds, "s) on ", BrokerSymbol);
      return false;
   }

   if(!RiskManagementOK())
      return false;

   if(!TradeProtectionOK())
      return false;

   // See the matching comment in ExecuteBuy() - cheap re-check that the
   // basic trend direction hasn't already reversed between decision and
   // execution.
   if(!IsBearTrend() && !(UltraAggressiveFire || NeverBlockValidSniperEntry))
   {
      if(EnableVerboseLogging)
         Print("SELL aborted: trend no longer bearish at execution time.");
      return false;
   }

   double bid = SymbolInfoDouble(BrokerSymbol,SYMBOL_BID);
   double point = SymbolInfoDouble(BrokerSymbol,SYMBOL_POINT);

   if(bid <= 0 || point <= 0)
   {
      Print("Invalid market price.");
      return false;
   }

   double sl = 0.0;
   double tp = 0.0;
   double tp1Price = 0.0;
   double tp2Price = 0.0;
   double tp3Price = 0.0;

   double slDistance, tp1Distance, tp2Distance, tp3Distance;
   GetTradeDistances(slDistance, tp1Distance, tp2Distance, tp3Distance);

   sl = bid + slDistance;
   if(APEX_UseSweepSL && g_PendingStrategyTag == "APEX" && g_APEX_InvalidationPrice > 0.0)
   {
      double apexSL = g_APEX_InvalidationPrice;
      if(apexSL > bid)
      {
         if(apexSL > sl)
            sl = apexSL;
         Print("APEX SELL SL → sweep invalidation ", DoubleToString(sl, UltraSymDigits(BrokerSymbol)),
               " on ", BrokerSymbol);
      }
   }
   else if(LCS_UseSweepSL && g_PendingStrategyTag == "LCS" && g_LCS_InvalidationPrice > 0.0)
   {
      double lcsSL = g_LCS_InvalidationPrice;
      if(lcsSL > bid)
      {
         if(lcsSL > sl)
            sl = lcsSL;
         Print("LCS SELL SL → sweep invalidation ", DoubleToString(sl, UltraSymDigits(BrokerSymbol)),
               " on ", BrokerSymbol);
      }
   }
   tp1Price = bid - tp1Distance;
   tp2Price = bid - tp2Distance;
   tp3Price = bid - tp3Distance;
   tp = InitialBrokerTP(false, bid, tp2Distance, tp3Distance, tp2Price, tp3Price);

   if(!CheckTradeStops(bid,sl,tp))
   {
      Print("Failed to validate SELL stops.");
      return false;
   }

   // See the matching fix and comment in ExecuteBuy() above.
   double actualSLDistance = sl - bid;

   if(MathAbs(actualSLDistance - slDistance) > SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT))
   {
      tp1Price = bid - actualSLDistance * TP1_RR_Ratio;
      tp2Price = bid - actualSLDistance * TP2_RR_Ratio;
      tp3Price = bid - actualSLDistance * TP3_RR_Ratio;
      tp = InitialBrokerTP(false, bid, actualSLDistance * TP2_RR_Ratio,
                          actualSLDistance * TP3_RR_Ratio, tp2Price, tp3Price);
      CheckTradeStops(bid, sl, tp);
   }

   double lot = CalculateLotSize(actualSLDistance);

   if(lot <= 0)
   {
      Print("Invalid lot size.");
      return false;
   }

   if(!HasSufficientMargin(ORDER_TYPE_SELL, lot, bid))
      return false;

   LastAttemptTimeArr[symIdx] = TimeCurrent();

   g_Trade.SetExpertMagicNumber(MagicNumber);
   g_Trade.SetDeviationInPoints(GetEffectiveSlippagePoints());

   const int MAX_SEND_RETRIES = 3;
   bool result = false;

   for(int attempt = 1; attempt <= MAX_SEND_RETRIES; attempt++)
   {
      ResetLastError();

      result = g_Trade.Sell(lot, BrokerSymbol, 0.0, sl, tp, TradeComment);

      if(result)
         break;

      uint retcode = g_Trade.ResultRetcode();

      if(IsTransientOrderRetcode(retcode))
      {
         if(EnableVerboseLogging)
            Print("SELL transient error (", retcode, ") attempt ", attempt, "/", MAX_SEND_RETRIES, " - refreshing price and retrying.");

         Sleep(200);

         bid = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);

         if(bid <= 0)
            break;

         sl = bid + slDistance;
         tp1Price = bid - tp1Distance;
         tp2Price = bid - tp2Distance;
         tp3Price = bid - tp3Distance;
         tp = InitialBrokerTP(false, bid, tp2Distance, tp3Distance, tp2Price, tp3Price);

         CheckTradeStops(bid, sl, tp);
         continue;
      }

      if(IsFatalOrderRetcode(retcode))
      {
         Print("SELL FAILED (fatal) | Retcode: ", retcode, " | ", DescribeOrderRetcode(retcode, g_Trade.ResultRetcodeDescription()));
         return false;
      }

      break;
   }

   if(result)
   {
      Print("SELL executed successfully.");
      ulong posTicket = ResolvePositionTicket(g_Trade.ResultOrder());
      LastTradeTimeArr[symIdx] = TimeCurrent();
      MarkContFallbackFillIfNeeded();
      RegisterTradeState(posTicket, tp1Price, tp2Price, tp3Price, false);
      RecordSignalSnapshot(posTicket, false);
      return true;
   }

   // Same no-stops fallback as ExecuteBuy() - see comments there.
   if(g_Trade.ResultRetcode() == TRADE_RETCODE_INVALID_STOPS)
   {
      if(EnableVerboseLogging)
         Print("SELL retry: opening without stops, will attach SL/TP after fill.");

      ResetLastError();

      bool openedNoStops = g_Trade.Sell(lot, BrokerSymbol, 0.0, 0.0, 0.0, TradeComment);

      if(openedNoStops)
      {
         ulong newTicket = ResolvePositionTicket(g_Trade.ResultOrder());
         bool stopsAttached = false;

         if(newTicket == 0)
         {
            Print("HARDEN: SELL no-stops fill but ticket unresolved — abort attach");
            return false;
         }

         if(PositionSelectByTicket(newTicket))
         {
            if(g_Trade.PositionModify(newTicket, sl, tp))
            {
               stopsAttached = true;
            }
            else
            {
               Print("SELL opened without stops, first attach attempt failed: ",
                     g_Trade.ResultRetcodeDescription(), " - retrying with recalculated stops.");

               double curPrice = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);
               double retrySL = curPrice + slDistance;
               // SAFE42: far TP3 so sure ladder is not cut at TP2
               double retryTP1 = curPrice - slDistance * TP1_RR_Ratio;
               double retryTP2 = curPrice - slDistance * TP2_RR_Ratio;
               double retryTP3 = curPrice - slDistance * TP3_RR_Ratio;
               double retryTP = InitialBrokerTP(false, curPrice, slDistance * TP2_RR_Ratio,
                                               slDistance * TP3_RR_Ratio, retryTP2, retryTP3);
               CheckTradeStops(curPrice, retrySL, retryTP);

               if(g_Trade.PositionModify(newTicket, retrySL, retryTP))
               {
                  stopsAttached = true;
                  sl = retrySL; tp = retryTP;
                  tp1Price = retryTP1; tp2Price = retryTP2; tp3Price = retryTP3;
               }
            }
         }

         if(!stopsAttached)
         {
            Print("SELL: could not attach SL/TP after fallback - closing the unprotected position for safety (ticket ", newTicket, ").");
            UltraMission_ClosePosition(newTicket, "EXEC cleanup invalid stops", true);
            return false;
         }

         Print("SELL executed successfully (no-stops fallback).");
         LastTradeTimeArr[symIdx] = TimeCurrent();
         MarkContFallbackFillIfNeeded();
         RegisterTradeState(newTicket, tp1Price, tp2Price, tp3Price, false);
         RecordSignalSnapshot(newTicket, false);
         return true;
      }
   }

   Print(
      "SELL FAILED | Retcode: ",
      g_Trade.ResultRetcode(),
      " | ",
      g_Trade.ResultRetcodeDescription()
   );

   return false;
}
input int PostLossCooldownMinutes = 0; // aggressive sniper: do not block re-entry after a loss

bool CooldownFinished()
{
   int symIdx = GetSymbolIndex(BrokerSymbol);

   if(symIdx < 0)
   {
      // ALLTRADE56: do not hard-block unknown index — allow entry path
      Print("CooldownFinished: symbol not in tracking list yet: ", BrokerSymbol,
            " — allowing (fail-open)");
      return true;
   }

   if(LastTradeTimeArr[symIdx] == 0)
      return true;

   // ALLTRADE56 / NeverBlock: MaxOpenTrades is the real limit — no idle cooldown blocks
   if(NeverBlockValidSniperEntry || UltraAggressiveFire)
      return true;

   if(TradeCooldownMinutes <= 0 && (NonScalpCooldownMinutes <= 0 || !IsNonScalpSymbol()))
      return true;

   int cooldownMinutes = IsNonScalpSymbol() ? NonScalpCooldownMinutes : TradeCooldownMinutes;

   if(cooldownMinutes <= 0)
      return true;

   if(TimeCurrent() - LastTradeTimeArr[symIdx] < cooldownMinutes * 60)
      return false;

   if(PostLossCooldownMinutes > 0 &&
      LastTradeWasLossArr[symIdx] &&
      (TimeCurrent() - LastLossCloseTimeArr[symIdx] < PostLossCooldownMinutes * 60))
   {
      if(EnableVerboseLogging)
         Print("Post-loss cooldown active - waiting before next entry.");
      return false;
   }

   return true;
}
// NOTE: Parts 7 and 8 used to hold a second, unused signal path
// (RunAISignalEngine, calling the now-removed BuySignal/SellSignal) and
// an EA "control module" (StartHitmanAI/RunHitmanAI/StopHitmanAI)
// that just printed log messages and was never called from OnInit/OnTick/
// OnDeinit. Removed as dead code - InstantExecution() (called from OnTick)
// is the actual, and only, execution path.
//+------------------------------------------------------------------+
//|              PART 9 - TRADE PROTECTION SYSTEM                    |
//+------------------------------------------------------------------+

//================ PROTECTION SETTINGS ==============================//

input group "SPREAD"
// OK66: high spread NEVER blocks — CheckSpread is a no-op allow.

//================ CHECK SPREAD =====================================//

bool CheckSpread()
{
   return true; // never block on spread (news spikes included)
}


//================ COUNT OPEN TRADES ================================//

// FIX/UPGRADE: an EA that hardcodes 0.01 lots should never itself open
// anything larger - but a leftover position from before that fix (like the
// old 0.29-lot BTCUSD trade from earlier) can still be sitting open. This
// keeps those out of the trade count / dashboard so they don't clutter the
// view or eat into MaxOpenTrades, WITHOUT skipping them in
// ManageOpenTrades() - that still applies SL/TP/breakeven/trailing to every
// matching position regardless of size, since ignoring risk management on
// a real open position just because of its size would be the more
// dangerous choice.

input double IgnoreTradesAboveLots = 100.0; // only ignore absurd sizes; was 0.015 and bypassed MaxOpenTrades when LotSize raised

int CountOpenTrades()
{
   int total = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      // FIX: this used to read PositionGetString(POSITION_SYMBOL) /
      // PositionGetInteger(POSITION_MAGIC) / PositionGetDouble(POSITION_VOLUME)
      // directly, with no PositionGetTicket(i) beforehand to actually
      // select position #i into context first. Without that selection
      // step, each of those Get calls falls back to whatever position was
      // last selected elsewhere in the program (or nothing), so the loop
      // could silently recheck the same position over and over instead of
      // iterating through every open position - producing a wrong count.
      // PositionGetTicket(i) both returns the ticket AND selects that
      // position for the subsequent property reads, same pattern already
      // used correctly elsewhere in this file (RestoreTradeStates, etc).
      ulong ticket = PositionGetTicket(i);

      if(ticket == 0)
         continue;
      if(!PositionSelectByTicket(ticket))
         continue;

      if(PositionGetString(POSITION_SYMBOL) == BrokerSymbol &&
         PositionGetInteger(POSITION_MAGIC) == MagicNumber &&
         PositionGetDouble(POSITION_VOLUME) <= IgnoreTradesAboveLots)
      {
         total++;
      }
   }

   return total;
}


//================ TRADE PROTECTION CHECK ===========================//

// FIX: this used to re-check CountOpenTrades() >= MaxOpenTrades here, on
// top of the identical check MaxTradesProtection() (Part 5) already does
// inside RiskManagementOK() - both functions are called back-to-back on
// every trade attempt (see FinalTradeCheck), so the same PositionsTotal()
// loop was running twice for the same answer. Removed here; the check
// still happens exactly once, via RiskManagementOK() -> MaxTradesProtection().

bool TradeProtectionOK()
{
   // CheckSpread / NewsTradingAllowed are permanent allow (OK66) — only terminal gate remains
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
   {
      Print("Trading disabled by terminal");
      return false;
   }
   return true;
}
//+------------------------------------------------------------------+
//|              PART 10 - TRADE MANAGEMENT SYSTEM                   |
//+------------------------------------------------------------------+

//================ MANAGEMENT SETTINGS ==============================//

input bool EnableBreakEven = true;
input bool EnableTrailing  = true;   // OK38: ON — trail runner after TP ladder locks profit

// false = aggressive TP1/TP2/TP3 scale-out + SL profit lock + ATR trailing (OK38 default).
// true  = fixed SL/TP/breakeven only (old PRISM fixed mode).
input bool UseFixedTradeManagement = false;

input double BreakEvenPoints = 500;
input double TrailingPoints  = 300;

// FIX: BreakEvenPoints was a flat points distance, same forex-scale
// assumption already fixed for stops/TP - suitable for EURUSD, not
// necessarily for XAUUSD or BTCUSD. EnableATRBreakEven mirrors the
// existing EnableATRTrailing pattern: when on, the breakeven trigger
// distance scales off ATR instead of a fixed point count.
input bool   EnableATRBreakEven      = true;
input double ATR_BreakEvenMultiplier = 1.0;

double GetBreakEvenDistance(double point)
{
   if(EnableATRBreakEven)
   {
      double atr = GetFilterATR();

      if(atr > 0.0)
         return atr * ATR_BreakEvenMultiplier;
   }

   return BreakEvenPoints * point;
}

//----- Aggressive profit-lock SL after a TP level is hit ----------------//
// Locks the stop INTO profit so a reversal can't give back the whole move.
// fraction=0 → breakeven; fraction=1 → lock at the hit TP level (minus buffer).
double ComputeProfitLockSL(const bool isBuy,
                           const double openPrice,
                           const double tpLevelHit,
                           const double fraction,
                           const double currentSL)
{
   double frac = MathMax(0.0, MathMin(fraction, 1.5));
   double move = isBuy ? (tpLevelHit - openPrice) : (openPrice - tpLevelHit);
   if(move <= 0.0)
      return currentSL;

   double atr = GetFilterATR();
   double buffer = (atr > 0.0) ? (atr * LockProfitBufferATR) : 0.0;

   double locked = isBuy
      ? (openPrice + move * frac - buffer)
      : (openPrice - move * frac + buffer);

   // Never lock on the wrong side of entry when SecureProfit is on with frac>0
   if(isBuy && locked < openPrice)
      locked = openPrice;
   if(!isBuy && locked > openPrice)
      locked = openPrice;

   locked = NormalizeTradePrice(locked);

   // Never loosen an existing stop
   if(isBuy)
   {
      if(currentSL > 0.0 && locked <= currentSL)
         return currentSL;
      return locked;
   }

   if(currentSL > 0.0 && locked >= currentSL)
      return currentSL;
   return locked;
}

bool ApplyProfitLockSL(const ulong ticket,
                       const bool isBuy,
                       const double openPrice,
                       const double tpLevelHit,
                       const double fraction,
                       const double nextTP,
                       const bool applyTP)
{
   if(!PositionSelectByTicket(ticket))
      return false;

   double curSL = PositionGetDouble(POSITION_SL);
   double curTP = PositionGetDouble(POSITION_TP);
   double newSL = curSL;

   if(SecureProfitOnTPHit)
      newSL = ComputeProfitLockSL(isBuy, openPrice, tpLevelHit, fraction, curSL);
   else if(MoveSLToBreakEvenAtTP1)
      newSL = isBuy
         ? ((curSL < openPrice) ? openPrice : curSL)
         : ((curSL > openPrice || curSL == 0.0) ? openPrice : curSL);

   // BUGFIX40: applyTP=true allows nextTP=0 to CLEAR broker TP for trailing.
   // Old code only set TP when nextTP>0, so trail runners kept TP3 and got cut.
   double newTP = curTP;
   if(applyTP)
      newTP = nextTP;
   else if(ExtendTPAfterLock && nextTP > 0.0)
      newTP = nextTP;

   if(MathAbs(newSL - curSL) < SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT) &&
      MathAbs(newTP - curTP) < SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT))
      return true;

   bool ok = g_Trade.PositionModify(ticket, newSL, newTP);
   if(ok)
      Print("PROFIT LOCK: ticket ", ticket,
            " SL→", DoubleToString(newSL, UltraSymDigits(BrokerSymbol)),
            " TP→", DoubleToString(newTP, UltraSymDigits(BrokerSymbol)),
            " (secured after TP hit)");
   else
      Print("PROFIT LOCK failed on ticket ", ticket, ": ", g_Trade.ResultRetcodeDescription());
   return ok;
}

input group "LONG-TERM HOLDING - ADAPTIVE / SAFETY"

// FIX/UPGRADE - the original long-term-holding logic only ever counted
// bars: EnableLongTermHolding + MinimumHoldBars decided when trend-exit/
// trailing were even ALLOWED to touch a position, but there was: (a) no
// cap on how long a trade could be held if nothing else ever triggered,
// (b) no adaptation to whether the market is actually trending or
// ranging right now, and (c) no way to recognize "this trade has gone
// nowhere for a very long time" and do something about it. The three
// settings below address each of those, independently of each other.

input bool   EnableMaxHoldBars      = true;
input int    MaxHoldBars            = 800;   // hard cap (EntryTF bars) - closes the position outright if still open this long, regardless of any other condition
input bool   EnableAdaptiveHoldTime = true;   // shortens the minimum hold requirement while the market is in a RANGING regime (Part 15) - a trade sitting through chop doesn't need the same patience as one riding a genuine trend
input double RangingHoldTimeFactor  = 0.5;    // effectiveMinHoldBars is multiplied by this while GetMarketRegime() == REGIME_RANGING

input bool   EnableStagnationExit      = false; // OFF — was closing trades that were still developing
input int    StagnationLookbackBars    = 250; // only checked once a trade has been open at least this many EntryTF bars
input double StagnationProgressATRMultiple = 0.35; // if re-enabled: require less progress before judging stagnant

// Forward — implemented with Market Defense Engine (after IMCE/trap helpers)
bool MarketDefendOpenPosition(const ulong ticket, const long type, const double openPrice,
                              const double price, double &currentSL, double &currentTP,
                              const int stateIndex);

//================ MANAGE OPEN TRADES ===============================//

void ManageOpenTrades()
{
   PruneTradeStates();

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {

      ulong ticket = PositionGetTicket(i);

      if(ticket == 0)
         continue;


      if(!PositionSelectByTicket(ticket))
         continue;


      string symbol =
      PositionGetString(
         POSITION_SYMBOL
      );


      if(symbol != BrokerSymbol)
         continue;


      // FIX: this loop was only ever filtering by symbol - never by magic
      // number. CountOpenTrades() and the TP1/TP2 state tracking both
      // correctly check MagicNumber, but this actual management loop (the
      // one that moves stops, takes partial profit, and CLOSES positions)
      // never did. That means it was managing and potentially closing ANY
      // position on this symbol - a manual trade you opened yourself, a
      // different EA's position, or a leftover position from earlier
      // testing with a different magic number - not just this EA's own
      // trades. This is very likely the cause of "closes other trades."

      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;


      long type =
      PositionGetInteger(
         POSITION_TYPE
      );


      double openPrice =
      PositionGetDouble(
         POSITION_PRICE_OPEN
      );


      double currentSL =
      PositionGetDouble(
         POSITION_SL
      );


      double currentTP =
      PositionGetDouble(
         POSITION_TP
      );


      double point =
      SymbolInfoDouble(
         BrokerSymbol,
         SYMBOL_POINT
      );


      double price;


      if(type == POSITION_TYPE_BUY)
      {
         price =
         SymbolInfoDouble(
            BrokerSymbol,
            SYMBOL_BID
         );
      }
      else
      {
         price =
         SymbolInfoDouble(
            BrokerSymbol,
            SYMBOL_ASK
         );
      }

      // HARDEN: skip corrupt price/point/bar data — do not manage blindly
      if(point <= 0.0 || !MathIsValidNumber(point))
         continue;
      if(price <= 0.0 || !MathIsValidNumber(price))
         continue;


      // How many bars has this position been open? Used to gate trailing/
      // trend-exit management so a fresh trade isn't immediately stopped
      // out or closed by noise (EnableLongTermHolding/MinimumHoldBars).
      //
      // Uses EntryTF (the EA's actual trading timeframe), not PERIOD_CURRENT.
      // PERIOD_CURRENT is whatever timeframe the chart the EA is attached to
      // happens to be showing - if the EA sits on an H4 chart but trades off
      // M15 (the default EntryTF), MinimumHoldBars=20 would mean 80 hours
      // instead of the intended ~5 hours, holding trades far longer than
      // configured before any protective management can act.
      //
      // Symbols matching NonScalpSymbolKeywords use NonScalpMinimumHoldBars
      // instead - same idea as the cooldown/SL widening: BTCUSD gets held
      // long enough to actually be a swing-style trade rather than being
      // eligible for trend-exit/trailing management after the same short
      // window used for forex pairs.
      int effectiveMinHoldBars = IsNonScalpSymbol() ? NonScalpMinimumHoldBars : MinimumHoldBars;

      // OK64: ContFallback / APEX / LCS are swing tags — force longer hold
      int stHold = FindTradeState(ticket);
      string holdTag = (stHold >= 0) ? TradeStates[stHold].strategyTag : "";
      bool swingTag = (holdTag == "ContFallback" || holdTag == "APEX" || holdTag == "LCS");
      if(EnableAntiScalpMode && swingTag)
         effectiveMinHoldBars = (int)MathMax(effectiveMinHoldBars, ContFallbackMinimumHoldBars);

      // UPGRADE: adapt the minimum hold requirement to the current market
      // regime - a ranging market doesn't reward the same patience a
      // genuine trend does, so require less time before management can
      // step in while ranging.
      bool allowAdaptiveHold = EnableAdaptiveHoldTime && EnableRegimeDetection && GetMarketRegime() == REGIME_RANGING;
      if(allowAdaptiveHold && ContFallbackDisableAdaptiveHold && swingTag)
         allowAdaptiveHold = false;
      if(allowAdaptiveHold)
         effectiveMinHoldBars = (int)MathMax(1.0, effectiveMinHoldBars * RangingHoldTimeFactor);

      datetime openTime = (datetime)PositionGetInteger(POSITION_TIME);
      int barsHeld = iBarShift(BrokerSymbol, EntryTF, openTime);
      if(barsHeld < 0)
         barsHeld = 0;
      bool holdPeriodOK = (!EnableLongTermHolding) || (barsHeld >= effectiveMinHoldBars);


      //================ MAX HOLD TIME (hard cap) =================//
      // UPGRADE: previously nothing forced a trade closed if it just sat
      // there indefinitely with none of trend-exit/trailing/TP ever
      // triggering. This is a simple backstop - regardless of every other
      // condition, a position this old gets closed.

      if(EnableMaxHoldBars && barsHeld >= MaxHoldBars)
      {
         Print("Max hold time reached (", barsHeld, " bars) - Mission close ticket ", ticket);
         UltraMission_ClosePosition(ticket, "RISK max hold bars", true);
         continue;
      }

      //================ MARKET DEFENSE =================//
      // Protect open trades against flips, chop, traps, and peak retrace.
      int defendState = FindTradeState(ticket);
      if(EnableMarketDefense)
      {
         if(MarketDefendOpenPosition(ticket, type, openPrice, price, currentSL, currentTP, defendState))
            continue; // position closed by defense
         // refresh after possible SL modify
         if(!PositionSelectByTicket(ticket))
            continue;
         currentSL = PositionGetDouble(POSITION_SL);
         currentTP = PositionGetDouble(POSITION_TP);
      }

      //================ DEFENSE LINE 8 — POSITION =================//
      if(UltraDefenseEnabled && UltraDefensePosition)
      {
         if(UltraDefense_Line8_Position(ticket, type, openPrice, price, currentSL, currentTP, defendState))
            continue;
         if(!PositionSelectByTicket(ticket))
            continue;
         currentSL = PositionGetDouble(POSITION_SL);
         currentTP = PositionGetDouble(POSITION_TP);
      }

      //================ ULTRA X — LEVEL 8 MISSION CONTROL (HOLD/MANAGE/EXIT) ===//
      if(UltraUpgradeEnabled && UltraSmartExitEnabled)
      {
         bool isBuyPos = (type == POSITION_TYPE_BUY);
         string sxWhy = "";
         UltraSnap sxSnap = g_UltraLastSnap;
         bool sxCached = false;
         bool snapOK = false;
         if(UltraFastSignalEnabled)
            snapOK = UltraUFSE_BuildSnapshot(BrokerSymbol, sxSnap, sxCached);
         else
            snapOK = UltraBuildSnapshot(BrokerSymbol, sxSnap);
         if(!snapOK)
            sxSnap = g_UltraLastSnap;

         ENUM_SUPREME_DECISION mission = UltraMission_PositionCommand(ticket, BrokerSymbol, isBuyPos, sxSnap, sxWhy);
         ENUM_SMART_EXIT sx = UltraMission_ToSmartExit(mission);

         // Minimum hold before Mission EXIT can fire (protect fresh entries)
         int minMissionExitBars = MinimumHoldBars;
         if(minMissionExitBars < 3) minMissionExitBars = 3;
         bool canMissionExit = (barsHeld >= minMissionExitBars);

         if((mission == SUP_EXIT || sx == SX_CLOSE) && canMissionExit)
         {
            if(UltraUpgradeLog)
               Print("MISSION EXIT request ticket=", ticket, " bars=", barsHeld, " ", sxWhy);
            if(UltraMission_ClosePosition(ticket, sxWhy, false))
               continue;
         }
         if((mission == SUP_EXIT || sx == SX_CLOSE) && !canMissionExit)
         {
            // Too early to exit — protect with BE if possible instead
            if(UltraUpgradeLog)
               Print("MISSION EXIT blocked (min hold) ticket=", ticket, " bars=", barsHeld);
            mission = SUP_MANAGE;
            sx = SX_BE;
         }
         if(mission == SUP_MANAGE || sx == SX_BE || sx == SX_TIGHTEN)
         {
            bool needsBE = isBuyPos ? (currentSL < openPrice) : (currentSL > openPrice || currentSL <= 0.0);
            bool atProfit = isBuyPos ? (price >= openPrice) : (price <= openPrice);
            if(needsBE && atProfit)
            {
               if(g_Trade.PositionModify(ticket, openPrice, currentTP))
               {
                  currentSL = openPrice;
                  if(UltraUpgradeLog)
                     Print("MISSION MANAGE/BE ticket=", ticket, " ", sxWhy);
               }
            }
         }
         // SUP_HOLD → no exit, thesis still valid
         if(!PositionSelectByTicket(ticket))
            continue;
         currentSL = PositionGetDouble(POSITION_SL);
         currentTP = PositionGetDouble(POSITION_TP);
      }


      //================ BREAK EVEN =================//
      // (Break-even stays active in BOTH fixed and dynamic management
      // modes - "Fixed Break-Even" is explicitly kept per your P.R.I.S.M.
      // spec even with trailing/partial-close disabled.)

      if(EnableBreakEven)
      {
         double breakEvenDistance = GetBreakEvenDistance(point);

         if(type == POSITION_TYPE_BUY)
         {

            if(price - openPrice >= breakEvenDistance)
            {

               if(currentSL < openPrice)
               {
                  if(g_Trade.PositionModify(ticket, openPrice, currentTP))
                     currentSL = openPrice;
               }

            }

         }



         if(type == POSITION_TYPE_SELL)
         {

            if(openPrice - price >= breakEvenDistance)
            {

               if(currentSL > openPrice || currentSL == 0)
               {
                  if(g_Trade.PositionModify(ticket, openPrice, currentTP))
                     currentSL = openPrice;
               }

            }

         }

      }



      //================ TP1 SCALE-OUT + PROFIT LOCK → TP2 ================//
      // BUGFIX40: no false pre-entry TP touch; failed partial does not advance;
      // EnableTP3Runner honored for post-TP1 broker TP; skip trail same tick.

      bool ladderActedThisTick = false;

      if(ProfitLadderActive())
      {
      int stateIndex = FindTradeState(ticket);

      if(stateIndex >= 0 && !TradeStates[stateIndex].tp1Taken)
      {
         bool tp1Hit = LevelTouchedForTP((type == POSITION_TYPE_BUY),
                                         TradeStates[stateIndex].tp1Price, price, barsHeld);

         if(tp1Hit)
         {
            double currentVolume = PositionGetDouble(POSITION_VOLUME);

            double volumeStep = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_STEP);
            double minVolume  = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_MIN);

            double closeVolume = currentVolume * (TP1_ClosePercent / 100.0);

            if(volumeStep > 0)
               closeVolume = MathFloor(closeVolume / volumeStep) * volumeStep;

            double remainder = currentVolume - closeVolume;
            bool advanceLadder = false;
            bool didPartial = false;

            if(closeVolume >= minVolume && remainder >= minVolume)
            {
               if(UltraMission_ClosePartial(ticket, closeVolume, "TP1 partial"))
               {
                  Print("TP1 hit: closed ", DoubleToString(closeVolume,2),
                        " lots of ticket ", ticket, " — locking profit, remainder → TP2");
                  advanceLadder = true;
                  didPartial = true;
               }
               else
               {
                  Print("TP1 partial close failed on ticket ", ticket, ": ",
                        g_Trade.ResultRetcodeDescription(), " — will retry next tick");
               }
            }
            else if(remainder < minVolume && currentVolume >= minVolume && closeVolume >= minVolume)
            {
               if(UltraMission_ClosePosition(ticket, "TP ladder full close", true))
               {
                  Print("TP1 hit but position too small to split - closed in full: ", ticket);
                  TradeStates[stateIndex].tp1Taken = true;
                  DeleteTradeStateGlobals(ticket);
                  continue;
               }
            }
            else
            {
               // Min lot: cannot partial — still lock SL and advance (intentional)
               Print("TP1 hit at min lot — locking SL into profit, advancing to TP2: ", ticket);
               advanceLadder = true;
            }

            if(advanceLadder)
            {
               // SAFE42: lock must succeed; if partial already done, still set flag
               // so we never partial twice — lock retries via needsLock path below.
               double nextTP = TradeStates[stateIndex].tp2Price;
               if(EnableTP3Runner && TradeStates[stateIndex].tp3Price > 0.0)
                  nextTP = TradeStates[stateIndex].tp3Price;

               bool locked = ApplyProfitLockSL(ticket,
                                 (type == POSITION_TYPE_BUY),
                                 openPrice,
                                 TradeStates[stateIndex].tp1Price,
                                 LockProfitAtTP1_Fraction,
                                 nextTP,
                                 true);
               if(locked || didPartial)
               {
                  TradeStates[stateIndex].tp1Taken = true;
                  PersistTradeState(stateIndex);
                  ladderActedThisTick = true;
                  if(locked)
                     Print("SURE LADDER: TP1 secured → now hunting TP2 on ticket ", ticket);
                  else
                     Print("SAFE: TP1 partial done, lock pending retry on ticket ", ticket);
               }
               else
               {
                  Print("SAFE: TP1 lock FAILED on ticket ", ticket,
                        " — will retry next tick (flag not set)");
               }
            }
         }
      }

      // SAFE42: if TP1 was marked earlier but SL never locked, retry lock every tick
      if(stateIndex >= 0 && TradeStates[stateIndex].tp1Taken && SecureProfitOnTPHit)
      {
         if(PositionSelectByTicket(ticket))
         {
            double liveSL = PositionGetDouble(POSITION_SL);
            double wantSL = ComputeProfitLockSL((type == POSITION_TYPE_BUY), openPrice,
                                                TradeStates[stateIndex].tp1Price,
                                                LockProfitAtTP1_Fraction, liveSL);
            bool needsLock = (type == POSITION_TYPE_BUY)
               ? (liveSL < wantSL - SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT))
               : (liveSL == 0.0 || liveSL > wantSL + SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT));
            if(needsLock && !TradeStates[stateIndex].tp2Taken)
            {
               double nextTP = TradeStates[stateIndex].tp2Price;
               if(EnableTP3Runner && TradeStates[stateIndex].tp3Price > 0.0)
                  nextTP = TradeStates[stateIndex].tp3Price;
               if(ApplyProfitLockSL(ticket, (type == POSITION_TYPE_BUY), openPrice,
                                    TradeStates[stateIndex].tp1Price,
                                    LockProfitAtTP1_Fraction, nextTP, true))
               {
                  ladderActedThisTick = true;
                  Print("SAFE: retried TP1 profit lock OK on ticket ", ticket);
               }
            }
         }
      }



      //================ TP2 SCALE-OUT + PROFIT LOCK → TP3 / TRAIL =========//
      if(stateIndex >= 0 && TradeStates[stateIndex].tp1Taken && !TradeStates[stateIndex].tp2Taken
         && TradeStates[stateIndex].tp2Price > 0.0)
      {
         // When EnableTP3Runner=false, TP2 is the final target: lock + leave TP at TP2
         bool tp2Hit = LevelTouchedForTP((type == POSITION_TYPE_BUY),
                                         TradeStates[stateIndex].tp2Price, price, barsHeld);

         if(tp2Hit)
         {
            double currentVolume2 = PositionGetDouble(POSITION_VOLUME);

            double volumeStep2 = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_STEP);
            double minVolume2  = SymbolInfoDouble(BrokerSymbol, SYMBOL_VOLUME_MIN);

            double closeVolume2 = currentVolume2 * (TP2_ClosePercent / 100.0);

            if(volumeStep2 > 0)
               closeVolume2 = MathFloor(closeVolume2 / volumeStep2) * volumeStep2;

            double remainder2 = currentVolume2 - closeVolume2;
            bool advanceTP2 = false;
            bool didPartial2 = false;

            if(closeVolume2 >= minVolume2 && remainder2 >= minVolume2)
            {
               if(UltraMission_ClosePartial(ticket, closeVolume2, "TP2 partial"))
               {
                  Print("TP2 hit: closed ", DoubleToString(closeVolume2,2),
                        " lots of ticket ", ticket, " — locking more profit, runner → TP3/trail");
                  advanceTP2 = true;
                  didPartial2 = true;
               }
               else
               {
                  Print("TP2 partial close failed on ticket ", ticket, ": ",
                        g_Trade.ResultRetcodeDescription(), " — will retry next tick");
               }
            }
            else if(remainder2 < minVolume2 && currentVolume2 >= minVolume2 && closeVolume2 >= minVolume2)
            {
               // BUGFIX40: mirror TP1 — can't leave dust remainder
               if(UltraMission_ClosePosition(ticket, "TP ladder full close", true))
               {
                  Print("TP2 hit but position too small to split - closed in full: ", ticket);
                  TradeStates[stateIndex].tp2Taken = true;
                  DeleteTradeStateGlobals(ticket);
                  continue;
               }
            }
            else
            {
               Print("TP2 hit at min lot — lock SL further, activate runner: ", ticket);
               advanceTP2 = true;
            }

            if(advanceTP2)
            {
               bool lockOK = false;
               if(PositionSelectByTicket(ticket))
               {
                  if(!EnableTP3Runner)
                  {
                     lockOK = ApplyProfitLockSL(ticket,
                                       (type == POSITION_TYPE_BUY),
                                       openPrice,
                                       TradeStates[stateIndex].tp2Price,
                                       LockProfitAtTP2_Fraction,
                                       TradeStates[stateIndex].tp2Price,
                                       true);
                     if(lockOK)
                        Print("SURE LADDER: TP2 secured as final target on ticket ", ticket);
                  }
                  else if(EnableTrailing)
                  {
                     lockOK = ApplyProfitLockSL(ticket,
                                       (type == POSITION_TYPE_BUY),
                                       openPrice,
                                       TradeStates[stateIndex].tp2Price,
                                       LockProfitAtTP2_Fraction,
                                       0.0,
                                       true);
                     if(PositionSelectByTicket(ticket))
                     {
                        double curSL2 = PositionGetDouble(POSITION_SL);
                        double tp1Lock = TradeStates[stateIndex].tp1Price;
                        bool needRaise = (type == POSITION_TYPE_BUY)
                           ? (curSL2 < tp1Lock)
                           : (curSL2 == 0.0 || curSL2 > tp1Lock);
                        if(needRaise)
                        {
                           if(g_Trade.PositionModify(ticket, tp1Lock, 0.0))
                              lockOK = true;
                        }
                        else
                        {
                           double curTP2 = PositionGetDouble(POSITION_TP);
                           if(curTP2 > 0.0)
                              g_Trade.PositionModify(ticket, curSL2, 0.0);
                           lockOK = true; // SL already at/above TP1
                        }
                     }
                     if(lockOK)
                        Print("SURE LADDER: TP2 secured → trailing runner on ticket ", ticket);
                  }
                  else
                  {
                     double nextTP = TradeStates[stateIndex].tp3Price;
                     lockOK = ApplyProfitLockSL(ticket,
                                       (type == POSITION_TYPE_BUY),
                                       openPrice,
                                       TradeStates[stateIndex].tp2Price,
                                       LockProfitAtTP2_Fraction,
                                       nextTP,
                                       true);
                     if(PositionSelectByTicket(ticket))
                     {
                        double curSL2 = PositionGetDouble(POSITION_SL);
                        double tp1Lock = TradeStates[stateIndex].tp1Price;
                        double curTP2 = PositionGetDouble(POSITION_TP);
                        bool needRaise = (type == POSITION_TYPE_BUY)
                           ? (curSL2 < tp1Lock)
                           : (curSL2 == 0.0 || curSL2 > tp1Lock);
                        if(needRaise)
                           g_Trade.PositionModify(ticket, tp1Lock, curTP2);
                     }
                     if(lockOK)
                        Print("SURE LADDER: TP2 secured → hunting TP3 on ticket ", ticket);
                  }
               }

               // SAFE42: mark taken if lock OK OR partial already done (avoid double partial)
               if(lockOK || didPartial2)
               {
                  TradeStates[stateIndex].tp2Taken = true;
                  PersistTradeState(stateIndex);
                  ladderActedThisTick = true;
                  if(!lockOK)
                     Print("SAFE: TP2 partial done, lock pending — ticket ", ticket);
               }
               else
               {
                  Print("SAFE: TP2 lock FAILED on ticket ", ticket,
                        " — will retry next tick (flag not set)");
               }
            }
         }
      }

      // AUDITFIX49: TP2 lock retry (mirror TP1 SAFE42) when partial done but SL not locked
      if(stateIndex >= 0 && TradeStates[stateIndex].tp2Taken && SecureProfitOnTPHit)
      {
         if(PositionSelectByTicket(ticket))
         {
            double liveSL2 = PositionGetDouble(POSITION_SL);
            double wantSL2 = ComputeProfitLockSL((type == POSITION_TYPE_BUY), openPrice,
                                                 TradeStates[stateIndex].tp2Price,
                                                 LockProfitAtTP2_Fraction, liveSL2);
            bool needsLock2 = (type == POSITION_TYPE_BUY)
               ? (liveSL2 < wantSL2 - SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT))
               : (liveSL2 == 0.0 || liveSL2 > wantSL2 + SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT));
            if(needsLock2)
            {
               double nextTP2 = 0.0;
               bool applyTP = true;
               if(!EnableTP3Runner)
                  nextTP2 = TradeStates[stateIndex].tp2Price;
               else if(EnableTrailing)
                  nextTP2 = 0.0;
               else
                  nextTP2 = TradeStates[stateIndex].tp3Price;

               if(ApplyProfitLockSL(ticket, (type == POSITION_TYPE_BUY), openPrice,
                                    TradeStates[stateIndex].tp2Price,
                                    LockProfitAtTP2_Fraction, nextTP2, applyTP))
               {
                  ladderActedThisTick = true;
                  Print("SAFE: retried TP2 profit lock OK on ticket ", ticket);
               }
            }
         }
      }
      } // end sure profit ladder (TP1 → lock → TP2 → lock → TP3/trail)



      //================ STAGNATION EXIT (UPGRADE) =================//
      // BUGFIX40: skip once TP1 profit is locked — current P/L distance is NOT
      // MFE and was killing pullback runners after a successful TP1 bank.

      int stagState = FindTradeState(ticket);
      bool profitAlreadyLocked = (stagState >= 0 && TradeStates[stagState].tp1Taken);

      if(EnableStagnationExit && barsHeld >= StagnationLookbackBars && !profitAlreadyLocked)
      {
         double atrNow = GetFilterATR();

         if(atrNow > 0.0)
         {
            double favorableMove = (type == POSITION_TYPE_BUY) ? (price - openPrice) : (openPrice - price);

            if(favorableMove < atrNow * StagnationProgressATRMultiple)
            {
               Print("Stagnation exit: ticket ", ticket, " has made no real progress after ",
                     barsHeld, " bars - Mission close.");
               UltraMission_ClosePosition(ticket, "RISK stagnation exit", true);
               continue;
            }
         }
      }



      //================ TREND EXIT (ADX) =================//
      // Closes the position if the trend has lost strength, once the
      // minimum hold period has passed. Skipped for non-scalp symbols
      // (BTC/ETH by default) unless NonScalpDisableTrendExit is turned off.

      bool trendExitAllowed = EnableTrendExit && !(IsNonScalpSymbol() && NonScalpDisableTrendExit);

      if(trendExitAllowed && holdPeriodOK)
      {
         if(GetADX() < TrendExitADXLevel)
         {
            Print("Trend exit: ADX below ", TrendExitADXLevel, ", Mission close ticket ", ticket);
            UltraMission_ClosePosition(ticket, "RISK trend exit ADX", true);
            continue;
         }
      }



      //================ TRAILING STOP =================//
      // BUGFIX40: skip same tick as ladder lock (stale currentSL was loosening
      // the just-secured profit SL). Re-read live SL before comparing.

      // Trail always after TP1 profit-lock (aggressive); otherwise wait for hold period
      int trailStateGate = FindTradeState(ticket);
      bool trailAfterLock = (ProfitLadderActive() && trailStateGate >= 0 &&
                             TradeStates[trailStateGate].tp1Taken);
      if(!ladderActedThisTick &&
         (!UseFixedTradeManagement || ForceSureProfitLadder) &&
         EnableTrailing && (holdPeriodOK || trailAfterLock))
      {
         // Refresh SL/TP after possible ladder modifies earlier in this loop
         if(!PositionSelectByTicket(ticket))
            continue;
         currentSL = PositionGetDouble(POSITION_SL);
         currentTP = PositionGetDouble(POSITION_TP);

         double newSL;

         double trailingDistance = TrailingPoints * point;

         if(EnableATRTrailing)
         {
            double atr = GetFilterATR();

            if(atr > 0.0)
            {
               bool afterTP1 = trailAfterLock;
               double trailMult = (ProfitLadderActive() && afterTP1)
                  ? AggressiveTrailATRMult
                  : ATR_TrailingMultiplier;
               trailingDistance = atr * trailMult;
            }
         }



         if(type == POSITION_TYPE_BUY)
         {

            newSL =
            price - trailingDistance;


            long stopLevel = UltraSymStopsLevel(BrokerSymbol);


double minimumDistance =
stopLevel * point;


if((price - newSL) >= minimumDistance)
{
   newSL = NormalizeTradePrice(newSL);


   if(newSL > currentSL)
   {
      if(g_Trade.PositionModify(ticket, newSL, currentTP))
         currentSL = newSL;
   }
}

         }



         if(type == POSITION_TYPE_SELL)
         {

            newSL =
            price + trailingDistance;


            long stopLevel = UltraSymStopsLevel(BrokerSymbol);


double minimumDistance =
stopLevel * point;


if((newSL - price) >= minimumDistance)
{
   newSL = NormalizeTradePrice(newSL);


   if(newSL < currentSL || currentSL == 0)
   {
      if(g_Trade.PositionModify(ticket, newSL, currentTP))
         currentSL = newSL;
   }
}
         }

      }

   }

}
//+------------------------------------------------------------------+
//|              PART 11 - ADVANCED MARKET FILTERS                   |
//+------------------------------------------------------------------+

//================ FILTER SETTINGS ==================================//

input bool EnableVolatilityFilter = false;

input int ATR_Filter_Period = 14;

input double MinimumATRPoints = 20;


//================ INITIALIZE FILTER =================================//

bool InitializeMarketFilters()
{
   // Per-symbol, same pattern as InitializeIndicators() - loops over
   // MultiSymbolList instead of creating a single handle for BrokerSymbol.

   for(int i = 0; i < ArraySize(MultiSymbolList); i++)
   {
      FilterATRHandles[i] = iATR(MultiSymbolList[i], EntryTF, ATR_Filter_Period);

      if(FilterATRHandles[i] == INVALID_HANDLE)
      {
         Print("Market Filter ATR failed for ", MultiSymbolList[i]);
         return false;
      }
   }

   return true;

}


//================ GET ATR ===========================================//

double GetFilterATR()
{
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0 || FilterATRHandles[idx] == INVALID_HANDLE)
      return 0;

   double atr[];

   ArraySetAsSeries(
      atr,
      true
   );


   if(CopyBuffer(
      FilterATRHandles[idx],
      0,
      0,
      1,
      atr
   ) <= 0)
   {
      return 0;
   }

   // HARDEN: refuse EMPTY_VALUE / NaN as a usable ATR
   if(!MathIsValidNumber(atr[0]) || atr[0] == EMPTY_VALUE || atr[0] <= 0.0)
      return 0;

   return atr[0];

}


//================ MARKET CONDITION CHECK ============================//

bool MarketConditionOK()
{

   // Volatility filter disabled
   if(!EnableVolatilityFilter)
   {
      return true;
   }


   double atr =
   GetFilterATR();


   double point =
   SymbolInfoDouble(
      BrokerSymbol,
      SYMBOL_POINT
   );


   if(point <= 0)
      return true;


   double atrPoints =
   atr / point;


   if(atrPoints < MinimumATRPoints)
   {
      if(EnableVerboseLogging)
         Print("Market blocked: Low volatility");
      return false;
   }


   return true;

}

//================ VOLATILITY EXPANSION FILTER ========================//
// FIX/UPGRADE: EnableVolatilityFilter above only checks "is ATR above a
// fixed number" - a static threshold that means something different on
// every symbol and never adapts to changing conditions. This is a
// genuinely different signal: is volatility EXPANDING right now, relative
// to its own recent history? Compares current ATR to the average ATR over
// the last VolatilityExpansionLookback bars - a ratio meaningfully above 1
// means volatility is actively picking up (the kind of environment SMC
// setups tend to work better in), not just "high" by some arbitrary
// fixed number.

input group "VOLATILITY EXPANSION FILTER"

input bool   EnableVolatilityExpansionFilter = false;
input int    VolatilityExpansionLookback     = 20;
input double VolatilityExpansionMultiplier   = 1.2;

bool IsVolatilityExpanding()
{
   if(!EnableVolatilityExpansionFilter)
      return false; // filter off - contributes nothing to score, doesn't block anything

   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0 || FilterATRHandles[idx] == INVALID_HANDLE)
      return false;

   double atrHistory[];
   ArraySetAsSeries(atrHistory, true);

   int needed = VolatilityExpansionLookback + 1;

   if(CopyBuffer(FilterATRHandles[idx], 0, 0, needed, atrHistory) < needed)
      return false; // not enough history yet - fail safe, don't award the score bonus

   double currentATR = atrHistory[0];

   double sum = 0.0;

   for(int i = 1; i <= VolatilityExpansionLookback; i++)
      sum += atrHistory[i];

   double avgATR = sum / VolatilityExpansionLookback;

   if(avgATR <= 0.0)
      return false;

   return (currentATR >= avgATR * VolatilityExpansionMultiplier);
}

// NEW (this pass): the complement of the expansion check above. A
// volatility CONTRACTION (current ATR meaningfully below its own recent
// average) typically precedes a breakout - useful as context even though
// it points the opposite direction from "trade now": it's a reason to
// expect a move is coming, not evidence a move is already underway. Not
// wired into the trade score as a bonus (that would fight the expansion
// filter's logic); exposed for diagnostics/dashboard and for the
// volatility-breakout strategy setups, which specifically want to know
// "are we coiled" before a range/channel break.
input double VolatilityContractionMultiplier = 0.7;

bool IsVolatilityContracting()
{
   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0 || FilterATRHandles[idx] == INVALID_HANDLE)
      return false;

   double atrHistory[];
   ArraySetAsSeries(atrHistory, true);

   int needed = VolatilityExpansionLookback + 1;
   if(CopyBuffer(FilterATRHandles[idx], 0, 0, needed, atrHistory) < needed)
      return false;

   double currentATR = atrHistory[0];
   double sum = 0.0;
   for(int i = 1; i <= VolatilityExpansionLookback; i++)
      sum += atrHistory[i];

   double avgATR = sum / VolatilityExpansionLookback;
   if(avgATR <= 0.0)
      return false;

   return (currentATR <= avgATR * VolatilityContractionMultiplier);
}
//+------------------------------------------------------------------+
//|              PART 12 - SMART MONEY CONCEPTS ENGINE               |
//+------------------------------------------------------------------+

//================ SMC SETTINGS =====================================//

input int StructureLookback = 20;
input int SwingBars = 3; // REDUCED from 5 per request - a swing point needed 4 clean bars on each side to confirm at 5, which is genuinely rare. At 3, swing points (and therefore BOS/liquidity-sweep reference levels) register more often. Tradeoff: each individual swing point is less significant/confirmed than before - more opportunities, slightly lower bar for what counts as "structure."

// FIX #1 - TIMEFRAME MISMATCH: every function in this section used to read
// PERIOD_CURRENT, which is whatever timeframe the chart the EA happens to
// be attached to is showing - not EntryTF, the timeframe the EA actually
// trades off (M15 by default). Attach this EA to an H4 chart and every BOS/
// FVG/order-block/liquidity-sweep read was silently analyzing H4 structure
// while the EA executed as if it were M15 structure. This is the exact
// same class of bug already fixed for barsHeld() in ManageOpenTrades() -
// now applied consistently here too. All iHigh/iLow/iClose/iOpen calls
// below use EntryTF explicitly.


//================ GET HIGH ==========================================//

double GetRecentHigh(ENUM_TIMEFRAMES tf = PERIOD_CURRENT)
{
   // FIX #2 - INCOMPLETE CANDLE: the old loop let i-j reach 0, which is the
   // currently-forming (unclosed) bar. Validating a "confirmed" swing high
   // against a candle whose high can still move intrabar means the signal
   // could repaint - true one tick, false the next, on the same bar. j now
   // stops one bar short so index 0 is never touched; only fully closed
   // bars (index 1+) count as confirmation.
   //
   // tf defaults to PERIOD_CURRENT as a sentinel (MQL5 default params must
   // be compile-time constants, so it can't default directly to the
   // EntryTF input) - mapped to EntryTF below. Passing an explicit
   // timeframe (e.g. HigherTimeframe) is what makes multi-timeframe
   // confluence possible without duplicating this whole function.

   ENUM_TIMEFRAMES workingTF = (tf == PERIOD_CURRENT) ? EntryTF : tf;

   // PERFORMANCE: cache the EntryTF result once per decision cycle per
   // symbol - see SwingCacheCycleArr declaration above. Only the EntryTF
   // path is cached; explicit-timeframe (HTF) calls fall through uncached
   // since they run far less often.
   bool cacheable = (workingTF == EntryTF);
   int idx = cacheable ? GetSymbolIndex(BrokerSymbol) : -1;

   if(cacheable && idx >= 0 && idx < ArraySize(SwingHighCacheCycleArr) && SwingHighCacheCycleArr[idx] == (long)g_CycleCounter)
      return SwingHighCacheArr[idx];

   double result = EMPTY_VALUE;

   for(int i = SwingBars; i < StructureLookback; i++)
   {
      bool swing = true;

      double high = iHigh(BrokerSymbol, workingTF, i);
      if(!MathIsValidNumber(high) || high <= 0.0 || high == EMPTY_VALUE)
         continue;

      for(int j = 1; j < SwingBars; j++)
      {
         double hj = iHigh(BrokerSymbol, workingTF, i-j);
         double hk = iHigh(BrokerSymbol, workingTF, i+j);
         if(!MathIsValidNumber(hj) || !MathIsValidNumber(hk) || hj <= 0.0 || hk <= 0.0)
         {
            swing = false;
            break;
         }
         if(high <= hj || high <= hk)
         {
            swing = false;
            break;
         }
      }

      if(swing)
      {
         result = high;
         break;
      }
   }

   if(cacheable && idx >= 0 && idx < ArraySize(SwingHighCacheCycleArr))
   {
      SwingHighCacheCycleArr[idx] = (long)g_CycleCounter;
      SwingHighCacheArr[idx]      = result;
   }

   return result;
}


//================ GET LOW ===========================================//

double GetRecentLow(ENUM_TIMEFRAMES tf = PERIOD_CURRENT)
{
   // Same incomplete-candle fix and timeframe-parameter pattern as
   // GetRecentHigh() above.

   ENUM_TIMEFRAMES workingTF = (tf == PERIOD_CURRENT) ? EntryTF : tf;

   bool cacheable = (workingTF == EntryTF);
   int idx = cacheable ? GetSymbolIndex(BrokerSymbol) : -1;

   if(cacheable && idx >= 0 && idx < ArraySize(SwingLowCacheCycleArr) && SwingLowCacheCycleArr[idx] == (long)g_CycleCounter)
      return SwingLowCacheArr[idx];

   double result = EMPTY_VALUE;

   for(int i = SwingBars; i < StructureLookback; i++)
   {
      bool swing = true;

      double low = iLow(BrokerSymbol, workingTF, i);
      if(!MathIsValidNumber(low) || low <= 0.0 || low == EMPTY_VALUE)
         continue;

      for(int j = 1; j < SwingBars; j++)
      {
         double lj = iLow(BrokerSymbol, workingTF, i-j);
         double lk = iLow(BrokerSymbol, workingTF, i+j);
         if(!MathIsValidNumber(lj) || !MathIsValidNumber(lk) || lj <= 0.0 || lk <= 0.0)
         {
            swing = false;
            break;
         }
         if(low >= lj || low >= lk)
         {
            swing = false;
            break;
         }
      }

      if(swing)
      {
         result = low;
         break;
      }
   }

   if(cacheable && idx >= 0 && idx < ArraySize(SwingLowCacheCycleArr))
   {
      SwingLowCacheCycleArr[idx] = (long)g_CycleCounter;
      SwingLowCacheArr[idx]      = result;
   }

   return result;
}


// MULTI-SWING VALIDATION HELPERS (this pass): GetRecentHigh()/GetRecentLow()
// return only the single nearest confirmed swing point. A CHoCH built off
// just that one point can be tripped by one noisy, barely-qualifying swing.
// These walk past the first swing found and return the NEXT one further
// back, so a break can be checked against two independent swing points
// instead of one. Deliberately NOT cached (called far less often than the
// primary swing lookup - only during an actual CHoCH candidate, not every
// cycle).
double GetSecondRecentHigh(ENUM_TIMEFRAMES tf = PERIOD_CURRENT)
{
   ENUM_TIMEFRAMES workingTF = (tf == PERIOD_CURRENT) ? EntryTF : tf;
   bool foundFirst = false;

   for(int i = SwingBars; i < StructureLookback; i++)
   {
      bool swing = true;
      double high = iHigh(BrokerSymbol, workingTF, i);

      for(int j = 1; j < SwingBars; j++)
      {
         if(high <= iHigh(BrokerSymbol, workingTF, i-j) || high <= iHigh(BrokerSymbol, workingTF, i+j))
         { swing = false; break; }
      }

      if(swing)
      {
         if(!foundFirst) { foundFirst = true; continue; }
         return high;
      }
   }

   return EMPTY_VALUE;
}

double GetSecondRecentLow(ENUM_TIMEFRAMES tf = PERIOD_CURRENT)
{
   ENUM_TIMEFRAMES workingTF = (tf == PERIOD_CURRENT) ? EntryTF : tf;
   bool foundFirst = false;

   for(int i = SwingBars; i < StructureLookback; i++)
   {
      bool swing = true;
      double low = iLow(BrokerSymbol, workingTF, i);

      for(int j = 1; j < SwingBars; j++)
      {
         if(low >= iLow(BrokerSymbol, workingTF, i-j) || low >= iLow(BrokerSymbol, workingTF, i+j))
         { swing = false; break; }
      }

      if(swing)
      {
         if(!foundFirst) { foundFirst = true; continue; }
         return low;
      }
   }

   return EMPTY_VALUE;
}

//================ PREMIUM / DISCOUNT ZONE ============================//
// NEW (from P.R.I.S.M. manual review): this concept did not exist
// anywhere in the EA before. The idea is simple and well-defined enough
// to add safely as an opt-in filter without recreating the "gate that
// never fires" problem: split the current swing range in half (the
// equilibrium/50% level) and only take buys in the lower (discount)
// half, sells in the upper (premium) half. This avoids buying into an
// already-extended move or selling into an already-cheap one. Off by
// default - turn on deliberately.

input bool EnablePremiumDiscountFilter = false;

// FINE-TUNE (this pass): a flat 50% equilibrium split treats a quiet range
// and a strongly trending leg identically. In a genuine strong trend, price
// spends most of its time in what a static midpoint calls "premium" (for
// an uptrend) simply because it's making higher highs faster than the
// range midpoint can catch up - a strict 50/50 gate would reject most
// continuation entries in exactly the condition SMC trend-following is
// supposed to work best in. During a confirmed strong trend (TrendStrong()
// - ADX/EMA-slope based, already computed elsewhere), the zone boundary
// shifts in the trend's favor instead of staying pinned at the midpoint:
// buys are allowed further up into the range in a strong uptrend, sells
// further down in a strong downtrend. Ranging/weak-trend conditions keep
// the original strict 50/50 split.
input double StrongTrendZoneBiasPercent = 20.0; // how far (in % of range) the accepted zone boundary shifts in the trend's favor during a confirmed strong trend

double GetEquilibrium()
{
   double high = GetRecentHigh();
   double low  = GetRecentLow();

   if(high == EMPTY_VALUE || low == EMPTY_VALUE)
      return EMPTY_VALUE;

   return (high + low) / 2.0;
}

bool InDiscountZone() // lower half of the range - where buys are preferred
{
   double high = GetRecentHigh();
   double low  = GetRecentLow();

   if(high == EMPTY_VALUE || low == EMPTY_VALUE)
      return true; // fail open - don't block trading just because range data isn't ready

   double range = high - low;
   double boundary = (high + low) / 2.0;

   // In a strong uptrend, allow buys further up into the range rather than
   // strictly below the 50% midpoint - continuation entries shouldn't be
   // penalized just for the trend having already moved.
   if(range > 0.0 && TrendStrong() && IsBullTrend())
      boundary = low + range * MathMin(0.95, 0.5 + StrongTrendZoneBiasPercent / 100.0);

   return SymbolInfoDouble(BrokerSymbol, SYMBOL_BID) < boundary;
}

bool InPremiumZone() // upper half of the range - where sells are preferred
{
   double high = GetRecentHigh();
   double low  = GetRecentLow();

   if(high == EMPTY_VALUE || low == EMPTY_VALUE)
      return true;

   double range = high - low;
   double boundary = (high + low) / 2.0;

   // Mirror image for a strong downtrend: allow sells further down into the
   // range rather than strictly above the 50% midpoint.
   if(range > 0.0 && TrendStrong() && IsBearTrend())
      boundary = high - range * MathMin(0.95, 0.5 + StrongTrendZoneBiasPercent / 100.0);

   return SymbolInfoDouble(BrokerSymbol, SYMBOL_BID) > boundary;
}


//================ PRIOR DAY / WEEK LIQUIDITY LEVELS ==================//
// NEW (from P.R.I.S.M. manual review): the EA's liquidity/sweep logic
// only ever looked at swing highs/lows on the entry timeframe. Previous
// day and previous week highs/lows are genuinely different, commonly
// watched liquidity levels that weren't tracked anywhere. Added as a
// small, additive SCORE BONUS (not a hard gate) when price is trading
// close to one of these levels in the trade's direction - same
// "distance to liquidity" idea the manual describes, without adding
// another AND-condition that could choke off trades.

double GetPreviousDayHigh() { return iHigh(BrokerSymbol, PERIOD_D1, 1); }
double GetPreviousDayLow()  { return iLow(BrokerSymbol, PERIOD_D1, 1);  }
double GetPreviousWeekHigh(){ return iHigh(BrokerSymbol, PERIOD_W1, 1); }
double GetPreviousWeekLow() { return iLow(BrokerSymbol, PERIOD_W1, 1);  }

input double LiquidityProximityATRMultiple = 0.5; // how close price must be to a prior D1/W1 level to count as "near liquidity"

int GetLiquidityProximityScore(bool buy)
{
   double atr = GetFilterATR();

   if(atr <= 0.0)
      return 0;

   double threshold = atr * LiquidityProximityATRMultiple;
   double price = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);

   double pdh = GetPreviousDayHigh();
   double pdl = GetPreviousDayLow();
   double pwh = GetPreviousWeekHigh();
   double pwl = GetPreviousWeekLow();

   int score = 0;

   if(buy)
   {
      // Buying near recently-swept sell-side liquidity (a prior low) is
      // the higher-quality location per the manual's liquidity model.
      if(pdl > 0 && MathAbs(price - pdl) <= threshold) score += 5;
      if(pwl > 0 && MathAbs(price - pwl) <= threshold) score += 5; // weekly level carries more weight
   }
   else
   {
      if(pdh > 0 && MathAbs(price - pdh) <= threshold) score += 5;
      if(pwh > 0 && MathAbs(price - pwh) <= threshold) score += 5;
   }

   return score; // 0-10 bonus points
}

// STRENGTHENED: previously any close even a single tick beyond the swing
// level counted as a full break of structure. That's indistinguishable
// from noise/spread wobble right at the level. Now the close has to clear
// the swing level by a minimum ATR-scaled margin, so only decisive breaks
// count - the same standard already applied to the order-block impulse
// filter.

input double BOS_MinBreakATRMultiple = 0.1; // CHANGED: was 0.0, which made this a no-op (any break of any size passed) despite the comment above describing it as a real filter. 0.1 requires a break to actually clear the level by a small but real margin, not just noise.

// FURTHER FINE-TUNE (this pass): the ATR-margin break requirement already
// filters ordinary noise, but a single decisive close beyond the level can
// still be a one-bar spike that immediately gets reclaimed (a false break/
// liquidity grab rather than a genuine structure shift). Optional second
// stage: when enabled, also requires the PREVIOUS closed bar (index 2) to
// already be positioned on the breakout side of the level (not just the
// most recent close), i.e. two consecutive closes confirming the same
// side. Off by default so behavior doesn't change unless deliberately
// tightened.
input bool BOS_RequireTwoBarConfirmation = false; // require 2 consecutive closes beyond the level, not just 1, to further cut false breaks

bool DetectBOS()
{
   int idx = GetSymbolIndex(BrokerSymbol);

   // PERFORMANCE: cache once per decision cycle per symbol - DetectBOS() is
   // called from CalculateTradeScore(), HasStructureConfluence(),
   // diagnostics and signal-snapshot capture, several times per cycle.
   if(idx >= 0 && idx < ArraySize(BOS_CacheCycleArr) && BOS_CacheCycleArr[idx] == (long)g_CycleCounter)
      return BOS_CacheResultArr[idx];

   bool result = false;

   double swingHigh = GetRecentHigh();
   double swingLow  = GetRecentLow();

   if(swingHigh != EMPTY_VALUE && swingLow != EMPTY_VALUE)
   {
      double close1 = iClose(BrokerSymbol, EntryTF, 1);
      double close2 = iClose(BrokerSymbol, EntryTF, 2);
      double close3 = iClose(BrokerSymbol, EntryTF, 3);

      double atr = GetFilterATR();
      double minBreakMargin = (atr > 0.0) ? (atr * BOS_MinBreakATRMultiple) : 0.0;

      // Bullish BOS - with two-bar confirmation on, the "before" reference
      // shifts back one bar (close3) and BOTH of the last two closed bars
      // (close2 and close1) must be beyond the level, instead of just the
      // single most recent close.
      bool bullBreak = !BOS_RequireTwoBarConfirmation
         ? (close2 <= swingHigh && close1 > swingHigh + minBreakMargin)
         : (close3 <= swingHigh && close2 > swingHigh + minBreakMargin && close1 > swingHigh + minBreakMargin);

      if(bullBreak)
      {
         if(EnableVerboseLogging) Print("Bullish BOS confirmed");
         if(idx >= 0 && idx < ArraySize(LastBOSTrueBarTimeArr))
            LastBOSTrueBarTimeArr[idx] = iTime(BrokerSymbol, EntryTF, 1);
         result = true;
      }

      // Bearish BOS
      if(!result)
      {
         bool bearBreak = !BOS_RequireTwoBarConfirmation
            ? (close2 >= swingLow && close1 < swingLow - minBreakMargin)
            : (close3 >= swingLow && close2 < swingLow - minBreakMargin && close1 < swingLow - minBreakMargin);

         if(bearBreak)
         {
            if(EnableVerboseLogging) Print("Bearish BOS confirmed");
            if(idx >= 0 && idx < ArraySize(LastBOSTrueBarTimeArr))
               LastBOSTrueBarTimeArr[idx] = iTime(BrokerSymbol, EntryTF, 1);
            result = true;
         }
      }
   }

   if(idx >= 0 && idx < ArraySize(BOS_CacheCycleArr))
   {
      BOS_CacheCycleArr[idx]  = (long)g_CycleCounter;
      BOS_CacheResultArr[idx] = result;
   }

   return result;
}

//================ MULTI-TIMEFRAME SMC CONFLUENCE (UPGRADE) ===========//
// FIX/UPGRADE: DetectBOS() above only ever looks at EntryTF - a break of
// structure on a 15-minute chart says nothing about whether the higher
// timeframe actually agrees. This adds a genuinely separate, directional
// check: has EntryTF's higher timeframe (HigherTimeframe, already used for
// HTFConfirms' EMA-based trend check) ALSO had a same-direction break of
// structure recently? That's a materially stronger confirmation than
// "price happens to be on the correct side of the HTF EMA" - it requires
// actual HTF structure to have shifted, not just price position.

bool DetectDirectionalBOS(ENUM_TIMEFRAMES tf, bool buy)
{
   double swingHigh = GetRecentHigh(tf);
   double swingLow  = GetRecentLow(tf);

   if(swingHigh == EMPTY_VALUE || swingLow == EMPTY_VALUE)
      return false;

   double close1 = iClose(BrokerSymbol, tf, 1);
   double close2 = iClose(BrokerSymbol, tf, 2);

   double atr = GetFilterATR(); // EntryTF-scaled ATR used as the margin reference even for HTF checks - a reasonable approximation rather than maintaining a second ATR handle per timeframe.
   double minBreakMargin = (atr > 0.0) ? (atr * BOS_MinBreakATRMultiple) : 0.0;

   if(buy)
      return (close2 <= swingHigh && close1 > swingHigh + minBreakMargin);
   else
      return (close2 >= swingLow && close1 < swingLow - minBreakMargin);
}

// BEST-NEXT48: same-direction BOS checked at a specific closed bar (lookback-capable).
bool IsDirectionalBOSAtBar(ENUM_TIMEFRAMES tf, const bool buy, const int bar)
{
   if(bar < 1)
      return false;

   int swingStart = bar + 2;
   int swingEnd = bar + 2 + MathMax(SwingBars * 2, 6);
   if(Bars(BrokerSymbol, tf) <= swingEnd)
      return false;

   double atr = GetFilterATR();
   double minBreakMargin = (atr > 0.0) ? (atr * BOS_MinBreakATRMultiple) : 0.0;
   double close1 = iClose(BrokerSymbol, tf, bar);
   double close2 = iClose(BrokerSymbol, tf, bar + 1);

   if(buy)
   {
      double swingHigh = iHigh(BrokerSymbol, tf, swingStart);
      for(int j = swingStart + 1; j <= swingEnd; j++)
      {
         double h = iHigh(BrokerSymbol, tf, j);
         if(h > swingHigh) swingHigh = h;
      }
      return (close2 <= swingHigh && close1 > swingHigh + minBreakMargin);
   }

   double swingLow = iLow(BrokerSymbol, tf, swingStart);
   for(int j = swingStart + 1; j <= swingEnd; j++)
   {
      double l = iLow(BrokerSymbol, tf, j);
      if(l < swingLow) swingLow = l;
   }
   return (close2 >= swingLow && close1 < swingLow - minBreakMargin);
}

bool RecentDirectionalBOS(const bool buy, const int lookbackBars)
{
   int lb = MathMax(lookbackBars, 1);
   // Prefer current-bar DetectDirectionalBOS (uses confirmed swing helpers)
   if(DetectDirectionalBOS(EntryTF, buy))
      return true;

   for(int i = 1; i <= lb; i++)
   {
      if(IsDirectionalBOSAtBar(EntryTF, buy, i))
         return true;
   }
   return false;
}

// Live Cont/ICE/IMCE structure BOS — lookback when DirectionalBOS_LookbackBars > 1
bool StructureDirectionalBOS(const bool buy)
{
   int lb = DirectionalBOS_LookbackBars;
   if(lb <= 1)
      return DetectDirectionalBOS(EntryTF, buy);
   return RecentDirectionalBOS(buy, lb);
}

input group "MULTI-TIMEFRAME SMC CONFLUENCE"

input bool EnableMTFStructureConfluence = false; // require a same-direction BOS on HigherTimeframe, not just EntryTF

bool HasHTFStructureConfluence(bool buy)
{
   if(!EnableMTFStructureConfluence)
      return true; // neutral when disabled - doesn't block anything

   return DetectDirectionalBOS(HigherTimeframe, buy);
}


//================ LIQUIDITY SWEEP ==================================//

// STRENGTHENED: same issue as BOS above - a wick clearing the prior
// high/low by a hair used to count as a full liquidity sweep. Now requires
// the wick to clear the level by a minimum ATR-scaled depth, so it reflects
// an actual stop-hunt-style spike rather than ordinary noise at the level.

input double LiquiditySweep_MinDepthATRMultiple = 0.1; // CHANGED: was 0.0 - same no-op issue as BOS_MinBreakATRMultiple above.

// FURTHER STRENGTHENED (this pass): depth alone doesn't distinguish a real
// spike-and-reject wick from a bar that simply broke out and kept most of
// its range beyond the level (a strong bar in that direction, not a
// rejection of it). Requiring the piercing wick to be a meaningful share
// of the bar's own total range filters out bars where the "sweep" is
// really just ordinary directional strength.
input double LiquiditySweep_MinWickRatio = 0.33; // the piercing wick must be at least this fraction of the bar's total high-low range

bool IsBuySideLiquiditySweepAtBar(const int bar)
{
   // Sweep of highs → bearish reversal fuel (SELL)
   if(bar < 1)
      return false;

   double currentHigh = iHigh(BrokerSymbol, EntryTF, bar);
   double currentLow  = iLow(BrokerSymbol, EntryTF, bar);
   double close = iClose(BrokerSymbol, EntryTF, bar);
   double barRange = currentHigh - currentLow;
   if(barRange <= 0.0)
      return false;

   // Prior swing high from bars after this bar
   double previousHigh = iHigh(BrokerSymbol, EntryTF, bar + 1);
   for(int j = bar + 2; j <= bar + 6; j++)
   {
      double h = iHigh(BrokerSymbol, EntryTF, j);
      if(h > previousHigh) previousHigh = h;
   }

   double atr = GetFilterATR();
   double minSweepDepth = (atr > 0.0) ? (atr * LiquiditySweep_MinDepthATRMultiple) : 0.0;

   if(!(currentHigh > previousHigh + minSweepDepth && close < previousHigh))
      return false;

   double wick = currentHigh - MathMax(close, previousHigh);
   return (wick / barRange >= LiquiditySweep_MinWickRatio);
}

bool IsSellSideLiquiditySweepAtBar(const int bar)
{
   // Sweep of lows → bullish reversal fuel (BUY)
   if(bar < 1)
      return false;

   double currentHigh = iHigh(BrokerSymbol, EntryTF, bar);
   double currentLow  = iLow(BrokerSymbol, EntryTF, bar);
   double close = iClose(BrokerSymbol, EntryTF, bar);
   double barRange = currentHigh - currentLow;
   if(barRange <= 0.0)
      return false;

   double previousLow = iLow(BrokerSymbol, EntryTF, bar + 1);
   for(int j = bar + 2; j <= bar + 6; j++)
   {
      double l = iLow(BrokerSymbol, EntryTF, j);
      if(l < previousLow) previousLow = l;
   }

   double atr = GetFilterATR();
   double minSweepDepth = (atr > 0.0) ? (atr * LiquiditySweep_MinDepthATRMultiple) : 0.0;

   if(!(currentLow < previousLow - minSweepDepth && close > previousLow))
      return false;

   double wick = MathMin(close, previousLow) - currentLow;
   return (wick / barRange >= LiquiditySweep_MinWickRatio);
}

bool DetectLiquiditySweep()
{
   bool buySide = IsBuySideLiquiditySweepAtBar(1);
   bool sellSide = IsSellSideLiquiditySweepAtBar(1);

   if(buySide || sellSide)
   {
      if(EnableVerboseLogging)
         Print(buySide ? "Buy-side liquidity sweep detected"
                       : "Sell-side liquidity sweep detected");
      int sIdx = GetSymbolIndex(BrokerSymbol);
      if(sIdx >= 0 && sIdx < ArraySize(LastSweepTrueBarTimeArr))
         LastSweepTrueBarTimeArr[sIdx] = iTime(BrokerSymbol, EntryTF, 1);
      return true;
   }
   return false;
}

// Directional sweep recency for CORRECT reversal signals.
// buy=true  → need sell-side liquidity taken (lows swept)
// buy=false → need buy-side liquidity taken (highs swept)
// Returns most-recent bar index of that side sweep, or 0 if none.
int MostRecentCorrectSweepBar(const bool buy, const int lookbackBars)
{
   int lb = MathMax(lookbackBars, 1);
   for(int i = 1; i <= lb; i++)
   {
      if(buy && IsSellSideLiquiditySweepAtBar(i))
         return i;
      if(!buy && IsBuySideLiquiditySweepAtBar(i))
         return i;
   }
   // Stop-hunt is stricter same-side signature (bar 1)
   if(buy && DetectStopHunt(false))
      return 1;
   if(!buy && DetectStopHunt(true))
      return 1;
   return 0;
}

int MostRecentWrongSideSweepBar(const bool buy, const int lookbackBars)
{
   int lb = MathMax(lookbackBars, 1);
   for(int i = 1; i <= lb; i++)
   {
      // Wrong side for BUY entry = highs swept (bearish fuel) — adverse to open longs too
      // Wrong side for SELL entry = lows swept (bullish fuel) — adverse to open shorts too
      if(buy && IsBuySideLiquiditySweepAtBar(i))
         return i;
      if(!buy && IsSellSideLiquiditySweepAtBar(i))
         return i;
   }
   if(buy && DetectStopHunt(true))
      return 1;
   if(!buy && DetectStopHunt(false))
      return 1;
   return 0;
}

bool RecentDirectionalSweep(const bool buy, const int lookbackBars)
{
   return (MostRecentCorrectSweepBar(buy, lookbackBars) > 0);
}

bool ReversalReclaimConfirm(const bool buy, const int rec)
{
   // AUDITFIX49: directional CHoCH only — undirected flip no longer counts as reclaim
   bool choch = RecentDirectionalCHoCH(buy, rec);
   bool disp = (GetDisplacementScore(buy) >= 5);
   bool inducement = DetectInducement(buy);
   bool stopHunt = buy ? DetectStopHunt(false) : DetectStopHunt(true);

   // Strong reclaim signatures (always valid)
   if(choch || disp || inducement || stopHunt)
      return true;

   // Plain reclaim candle alone is weak — only allowed when StrictCorrect is OFF
   if(!ReversalStrictCorrectSignal)
   {
      double o = iOpen(BrokerSymbol, EntryTF, 1);
      double c = iClose(BrokerSymbol, EntryTF, 1);
      if(buy && c > o)
         return true;
      if(!buy && c < o)
         return true;
   }

   return false;
}

// Master validator: correct-side sweep + zone + strong reclaim = CORRECT signal
// Rejects wrong-side / continuation traps so RevSniper does not fire the wrong way.
bool MarketReversalSignalOK(const bool buy, string &detail)
{
   detail = "";
   int rec = (EnableEarlyMarketReversal
              ? MathMax(EffectiveStructureRecency(), ReversalStructureRecencyBars)
              : EffectiveStructureRecency());

   int correctBar = MostRecentCorrectSweepBar(buy, rec);
   int wrongBar = MostRecentWrongSideSweepBar(buy, rec);
   bool correctSweep = (correctBar > 0);
   bool anySweep = RecentSweep(rec);
   bool choch = RecentCHoCH(rec);
   bool zone = ActiveOrderBlock(buy) || ActiveFVG(buy);
   bool reclaim = ReversalReclaimConfirm(buy, rec);
   bool trap = DetectFakeBreakoutTrap(buy);
   bool stopHunt = buy ? DetectStopHunt(false) : DetectStopHunt(true);

   bool sweepOK = ReversalRequireCorrectSideSweep ? correctSweep
                  : (ReversalAcceptCHoCHOrSweep ? (anySweep || choch) : anySweep);
   bool zoneOK = ReversalRequireZone ? zone : true;
   bool reclaimOK = ReversalRequireReclaimConfirm ? reclaim : true;

   if(trap)
   {
      detail = "blocked: fake-breakout trap in trade direction";
      return false;
   }
   if(!sweepOK)
   {
      detail = buy ? "need sell-side sweep (lows taken)" : "need buy-side sweep (highs taken)";
      return false;
   }
   // Anti-continuation: opposite sweep as-recent or more-recent = wrong signal
   if(ReversalRejectWrongSideRecent && wrongBar > 0 &&
      (correctBar == 0 || wrongBar <= correctBar))
   {
      detail = buy
         ? "blocked: wrong-side (highs) sweep recent — continuation not BUY rev"
         : "blocked: wrong-side (lows) sweep recent — continuation not SELL rev";
      return false;
   }
   if(ReversalPreferStopHunt && !stopHunt)
   {
      detail = "need stop-hunt candle (PreferStopHunt=true)";
      return false;
   }
   if(!zoneOK)
   {
      detail = "need OB/FVG zone in trade direction";
      return false;
   }
   if(!reclaimOK)
   {
      detail = ReversalStrictCorrectSignal
         ? "need strong reclaim (CHoCH / displacement / stop-hunt / inducement)"
         : "need reclaim (CHoCH / displacement / reclaim candle)";
      return false;
   }

   if(!ReversalRequireTrendADX)
   {
      detail = StringFormat("OK correctSweep=Y@%d wrongSide=%s zone=%s reclaim=%s CHoCH=%s stopHunt=%s",
                            correctBar,
                            (wrongBar > 0 ? IntegerToString(wrongBar) : "N"),
                            zone ? "Y" : "N",
                            reclaim ? "Y" : "N",
                            choch ? "Y" : "N",
                            stopHunt ? "Y" : "N");
      return true;
   }

   if(buy && !(IsBullTrend() && TrendStrong()))
   {
      detail = "trend+ADX not yet bullish";
      return false;
   }
   if(!buy && !(IsBearTrend() && TrendStrong()))
   {
      detail = "trend+ADX not yet bearish";
      return false;
   }

   detail = "OK with trend+ADX + correct-side stack";
   return true;
}

//================ STOP HUNT DETECTION (NEW) =========================//
// A stop hunt is a stricter, higher-conviction subset of a liquidity
// sweep: not just a wick past the level with a close back inside, but a
// spike beyond the level immediately followed by a decisive reversal close
// on the SAME bar that leaves the close near the opposite end of that
// bar's range - the classic "stop-run candle" signature (long wick, close
// away from the extreme, real body pointing the other way). Distinguishing
// this from a generic sweep matters because it's the pattern most closely
// associated with deliberate liquidity grabs rather than a level simply
// being tested and holding.
input double StopHunt_MinCloseBackFraction = 0.5; // close must be at least this far back from the spike extreme, as a fraction of the bar's range

bool DetectStopHunt(bool buySide)
{
   double high = iHigh(BrokerSymbol, EntryTF, 1);
   double low  = iLow(BrokerSymbol, EntryTF, 1);
   double close = iClose(BrokerSymbol, EntryTF, 1);
   double barRange = high - low;

   if(barRange <= 0.0)
      return false;

   double level = buySide ? GetRecentHigh() : GetRecentLow();
   if(level == EMPTY_VALUE)
      return false;

   double atr = GetFilterATR();
   double minDepth = (atr > 0.0) ? (atr * LiquiditySweep_MinDepthATRMultiple) : 0.0;

   if(buySide)
   {
      if(high <= level + minDepth)
         return false;
      // How far the close has retreated from the high, relative to the
      // whole bar's range - a decisive reversal close sits well below the
      // spike, not just a hair off the top.
      double closeBackFraction = (high - close) / barRange;
      return (close < level && closeBackFraction >= StopHunt_MinCloseBackFraction);
   }
   else
   {
      if(low >= level - minDepth)
         return false;
      double closeBackFraction = (close - low) / barRange;
      return (close > level && closeBackFraction >= StopHunt_MinCloseBackFraction);
   }
}

// UPGRADE - LIQUIDITY ENGINE: graduated scoring by sweep depth, same
// pattern as the FVG quality score above. A wick that barely pokes past
// the prior level and one that spikes well beyond it before reversing are
// different-quality signals - a deeper spike is a more convincing
// stop-hunt; scoring it flat at +10 either way threw that information
// away.

int GetLiquiditySweepQualityScore()
{
   double currentHigh = iHigh(BrokerSymbol, EntryTF, 1);
   double currentLow  = iLow(BrokerSymbol, EntryTF, 1);

   double previousHigh = GetRecentHigh();
   double previousLow  = GetRecentLow();

   if(previousHigh == EMPTY_VALUE || previousLow == EMPTY_VALUE)
      return 0;

   double close = iClose(BrokerSymbol, EntryTF, 1);
   double atr = GetFilterATR();

   double depth = 0.0;

   if(currentHigh > previousHigh && close < previousHigh)
      depth = currentHigh - previousHigh;
   else if(currentLow < previousLow && close > previousLow)
      depth = previousLow - currentLow;
   else
      return 0; // no sweep at all

   if(atr <= 0.0)
      return 5;

   double ratio = depth / atr;

   if(ratio >= 0.5) return 15; // deep, convincing spike beyond the level
   if(ratio >= 0.2) return 10;

   return 5; // shallow poke past the level - still counts, just weakly
}
//==============================================================
// EQUAL HIGHS
//==============================================================

// FIX #4 - TOLERANCE DOESN'T SCALE TO THE INSTRUMENT: a flat "10 points"
// tolerance is the same class of bug as the old fixed StopLossPoints - on
// BTCUSD, 10 points can be a fraction of a dollar of "equal", which almost
// never actually triggers on a genuinely equal high, while on a tighter
// forex pair it's comparatively enormous. Tolerance now scales off ATR
// (falls back to the old point-based tolerance if ATR isn't ready yet).

double EqualLevelTolerance()
{
   double atr = GetFilterATR();

   if(atr > 0.0)
      return atr * 0.1;

   return 10 * SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT);
}

input int EqualLevelLookbackBars = 15; // how many closed bars back to search for a genuine equal-highs/lows liquidity pool

// UPGRADE: scans back over EqualLevelLookbackBars closed candles and counts
// how many highs sit within EqualLevelTolerance() of the most recent closed
// bar's high. 2 touches is the bare minimum SMC definition of "equal
// highs"; 3+ is a much more heavily defended (and more meaningful) pool.
int CountEqualHighTouches()
{
   double refHigh = iHigh(BrokerSymbol, EntryTF, 1);
   double tolerance = EqualLevelTolerance();

   int touches = 1; // the reference bar itself counts as one

   for(int i = 2; i <= EqualLevelLookbackBars; i++)
   {
      if(MathAbs(iHigh(BrokerSymbol, EntryTF, i) - refHigh) <= tolerance)
         touches++;
   }

   return touches;
}

int CountEqualLowTouches()
{
   double refLow = iLow(BrokerSymbol, EntryTF, 1);
   double tolerance = EqualLevelTolerance();

   int touches = 1;

   for(int i = 2; i <= EqualLevelLookbackBars; i++)
   {
      if(MathAbs(iLow(BrokerSymbol, EntryTF, i) - refLow) <= tolerance)
         touches++;
   }

   return touches;
}

bool IsEqualHigh()
{
   return CountEqualHighTouches() >= 2;
}

//==============================================================
// EQUAL LOWS
//==============================================================

bool IsEqualLow()
{
   return CountEqualLowTouches() >= 2;
}

// Graduated version for scoring - a 2-touch pool and a 4+-touch pool are
// not equally significant liquidity, same graduated-scoring pattern used
// for the FVG/sweep quality scorers.
int GetEqualHighPoolScore()
{
   int touches = CountEqualHighTouches();
   if(touches >= 4) return 15;
   if(touches == 3) return 10;
   if(touches == 2) return 5;
   return 0;
}

int GetEqualLowPoolScore()
{
   int touches = CountEqualLowTouches();
   if(touches >= 4) return 15;
   if(touches == 3) return 10;
   if(touches == 2) return 5;
   return 0;
}
//==============================================================
// BULLISH FAIR VALUE GAP
//==============================================================

// FILTER INSIGNIFICANT FVGs (this pass): previously ANY gap greater than
// zero counted as a detected FVG - a one-point gap from spread noise or a
// quiet tick registered exactly the same as a genuine displacement gap.
// GetBullish/BearishFVGQualityScore() already discounted tiny gaps in the
// SCORE, but DetectBullish/BearishFVG() themselves (used by structure
// confluence, FVG tracking, and the FVG+OB strategy setups) still treated
// a microscopic gap as a real, trackable one. This adds a minimum
// ATR-scaled size gate at the source so an insignificant gap is filtered
// out everywhere consistently, not just where scoring happens to touch it.
input double FVG_MinSizeATRMultiple = 0.1; // minimum gap size, as a multiple of ATR, to count as a real FVG at all (0 = no minimum, old behavior)

bool DetectBullishFVG()
{
   double high3 = iHigh(BrokerSymbol, EntryTF, 3);
   double low1  = iLow(BrokerSymbol, EntryTF, 1);

   double gapSize = low1 - high3;
   if(gapSize <= 0)
      return false;

   if(FVG_MinSizeATRMultiple <= 0.0)
      return true;

   double atr = GetFilterATR();
   if(atr <= 0.0)
      return true; // can't scale to volatility yet - don't block on missing data

   return (gapSize >= atr * FVG_MinSizeATRMultiple);
}

//==============================================================
// BEARISH FAIR VALUE GAP
//==============================================================

bool DetectBearishFVG()
{
   double low3  = iLow(BrokerSymbol, EntryTF, 3);
   double high1 = iHigh(BrokerSymbol, EntryTF, 1);

   double gapSize = low3 - high1;
   if(gapSize <= 0)
      return false;

   if(FVG_MinSizeATRMultiple <= 0.0)
      return true;

   double atr = GetFilterATR();
   if(atr <= 0.0)
      return true;

   return (gapSize >= atr * FVG_MinSizeATRMultiple);
}

//==============================================================
// FVG QUALITY SCORING (UPGRADE)
//==============================================================
// FIX/UPGRADE: DetectBullishFVG()/DetectBearishFVG() above are still
// binary - a gap of 1 point and a gap of 50x ATR score identically. A
// three-candle gap that's tiny relative to current volatility is barely
// meaningful (near-certain to get filled immediately and isn't a real
// imbalance); a gap that's large relative to ATR reflects genuine
// displacement. This scores the gap size against ATR instead of just
// checking existence, so CalculateTradeScore() below can weight a strong
// FVG higher than a token one.

int GetBullishFVGQualityScore()
{
   double high3 = iHigh(BrokerSymbol, EntryTF, 3);
   double low1  = iLow(BrokerSymbol, EntryTF, 1);

   double gapSize = low1 - high3;

   if(gapSize <= 0)
      return 0; // no FVG at all

   double atr = GetFilterATR();

   if(atr <= 0.0)
      return 5; // can't scale to volatility yet - modest flat fallback

   double ratio = gapSize / atr;

   if(ratio >= 1.0)  return 15; // large gap relative to current volatility - strong displacement
   if(ratio >= 0.5)  return 10;
   if(ratio >= 0.2)  return 5;

   return 2; // technically an FVG, but tiny - low quality, barely counts
}

int GetBearishFVGQualityScore()
{
   double low3  = iLow(BrokerSymbol, EntryTF, 3);
   double high1 = iHigh(BrokerSymbol, EntryTF, 1);

   double gapSize = low3 - high1;

   if(gapSize <= 0)
      return 0;

   double atr = GetFilterATR();

   if(atr <= 0.0)
      return 5;

   double ratio = gapSize / atr;

   if(ratio >= 1.0)  return 15;
   if(ratio >= 0.5)  return 10;
   if(ratio >= 0.2)  return 5;

   return 2;
}
//==============================================================
// BULLISH ORDER BLOCK
//==============================================================

// FIX #5 - NO IMPULSE-STRENGTH FILTER: the old version only checked that
// bar 1's high cleared bar 2's high after a down candle - true of almost
// any two-candle wiggle, so it fired constantly and added score noise
// rather than flagging a genuine institutional-style impulse move. Now
// requires bar 1's full range to exceed a minimum multiple of ATR, so only
// candles that actually moved with force count.

input double OrderBlockMinATRMultiple = 0.3; // CHANGED: was 0.0 - the comment above describes this as requiring a genuinely forceful impulse candle, but 0.0 meant impulseRange >= atr*0 was true for any candle at all, so the check never actually filtered anything. 0.3 requires the impulse candle to have real range relative to current volatility.

// UPGRADE - BETTER ORDER-BLOCK VALIDATION: impulse strength alone (above)
// still allows a base candle that was itself a big, messy move to count
// as the "order block." The classic definition wants the base candle to
// reflect consolidation/absorption right before the impulse - a tight,
// contained candle, not another wide swing. Adding a max-range check on
// the base candle (bar 2) alongside the existing impulse-strength check
// on bar 1 means both halves of the pattern now have to look right, not
// just the breakout half.

input double OrderBlockMaxBaseATRMultiple = 1.2; // CHANGED: was 999.0 (explicitly a no-op per the old comment). 1.2 actually requires the base candle to be reasonably contained relative to volatility, matching the "tight base" definition described above, while staying loose enough not to reject normal setups.

bool DetectBullishOrderBlock()
{
   double open2  = iOpen(BrokerSymbol, EntryTF, 2);
   double close2 = iClose(BrokerSymbol, EntryTF, 2);
   double high2  = iHigh(BrokerSymbol, EntryTF, 2);
   double low2   = iLow(BrokerSymbol, EntryTF, 2);

   double high1 = iHigh(BrokerSymbol, EntryTF, 1);
   double low1  = iLow(BrokerSymbol, EntryTF, 1);

   double atr = GetFilterATR();
   double impulseRange = high1 - low1;
   double baseRange     = high2 - low2;

   bool impulseStrongEnough = (atr <= 0.0) || (impulseRange >= atr * OrderBlockMinATRMultiple);
   bool baseTightEnough     = (atr <= 0.0) || (baseRange <= atr * OrderBlockMaxBaseATRMultiple);

   // Last bearish candle before a genuinely forceful bullish impulse
   if(close2 < open2 && high1 > high2 && impulseStrongEnough && baseTightEnough)
      return true;

   return false;
}
//==============================================================
// BEARISH ORDER BLOCK
//==============================================================

bool DetectBearishOrderBlock()
{
   double open2  = iOpen(BrokerSymbol, EntryTF, 2);
   double close2 = iClose(BrokerSymbol, EntryTF, 2);
   double high2  = iHigh(BrokerSymbol, EntryTF, 2);
   double low2   = iLow(BrokerSymbol, EntryTF, 2);

   double high1 = iHigh(BrokerSymbol, EntryTF, 1);
   double low1  = iLow(BrokerSymbol, EntryTF, 1);

   double atr = GetFilterATR();
   double impulseRange = high1 - low1;
   double baseRange     = high2 - low2;

   bool impulseStrongEnough = (atr <= 0.0) || (impulseRange >= atr * OrderBlockMinATRMultiple);
   bool baseTightEnough     = (atr <= 0.0) || (baseRange <= atr * OrderBlockMaxBaseATRMultiple);

   // Last bullish candle before a genuinely forceful bearish impulse
   if(close2 > open2 && low1 < low2 && impulseStrongEnough && baseTightEnough)
      return true;

   return false;
}

//================ CHOCH DETECTION ==================================//

// FIX #3 - TICK NOISE + BAD SEED VALUE + MULTI-SYMBOL STATE BLEED:
//   a) The old version called TrendBullish() (live Bid vs EMA) on every
//      tick, so as price oscillated around the EMA it could flip back and
//      forth and fire a "CHoCH" many times within a single bar - noise,
//      not a real change of character.
//   b) `static bool lastBullTrend = TrendBullish();` only runs once, ever,
//      at the first call. If indicators weren't ready yet at that moment,
//      GetEMA() returns EMPTY_VALUE (an astronomically large sentinel), so
//      TrendBullish() would evaluate false regardless of the real trend -
//      seeding the wrong starting state and guaranteeing one bogus CHoCH
//      signal the moment real data arrives.
//   c) FOUND IN THIS REVIEW: all of the state above used to live in
//      function-local `static` variables - meaning ONE shared state for
//      every symbol. In multi-symbol mode, calling this for EURUSD then
//      GBPUSD in the same trading cycle compared GBPUSD's trend against
//      EURUSD's last recorded state, and "already evaluated this bar"
//      was checked against whichever symbol happened to run last -
//      producing false CHoCH signals purely from switching symbols, and
//      silently skipping genuine new-bar evaluations for others. State is
//      now held in the per-symbol arrays declared in Part 1
//      (CHoCH_LastBarTimeArr / CHoCH_LastBullTrendArr /
//      CHoCH_StateInitializedArr), indexed the same way as every other
//      per-symbol tracker in this file.
// Fix: only evaluate once per newly closed bar, per symbol, and skip
// entirely (no state change, no false signal) until GetEMA() returns real
// data.

// FINE-TUNE (this pass): the EMA-cross trend flip below is a genuine,
// stateful, once-per-bar-per-symbol signal (Fix #3), but an EMA cross by
// itself can happen on a shallow pullback that never actually broke any
// real price structure - it's a trend-follow signal wearing a structure
// name. This adds an actual price-structure requirement on top: the flip
// only counts as CHoCH if price has ALSO closed beyond two independent
// recent swing points in the new direction (GetRecentHigh/Low - the
// nearest swing - AND GetSecondRecentHigh/Low - the next one back), not
// just crossed the EMA. Two independent swings have to agree, not one.
// Falls back to the EMA-only signal if a second swing genuinely isn't
// available yet (fresh chart / thin history) rather than blocking forever.
input bool EnableCHoCH_MultiSwingValidation = true; // require 2 independent swing points to agree with the EMA-cross flip, not just the nearest one

bool CHoCH_MultiSwingConfirms(bool bullish)
{
   if(!EnableCHoCH_MultiSwingValidation)
      return true;

   double close1 = iClose(BrokerSymbol, EntryTF, 1);

   if(bullish)
   {
      double swingHigh1 = GetRecentHigh();
      double swingHigh2 = GetSecondRecentHigh();

      if(swingHigh1 == EMPTY_VALUE)
         return true; // no structure data yet - don't block on a missing reference

      bool clearedPrimary = close1 > swingHigh1;
      bool clearedSecondary = (swingHigh2 == EMPTY_VALUE) ? true : (close1 > swingHigh2);

      return clearedPrimary && clearedSecondary;
   }
   else
   {
      double swingLow1 = GetRecentLow();
      double swingLow2 = GetSecondRecentLow();

      if(swingLow1 == EMPTY_VALUE)
         return true;

      bool clearedPrimary = close1 < swingLow1;
      bool clearedSecondary = (swingLow2 == EMPTY_VALUE) ? true : (close1 < swingLow2);

      return clearedPrimary && clearedSecondary;
   }
}

bool DetectCHoCH()
{
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0)
      return false;

   // FIX (this review): every caller within the same decision cycle must
   // see the same answer. Return the cached result immediately if this
   // symbol has already been evaluated during the current g_CycleCounter
   // tick, instead of re-running the once-per-bar state machine below
   // (which would incorrectly return false for every caller after the
   // first).
   if(idx < ArraySize(CHoCH_CacheCycleArr) && CHoCH_CacheCycleArr[idx] == (long)g_CycleCounter)
      return CHoCH_CacheResultArr[idx];

   bool result = false;

   datetime currentBarTime = iTime(BrokerSymbol, EntryTF, 0);

   if(currentBarTime != CHoCH_LastBarTimeArr[idx])
   {
      double ema = GetEMA();

      if(ema != EMPTY_VALUE) // indicators not ready - don't seed a false state
      {
         CHoCH_LastBarTimeArr[idx] = currentBarTime;

         bool currentBullTrend = (SymbolInfoDouble(BrokerSymbol, SYMBOL_BID) > ema);

         if(!CHoCH_StateInitializedArr[idx])
         {
            // First valid read for this symbol - record the starting state
            // without claiming a "change" happened, since there's nothing
            // to compare against yet.
            CHoCH_StateInitializedArr[idx] = true;
            CHoCH_LastBullTrendArr[idx] = currentBullTrend;
         }
         else if(currentBullTrend != CHoCH_LastBullTrendArr[idx])
         {
            // The EMA state has flipped - record the new state either way
            // (so the next comparison is against the correct baseline), but
            // only report it as a CHoCH result if multi-swing validation
            // (or its "no data yet" fallback) actually agrees that price
            // structure backs it up. A flip that fails validation still
            // updates the trend baseline; it just doesn't fire a signal.
            CHoCH_LastBullTrendArr[idx] = currentBullTrend;

            if(CHoCH_MultiSwingConfirms(currentBullTrend))
            {
               result = true;
               LastCHoCHTrueBarTimeArr[idx] = currentBarTime;
               // AUDITFIX49: lock direction of THIS confirmed CHoCH for reclaim polarity
               if(idx < ArraySize(LastCHoCHWasBullArr))
                  LastCHoCHWasBullArr[idx] = currentBullTrend;

               if(EnableVerboseLogging)
                  Print(currentBullTrend ? "Bullish CHoCH detected" : "Bearish CHoCH detected", " on ", BrokerSymbol);
            }
            else if(EnableVerboseLogging)
            {
               Print("CHoCH candidate (", currentBullTrend ? "bullish" : "bearish", ") on ", BrokerSymbol,
                     " rejected - EMA flipped but structure didn't confirm with multi-swing validation.");
            }
         }
      }
   }

   // Cache this cycle's result for this symbol so every other caller this
   // tick (scoring, confluence, HTF confluence, snapshot, dashboard) reuses
   // it instead of re-triggering the once-per-bar gate above.
   if(idx < ArraySize(CHoCH_CacheCycleArr))
   {
      CHoCH_CacheCycleArr[idx]  = (long)g_CycleCounter;
      CHoCH_CacheResultArr[idx] = result;
   }

   return result;
}

//======================================================================//
//   ORDER BLOCK FRESH / MITIGATED / INVALIDATED TRACKING (NEW)         //
//======================================================================//
// DetectBullishOrderBlock()/DetectBearishOrderBlock() only ever examine the
// last 2 candles, so a caller a few bars later has no way to know whether
// a zone exists at all, is still fresh, has been tapped once (mitigated -
// still worth respecting once, but weaker the second time), or has been
// closed straight through (invalidated - shouldn't count as support/
// resistance anymore). This block gives the zone a persistent lifetime.

input double OB_InvalidationATRMultiple = 0.15; // how far price must close beyond the zone to count as a clean invalidating break, not just a wick poke

// Runs once per newly closed EntryTF bar per symbol. Detects a brand-new
// zone (overwriting the previous one of the same direction - only the most
// recent zone per direction is tracked), then updates mitigation/
// invalidation state for whichever zone is already active.
void UpdateOrderBlockTracking()
{
   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0 || idx >= ArraySize(OB_LastProcessedBarTimeArr))
      return;

   datetime currentBarTime = iTime(BrokerSymbol, EntryTF, 0);
   if(currentBarTime == OB_LastProcessedBarTimeArr[idx])
      return; // already processed this bar for this symbol

   OB_LastProcessedBarTimeArr[idx] = currentBarTime;

   double atr = GetFilterATR();
   double invalidationMargin = (atr > 0.0) ? (atr * OB_InvalidationATRMultiple) : 0.0;

   // --- Bullish zone ---
   if(DetectBullishOrderBlock())
   {
      // New impulse just confirmed - the base candle is bar 2.
      OB_Bull_TopArr[idx]      = iHigh(BrokerSymbol, EntryTF, 2);
      OB_Bull_BottomArr[idx]   = iLow(BrokerSymbol, EntryTF, 2);
      OB_Bull_BarTimeArr[idx]  = iTime(BrokerSymbol, EntryTF, 2);
      OB_Bull_ActiveArr[idx]   = true;
      OB_Bull_MitigatedArr[idx] = false;

      if(EnableVerboseLogging)
         Print("New bullish order block tracked on ", BrokerSymbol, ": ", OB_Bull_BottomArr[idx], " - ", OB_Bull_TopArr[idx]);
   }
   else if(OB_Bull_ActiveArr[idx])
   {
      double low1  = iLow(BrokerSymbol, EntryTF, 1);
      double close1 = iClose(BrokerSymbol, EntryTF, 1);

      // Invalidation first - a decisive close below the zone means it's no
      // longer valid demand and should stop scoring altogether.
      if(close1 < OB_Bull_BottomArr[idx] - invalidationMargin)
      {
         OB_Bull_ActiveArr[idx] = false;
         if(EnableVerboseLogging) Print("Bullish order block invalidated on ", BrokerSymbol);
      }
      // Otherwise, mitigation - price traded back into the zone (wicked or
      // closed into it) without invalidating it. Still respected, but a
      // second-touch zone is weaker than an untouched one.
      else if(low1 <= OB_Bull_TopArr[idx] && !OB_Bull_MitigatedArr[idx])
      {
         OB_Bull_MitigatedArr[idx] = true;
         if(EnableVerboseLogging) Print("Bullish order block mitigated (first tap) on ", BrokerSymbol);
      }
   }

   // --- Bearish zone ---
   if(DetectBearishOrderBlock())
   {
      OB_Bear_TopArr[idx]      = iHigh(BrokerSymbol, EntryTF, 2);
      OB_Bear_BottomArr[idx]   = iLow(BrokerSymbol, EntryTF, 2);
      OB_Bear_BarTimeArr[idx]  = iTime(BrokerSymbol, EntryTF, 2);
      OB_Bear_ActiveArr[idx]   = true;
      OB_Bear_MitigatedArr[idx] = false;

      if(EnableVerboseLogging)
         Print("New bearish order block tracked on ", BrokerSymbol, ": ", OB_Bear_BottomArr[idx], " - ", OB_Bear_TopArr[idx]);
   }
   else if(OB_Bear_ActiveArr[idx])
   {
      double high1  = iHigh(BrokerSymbol, EntryTF, 1);
      double close1 = iClose(BrokerSymbol, EntryTF, 1);

      if(close1 > OB_Bear_TopArr[idx] + invalidationMargin)
      {
         OB_Bear_ActiveArr[idx] = false;
         if(EnableVerboseLogging) Print("Bearish order block invalidated on ", BrokerSymbol);
      }
      else if(high1 >= OB_Bear_BottomArr[idx] && !OB_Bear_MitigatedArr[idx])
      {
         OB_Bear_MitigatedArr[idx] = true;
         if(EnableVerboseLogging) Print("Bearish order block mitigated (first tap) on ", BrokerSymbol);
      }
   }
}

// True only for a zone that is (a) currently tracked, (b) not invalidated,
// and (c) not yet mitigated - a genuinely fresh, untouched order block.
// This is what CalculatePRISMScore() now rewards instead of the old flat
// "was one detected on the last 2 candles" check.
bool IsOrderBlockFreshAndValid(bool buy)
{
   UpdateOrderBlockTracking();

   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0)
      return buy ? DetectBullishOrderBlock() : DetectBearishOrderBlock(); // fallback if symbol isn't tracked

   if(buy)
      return OB_Bull_ActiveArr[idx] && !OB_Bull_MitigatedArr[idx];
   else
      return OB_Bear_ActiveArr[idx] && !OB_Bear_MitigatedArr[idx];
}

// True for a zone that's still valid (not invalidated) but has already
// been tapped once - still usable context (e.g. for tighter stop
// placement or a lower-conviction re-entry), just not full-weight fresh
// supply/demand anymore.
bool IsOrderBlockMitigated(bool buy)
{
   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0) return false;

   if(buy)
      return OB_Bull_ActiveArr[idx] && OB_Bull_MitigatedArr[idx];
   else
      return OB_Bear_ActiveArr[idx] && OB_Bear_MitigatedArr[idx];
}


//======================================================================//
//   FAIR VALUE GAP MITIGATION TRACKING (NEW)                           //
//======================================================================//

// Runs once per newly closed bar per symbol - same pattern as order block
// tracking above. Tracks how much of the most recent gap in each direction
// has since been retraced, and drops it once fully filled.
void UpdateFVGTracking()
{
   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0 || idx >= ArraySize(FVG_LastProcessedBarTimeArr))
      return;

   datetime currentBarTime = iTime(BrokerSymbol, EntryTF, 0);
   if(currentBarTime == FVG_LastProcessedBarTimeArr[idx])
      return;

   FVG_LastProcessedBarTimeArr[idx] = currentBarTime;

   // --- Bullish gap: bottom = bar3 high, top = bar1 low (at time of formation) ---
   if(DetectBullishFVG())
   {
      FVG_Bull_BottomArr[idx]   = iHigh(BrokerSymbol, EntryTF, 3);
      FVG_Bull_TopArr[idx]      = iLow(BrokerSymbol, EntryTF, 1);
      FVG_Bull_BarTimeArr[idx]  = iTime(BrokerSymbol, EntryTF, 1);
      FVG_Bull_ActiveArr[idx]   = true;
      FVG_Bull_FilledPctArr[idx] = 0.0;
   }
   else if(FVG_Bull_ActiveArr[idx])
   {
      double low1 = iLow(BrokerSymbol, EntryTF, 1);
      double top = FVG_Bull_TopArr[idx];
      double bottom = FVG_Bull_BottomArr[idx];
      double range = top - bottom;

      if(range > 0.0 && low1 < top)
      {
         double filled = (top - MathMax(low1, bottom)) / range * 100.0;
         FVG_Bull_FilledPctArr[idx] = MathMax(FVG_Bull_FilledPctArr[idx], MathMin(filled, 100.0));
      }

      if(FVG_Bull_FilledPctArr[idx] >= 100.0)
         FVG_Bull_ActiveArr[idx] = false; // fully filled - no longer live imbalance
   }

   // --- Bearish gap: bottom = bar1 high, top = bar3 low (at time of formation) ---
   if(DetectBearishFVG())
   {
      FVG_Bear_BottomArr[idx]   = iHigh(BrokerSymbol, EntryTF, 1);
      FVG_Bear_TopArr[idx]      = iLow(BrokerSymbol, EntryTF, 3);
      FVG_Bear_BarTimeArr[idx]  = iTime(BrokerSymbol, EntryTF, 1);
      FVG_Bear_ActiveArr[idx]   = true;
      FVG_Bear_FilledPctArr[idx] = 0.0;
   }
   else if(FVG_Bear_ActiveArr[idx])
   {
      double high1 = iHigh(BrokerSymbol, EntryTF, 1);
      double top = FVG_Bear_TopArr[idx];
      double bottom = FVG_Bear_BottomArr[idx];
      double range = top - bottom;

      if(range > 0.0 && high1 > bottom)
      {
         double filled = (MathMin(high1, top) - bottom) / range * 100.0;
         FVG_Bear_FilledPctArr[idx] = MathMax(FVG_Bear_FilledPctArr[idx], MathMin(filled, 100.0));
      }

      if(FVG_Bear_FilledPctArr[idx] >= 100.0)
         FVG_Bear_ActiveArr[idx] = false;
   }
}

double GetFVGFilledPercent(bool buy)
{
   UpdateFVGTracking();

   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0) return 0.0;

   if(buy)
      return FVG_Bull_ActiveArr[idx] ? FVG_Bull_FilledPctArr[idx] : 100.0; // no active/tracked gap = treat as "nothing fresh to lean on"
   else
      return FVG_Bear_ActiveArr[idx] ? FVG_Bear_FilledPctArr[idx] : 100.0;
}

// UPGRADE: combines the existing ATR-scaled gap-size quality score with the
// mitigation state above - a large, untouched gap scores at full weight; a
// large gap that's already 80% filled back in is much weaker supporting
// evidence even though its raw size hasn't changed. This is what
// CalculatePRISMScore() now uses instead of calling the raw per-direction
// quality scorers directly.
int GetFVGQualityScore(bool buy)
{
   int baseScore = buy ? GetBullishFVGQualityScore() : GetBearishFVGQualityScore();
   if(baseScore <= 0)
      return 0;

   double filledPct = GetFVGFilledPercent(buy);
   double remainingFraction = MathMax(0.0, (100.0 - filledPct) / 100.0);

   return (int)MathRound(baseScore * remainingFraction);
}


//======================================================================//
//   FAKE BREAKOUT / TRAP / INDUCEMENT DETECTION (NEW)                  //
//======================================================================//
// Distinguishes "price is breaking out cleanly" from "price already tried
// this break recently and got rejected" - a classic inducement/stop-hunt
// pattern where retail breakout traders get trapped just before a reversal.
// Simplification, stated plainly: this reuses the CURRENT swing high/low
// as the reference level for the whole lookback window rather than
// recomputing the swing level bar-by-bar historically. On a fast-moving
// market the swing level can shift within the lookback window, which would
// under-count older trap attempts - an acceptable tradeoff for a cheap,
// stateless heuristic filter rather than a full historical structure replay.

input int FakeBreakoutLookbackBars = 5;

// STRENGTHENED (this pass): the old reversal check only required the close
// to be back on the wrong side of the level BY ANY AMOUNT, including a
// single point - indistinguishable from noise sitting right at the level.
// Now requires the reversal close to have retreated back past the level by
// a minimum ATR-scaled margin too, matching the same "decisive, not a
// hair" standard already used for BOS/sweep detection.
input double FakeBreakoutReversalATRMultiple = 0.05; // how far back past the level the reversal close must sit to count as a confirmed failed break, not just noise

bool DetectFakeBreakoutTrap(bool buy)
{
   double swingHigh = GetRecentHigh();
   double swingLow  = GetRecentLow();

   if(swingHigh == EMPTY_VALUE || swingLow == EMPTY_VALUE)
      return false;

   double atr = GetFilterATR();
   double margin = (atr > 0.0) ? (atr * BOS_MinBreakATRMultiple) : 0.0;
   double reversalMargin = (atr > 0.0) ? (atr * FakeBreakoutReversalATRMultiple) : 0.0;

   if(buy)
   {
      bool brokeAbove = false;
      for(int i = FakeBreakoutLookbackBars; i >= 2; i--)
      {
         if(iClose(BrokerSymbol, EntryTF, i) > swingHigh + margin) { brokeAbove = true; break; }
      }
      if(!brokeAbove)
         return false;

      // A break happened recently but the most recently closed bar has
      // decisively reclaimed the level, not just poked back below it by a
      // tick. That's a trap for anyone who bought the breakout, and a
      // warning sign against buying now too.
      return (iClose(BrokerSymbol, EntryTF, 1) < swingHigh - reversalMargin);
   }
   else
   {
      bool brokeBelow = false;
      for(int i = FakeBreakoutLookbackBars; i >= 2; i--)
      {
         if(iClose(BrokerSymbol, EntryTF, i) < swingLow - margin) { brokeBelow = true; break; }
      }
      if(!brokeBelow)
         return false;

      return (iClose(BrokerSymbol, EntryTF, 1) > swingLow + reversalMargin);
   }
}

//================ INDUCEMENT DETECTION (NEW) =========================//
// A trap (above) is the general "a breakout failed" pattern. Inducement is
// the specific SMC variant of that idea used as a POSITIVE signal for the
// opposite direction: a shallow, engineered-looking break of a minor level
// that reverses quickly, right before the real move develops the other
// way. Distinguished from the general trap by requiring the failed break
// to have been shallow (a small multiple of ATR beyond the level, not a
// deep push) AND to have reversed within a tight bar count - the "quick
// fakeout that shakes out early entries" signature, rather than a break
// that ran a long way before eventually failing.
input int InducementMaxBreakBars = 2;              // the failed break must reverse within this many bars to count as inducement (tighter than the general trap lookback)
input double InducementMaxDepthATRMultiple = 0.35; // the break beyond the level must stay shallower than this to look "engineered" rather than a genuine strong push

bool DetectInducement(bool reversalDirectionIsBuy)
{
   // reversalDirectionIsBuy = true means: sell-side liquidity was
   // induced/swept and we're now looking for the bullish reversal that
   // typically follows.
   double atr = GetFilterATR();
   if(atr <= 0.0)
      return false;

   double swingLow  = GetRecentLow();
   double swingHigh = GetRecentHigh();

   if(reversalDirectionIsBuy)
   {
      if(swingLow == EMPTY_VALUE)
         return false;

      for(int i = InducementMaxBreakBars; i >= 1; i--)
      {
         double lo = iLow(BrokerSymbol, EntryTF, i);
         double depth = swingLow - lo;

         if(depth > 0.0 && depth <= atr * InducementMaxDepthATRMultiple)
         {
            // Shallow break found - now check it has since reclaimed the
            // level decisively.
            if(iClose(BrokerSymbol, EntryTF, 1) > swingLow)
               return true;
         }
      }
      return false;
   }
   else
   {
      if(swingHigh == EMPTY_VALUE)
         return false;

      for(int i = InducementMaxBreakBars; i >= 1; i--)
      {
         double hi = iHigh(BrokerSymbol, EntryTF, i);
         double depth = hi - swingHigh;

         if(depth > 0.0 && depth <= atr * InducementMaxDepthATRMultiple)
         {
            if(iClose(BrokerSymbol, EntryTF, 1) < swingHigh)
               return true;
         }
      }
      return false;
   }
}

//+------------------------------------------------------------------+
//|              PART 13 - MULTI SYMBOL SCANNER                      |
//+------------------------------------------------------------------+

//================ SYMBOL SETTINGS ==================================//

input string TradeSymbols =
"EURUSD,GBPUSD,USDJPY,AUDUSD,USDCAD,XAUUSD,BTCUSD";

input group "MULTI-SYMBOL EXECUTION"

// UPGRADE - REAL MULTI-SYMBOL TRADING: TradeSymbols above used to be
// informational only - it preloaded symbols into Market Watch but the EA
// only ever traded BrokerSymbol (the chart's own symbol). With this on,
// the EA actually scans and trades every symbol in TradeSymbols (plus
// whatever chart it's attached to), each with its own indicators, its
// own cooldown/loss tracking, and its own non-scalp treatment where
// applicable (BTC/ETH still get the wider stops and longer holds, other
// symbols don't). Off by default so existing single-symbol setups are
// completely unaffected unless this is explicitly turned on.
//
// IMPORTANT MT5 CONSTRAINT: an EA only receives OnTick() for the symbol
// of the chart it's attached to - there's no way around that. To actually
// evaluate OTHER symbols in the list on a regular basis (not just when
// the chart's own symbol happens to tick), this also starts a timer
// (MultiSymbolTimerSeconds) that runs the same trading cycle on a fixed
// interval. The chart's own symbol gets checked on both real ticks AND
// the timer; every other symbol in the list is only checked via the timer.


//================ SYMBOL ARRAY =====================================//

string SymbolList[];


//================ INITIALIZE SYMBOLS ================================//

void InitializeSymbols()
{

   int count =
   StringSplit(
      TradeSymbols,
      ',',
      SymbolList
   );


   for(int i = 0; i < count; i++)
   {
      string sym = SymbolList[i];
      StringTrimLeft(sym);
      StringTrimRight(sym);

      bool selected = SymbolSelect(sym, true);

      // FIX: this loop never got the suffix auto-detection fix applied to
      // BuildMultiSymbolList() - a broker suffixing every symbol (e.g.
      // "XAUUSD.m" instead of "XAUUSD") made this log falsely report
      // "Symbol unavailable" for symbols that were actually fine, just
      // under a different exact name. Purely cosmetic (this loop doesn't
      // gate trading), but a false "unavailable" is still a real bug in
      // what it reports.
      if(!selected)
      {
         string variant = FindBrokerSymbolVariant(sym);

         if(variant != "" && SymbolSelect(variant, true))
         {
            sym = variant;
            selected = true;
         }
      }

      if(selected)
      {
         Print("Symbol enabled: ", sym);
      }
      else
      {
         Print("Symbol unavailable: ", sym);
      }

   }

   BuildMultiSymbolList();

}

//================ BUILD MULTI-SYMBOL LIST ============================//
// Constructs MultiSymbolList[] - always includes PrimarySymbol (the
// chart's own symbol) first, and additionally every symbol from
// TradeSymbols if EnableMultiSymbolTrading is on. With multi-symbol
// trading off, this ends up as a single-element array containing just the
// chart's symbol - functionally identical to how the EA behaved before
// any of this existed, just routed through the same array-based lookup
// used everywhere else now.

// FIX: this used to call SymbolSelect(sym, true) on the TradeSymbols entry
// exactly as typed - "EURUSD" - and skip it entirely if that exact name
// didn't exist. Many brokers (including the one in your screenshots -
// symbols show up as XAUUSD.m, BTCUSD.m, US30.std) suffix every symbol
// name, so "EURUSD" never matches anything and gets silently dropped,
// leaving MultiSymbolList with only the chart's own symbol regardless of
// how many symbols were listed in TradeSymbols. This is very likely why
// other symbols weren't opening at all. FindBrokerSymbolVariant() below
// scans every symbol the broker actually offers for one that STARTS WITH
// the requested name (case-insensitive) - "EURUSD" now matches
// "EURUSD.m", "EURUSDm", "EURUSD_i", or whatever suffix convention this
// specific broker uses, with no manual suffix configuration needed.

string FindBrokerSymbolVariant(string requestedName)
{
   string reqUpper = requestedName;
   StringToUpper(reqUpper);

   int total = SymbolsTotal(false); // false = every symbol the broker offers, not just Market Watch

   for(int i = 0; i < total; i++)
   {
      string candidate = SymbolName(i, false);
      string candUpper = candidate;
      StringToUpper(candUpper);

      if(StringFind(candUpper, reqUpper) == 0) // candidate starts with the requested name
         return candidate;
   }

   return ""; // genuinely not offered by this broker under any suffix
}

void BuildMultiSymbolList()
{
   ArrayResize(MultiSymbolList, 0);

   int n = ArraySize(MultiSymbolList);
   ArrayResize(MultiSymbolList, n + 1);
   MultiSymbolList[n] = PrimarySymbol;

   if(EnableMultiSymbolTrading)
   {
      for(int i = 0; i < ArraySize(SymbolList); i++)
      {
         string sym = SymbolList[i];
         StringTrimLeft(sym);
         StringTrimRight(sym);

         if(sym == "" || sym == PrimarySymbol)
            continue;

         bool selected = SymbolSelect(sym, true);

         if(!selected)
         {
            string variant = FindBrokerSymbolVariant(sym);

            if(variant != "" && variant != PrimarySymbol)
            {
               if(SymbolSelect(variant, true))
               {
                  Print("TradeSymbols entry '", sym, "' matched to broker symbol '", variant, "' (suffix auto-detected).");
                  sym = variant;
                  selected = true;
               }
            }
         }

         if(!selected)
         {
            Print("TradeSymbols entry '", sym, "' could not be matched to any symbol this broker offers - skipped.");
            continue;
         }

         // Guard against the auto-detected variant turning out to be a
         // duplicate already in the list (e.g. two TradeSymbols entries
         // both resolving to the same broker symbol).
         bool alreadyInList = false;

         for(int j = 0; j < ArraySize(MultiSymbolList); j++)
            if(MultiSymbolList[j] == sym) { alreadyInList = true; break; }

         if(alreadyInList)
            continue;

         n = ArraySize(MultiSymbolList);
         ArrayResize(MultiSymbolList, n + 1);
         MultiSymbolList[n] = sym;
      }
   }

   Print("Multi-symbol list built (", ArraySize(MultiSymbolList), " symbol[s]): ",
         EnableMultiSymbolTrading ? "multi-symbol trading ON" : "single-symbol mode");
}

//================ SYMBOL INDEX LOOKUP ================================//
// Every per-symbol array (indicator handles, cooldown tracking) is
// index-matched to MultiSymbolList - this finds the right index for
// whatever symbol BrokerSymbol currently points to.
// ALLTRADE56: exact → case-insensitive → base-prefix (EURUSD ↔ EURUSD.m)

string SymbolBaseName(string symbol)
{
   string s = symbol;
   StringToUpper(s);
   // Strip common broker suffixes (.m, .i, .pro, _m, etc.) for matching
   int dot = StringFind(s, ".");
   if(dot > 0)
      s = StringSubstr(s, 0, dot);
   int us = StringFind(s, "_");
   if(us > 3) // keep XAU_USD style; only strip trailing _m style if long
   {
      string tail = StringSubstr(s, us + 1);
      if(StringLen(tail) <= 3)
         s = StringSubstr(s, 0, us);
   }
   return s;
}

bool SymbolNamesMatch(string a, string b)
{
   if(a == b)
      return true;
   string au = a, bu = b;
   StringToUpper(au);
   StringToUpper(bu);
   if(au == bu)
      return true;
   string ab = SymbolBaseName(a);
   string bb = SymbolBaseName(b);
   return (ab != "" && ab == bb);
}

int GetSymbolIndex(string symbol)
{
   int n = ArraySize(MultiSymbolList);
   for(int i = 0; i < n; i++)
      if(MultiSymbolList[i] == symbol)
         return i;

   for(int j = 0; j < n; j++)
      if(SymbolNamesMatch(MultiSymbolList[j], symbol))
         return j;

   return -1;
}


// NOTE: this section used to also carry IsSymbolValid() and ScanMarkets() -
// helper functions for looping over TradeSymbols and printing their bid
// prices. Confirmed dead: neither is called from OnInit, OnTick, or
// anywhere else in the file. InitializeSymbols() above still runs (it
// pre-selects the symbols in TradeSymbols so they're visible in Market
// Watch), but the scan/validate step that would have used them for actual
// multi-symbol logic was never wired in. Removed rather than left as an
// unused dead end - if multi-symbol trading is built out later, this is
// where that logic would go.
//+------------------------------------------------------------------+
//|              PART 14 - ADVANCED RISK ENGINE                      |
//+------------------------------------------------------------------+

//================ INITIALIZE RISK =================================//

void InitializeRiskEngine()
{
   // Seed the real daily-loss reference balance (Part 5) immediately
   // instead of waiting for the first tick.
   UpdateDailyReferenceBalance();

   Print("Risk Engine Initialized");
}

//+------------------------------------------------------------------+
//|              PART 15b - MEAN-REVERSION STRATEGY (NEW)             |
//+------------------------------------------------------------------+
// ADDED: the existing SMC engine (BOS/CHoCH/FVG/Order Block/liquidity
// sweep, Part 12) is fundamentally a TREND-FOLLOWING/breakout model - it
// looks for structure breaking and continuing, which is exactly the kind
// of behavior that does NOT happen in a genuinely ranging market. Rather
// than force one model to handle both regimes, this adds a second,
// independent strategy: classic RSI + Bollinger Band mean-reversion,
// which specifically wants the OPPOSITE conditions the SMC engine wants
// (price stretched to an extreme, expected to revert, not continue).
// StrategyMode below controls which one actually trades; ADAPTIVE_REGIME
// (the default) uses GetMarketRegime() (Part 15) to hand entries to
// whichever model actually fits current conditions - SMC during
// REGIME_TRENDING, mean-reversion during REGIME_RANGING - rather than
// running a trend model through chop or a reversion model through a
// genuine trend.

enum ENUM_STRATEGY_MODE
{
   STRATEGY_PRISM   // P.R.I.S.M.: the Strategy Priority Engine (Trend Pullback + Liquidity Sweep + FVG/OB + structure-based Volatility Breakout), hard-gated only - no RSI/BB, no ATR-blocking, no additive score. This is now the EA's only strategy; the legacy SMC/mean-reversion/adaptive-regime/trend-following modes have been removed per request.
};

input group "STRATEGY SELECTION"

input ENUM_STRATEGY_MODE StrategyMode = STRATEGY_PRISM;

input group "MEAN-REVERSION STRATEGY"

input int    RSI_Period      = 14;
input double RSI_Oversold    = 30.0;
input double RSI_Overbought  = 70.0;
input int    BB_Period       = 20;
input double BB_Deviation    = 2.0;
input bool   MeanReversionRequireHTFAgreement = false; // if true, still requires HTFConfirms() in the reversion's direction - off by default since mean-reversion is intentionally counter-trend on the entry timeframe

double GetRSI()
{
   // RSI deliberately removed from the live PRISM stack (no MACD/Stoch either).
   // Kept as a stub so any legacy mean-reversion helper still compiles.
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0 || RSIHandlesArr[idx] == INVALID_HANDLE)
      return EMPTY_VALUE;

   if(idx < ArraySize(RSI_CacheCycleArr) && RSI_CacheCycleArr[idx] == (long)g_CycleCounter)
      return RSI_CacheValueArr[idx];

   double buf[];
   ArraySetAsSeries(buf, true);

   int need = SignalBarIndex() + 1;

   if(CopyBuffer(RSIHandlesArr[idx], 0, 0, need, buf) < need)
      return EMPTY_VALUE;

   double result = buf[SignalBarIndex()];

   if(idx < ArraySize(RSI_CacheCycleArr))
   {
      RSI_CacheCycleArr[idx] = (long)g_CycleCounter;
      RSI_CacheValueArr[idx] = result;
   }

   return result;
}

bool GetBollingerBands(double &upper, double &lower, double &mid)
{
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0 || BBHandlesArr[idx] == INVALID_HANDLE)
      return false;

   if(idx < ArraySize(BB_CacheCycleArr) && BB_CacheCycleArr[idx] == (long)g_CycleCounter)
   {
      upper = BB_CacheUpperArr[idx];
      lower = BB_CacheLowerArr[idx];
      mid   = BB_CacheMidArr[idx];
      return true;
   }

   double bufMid[], bufUpper[], bufLower[];
   ArraySetAsSeries(bufMid, true);
   ArraySetAsSeries(bufUpper, true);
   ArraySetAsSeries(bufLower, true);

   int need = SignalBarIndex() + 1;

   if(CopyBuffer(BBHandlesArr[idx], 0, 0, need, bufMid)   < need) return false; // BASE_LINE
   if(CopyBuffer(BBHandlesArr[idx], 1, 0, need, bufUpper) < need) return false; // UPPER_BAND
   if(CopyBuffer(BBHandlesArr[idx], 2, 0, need, bufLower) < need) return false; // LOWER_BAND

   int b = SignalBarIndex();
   mid   = bufMid[b];
   upper = bufUpper[b];
   lower = bufLower[b];

   if(idx < ArraySize(BB_CacheCycleArr))
   {
      BB_CacheCycleArr[idx]  = (long)g_CycleCounter;
      BB_CacheUpperArr[idx]  = upper;
      BB_CacheLowerArr[idx]  = lower;
      BB_CacheMidArr[idx]    = mid;
   }

   return true;
}

// Legacy helper only (not on PRISM path). RSI removed — BB stretch alone.
bool MeanReversionBuySetup()
{
   double upper, lower, mid;

   if(!GetBollingerBands(upper, lower, mid))
      return false;

   double price = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);

   if(price > lower)
      return false;

   if(MeanReversionRequireHTFAgreement && !HTFConfirms(true))
      return false;

   return true;
}

bool MeanReversionSellSetup()
{
   double upper, lower, mid;

   if(!GetBollingerBands(upper, lower, mid))
      return false;

   double price = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);

   if(price < upper)
      return false;

   if(MeanReversionRequireHTFAgreement && !HTFConfirms(false))
      return false;

   return true;
}

// Decides which model actually gets to trade this bar, per StrategyMode.
// Returns via out-parameters so InstantExecution() has one single call
// site regardless of which underlying model fired.
//+------------------------------------------------------------------+
//|      PART 15h - STRATEGY PRIORITY ENGINE (SPEC-COMPLIANT) (NEW)  |
//+------------------------------------------------------------------+
// ADDED to actually resolve the conflict between your architecture spec
// and the pre-existing code: the spec forbids ATR-blocking, RSI/BB
// standalone entries, and additive score-based trading - all three exist
// elsewhere in this file (legacy modes, kept for comparison, not deleted).
// This is the genuinely spec-compliant path: a structure-based volatility
// breakout (no ATR gate) plus a real priority engine that checks every
// spec-named strategy, rejects the bar outright if any two valid setups
// disagree on direction, and otherwise picks the one with the most
// independently-confirmed conditions - a tie-break RULE among already-
// fully-valid setups, not a score threshold that decides validity itself.
// Structure is still the boss: nothing here can turn an invalid setup
// into a valid one by accumulating points the way MinimumTradeScore does.

//+------------------------------------------------------------------+
//|   CRITICAL FIX (this pass): SAME-BAR COINCIDENCE BUG              |
//+------------------------------------------------------------------+
// DetectBOS(), DetectCHoCH(), DetectLiquiditySweep() and
// DetectBullish/BearishOrderBlock()/FVG() are each true for ONE bar only -
// the exact bar the event happens on. The PRISM strategy setups below were
// requiring several of these to all be true on that same single bar at
// once (e.g. LiquiditySweepBuySetup wanted a sweep AND a CHoCH AND a fresh
// order block all on one candle) - independent one-bar events essentially
// never coincide like that, which is why real setups were sitting blocked
// for very long stretches. These helpers give BOS/CHoCH/sweep a recency
// window (did it happen within the last few bars, not literally this
// bar), and route order block / FVG checks through the PERSISTENT
// fresh/mitigated/active trackers that already exist elsewhere in the file
// (IsOrderBlockFreshAndValid, FVG_Bull/Bear_ActiveArr) instead of their
// raw one-bar detectors. This is still genuine SMC confluence - sweep,
// then CHoCH, then a trade off the resulting order block, in that
// sequence over a few candles - just no longer requiring all of it to
// physically be the same candle, which was never how these patterns
// actually play out in real price action. Placed here (ahead of
// CountConfirmingConditions/CalculatePRISMScore/the strategy setups
// themselves) so every consumer - the scoring gate included - sees the
// same recency-tolerant picture instead of the scoring gate silently
// undercutting the setups' own fix with a stricter same-bar read.

input group "PRISM STRUCTURE RECENCY WINDOW"

input int PRISM_StructureRecencyBars = 15; // how many recent bars a BOS/CHoCH/sweep event stays "valid" for confluence purposes, instead of requiring the literal current bar


int EffectiveStructureRecency()
{
   if(EnableInstantSniperMode)
      return MathMax(PRISM_StructureRecencyBars, InstantStructureRecencyBars);
   return PRISM_StructureRecencyBars;
}

double EffectivePullbackATRMultiple()
{
   if(EnableInstantSniperMode)
      return MathMax(PullbackMaxATRMultiple, InstantPullbackATRMultiple);
   return PullbackMaxATRMultiple;
}

bool EventQualityModeActive(); // forward
bool PRIME_IsLiveTag(const string tag); // OK93 forward — Ultra live tags
void UltraCoreInit();
double GetWinRatePercent();
double GetProfitFactor();
double GetAverageRR();
bool QualityGatesActive();

int EffectiveMinimumMPIScore()
{
   // Instant open, quality prefer: MPI never gates entries (floor = 0).
   if(AggressiveInstantQuality || AggressiveInstitutionalExecution)
      return 0;

   if(EventQualityModeActive())
      return MathMax(EventQualityMPIScore, QualityMPIScore);
   if(EnableAlwaysQualityMode)
      return MathMax(QualityMPIScore, InstantMinimumMPIScore);
   if(NeverBlockValidSniperEntry)
      return 0;
   if(EnableInstantSniperMode)
      return MathMin(MinimumMPIScore, InstantMinimumMPIScore);
   return MinimumMPIScore;
}

// Shared calendar currency resolver — used by news hard-block + event quality.
void PRISM_GetSymbolCurrencies(string &baseCcy, string &quoteCcy)
{
   baseCcy = StringSubstr(BrokerSymbol, 0, 3);
   if(StringLen(BrokerSymbol) >= 6)
      quoteCcy = StringSubstr(BrokerSymbol, 3, 3);
   else
      quoteCcy = StringSubstr(BrokerSymbol, StringLen(BrokerSymbol) - 3, 3);
}

bool PRISM_CalendarCurrencyRelevant(const string eventCurrency,
                                    const string baseCcy,
                                    const string quoteCcy,
                                    const bool cryptoUsd)
{
   return (eventCurrency == baseCcy) ||
          (eventCurrency == quoteCcy) ||
          (cryptoUsd && eventCurrency == "USD");
}

// High-impact event window detector — does NOT block trading.
// Used only to switch into quality-sniper mode (CPI/NFP/FOMC, etc.).
bool IsHighImpactEventWindow()
{
   string baseCcy, quoteCcy;
   PRISM_GetSymbolCurrencies(baseCcy, quoteCcy);

   bool cryptoUsd = (EventQualityAppliesToCrypto && IsNonScalpSymbol() &&
                     (StringFind(BrokerSymbol, "USD") >= 0 || quoteCcy == "USD"));

   datetime from = TimeCurrent() - EventMinutesAfterNews  * 60;
   datetime to   = TimeCurrent() + EventMinutesBeforeNews * 60;

   MqlCalendarValue values[];
   int total = CalendarValueHistory(values, from, to, NULL, NULL);
   if(total <= 0)
      return false;

   for(int i = 0; i < total; i++)
   {
      MqlCalendarEvent event;
      if(!CalendarEventById(values[i].event_id, event))
         continue;
      if(event.importance != CALENDAR_IMPORTANCE_HIGH)
         continue;

      MqlCalendarCountry country;
      if(!CalendarCountryById(event.country_id, country))
         continue;

      if(PRISM_CalendarCurrencyRelevant(country.currency, baseCcy, quoteCcy, cryptoUsd))
         return true;
   }
   return false;
}

ulong g_EventQualityCycle = 0;
bool  g_EventQualityCached = false;

bool EventQualityModeActive()
{
   return false; // OK67: news awareness must never tighten/block via EventQuality
}

// Regular sessions + events: quality gates stay on when AlwaysQuality is enabled.
bool QualityGatesActive()
{
   return EnableAlwaysQualityMode || EventQualityModeActive();
}

bool QualityWeakPathsDisabled()
{
   if(EventQualityModeActive() && EventDisableWeakPaths)
      return true;
   if(EnableAlwaysQualityMode && QualityDisableWeakPaths)
      return true;
   return false;
}

bool QualityNeedsStructureZone()
{
   if(EventQualityModeActive())
      return EventRequireStructureZone;
   if(EnableAlwaysQualityMode)
      return QualityRequireStructureZone;
   return false;
}

bool QualityNeedsTrendAndADX()
{
   if(EventQualityModeActive())
      return EventRequireTrendAndADX;
   if(EnableAlwaysQualityMode)
      return QualityRequireTrendAndADX;
   return false;
}

// InstantTrend is intentionally weak — off under quality mode.
bool InstantTrendSniperBuySetup()
{
   if(BestPathsOnly)
      return false; // BEST-NEXT48: Cont/Rev only
   if(!EnableInstantSniperMode || !AllowTrendOnlyInstantEntry)
      return false;
   // Aggressive institutional execution: InstantTrend stays alive.
   // Only suppress when user explicitly disables weak paths AND not in aggressive mode.
   if(QualityWeakPathsDisabled() && !AggressiveInstitutionalExecution)
      return false;
   if(!IsBullTrend())
      return false;
   if(!TrendStrong())
      return false;
   return true;
}

bool InstantTrendSniperSellSetup()
{
   if(BestPathsOnly)
      return false; // BEST-NEXT48: Cont/Rev only
   if(!EnableInstantSniperMode || !AllowTrendOnlyInstantEntry)
      return false;
   if(QualityWeakPathsDisabled() && !AggressiveInstitutionalExecution)
      return false;
   if(!IsBearTrend())
      return false;
   if(!TrendStrong())
      return false;
   return true;
}

bool RecentBOS(int lookbackBars)
{
   if(DetectBOS())
      return true;

   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0 || idx >= ArraySize(LastBOSTrueBarTimeArr) || LastBOSTrueBarTimeArr[idx] <= 0)
      return false;

   int bars = iBarShift(BrokerSymbol, EntryTF, LastBOSTrueBarTimeArr[idx]);
   return (bars >= 0 && bars <= lookbackBars);
}

bool RecentCHoCH(int lookbackBars)
{
   if(DetectCHoCH())
      return true;

   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0 || idx >= ArraySize(LastCHoCHTrueBarTimeArr) || LastCHoCHTrueBarTimeArr[idx] <= 0)
      return false;

   int bars = iBarShift(BrokerSymbol, EntryTF, LastCHoCHTrueBarTimeArr[idx]);
   return (bars >= 0 && bars <= lookbackBars);
}

// AUDITFIX49: CHoCH reclaim must match trade direction (bull CHoCH for BUY, bear for SELL)
bool RecentDirectionalCHoCH(const bool buy, const int lookbackBars)
{
   if(!RecentCHoCH(lookbackBars))
      return false;

   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0 || idx >= ArraySize(LastCHoCHWasBullArr))
   {
      // Fallback: require live EMA side if direction history missing
      return buy ? IsBullTrend() : IsBearTrend();
   }

   // If CHoCH is firing THIS cycle, DetectCHoCH already set LastCHoCHWasBullArr
   return buy ? LastCHoCHWasBullArr[idx] : !LastCHoCHWasBullArr[idx];
}

bool RecentSweep(int lookbackBars)
{
   if(DetectLiquiditySweep())
      return true;

   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0 || idx >= ArraySize(LastSweepTrueBarTimeArr) || LastSweepTrueBarTimeArr[idx] <= 0)
      return false;

   int bars = iBarShift(BrokerSymbol, EntryTF, LastSweepTrueBarTimeArr[idx]);
   return (bars >= 0 && bars <= lookbackBars);
}

// Order blocks: use the persistent fresh-OR-mitigated state (still an
// active, non-invalidated zone) rather than the raw one-bar detector -
// this is exactly what IsOrderBlockFreshAndValid()/IsOrderBlockMitigated()
// were already built for, just not actually wired into the live PRISM
// strategies before this fix.
bool ActiveOrderBlock(bool buy)
{
   return IsOrderBlockFreshAndValid(buy) || IsOrderBlockMitigated(buy);
}

// FVGs: same idea, using the persistent Active tracker (drops to false
// once the gap is fully filled/mitigated - see UpdateFVGTracking()).
bool ActiveFVG(bool buy)
{
   UpdateFVGTracking();

   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0)
      return buy ? DetectBullishFVG() : DetectBearishFVG();

   return buy ? FVG_Bull_ActiveArr[idx] : FVG_Bear_ActiveArr[idx];
}

// Path A quality continuation: trend (+ADX) + SAME-DIRECTION structure (BOS/OB/FVG).
bool AggressiveContinuationBuySetup()
{
   if(!AggressiveSniperEntries)
      return false;
   if(!IsBullTrend())
      return false;

   double ema = GetEMA();
   double atr = GetFilterATR();
   double price = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);
   bool pulled = (ema != EMPTY_VALUE && atr > 0.0 &&
                  MathAbs(price - ema) <= atr * EffectivePullbackATRMultiple());
   // SIGNAL OK45: Cont BUY needs bullish BOS — not any-direction DetectBOS/RecentBOS
   bool bos = StructureDirectionalBOS(true);
   bool zone = ActiveOrderBlock(true) || ActiveFVG(true);

   if(QualityGatesActive())
   {
      if(QualityNeedsTrendAndADX() && !TrendStrong())
         return false;
      // BEST/SAFE: Cont needs real structure (BOS or OB/FVG) — pullback alone is not enough
      if(BestQualitySetups || QualityNeedsStructureZone())
      {
         if(!(zone || bos))
            return false;
         return true;
      }
      // Legacy aggressive: trend+ADX enough
      if(AggressiveInstitutionalExecution)
         return true;
      if(QualityNeedsStructureZone() && !(zone || bos))
         return false;
      return true;
   }

   return bos || zone || pulled || TrendStrong();
}

bool AggressiveContinuationSellSetup()
{
   if(!AggressiveSniperEntries)
      return false;
   if(!IsBearTrend())
      return false;

   double ema = GetEMA();
   double atr = GetFilterATR();
   double price = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);
   bool pulled = (ema != EMPTY_VALUE && atr > 0.0 &&
                  MathAbs(price - ema) <= atr * EffectivePullbackATRMultiple());
   // SIGNAL OK45: Cont SELL needs bearish BOS — not any-direction DetectBOS/RecentBOS
   bool bos = StructureDirectionalBOS(false);
   bool zone = ActiveOrderBlock(false) || ActiveFVG(false);

   if(QualityGatesActive())
   {
      if(QualityNeedsTrendAndADX() && !TrendStrong())
         return false;
      if(BestQualitySetups || QualityNeedsStructureZone())
      {
         if(!(zone || bos))
            return false;
         return true;
      }
      if(AggressiveInstitutionalExecution)
         return true;
      if(QualityNeedsStructureZone() && !(zone || bos))
         return false;
      return true;
   }

   return bos || zone || pulled || TrendStrong();
}

// Path B — CORRECT MARKET REVERSAL sniper (signals only when stack is right).
// BUY  = sell-side liquidity swept (lows) more recently than highs + bullish zone + strong reclaim
// SELL = buy-side liquidity swept (highs) more recently than lows + bearish zone + strong reclaim
// Rejects wrong-side/continuation traps and weak candle-only reclaim.
bool AggressiveReversalBuySetup()
{
   if(!AggressiveSniperEntries)
      return false;

   string detail = "";
   bool ok = MarketReversalSignalOK(true, detail);
   if(ReversalLogValidation && (EnableVerboseLogging || EnableSetupLogging))
      Print("REV VALIDATE BUY: ", (ok ? "PASS" : "FAIL"), " — ", detail, " on ", BrokerSymbol);
   return ok;
}

bool AggressiveReversalSellSetup()
{
   if(!AggressiveSniperEntries)
      return false;

   string detail = "";
   bool ok = MarketReversalSignalOK(false, detail);
   if(ReversalLogValidation && (EnableVerboseLogging || EnableSetupLogging))
      Print("REV VALIDATE SELL: ", (ok ? "PASS" : "FAIL"), " — ", detail, " on ", BrokerSymbol);
   return ok;
}

input group "SPEC-COMPLIANT VOLATILITY BREAKOUT"

input int SpecBreakout_ChannelLookbackBars = 20; // structure reference: recent N-bar high/low channel, same channel logic as the legacy version, just without the ATR-expansion gate

bool SpecVolatilityBreakoutBuySetup()
{
   // BEST QUALITY: suppress weak channel breakouts (Cont/Rev preferred)
   if(BestQualitySetups && QualityDisableWeakPaths)
      return false;
   if(QualityWeakPathsDisabled() && !AggressiveInstitutionalExecution)
      return false;

   if(!TrendStrong())
      return false;

   double channelHigh = GetChannelHigh(SpecBreakout_ChannelLookbackBars);
   if(channelHigh <= 0.0)
      return false;

   double closeBar = iClose(BrokerSymbol, EntryTF, SignalBarIndex());
   if(EnableInstantSniperMode)
   {
      double atr = GetFilterATR();
      double pad = (atr > 0.0 ? atr * InstantChannelBreakATR : 0.0);
      return (closeBar >= channelHigh - pad);
   }
   return (closeBar > channelHigh);
}

bool SpecVolatilityBreakoutSellSetup()
{
   if(BestQualitySetups && QualityDisableWeakPaths)
      return false;
   if(QualityWeakPathsDisabled() && !AggressiveInstitutionalExecution)
      return false;

   if(!TrendStrong())
      return false;

   double channelLow = GetChannelLow(SpecBreakout_ChannelLookbackBars);
   if(channelLow <= 0.0)
      return false;

   double closeBar = iClose(BrokerSymbol, EntryTF, SignalBarIndex());
   if(EnableInstantSniperMode)
   {
      double atr = GetFilterATR();
      double pad = (atr > 0.0 ? atr * InstantChannelBreakATR : 0.0);
      return (closeBar <= channelLow + pad);
   }
   return (closeBar < channelLow);
}

bool IsDuplicateSignal(bool buy);
void MarkSignalApproved(bool buy);

//================ PRISM BEAST: UNIFIED STRUCTURE SNAPSHOT ============//
// Single structure read shared by MPI, ICE, and path ranking — eliminates
// 3-5 duplicate BOS/CHoCH/sweep calls per bar.
// (struct PRISMStructureSnapshot declared near SignalSnapshot above)

//================ PRISM ULTRA CORE v11 — CACHE / BEAST SCORE / SNIPER =//
// Design goals: zero redundant calc, explainable rejects, sniper quality,
// aggressive fire ONLY after approval. One structure + beast score per cycle.

ulong  g_UltraStructCycleBuy  = 0;
ulong  g_UltraStructCycleSell = 0;
string g_UltraStructSymbolBuy  = "";
string g_UltraStructSymbolSell = "";
PRISMStructureSnapshot g_UltraStructBuy;
PRISMStructureSnapshot g_UltraStructSell;

ulong  g_UltraBeastCycleBuy  = 0;
ulong  g_UltraBeastCycleSell = 0;
string g_UltraBeastSymbolBuy  = "";
string g_UltraBeastSymbolSell = "";
string g_UltraBeastTagBuy  = "";
string g_UltraBeastTagSell = "";

string g_UltraLastReject = "";
string g_UltraLastDecision = "IDLE";
string g_UltraLastGrade = "-";
int    g_UltraLastBeastScore = 0;
int    g_UltraLastConfidencePct = 0;
long   g_UltraLastDecisionMs = 0;
long   g_UltraDecisionStartMs = 0;
double g_UltraLastBid = 0.0;
double g_UltraLastAsk = 0.0;
int    g_UltraHealthOK = 1;
int    g_UltraRejectCount = 0;
int    g_UltraApproveCount = 0;

struct PRISMBeastScore
{
   int context;
   int htf;
   int structure;
   int liquidity;
   int smt;
   int bos;
   int choch;
   int orderBlock;
   int fvg;
   int premiumDiscount;
   int momentum;
   int confirmation;
   int executionQuality;
   int institutional;
   int trendStrength;
   int reversalProb;
   int volatility;
   int newsStability;
   int overall;
   int confidencePct;
};

PRISMBeastScore g_UltraBeastBuy;
PRISMBeastScore g_UltraBeastSell;

string g_UltraLastRejectPrinted = "";
datetime g_UltraLastRejectBar = 0;

void UltraSetReject(const string reason)
{
   g_UltraLastReject = reason;
   g_UltraLastDecision = "REJECT";
   g_UltraRejectCount++;

   // Throttle: same reason on same symbol prints at most once per EntryTF bar.
   // Cooldown / wait states must NOT flood Experts (your 17:38 spam).
   if(!(EnableUltraCore && UltraLogRejectReasons && (EnableVerboseLogging || EnableSetupLogging)))
      return;

   datetime bar = iTime(BrokerSymbol, EntryTF, 0);
   string key = BrokerSymbol + "|" + reason;
   if(bar == g_UltraLastRejectBar && key == g_UltraLastRejectPrinted)
      return;

   g_UltraLastRejectBar = bar;
   g_UltraLastRejectPrinted = key;
   Print("ULTRA REJECT: ", reason, " on ", BrokerSymbol);
}

void UltraSetWait(const string reason)
{
   // Silent wait (cooldown / final-check) — updates HUD state, no Experts spam.
   g_UltraLastReject = reason;
   g_UltraLastDecision = "WAIT";
}

void UltraSetApprove(const string tag, const string grade, const int beast, const int confPct)
{
   g_UltraLastDecision = "APPROVE " + tag;
   g_UltraLastGrade = grade;
   g_UltraLastBeastScore = beast;
   g_UltraLastConfidencePct = confPct;
   g_UltraLastReject = "";
   g_UltraApproveCount++;
}

PRISMStructureSnapshot PRISM_GetStructureSnapshot(bool buy, int recency)
{
   if(EnableUltraCore && UltraCycleCache)
   {
      if(buy && g_UltraStructCycleBuy == g_CycleCounter && g_UltraStructSymbolBuy == BrokerSymbol)
         return g_UltraStructBuy;
      if(!buy && g_UltraStructCycleSell == g_CycleCounter && g_UltraStructSymbolSell == BrokerSymbol)
         return g_UltraStructSell;
   }

   PRISMStructureSnapshot s;
   s.rec = (recency >= 0 ? recency : EffectiveStructureRecency());
   // BUGCLEAN46: ICE/MPI snapshot must be SAME-DIRECTION — not any-side BOS/sweep
   s.bos = StructureDirectionalBOS(buy);
   // AUDITFIX49: directional CHoCH in snapshot (HP/ICE polarity)
   s.choch = RecentDirectionalCHoCH(buy, s.rec);
   s.sweep = RecentDirectionalSweep(buy, s.rec);
   s.ob = ActiveOrderBlock(buy);
   s.fvg = ActiveFVG(buy);
   s.trend = (buy ? IsBullTrend() : IsBearTrend());
   s.trendStrong = TrendStrong();
   s.htfConfirms = HTFConfirms(buy);

   if(EnableUltraCore && UltraCycleCache)
   {
      if(buy)
      {
         g_UltraStructBuy = s;
         g_UltraStructCycleBuy = g_CycleCounter;
         g_UltraStructSymbolBuy = BrokerSymbol;
      }
      else
      {
         g_UltraStructSell = s;
         g_UltraStructCycleSell = g_CycleCounter;
         g_UltraStructSymbolSell = BrokerSymbol;
      }
   }
   return s;
}

enum ENUM_IMCE_CONTEXT
{
   IMCE_TREND_CONTINUATION = 0,
   IMCE_REVERSAL_LIQUIDITY = 1,
   IMCE_EXPANSION_BREAKOUT = 2,
   IMCE_MANIPULATION_CHOP  = 3,
   IMCE_NEUTRAL            = 4
};

struct PRISM_MarketIntel
{
   MarketRegime regime;
   ENUM_IMCE_CONTEXT imce;
   bool eventWindow;
   bool volExpanding;
   bool dailyBullBias;
   bool weeklyBullBias;
   bool htfBull;
};

ENUM_IMCE_CONTEXT GetIMCEContext();
string IMCEContextToString(ENUM_IMCE_CONTEXT ctx);
PRISM_MarketIntel PRISM_GetMarketIntel(bool buy);
bool PRISMReversalQualityOK(bool buy);
bool SMTInternalBullish();
bool SMTInternalBearish();
bool SMTCrossAssetBullish();
bool SMTCrossAssetBearish();
bool PRISM_IsReversalTag(const string tag);
bool PRISM_IsContinuationTag(const string tag);
int GetInstitutionalConfidenceScore(bool buy);
int CalculatePRISMScore(bool buy);
int CountConfirmingConditions(bool buy);
int GetDisplacementScore(bool buy);

int UltraSMTScore(bool buy, const string strategyTag)
{
   if(!EnableSMT) return 5;
   if(PRISM_IsContinuationTag(strategyTag) && !SMTBlockContinuationPaths)
      return 8;
   if(buy ? SMTInternalBullish() : SMTInternalBearish())
      return 15;
   if(StringLen(SMTReferenceSymbol) > 0)
   {
      if(buy ? SMTCrossAssetBullish() : SMTCrossAssetBearish())
         return 18;
   }
   if(PRISM_IsReversalTag(strategyTag))
      return 0;
   return 6;
}

PRISMBeastScore UltraComputeBeastScore(bool buy, const string strategyTag)
{
   PRISMBeastScore b;
   b.context = 0;
   b.htf = 0;
   b.structure = 0;
   b.liquidity = 0;
   b.smt = 0;
   b.bos = 0;
   b.choch = 0;
   b.orderBlock = 0;
   b.fvg = 0;
   b.premiumDiscount = 0;
   b.momentum = 0;
   b.confirmation = 0;
   b.executionQuality = 0;
   b.institutional = 0;
   b.trendStrength = 0;
   b.reversalProb = 0;
   b.volatility = 0;
   b.newsStability = 0;
   b.overall = 0;
   b.confidencePct = 0;

   PRISMStructureSnapshot s = PRISM_GetStructureSnapshot(buy);
   PRISM_MarketIntel intel = PRISM_GetMarketIntel(buy);
   int ice = GetInstitutionalConfidenceScore(buy);
   int mpi = CalculatePRISMScore(buy);
   int conf = CountConfirmingConditions(buy);
   int liqQ = GetLiquiditySweepQualityScore();
   int disp = GetDisplacementScore(buy);

   // Context (0-10)
   if(intel.imce == IMCE_TREND_CONTINUATION || intel.imce == IMCE_EXPANSION_BREAKOUT) b.context = 10;
   else if(intel.imce == IMCE_REVERSAL_LIQUIDITY) b.context = 8;
   else if(intel.imce == IMCE_NEUTRAL) b.context = 5;
   else b.context = 2;

   // HTF / Daily-Weekly bias (0-10)
   b.htf = 0;
   if(s.htfConfirms) b.htf += 5;
   if(buy ? intel.dailyBullBias : !intel.dailyBullBias) b.htf += 3;
   if(buy ? intel.weeklyBullBias : !intel.weeklyBullBias) b.htf += 2;
   if(b.htf > 10) b.htf = 10;

   // Structure (0-10)
   b.structure = 0;
   if(s.bos) b.structure += 4;
   if(s.choch) b.structure += 4;
   if(s.trend) b.structure += 2;
   if(b.structure > 10) b.structure = 10;

   b.bos = s.bos ? 8 : 0;
   b.choch = s.choch ? 8 : 0;
   b.orderBlock = s.ob ? (IsOrderBlockFreshAndValid(buy) ? 10 : 5) : 0;
   b.fvg = s.fvg ? MathMin((int)MathRound(GetFVGQualityScore(buy) / 2.0), 10) : 0;

   b.liquidity = MathMin(liqQ, 15);
   if(GetLiquidityProximityScore(buy) > 0) b.liquidity = MathMin(b.liquidity + 3, 15);

   b.smt = UltraSMTScore(buy, strategyTag);
   if(b.smt > 15) b.smt = 15;

   b.premiumDiscount = (buy ? InDiscountZone() : InPremiumZone()) ? 8 : 2;
   b.momentum = (intel.volExpanding ? 8 : 3) + MathMin(disp, 7);
   if(b.momentum > 15) b.momentum = 15;

   b.confirmation = MathMin(conf * 2, 12);
   b.executionQuality = (GetFilterATR() > 0.0) ? 8 : 0;
   double spr = (double)UltraSymSpread(BrokerSymbol);
   if(spr > 0 && spr < 50) b.executionQuality += 2;

   b.institutional = MathMin(ice / 8, 12);
   b.trendStrength = (s.trend ? 5 : 0) + (s.trendStrong ? 5 : 0);

   // Reversal probability — high only when stack is real
   b.reversalProb = 0;
   if(PRISM_IsReversalTag(strategyTag))
   {
      if(s.sweep && (s.choch || s.ob || s.fvg)) b.reversalProb = 12;
      else if(s.sweep) b.reversalProb = 5;
      if(DetectFakeBreakoutTrap(buy)) b.reversalProb = MathMax(0, b.reversalProb - 8);
   }
   else if(s.trend && s.trendStrong)
      b.reversalProb = 3; // continuation preferred

   b.volatility = intel.volExpanding ? 8 : (IsVolatilityContracting() ? 3 : 5);
   b.newsStability = intel.eventWindow ? 4 : 8;

   b.overall =
      b.context + b.htf + b.structure + b.liquidity + b.smt +
      b.bos + b.choch + b.orderBlock + b.fvg + b.premiumDiscount +
      b.momentum + b.confirmation + b.executionQuality + b.institutional +
      b.trendStrength + b.reversalProb + b.volatility + b.newsStability;

   // Normalize confidence % from overall (typical max ~180)
   b.confidencePct = (int)MathRound(100.0 * (double)b.overall / 180.0);
   if(b.confidencePct > 100) b.confidencePct = 100;
   if(b.confidencePct < 0) b.confidencePct = 0;

   // Fold MPI lightly so Beast aligns with existing quality floor
   if(mpi > 0)
      b.confidencePct = MathMin(100, (b.confidencePct + MathMin(mpi, 40)) / 2 + 20);

   return b;
}

PRISMBeastScore UltraGetBeastScore(bool buy, const string strategyTag)
{
   if(EnableUltraCore && UltraCycleCache)
   {
      if(buy && g_UltraBeastCycleBuy == g_CycleCounter &&
         g_UltraBeastSymbolBuy == BrokerSymbol && g_UltraBeastTagBuy == strategyTag)
         return g_UltraBeastBuy;
      if(!buy && g_UltraBeastCycleSell == g_CycleCounter &&
         g_UltraBeastSymbolSell == BrokerSymbol && g_UltraBeastTagSell == strategyTag)
         return g_UltraBeastSell;
   }

   PRISMBeastScore b = UltraComputeBeastScore(buy, strategyTag);

   if(EnableUltraCore && UltraCycleCache)
   {
      if(buy)
      {
         g_UltraBeastBuy = b;
         g_UltraBeastCycleBuy = g_CycleCounter;
         g_UltraBeastSymbolBuy = BrokerSymbol;
         g_UltraBeastTagBuy = strategyTag;
      }
      else
      {
         g_UltraBeastSell = b;
         g_UltraBeastCycleSell = g_CycleCounter;
         g_UltraBeastSymbolSell = BrokerSymbol;
         g_UltraBeastTagSell = strategyTag;
      }
   }
   return b;
}

// Sniper Entry Engine — BEST QUALITY checklist.
// Cont/Rev: structure already in path setup; HP confirmations HARD when BestQualitySetups.
// InstantTrend: Beast/Conf floors HARD; soft gates OFF by default.
// UltraAggressiveFire still means: once quality+engines pass → fire immediately.
bool UltraSniperEntryOK(bool buy, const string strategyTag, string &failReason)
{
   failReason = "";
   if(!EnableUltraCore || !UltraSniperEntryGate)
      return true;

   PRISMBeastScore beast = UltraGetBeastScore(buy, strategyTag);
   bool soft = (UltraInstantTrendSoftGates && strategyTag == "InstantTrend" && !BestQualitySetups);
   bool revTag = PRISM_IsReversalTag(strategyTag);
   bool aggro = UltraAggressiveFire || NeverBlockValidSniperEntry || AggressiveInstantQuality;
   bool lcsTag = (strategyTag == "LCS");
   bool apexTag = (strategyTag == "APEX" || PRIME_IsLiveTag(strategyTag));

   if(GetFilterATR() <= 0.0)
   {
      // ALLTRADE56: Cont/Rev/LCS/APEX already selected — Execute uses fixed-stop fallback.
      if((strategyTag == "ContSniper" || strategyTag == "RevSniper" || strategyTag == "ContFallback" || lcsTag || apexTag) &&
         (NeverBlockValidSniperEntry || UltraAggressiveFire))
      {
         if(EnableVerboseLogging || EnableSetupLogging)
            Print("ATR soft: unavailable on ", BrokerSymbol,
                  " — allowing ", strategyTag, " (fixed SL fallback in Execute)");
      }
      else
      {
         failReason = "risk: ATR unavailable";
         return false;
      }
   }

   // APEX / LCS / ContFallback already passed — NEVER post-FIRE veto
   if(apexTag)
   {
      Print("ULTRA APEX PASS (no post-FIRE veto) on ", BrokerSymbol, " — ", g_APEX_LastDetail);
      return true;
   }
   if(strategyTag == "ContFallback")
   {
      Print("ULTRA CONT FALLBACK PASS (execute) on ", BrokerSymbol, " ", (buy ? "BUY" : "SELL"));
      return true;
   }
   if(lcsTag && (NeverBlockValidSniperEntry || UltraAggressiveFire || !UltraSniperEntryGate))
   {
      if(EnableVerboseLogging || EnableSetupLogging)
         Print("ULTRA LCS PASS on ", BrokerSymbol, " — ", g_LCS_LastDetail);
      return true;
   }

   // CONTFIRE55: Cont/Rev already passed path setups + ICE/IMCE before FIRE.
   // Post-FIRE HP confirm veto was killing A+ ContSniper with silent/throttled
   // ULTRA REJECT — Journal showed FIRE then nothing / no fill.
   // NeverBlockValidSniperEntry / UltraAggressiveFire → HP is informational only.
   if(BestQualitySetups && UltraHP_MinConfirmations > 0 &&
      (strategyTag == "ContSniper" || strategyTag == "RevSniper"))
   {
      int conf = CountConfirmingConditions(buy);
      if(conf < UltraHP_MinConfirmations)
      {
         if(NeverBlockValidSniperEntry || UltraAggressiveFire || AggressiveInstantQuality)
         {
            if(EnableVerboseLogging || EnableSetupLogging)
               Print("HP soft: confirms ", conf, "/", UltraHP_MinConfirmations,
                     " on ", strategyTag, " ", BrokerSymbol,
                     " — allowing (NeverBlock/AggressiveFire, path already selected)");
         }
         else
         {
            failReason = StringFormat("HP quality: confirms %d < %d", conf, UltraHP_MinConfirmations);
            return false;
         }
      }
   }

   // InstantTrend: always apply score floors under BestQuality (fallback only if strong)
   if(strategyTag == "InstantTrend" && BestQualitySetups)
   {
      if(UltraMinBeastScore > 0 && beast.overall < UltraMinBeastScore)
      {
         failReason = "InstantTrend Beast " + IntegerToString(beast.overall) +
                      " < floor " + IntegerToString(UltraMinBeastScore);
         return false;
      }
      if(UltraMinConfidencePct > 0 && beast.confidencePct < UltraMinConfidencePct)
      {
         failReason = "InstantTrend Conf " + IntegerToString(beast.confidencePct) +
                      "% < floor " + IntegerToString(UltraMinConfidencePct);
         return false;
      }
      if(!TrendStrong())
      {
         failReason = "InstantTrend: trend not strong enough for quality fallback";
         return false;
      }
      // SAFE42: HTF confirm before Instant early-return (was dead code after aggro return)
      PRISMStructureSnapshot sIT = PRISM_GetStructureSnapshot(buy);
      if(!sIT.htfConfirms)
      {
         failReason = "InstantTrend: HTF not confirming";
         return false;
      }
   }

   // SAFE42: only ContSniper gets early Ultra pass — not TrendPullback/FVG+OB/VolBreakout
   if(strategyTag == "ContSniper" && aggro)
   {
      if(EnableVerboseLogging || EnableSetupLogging)
         Print("ULTRA QUALITY PASS ContSniper Beast=", beast.overall,
               " Conf=", beast.confidencePct, "% HP=ON on ", BrokerSymbol);
      return true;
   }

   // InstantTrend aggro pass only if BestQuality floors already cleared above
   if(strategyTag == "InstantTrend" && aggro && !BestQualitySetups)
   {
      if(EnableVerboseLogging || EnableSetupLogging)
         Print("ULTRA AGGRO PASS InstantTrend Beast=", beast.overall,
               " Conf=", beast.confidencePct, "% on ", BrokerSymbol);
      return true;
   }
   if(strategyTag == "InstantTrend" && aggro && BestQualitySetups)
   {
      if(EnableVerboseLogging || EnableSetupLogging)
         Print("ULTRA QUALITY FALLBACK InstantTrend Beast=", beast.overall,
               " Conf=", beast.confidencePct, "% on ", BrokerSymbol);
      return true;
   }

   PRISMStructureSnapshot s = PRISM_GetStructureSnapshot(buy);

   if(revTag)
   {
      if(!PRISMReversalQualityOK(buy))
      {
         failReason = "reversal: liquidity+structure stack failed";
         return false;
      }
      // BEST: prefer directional sweep already validated in MarketReversalSignalOK
      if(BestQualitySetups)
      {
         string revDetail = "";
         if(!MarketReversalSignalOK(buy, revDetail))
         {
            failReason = "reversal quality: " + revDetail;
            return false;
         }
      }
      else if(!s.sweep)
      {
         failReason = "liquidity confirmation missing";
         return false;
      }
      if(aggro)
      {
         if(EnableVerboseLogging || EnableSetupLogging)
            Print("ULTRA QUALITY PASS RevSniper Beast=", beast.overall,
                  " Conf=", beast.confidencePct, "% on ", BrokerSymbol);
         return true;
      }
   }

   // Non-aggressive quality path (UltraAggressiveFire=false) — remaining tags
   if(!s.trend)
   {
      failReason = "trend bias not aligned";
      return false;
   }

   if(BestQualitySetups && !s.htfConfirms && strategyTag == "InstantTrend")
   {
      failReason = "InstantTrend: HTF not confirming";
      return false;
   }

   if(!soft && EnableHTFConfirmation && !s.htfConfirms)
   {
      failReason = "HTF confirmation gate failed";
      return false;
   }

   if(!soft)
   {
      if(!(s.bos || s.ob || s.fvg || s.trendStrong))
      {
         failReason = "institutional confluence missing (BOS/OB/FVG/ADX)";
         return false;
      }
   }
   else if(!s.trendStrong && !AllowTrendOnlyInstantEntry)
   {
      failReason = "InstantTrend: trend not strong";
      return false;
   }

   if(EnablePremiumDiscountFilter && !NeverBlockValidSniperEntry)
   {
      if(buy && !InDiscountZone())
      {
         failReason = "premium/discount: buy not in discount";
         return false;
      }
      if(!buy && !InPremiumZone())
      {
         failReason = "premium/discount: sell not in premium";
         return false;
      }
   }

   if(!soft && DetectFakeBreakoutTrap(buy))
   {
      failReason = "entry candle: fake breakout trap in trade direction";
      return false;
   }

   if(UltraMinBeastScore > 0 && beast.overall < UltraMinBeastScore)
   {
      failReason = "BeastScore " + IntegerToString(beast.overall) +
                   " < UltraMinBeastScore " + IntegerToString(UltraMinBeastScore);
      return false;
   }

   if(UltraMinConfidencePct > 0 && beast.confidencePct < UltraMinConfidencePct)
   {
      failReason = "Confidence " + IntegerToString(beast.confidencePct) +
                   "% < UltraMinConfidencePct " + IntegerToString(UltraMinConfidencePct);
      return false;
   }

   return true;
}

bool UltraSmartTickUnchanged()
{
   if(!EnableUltraCore || !UltraSmartTickFilter)
      return false;

   // BUGFIX: must also match current bar — otherwise a new bar at same bid/ask
   // would be skipped and miss the sniper entry window.
   static datetime s_lastBar = 0;
   datetime bar = iTime(BrokerSymbol, EntryTF, 0);
   double bid = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);
   double ask = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);

   if(bar == s_lastBar && bid == g_UltraLastBid && ask == g_UltraLastAsk &&
      g_UltraLastDecision != "IDLE" && g_UltraLastDecision != "")
      return true;

   s_lastBar = bar;
   g_UltraLastBid = bid;
   g_UltraLastAsk = ask;
   return false;
}

bool PRISM_IsReversalTag(const string tag)
{
   return (tag == "RevSniper" || tag == "LiquiditySweep");
}

bool PRISM_IsContinuationTag(const string tag)
{
   return (tag == "ContSniper" || tag == "TrendPullback" ||
           tag == "InstantTrend" || tag == "VolBreakout(Spec)" ||
           tag == "FVG+OB");
}

// Counts how many independent confirming conditions are true for a given
// direction - used ONLY to break ties among setups that are ALREADY each
// individually fully valid (every one of their own hard gates already
// passed). This never makes an invalid setup valid; it only orders
// several simultaneously-valid setups by how much independent structure
// backs each one, per "rank valid strategies" / "select strongest valid
// setup" in the spec.
int CountConfirmingConditions(bool buy)
{
   PRISMStructureSnapshot s = PRISM_GetStructureSnapshot(buy, PRISM_StructureRecencyBars);
   int n = 0;

   if(s.trend) n++;
   if(s.trendStrong) n++;
   if(s.bos) n++;
   if(s.choch) n++;
   if(s.sweep) n++;
   if(s.fvg) n++;
   if(s.ob) n++;

   if(GetLiquidityProximityScore(buy) > 0) n++;

   return n;
}

//================ MARKET PRESSURE INDEX (real MPI, Part 16) =========//
// This is the actual 100-point scoring system from the manual, built for
// real from your existing detectors - not a placeholder. Deliberately
// used as ONE consolidated score instead of implementing Market
// Integrity/Market Strength/Market DNA/Trade Quality/Entry Confirmation
// etc. as 15 separate required 75+ gates: those systems in the manual
// all score the same 7 underlying things (trend, structure, liquidity,
// momentum, institutional confirmation, entry location, risk) under
// different names. Requiring 15 independent ~70%-likely gates to all
// pass simultaneously has roughly a 0.5% chance of ever happening
// (0.7^15) - this is arithmetic, not caution. One real MPI, gated at a
// sensible threshold, is what actually reflects the manual's Part 52
// decision flow: hard structural gates PLUS one final score check.

input int MinimumMPIScore = 0; // unused under AggressiveInstantQuality (no MPI wait)

// FIX (this pass): this function used to be defined *inside* the body of
// EvaluateSpecCompliantStrategies() below - an illegal nested function
// definition that MQL5 (like C++) does not allow, meaning the whole file
// could not compile. Moved to file scope here, and the missing gate
// against MinimumMPIScore has been restored in EvaluateSpecCompliantStrategies().

int CalculatePRISMScore(bool buy)
{
   PRISMStructureSnapshot s =
      PRISM_GetStructureSnapshot(buy, PRISM_StructureRecencyBars);

   int score = 0;

   if(s.trend) score += 10;
   if(s.trendStrong) score += 5;
   if(s.htfConfirms) score += 5;

   if(s.bos) score += 10;
   if(s.choch) score += 10;

   score += GetLiquiditySweepQualityScore();

   if(IsVolatilityExpanding()) score += 15;

   if(IsOrderBlockFreshAndValid(buy)) score += 5;
   score += (int)MathRound(GetFVGQualityScore(buy) / 3.0);

   if(buy ? InDiscountZone() : InPremiumZone()) score += 5;
   score += MathMin(GetLiquidityProximityScore(buy), 5);

   if(GetFilterATR() > 0.0) score += 10;

   if(DetectFakeBreakoutTrap(buy)) score -= 15;

   return score;
}

//+------------------------------------------------------------------+
//|  SMT + IMCE + INSTITUTIONAL CONFIDENCE ENGINE (PRISM layer)      |
//+------------------------------------------------------------------+

// GetDisplacementScore forward-declared in Ultra Core section above

// ENUM_IMCE_CONTEXT + PRISM_MarketIntel declared above in Ultra Core section

//----- ICE: Institutional Confidence Engine (0-100) ------------------//
int GetInstitutionalConfidenceScore(bool buy)
{
   PRISMStructureSnapshot s = PRISM_GetStructureSnapshot(buy);
   int score = 0;

   if(s.trend) score += 15;
   if(s.trendStrong) score += 15;
   if(s.bos) score += 12;
   if(s.choch) score += 10;
   if(s.sweep) score += 12;
   if(s.ob) score += 12;
   if(s.fvg) score += 10;
   if(GetDisplacementScore(buy) >= 5) score += 8;
   if(s.htfConfirms) score += 5;

   ENUM_IMCE_CONTEXT ctx = GetIMCEContext();
   if((ctx == IMCE_TREND_CONTINUATION || ctx == IMCE_EXPANSION_BREAKOUT) &&
      s.trend && s.trendStrong)
      score += 15;

   // Early market reversal: liquidity stack can score before EMA/ADX fully flips
   if(EnableEarlyMarketReversal)
   {
      int rec = MathMax(EffectiveStructureRecency(), ReversalStructureRecencyBars);
      // BUGCLEAN46: correct-side sweep only (BUY=lows, SELL=highs)
      bool liq = RecentDirectionalSweep(buy, rec) || RecentDirectionalCHoCH(buy, rec);
      bool zone = ActiveOrderBlock(buy) || ActiveFVG(buy);
      if(liq && zone)
         score += 15;
      if(ctx == IMCE_REVERSAL_LIQUIDITY)
         score += 10;
   }

   if(score > 100) score = 100;
   return score;
}

bool InstitutionalConfidenceOK(bool buy)
{
   if(!EnableInstitutionalConfidence || !ICERequireForEntry)
      return true;

   int ice = GetInstitutionalConfidenceScore(buy);
   // #9: soft-tighten ICE floor in event windows (still trades — higher bar only)
   int floor = ICE_MinScore;
   if(EventQualityModeActive() && EventICE_MinScoreBoost > 0)
      floor = ICE_MinScore + EventICE_MinScoreBoost;

   if(ice < floor)
   {
      if(EnableVerboseLogging || EnableSetupLogging)
         Print("ICE HARD-blocked ", (buy ? "BUY" : "SELL"), " on ", BrokerSymbol,
               " — ICE ", ice, " < floor ", floor,
               (EventQualityModeActive() ? " [EVENT]" : ""));
      return false;
   }
   return true;
}

//----- SMT: Smart Money Technique ------------------------------------//
// Cross-asset: primary makes a more extreme swing than the reference
// (bullish: primary lower-low, ref higher-low). Internal: liquidity sweep
// + reclaim / CHoCH in trade direction (single-chart SMT).

bool SMTInternalBullish()
{
   int rec = EffectiveStructureRecency();
   // SIGNAL OK45: directional sell-side sweep (lows), not any-side RecentSweep
   bool swept = RecentDirectionalSweep(true, rec);
   bool reclaim = RecentDirectionalCHoCH(true, rec) || StructureDirectionalBOS(true) ||
                  ActiveOrderBlock(true) || ActiveFVG(true);
   return swept && reclaim && (IsBullTrend() || RecentDirectionalCHoCH(true, rec));
}

bool SMTInternalBearish()
{
   int rec = EffectiveStructureRecency();
   // SIGNAL OK45: directional buy-side sweep (highs), not any-side RecentSweep
   bool swept = RecentDirectionalSweep(false, rec);
   bool reclaim = RecentDirectionalCHoCH(false, rec) || StructureDirectionalBOS(false) ||
                  ActiveOrderBlock(false) || ActiveFVG(false);
   return swept && reclaim && (IsBearTrend() || RecentDirectionalCHoCH(false, rec));
}

bool SMTCrossAssetBullish()
{
   if(SMTReferenceSymbol == "" || SMTReferenceSymbol == BrokerSymbol)
      return false;
   if(!SymbolSelect(SMTReferenceSymbol, true))
      return SMTFailOpenIfNoRefData;

   int lb = MathMax(SMTSwingLookbackBars, 5);
   int need = SignalBarIndex() + lb + 1;
   if(Bars(BrokerSymbol, EntryTF) < need || Bars(SMTReferenceSymbol, EntryTF) < need)
      return SMTFailOpenIfNoRefData;

   int b = SignalBarIndex();
   double pLowNow  = iLow(BrokerSymbol, EntryTF, iLowest(BrokerSymbol, EntryTF, MODE_LOW, lb, b));
   double pLowPast = iLow(BrokerSymbol, EntryTF, iLowest(BrokerSymbol, EntryTF, MODE_LOW, lb, b + lb));
   double rLowNow  = iLow(SMTReferenceSymbol, EntryTF, iLowest(SMTReferenceSymbol, EntryTF, MODE_LOW, lb, b));
   double rLowPast = iLow(SMTReferenceSymbol, EntryTF, iLowest(SMTReferenceSymbol, EntryTF, MODE_LOW, lb, b + lb));

   if(pLowPast <= 0.0 || rLowPast <= 0.0)
      return SMTFailOpenIfNoRefData;

   // Bullish SMT: primary made a lower low, reference made a higher low
   bool primaryLL = (pLowNow < pLowPast);
   bool refHL     = (rLowNow > rLowPast);
   return (primaryLL && refHL);
}

bool SMTCrossAssetBearish()
{
   if(SMTReferenceSymbol == "" || SMTReferenceSymbol == BrokerSymbol)
      return false;
   if(!SymbolSelect(SMTReferenceSymbol, true))
      return SMTFailOpenIfNoRefData;

   int lb = MathMax(SMTSwingLookbackBars, 5);
   int need = SignalBarIndex() + lb + 1;
   if(Bars(BrokerSymbol, EntryTF) < need || Bars(SMTReferenceSymbol, EntryTF) < need)
      return SMTFailOpenIfNoRefData;

   int b = SignalBarIndex();
   double pHighNow  = iHigh(BrokerSymbol, EntryTF, iHighest(BrokerSymbol, EntryTF, MODE_HIGH, lb, b));
   double pHighPast = iHigh(BrokerSymbol, EntryTF, iHighest(BrokerSymbol, EntryTF, MODE_HIGH, lb, b + lb));
   double rHighNow  = iHigh(SMTReferenceSymbol, EntryTF, iHighest(SMTReferenceSymbol, EntryTF, MODE_HIGH, lb, b));
   double rHighPast = iHigh(SMTReferenceSymbol, EntryTF, iHighest(SMTReferenceSymbol, EntryTF, MODE_HIGH, lb, b + lb));

   if(pHighPast <= 0.0 || rHighPast <= 0.0)
      return SMTFailOpenIfNoRefData;

   // Bearish SMT: primary higher high, reference lower high
   bool primaryHH = (pHighNow > pHighPast);
   bool refLH     = (rHighNow < rHighPast);
   return (primaryHH && refLH);
}

bool IsReversalSmtTag(const string strategyTag)
{
   return PRISM_IsReversalTag(strategyTag);
}

bool IsContinuationSmtTag(const string strategyTag)
{
   return PRISM_IsContinuationTag(strategyTag);
}

// SMT gate — tag-aware (no duplicate global veto after InstantTrend already passed).
bool SMTOK(bool buy, const string strategyTag)
{
   if(!EnableSMT || !SMTRequireForEntry)
      return true;

   // Continuation / InstantTrend: do NOT hard-block here.
   // RevSniper already embeds sweep+zone (internal SMT) — applying SMT again
   // on InstantTrend was the bug in your Experts log.
   if(IsContinuationSmtTag(strategyTag) && !SMTBlockContinuationPaths)
      return true;

   // Reversal tags: path already required liq+zone. Extra cross-asset SMT
   // only if a reference symbol is set; otherwise trust the path (no duplicate).
   if(IsReversalSmtTag(strategyTag) || strategyTag == "")
   {
      bool haveRef = (SMTReferenceSymbol != "" && SMTReferenceSymbol != BrokerSymbol);
      if(!haveRef)
         return true; // internal SMT already inside RevSniper/LiquiditySweep

      bool cross = buy ? SMTCrossAssetBullish() : SMTCrossAssetBearish();
      if(cross)
         return true;

      if(SMTAllowInternal && (buy ? SMTInternalBullish() : SMTInternalBearish()))
         return true;

      if(SMTFailOpenIfNoRefData)
         return true;

      if(EnableVerboseLogging || EnableSetupLogging)
         Print("SMT HARD-blocked ", strategyTag, " ", (buy ? "BUY" : "SELL"),
               " on ", BrokerSymbol, " — cross-asset SMT failed");
      return false;
   }

   return true;
}

//----- IMCE: Institutional Market Context Engine ---------------------//
ENUM_IMCE_CONTEXT GetIMCEContext()
{
   int rec = EffectiveStructureRecency();
   bool trapBuy = DetectFakeBreakoutTrap(true);
   bool trapSell = DetectFakeBreakoutTrap(false);
   bool sweep = RecentSweep(rec); // any-side OK for "liquidity event" regime detect
   // BUGCLEAN46: trend/expansion BOS must match trend direction
   bool bull = IsBullTrend();
   bool bear = IsBearTrend();
   bool bos = bull ? StructureDirectionalBOS(true)
                   : (bear ? StructureDirectionalBOS(false) : RecentBOS(rec));
   bool choch = RecentCHoCH(rec);
   bool expanding = IsVolatilityExpanding();
   bool trending = TrendStrong() && (bull || bear);

   // Strong trend wins over chop — avoids classifying BTC bull pullbacks as dead chop.
   if(sweep && choch)
      return IMCE_REVERSAL_LIQUIDITY;

   if(expanding && trending && bos)
      return IMCE_EXPANSION_BREAKOUT;

   if(trending && (bos || ActiveOrderBlock(bull) || ActiveFVG(bull)))
      return IMCE_TREND_CONTINUATION;

   if(EnableRegimeDetection && GetMarketRegime() == REGIME_RANGING && sweep)
      return IMCE_REVERSAL_LIQUIDITY;

   if(trending)
      return IMCE_TREND_CONTINUATION;

   // Directional chop: trap against flow, or any trap when not trending.
   bool chopContext = false;
   if(!bos)
   {
      if(trending)
         chopContext = (IsBullTrend() && trapBuy) || (IsBearTrend() && trapSell);
      else
         chopContext = trapBuy || trapSell;
   }
   if(chopContext)
      return IMCE_MANIPULATION_CHOP;

   return IMCE_NEUTRAL;
}

string IMCEContextToString(ENUM_IMCE_CONTEXT ctx)
{
   if(ctx == IMCE_TREND_CONTINUATION) return "TREND_CONTINUATION";
   if(ctx == IMCE_REVERSAL_LIQUIDITY) return "REVERSAL_LIQUIDITY";
   if(ctx == IMCE_EXPANSION_BREAKOUT) return "EXPANSION_BREAKOUT";
   if(ctx == IMCE_MANIPULATION_CHOP)  return "MANIPULATION_CHOP";
   return "NEUTRAL";
}

//================ MARKET DEFENSE ENGINE ==============================//
// Returns true if the position was CLOSED by defense (caller must continue).
bool MarketDefendOpenPosition(const ulong ticket, const long type, const double openPrice,
                              const double price, double &currentSL, double &currentTP,
                              const int stateIndex)
{
   if(!EnableMarketDefense)
      return false;
   if(!PositionSelectByTicket(ticket))
      return false;

   const bool isBuy = (type == POSITION_TYPE_BUY);
   const bool inProfit = isBuy ? (price > openPrice) : (price < openPrice);
   double atr = GetFilterATR();
   int rec = EffectiveStructureRecency();

   // --- Track peak favorable excursion (MFE) ---
   if(stateIndex >= 0)
   {
      double peak = TradeStates[stateIndex].peakFavorable;
      if(peak <= 0.0)
         peak = openPrice;
      if(isBuy && price > peak)
         peak = price;
      if(!isBuy && price < peak)
         peak = price;
      if(peak != TradeStates[stateIndex].peakFavorable)
      {
         TradeStates[stateIndex].peakFavorable = peak;
         PersistTradeState(stateIndex);
      }
   }

   const bool preTP1 = (stateIndex < 0) || !TradeStates[stateIndex].tp1Taken;
   double adverseMove = isBuy ? (openPrice - price) : (price - openPrice);
   if(adverseMove < 0.0)
      adverseMove = 0.0;

   // AUDITOK52: sticky peak adverse (arms #7 even after price recovers)
   if(stateIndex >= 0 && adverseMove > TradeStates[stateIndex].peakAdverse)
   {
      TradeStates[stateIndex].peakAdverse = adverseMove;
      PersistTradeState(stateIndex);
   }
   double peakAdv = (stateIndex >= 0) ? TradeStates[stateIndex].peakAdverse : adverseMove;

   // --- #8 MAE hard cut before TP1 ---
   if(DefenseMAE_StopEnabled && preTP1 && DefenseMAE_ATR > 0.0 && atr > 0.0)
   {
      if(adverseMove >= atr * DefenseMAE_ATR)
      {
         if(DefenseLogActions)
            Print("DEFEND MAE: adverse ", DoubleToString(adverseMove / atr, 2),
                  " ATR ≥ ", DoubleToString(DefenseMAE_ATR, 2),
                  " — Mission close ticket ", ticket);
         return UltraMission_ClosePosition(ticket, "RISK DEFEND MAE", true);
      }
   }

   // --- #7 Mid-path BE before TP1 (sticky arm → lock when recovered to entry) ---
   if(DefensePreTP1AdverseBE && preTP1 && atr > 0.0 && DefensePreTP1AdverseATR > 0.0)
   {
      bool armed = (peakAdv >= atr * DefensePreTP1AdverseATR);
      bool atOrAboveEntry = isBuy ? (price >= openPrice) : (price <= openPrice);
      bool profitOK = true;
      if(DefensePreTP1RequireProfitTiny)
         profitOK = inProfit || adverseMove <= atr * 0.10;

      if(armed && atOrAboveEntry && profitOK)
      {
         bool needBE = isBuy ? (currentSL < openPrice) : (currentSL > openPrice || currentSL == 0.0);
         if(needBE && g_Trade.PositionModify(ticket, openPrice, currentTP))
         {
            currentSL = openPrice;
            if(DefenseLogActions)
               Print("DEFEND BE: pre-TP1 adverse recover (armed ",
                     DoubleToString(peakAdv / atr, 2), " ATR) — locked BE ticket ", ticket);
         }
      }
   }

   // --- 1) Hard opposing reversal stack → close ---
   if(DefenseCloseOnHardReversal)
   {
      string detail = "";
      bool oppositeRev = MarketReversalSignalOK(!isBuy, detail);
      if(oppositeRev && (!DefenseRequireInProfitToClose || inProfit))
      {
         if(DefenseLogActions)
            Print("DEFEND CLOSE request: hard opposite reversal vs ", (isBuy ? "BUY" : "SELL"),
                  " ticket ", ticket, " — ", detail);
         return UltraMission_ClosePosition(ticket, "DEFEND hard reversal "+detail, false);
      }
   }

   // --- 2) Fake-breakout trap against our direction (pre-TP1) → close ---
   if(DefenseCloseOnTrapAgainst && DetectFakeBreakoutTrap(isBuy))
   {
      if(preTP1)
      {
         if(DefenseLogActions)
            Print("DEFEND CLOSE request: fake-breakout trap against ", (isBuy ? "BUY" : "SELL"),
                  " ticket ", ticket);
         return UltraMission_ClosePosition(ticket, "DEFEND trap against", false);
      }
      // After TP1: lock at least BE instead of full close
      if(inProfit)
      {
         bool needBE = isBuy ? (currentSL < openPrice) : (currentSL > openPrice || currentSL == 0.0);
         if(needBE && g_Trade.PositionModify(ticket, openPrice, currentTP))
         {
            currentSL = openPrice;
            if(DefenseLogActions)
               Print("DEFEND BE: trap after TP1 — locked breakeven on ticket ", ticket);
         }
      }
   }

   // --- 3) Adverse (wrong-side) sweep → lock breakeven ---
   if(DefenseLockBEOnAdverseSweep && inProfit)
   {
      int wrongBar = MostRecentWrongSideSweepBar(isBuy, MathMax(rec, 8));
      int correctBar = MostRecentCorrectSweepBar(isBuy, MathMax(rec, 8));
      // Wrong-side more recent than our fuel → market turning against us
      if(wrongBar > 0 && (correctBar == 0 || wrongBar < correctBar))
      {
         bool needBE = isBuy ? (currentSL < openPrice) : (currentSL > openPrice || currentSL == 0.0);
         if(needBE && g_Trade.PositionModify(ticket, openPrice, currentTP))
         {
            currentSL = openPrice;
            if(DefenseLogActions)
               Print("DEFEND BE: adverse sweep vs ", (isBuy ? "BUY" : "SELL"),
                     " — locked breakeven ticket ", ticket);
         }
      }
   }

   // --- 4) Manipulation chop while in profit → lock BE ---
   if(DefenseTightenOnChop && inProfit)
   {
      ENUM_IMCE_CONTEXT ctx = GetIMCEContext();
      if(ctx == IMCE_MANIPULATION_CHOP)
      {
         bool needBE = isBuy ? (currentSL < openPrice) : (currentSL > openPrice || currentSL == 0.0);
         if(needBE && g_Trade.PositionModify(ticket, openPrice, currentTP))
         {
            currentSL = openPrice;
            if(DefenseLogActions)
               Print("DEFEND BE: IMCE chop — locked breakeven ticket ", ticket);
         }
      }
   }

   // --- 5) Retrace from peak MFE → lock fraction of peak profit ---
   if(DefenseRetraceLockFromPeak && stateIndex >= 0 && atr > 0.0)
   {
      double peak = TradeStates[stateIndex].peakFavorable;
      if(peak > 0.0)
      {
         double peakMove = isBuy ? (peak - openPrice) : (openPrice - peak);
         double giveBack = isBuy ? (peak - price) : (price - peak);
         if(peakMove > 0.0 && giveBack >= atr * DefenseRetraceATR)
         {
            double lockMove = peakMove * MathMax(0.0, MathMin(DefenseRetraceLockFraction, 1.0));
            double lockSL = isBuy ? (openPrice + lockMove) : (openPrice - lockMove);
            lockSL = NormalizeTradePrice(lockSL);
            bool better = isBuy
               ? (lockSL > currentSL && lockSL < price)
               : ((currentSL == 0.0 || lockSL < currentSL) && lockSL > price);
            if(better && g_Trade.PositionModify(ticket, lockSL, currentTP))
            {
               currentSL = lockSL;
               if(DefenseLogActions)
                  Print("DEFEND LOCK: peak retrace — SL→", DoubleToString(lockSL,
                        UltraSymDigits(BrokerSymbol)),
                        " ticket ", ticket);
            }
         }
      }
   }

   return false;
}

bool IMCEAllows(bool buy, const string strategyTag)
{
   if(!EnableIMCE || !IMCERequireForEntry)
      return true;

   ENUM_IMCE_CONTEXT ctx = GetIMCEContext();

   bool contTag = PRISM_IsContinuationTag(strategyTag);
   bool revTag  = PRISM_IsReversalTag(strategyTag);

   if(IMCEBlockManipulationChop && ctx == IMCE_MANIPULATION_CHOP)
   {
      bool trendAligned =
         TrendStrong() && contTag && (buy ? IsBullTrend() : IsBearTrend());
      if(IMCEAllowTrendContinuationsInChop && trendAligned)
      {
         if(EnableVerboseLogging || EnableSetupLogging)
            Print("IMCE chop override ", strategyTag, " — trend-aligned continuation on ", BrokerSymbol);
         return true;
      }

      if(EnableVerboseLogging || EnableSetupLogging)
         Print("IMCE HARD-blocked ", strategyTag, " — manipulation/chop on ", BrokerSymbol);
      return false;
   }

   if(ctx == IMCE_TREND_CONTINUATION || ctx == IMCE_EXPANSION_BREAKOUT)
   {
      if(revTag)
      {
         int rec = (EnableEarlyMarketReversal
                    ? MathMax(EffectiveStructureRecency(), ReversalStructureRecencyBars)
                    : EffectiveStructureRecency());
         bool sweep = RecentDirectionalSweep(buy, rec);
         bool choch = RecentDirectionalCHoCH(buy, rec);
         bool zone = ActiveOrderBlock(buy) || ActiveFVG(buy);
         bool reclaim = ReversalReclaimConfirm(buy, rec);
         bool strongStack = sweep && (choch || zone) && reclaim;
         bool softStack = EnableEarlyMarketReversal && ReversalIMCESoftInTrend &&
                          sweep && zone && reclaim;

         if(!(strongStack || softStack))
         {
            if(EnableVerboseLogging || EnableSetupLogging)
               Print("IMCE HARD-blocked reversal in trend/expansion: ", strategyTag);
            return false;
         }
         if(EnableEarlyMarketReversal && (EnableVerboseLogging || EnableSetupLogging))
            Print("IMCE early-reversal PASS ", strategyTag,
                  " sweep=", sweep, " CHoCH=", choch, " zone=", zone,
                  " ctx=", IMCEContextToString(ctx), " on ", BrokerSymbol);
      }
      if(contTag && !(buy ? IsBullTrend() : IsBearTrend()))
      {
         if(EnableVerboseLogging || EnableSetupLogging)
            Print("IMCE HARD-blocked ", strategyTag, " — against trend context");
         return false;
      }
      return true;
   }

   if(ctx == IMCE_REVERSAL_LIQUIDITY)
   {
      // BUGCLEAN46: Cont needs SAME-DIRECTION BOS to survive reversal context
      if(contTag && !StructureDirectionalBOS(buy) && strategyTag != "InstantTrend")
      {
         if(EnableVerboseLogging || EnableSetupLogging)
            Print("IMCE HARD-blocked continuation in reversal context: ", strategyTag);
         return false;
      }
      return true;
   }

   // NEUTRAL: still require direction agreement for continuation tags
   if(contTag && !(buy ? IsBullTrend() : IsBearTrend()))
      return false;
   return true;
}

//----- PRISM BEAST: Market Intelligence + Reversal Quality -------------//
PRISM_MarketIntel PRISM_GetMarketIntel(bool buy)
{
   PRISM_MarketIntel m;
   m.regime = GetMarketRegime();
   m.imce = GetIMCEContext();
   m.eventWindow = EventQualityModeActive();
   m.volExpanding = IsVolatilityExpanding();
   m.htfBull = HTFTrendBullish();

   double price = buy
      ? SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK)
      : SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);
   double pdMid = (GetPreviousDayHigh() + GetPreviousDayLow()) / 2.0;
   double pwMid = (GetPreviousWeekHigh() + GetPreviousWeekLow()) / 2.0;
   m.dailyBullBias = (pdMid > 0.0 && price > pdMid);
   m.weeklyBullBias = (pwMid > 0.0 && price > pwMid);
   return m;
}

// Unified reversal stack — CORRECT directional validation.
bool PRISMReversalQualityOK(bool buy)
{
   if(!EnableBeastMode || !BeastRequireReversalStack)
      return true;

   string detail = "";
   if(!MarketReversalSignalOK(buy, detail))
      return false;

   if(BeastMinReversalLiquidityScore > 0)
   {
      int rec = (EnableEarlyMarketReversal
                 ? MathMax(EffectiveStructureRecency(), ReversalStructureRecencyBars)
                 : EffectiveStructureRecency());
      int liq = GetLiquiditySweepQualityScore();
      if(liq == 0 && RecentDirectionalSweep(buy, rec))
         liq = 8;
      if(liq == 0 && RecentCHoCH(rec) && EnableEarlyMarketReversal)
         liq = 6;
      if(liq < BeastMinReversalLiquidityScore)
         return false;
   }

   return true;
}

string PRISMGetTradeGrade(bool buy, const string strategyTag)
{
   int mpi = CalculatePRISMScore(buy);
   int ice = GetInstitutionalConfidenceScore(buy);
   int conf = CountConfirmingConditions(buy);
   int total = mpi + ice + conf * 5;

   if(EnableUltraCore)
   {
      PRISMBeastScore beast = UltraGetBeastScore(buy, strategyTag);
      total = beast.overall + beast.confidencePct;
   }

   if(PRISM_IsReversalTag(strategyTag) && !PRISMReversalQualityOK(buy))
      return "D";

   if(total >= 170) return "A+";
   if(total >= 140) return "A";
   if(total >= 110) return "B";
   if(total >= 80)  return "C";
   return "D";
}

bool PRISMFinalizeApproval(bool buy, const string strategyTag)
{
   if(EnableBeastMode && BeastDuplicateBarGuard && IsDuplicateSignal(buy))
   {
      UltraSetReject("duplicate bar guard");
      Print("BEAST: duplicate bar guard suppressed ", (buy ? "BUY" : "SELL"),
            " on ", BrokerSymbol, " (open position already on this EntryTF bar)");
      return false;
   }

   if(EnableUltraCore && UltraSniperEntryGate)
   {
      string fail = "";
      if(!UltraSniperEntryOK(buy, strategyTag, fail))
      {
         UltraSetReject("sniper entry: " + fail);
         return false;
      }
   }

   // Live APEX/ContFallback/LCS already passed their own checklist — skip PRISM score spam
   bool liveSwing = (strategyTag == "APEX" || strategyTag == "ContFallback" || strategyTag == "LCS" || PRIME_IsLiveTag(strategyTag));
   if(liveSwing)
   {
      UltraSetApprove(strategyTag, "A", 100, 100);
      if(EnableBeastMode && BeastCaptureSignalSnapshot)
         CapturePendingSignalSnapshot(buy, strategyTag);
      return true;
   }

   PRISMBeastScore beast = UltraGetBeastScore(buy, strategyTag);
   string grade = PRISMGetTradeGrade(buy, strategyTag);

   if(EnableBeastMode && EnableSniperMode)
   {
      Print("ULTRA SNIPER ", (buy ? "BUY" : "SELL"), " [", strategyTag, "] grade=",
            grade, " Beast=", beast.overall, " Conf=", beast.confidencePct, "%",
            " MPI=", CalculatePRISMScore(buy),
            " ICE=", GetInstitutionalConfidenceScore(buy),
            " IMCE=", IMCEContextToString(GetIMCEContext()));
   }

   UltraSetApprove(strategyTag, grade, beast.overall, beast.confidencePct);
   if(EnableBeastMode && BeastCaptureSignalSnapshot)
      CapturePendingSignalSnapshot(buy, strategyTag);
   return true;
}

bool PrismInstitutionalEnginesOK(bool buy, const string strategyTag)
{
   // APEX / LCS / ContFallback / PRIME embed own checklist — no ICE/IMCE/SMT re-veto
   if(strategyTag == "APEX" || strategyTag == "LCS" || PRIME_IsLiveTag(strategyTag))
      return true;
   if(strategyTag == "ContFallback" && ContFallbackBypassEngines)
      return true;

   if(EnableBeastMode && PRISM_IsReversalTag(strategyTag) && !PRISMReversalQualityOK(buy))
   {
      UltraSetReject("reversal stack insufficient for " + strategyTag);
      if(EnableVerboseLogging || EnableSetupLogging)
         Print("BEAST: reversal stack insufficient for ", strategyTag, " on ", BrokerSymbol);
      return false;
   }

   // ICE + IMCE hard for all paths.
   // SMT hard only on reversal tags (see SMTOK) — not duplicated on InstantTrend.
   if(!InstitutionalConfidenceOK(buy))
   {
      UltraSetReject("ICE below floor for " + strategyTag);
      return false;
   }
   if(!IMCEAllows(buy, strategyTag))
   {
      UltraSetReject("IMCE blocked " + strategyTag);
      return false;
   }
   if(!SMTOK(buy, strategyTag))
   {
      UltraSetReject("SMT blocked " + strategyTag);
      return false;
   }

   if(EnableVerboseLogging)
      Print("Engines PASSED ", strategyTag, " ", (buy ? "BUY" : "SELL"),
            " ICE=", GetInstitutionalConfidenceScore(buy),
            " Beast=", UltraGetBeastScore(buy, strategyTag).overall,
            " IMCE=", IMCEContextToString(GetIMCEContext()),
            " on ", BrokerSymbol);
   return true;
}

//----- FULL UPGRADE: path quality ranking ----------------------------//
// Lower base priority number = higher structural quality.
// InstantTrend is intentional aggressive fallback (priority 6).
int PathBasePriority(const string tag)
{
   if(!PreferQualityPaths)
   {
      // Aggressive-first order when quality preference is off
      if(tag == "InstantTrend")       return 1;
      if(tag == "ContSniper")         return 2;
      if(tag == "RevSniper")          return 3;
      if(tag == "LiquiditySweep")     return 4;
      if(tag == "FVG+OB")             return 5;
      if(tag == "TrendPullback")      return 6;
      if(tag == "VolBreakout(Spec)")  return 7;
      return 99;
   }

   if(tag == "RevSniper")          return 1; // most stacked SMT path
   if(tag == "ContSniper")         return 2; // trend + structure
   if(tag == "LiquiditySweep")     return 3;
   if(tag == "FVG+OB")             return 4;
   if(tag == "TrendPullback")      return 5;
   if(tag == "InstantTrend")       return 6; // aggressive fallback
   if(tag == "VolBreakout(Spec)")  return 7;
   return 99;
}

int PathQualityRankScore(const string tag, const bool buy)
{
   PRISMStructureSnapshot s = PRISM_GetStructureSnapshot(buy);
   int score = 1000 - PathBasePriority(tag) * 100;
   score += GetInstitutionalConfidenceScore(buy);

   if(s.bos) score += 8;
   if(s.ob || s.fvg) score += 8;
   if(s.sweep || s.choch) score += 6;

   if(PRISM_IsReversalTag(tag) && PRISMReversalQualityOK(buy))
      score += 20;

   if(EnableUltraCore)
      score += UltraGetBeastScore(buy, tag).overall / 2;

   // High-probability / BEST QUALITY: strongly prefer Cont/Rev over InstantTrend
   if(UltraHighProbability || BestQualitySetups)
   {
      if(tag == "RevSniper")
         score += 120;
      else if(tag == "ContSniper")
         score += 100;
      else if(tag == "LiquiditySweep" || tag == "FVG+OB")
         score += 45;
      else if(tag == "InstantTrend")
         score -= (BestQualitySetups ? 45 : 15); // fallback only
      else if(tag == "VolBreakout(Spec)" && QualityDisableWeakPaths)
         score -= 30;
      score += CountConfirmingConditions(buy) * (BestQualitySetups ? 12 : 8);
   }

   if(EnableAdaptivePathRanking)
   {
      int idx = FindStrategyTagIndex(tag);
      if(idx >= 0)
      {
         double w = g_StrategyTagWins[idx];
         double l = g_StrategyTagLosses[idx];
         if((w + l) >= AdaptivePathMinTrades && (w + l) > 0.0)
         {
            double wr = w / (w + l);
            score += (int)MathRound(wr * 50.0); // proven paths climb the rank
         }
      }
   }

   return score;
}

// The Priority Engine itself: evaluates every spec-named strategy for
// both directions, rejects the bar entirely if valid setups disagree on
// direction (a genuine conflict - spec says reject, not pick a side), and
// otherwise returns the single strongest valid setup by confirming-
// condition count.
void EvaluateSpecCompliantStrategies(bool &buySignal, bool &sellSignal, string &strategyTag)
{
   // OK93 REMOVED — old ContSniper/Rev/Instant/PRISM live router
   buySignal = false; sellSignal = false; strategyTag = "";
}


bool TrendPullbackBuySetup()
{
   if(!IsBullTrend())
      return false;

   if(!TrendStrong())
      return false;

   double ema = GetEMA();
   double atr = GetFilterATR();

   if(ema == EMPTY_VALUE || atr <= 0.0)
      return false;

   double price = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);
   double pullMul = EffectivePullbackATRMultiple();
   bool nearEma = (MathAbs(price - ema) <= atr * pullMul);

   // Quality mode (regular + events): need pullback or SAME-DIRECTION BOS — never trend-only.
   if(EnableInstantSniperMode || NeverBlockValidSniperEntry || QualityGatesActive())
   {
      if(QualityGatesActive())
         return (nearEma || StructureDirectionalBOS(true));
      if(NeverBlockValidSniperEntry)
         return true;
      if(nearEma)
         return true;
      if(StructureDirectionalBOS(true))
         return true;
      return false;
   }

   if(!nearEma)
      return false;
   if(!StructureDirectionalBOS(true))
      return false;
   return true;
}

bool TrendPullbackSellSetup()
{
   if(!IsBearTrend())
      return false;

   if(!TrendStrong())
      return false;

   double ema = GetEMA();
   double atr = GetFilterATR();

   if(ema == EMPTY_VALUE || atr <= 0.0)
      return false;

   double price = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);
   double pullMul = EffectivePullbackATRMultiple();
   bool nearEma = (MathAbs(price - ema) <= atr * pullMul);

   if(EnableInstantSniperMode || NeverBlockValidSniperEntry || QualityGatesActive())
   {
      if(QualityGatesActive())
         return (nearEma || StructureDirectionalBOS(false));
      if(NeverBlockValidSniperEntry)
         return true;
      if(nearEma)
         return true;
      if(StructureDirectionalBOS(false))
         return true;
      return false;
   }

   if(!nearEma)
      return false;
   if(!StructureDirectionalBOS(false))
      return false;
   return true;
}

input group "LIQUIDITY SWEEP STRATEGY"

bool LiquiditySweepBuySetup()
{
   int rec = EffectiveStructureRecency();
   bool sweep = RecentDirectionalSweep(true, rec);
   bool choch = RecentCHoCH(rec);
   bool ob = ActiveOrderBlock(true);
   bool dirOK = IsBullTrend() || !UseEMA;

   if(!dirOK)
      return false;

   if(EnableInstantSniperMode && InstantTwoOfThreeLiquidity)
   {
      int hits = (sweep ? 1 : 0) + (choch ? 1 : 0) + (ob ? 1 : 0);
      int need = 2; // quality: always 2 of 3
      if(NeverBlockValidSniperEntry && !QualityGatesActive())
         need = 1;
      return (hits >= need);
   }

   return (sweep && choch && ob);
}

bool LiquiditySweepSellSetup()
{
   int rec = EffectiveStructureRecency();
   bool sweep = RecentDirectionalSweep(false, rec);
   bool choch = RecentCHoCH(rec);
   bool ob = ActiveOrderBlock(false);
   bool dirOK = IsBearTrend() || !UseEMA;

   if(!dirOK)
      return false;

   if(EnableInstantSniperMode && InstantTwoOfThreeLiquidity)
   {
      int hits = (sweep ? 1 : 0) + (choch ? 1 : 0) + (ob ? 1 : 0);
      int need = 2;
      if(NeverBlockValidSniperEntry && !QualityGatesActive())
         need = 1;
      return (hits >= need);
   }

   return (sweep && choch && ob);
}

input group "FVG + ORDER BLOCK STRATEGY"

bool FVGOrderBlockBuySetup()
{
   bool bos = StructureDirectionalBOS(true);
   bool fvg = ActiveFVG(true);
   bool ob = ActiveOrderBlock(true);

   if(QualityGatesActive())
   {
      if(QualityNeedsTrendAndADX() && !(IsBullTrend() && TrendStrong()))
         return false;
      if(QualityNeedsStructureZone() && !(fvg || ob))
         return false;
      return (bos || (fvg && ob));
   }

   if(EnableInstantSniperMode && InstantFvgOrOb)
   {
      if(!(bos || IsBullTrend()))
         return false;
      return (fvg || ob);
   }

   return (bos && fvg && ob);
}

bool FVGOrderBlockSellSetup()
{
   bool bos = StructureDirectionalBOS(false);
   bool fvg = ActiveFVG(false);
   bool ob = ActiveOrderBlock(false);

   if(QualityGatesActive())
   {
      if(QualityNeedsTrendAndADX() && !(IsBearTrend() && TrendStrong()))
         return false;
      if(QualityNeedsStructureZone() && !(fvg || ob))
         return false;
      return (bos || (fvg && ob));
   }

   if(EnableInstantSniperMode && InstantFvgOrOb)
   {
      if(!(bos || IsBearTrend()))
         return false;
      return (fvg || ob);
   }

   return (bos && fvg && ob);
}

//+------------------------------------------------------------------+
//|              PART 15f - CORRELATION CONFIRMATION FILTER (NEW)    |
//+------------------------------------------------------------------+
// ADDED per request (Version A - a confirmation gate, not a standalone
// strategy). Applies to whichever strategy actually fired (SMC, mean-
// reversion, breakout, or trend-following) - before committing to the
// trade, checks that a second reference symbol isn't currently moving in
// a way that contradicts it. Example: a EURUSD long when GBPUSD is
// simultaneously breaking down hard could just be generic USD strength
// rather than EUR-specific weakness being wrong - a weaker case than the
// same EURUSD long with GBPUSD confirming the same move.
//
// Deliberately the SIMPLE version: one manually-specified reference
// symbol, one lookback window, one expected relationship (same-direction
// or inverse). It does not calculate a real statistical correlation
// coefficient, does not detect regime changes in that correlation, and
// does not adapt the reference symbol automatically - all real
// limitations of a lightweight filter versus a true pairs-trading system.
// Correlations between forex/metals/crypto are not stable and can break
// down entirely during the exact volatile conditions where you'd most
// want them to hold - this is a soft confirmation gate, not a guarantee.

input group "CORRELATION CONFIRMATION FILTER"

input bool   EnableCorrelationFilter      = false;
input string CorrelationCheckSymbol       = ""; // e.g. "GBPUSD.m" - leave blank to disable even if EnableCorrelationFilter is true
input int    CorrelationLookbackBars      = 20;
input bool   CorrelationExpectSameDirection = true; // true: reference symbol should move the SAME way (e.g. EURUSD vs GBPUSD); false: expect the OPPOSITE (inverse) relationship

bool CorrelationFilterOK(bool buy)
{
   if(!EnableCorrelationFilter)
      return true;

   if(CorrelationCheckSymbol == "" || CorrelationCheckSymbol == BrokerSymbol)
      return true; // nothing configured to check against - don't block on a missing setting

   if(!SymbolSelect(CorrelationCheckSymbol, true))
   {
      if(EnableVerboseLogging)
         Print("Correlation filter: reference symbol '", CorrelationCheckSymbol, "' unavailable - failing open (not blocking).");
      return true; // fail open - a config/availability problem shouldn't silently block all trading
   }

   int barsAvailable = Bars(CorrelationCheckSymbol, EntryTF);

   if(barsAvailable < SignalBarIndex() + CorrelationLookbackBars + 1)
      return true; // not enough history yet - fail open

   double closeNow  = iClose(CorrelationCheckSymbol, EntryTF, SignalBarIndex());
   double closePast = iClose(CorrelationCheckSymbol, EntryTF, SignalBarIndex() + CorrelationLookbackBars);

   if(closeNow <= 0.0 || closePast <= 0.0)
      return true;

   bool referenceIsBullish = (closeNow > closePast);

   bool agree = CorrelationExpectSameDirection
                ? (referenceIsBullish == buy)
                : (referenceIsBullish != buy);

   if(!agree)
   {
      if(EnableVerboseLogging)
         Print("Correlation filter blocked ", (buy ? "BUY" : "SELL"), " on ", BrokerSymbol,
               " - ", CorrelationCheckSymbol, " contradicts the expected relationship.");
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//|              PART 15e - TREND-FOLLOWING STRATEGY (NEW)           |
//+------------------------------------------------------------------+
// ADDED per request: a deliberately simple baseline model - a classic
// fast/slow EMA crossover confirmed by ADX strength. This is NOT meant to
// compete on sophistication with the SMC engine; it's meant to be a
// simple, well-understood reference point. If SMC's added complexity
// (BOS/CHoCH/FVG/Order Block/liquidity sweep) doesn't outperform this
// plain crossover once there's real trade data behind both, that's a
// meaningful signal the complexity isn't earning its keep. If SMC clearly
// beats it, that validates the extra machinery. Either result is useful -
// this exists to be compared against, not to be the "best" strategy.
//
// Honest caveat: EMA crossovers are among the most well-known, widely
// traded signals in retail forex - if this alone reliably made money, it
// wouldn't still be a beginner-tutorial staple. Treat it as a yardstick,
// not a strategy you should expect an edge from.

input group "TREND-FOLLOWING STRATEGY"

input int    TrendFollow_FastEMA_Period = 20;
input int    TrendFollow_SlowEMA_Period = 50;
input double TrendFollow_ADXMinimum     = 20.0;

// Returns fast/slow EMA values at the given bar offset (0 = SignalBarIndex()
// itself, 1 = one bar further back) - used to detect the exact crossover
// bar rather than just "which one is currently on top" (which would keep
// re-triggering every bar the cross stays in place, not just once at the
// actual cross).
bool GetTrendFollowEMAs(int barOffset, double &fastEMA, double &slowEMA)
{
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0 || FastEMAHandlesArr[idx] == INVALID_HANDLE || SlowEMAHandlesArr[idx] == INVALID_HANDLE)
      return false;

   double fastBuf[], slowBuf[];
   ArraySetAsSeries(fastBuf, true);
   ArraySetAsSeries(slowBuf, true);

   int need = SignalBarIndex() + barOffset + 1;

   if(CopyBuffer(FastEMAHandlesArr[idx], 0, 0, need, fastBuf) < need) return false;
   if(CopyBuffer(SlowEMAHandlesArr[idx], 0, 0, need, slowBuf) < need) return false;

   int b = SignalBarIndex() + barOffset;
   fastEMA = fastBuf[b];
   slowEMA = slowBuf[b];

   return true;
}

bool TrendFollowBuySetup()
{
   if(GetADX() < TrendFollow_ADXMinimum)
      return false;

   double fastNow, slowNow, fastPrev, slowPrev;

   if(!GetTrendFollowEMAs(0, fastNow, slowNow))  return false;
   if(!GetTrendFollowEMAs(1, fastPrev, slowPrev)) return false;

   // A genuine fresh cross THIS bar - fast is above slow now, but was at
   // or below slow the bar before. Requiring the actual cross event (not
   // just "fast is currently above slow") avoids re-firing on every bar
   // while an existing cross just continues to hold.
   return (fastNow > slowNow && fastPrev <= slowPrev);
}

bool TrendFollowSellSetup()
{
   if(GetADX() < TrendFollow_ADXMinimum)
      return false;

   double fastNow, slowNow, fastPrev, slowPrev;

   if(!GetTrendFollowEMAs(0, fastNow, slowNow))  return false;
   if(!GetTrendFollowEMAs(1, fastPrev, slowPrev)) return false;

   return (fastNow < slowNow && fastPrev >= slowPrev);
}

//+------------------------------------------------------------------+
//|              PART 15c - VOLATILITY-BREAKOUT STRATEGY (NEW)       |
//+------------------------------------------------------------------+
// ADDED per request: a third, independent model - unlike SMC (reads
// structure/breaks as continuation signals, can mistake a news spike for
// a genuine structural break) and mean-reversion (fades extremes, can get
// run over by a real trending move), this is a plain volatility-breakout
// momentum model: trade WITH a decisive move once volatility is
// confirmed to be genuinely expanding (reusing IsVolatilityExpanding(),
// Part 11) AND price has actually broken outside its recent trading range
// by a real margin - not fighting the move, not reading pattern intent
// into it, just following confirmed range expansion in whichever
// direction it's already moving. This is the most naturally-suited of the
// three models to a news-driven spike specifically, since it doesn't
// require any structural interpretation of WHY price moved - only that it
// genuinely did, meaningfully, right now. It has not been backtested any
// more than the other two - "naturally suited to the mechanism" is not
// the same claim as "proven to work here."

input group "VOLATILITY-BREAKOUT STRATEGY"

input int    VolBreakout_ChannelLookbackBars = 20;  // rolling high/low channel width, in EntryTF bars
input double VolBreakout_MinBreakATRMultiple = 0.15; // how decisively price must clear the channel edge, scaled by ATR - avoids marginal/noise breaks

// Rolling channel high/low over the N most recent CLOSED bars (excludes
// both the forming bar and the just-closed signal bar itself, so the
// signal bar is being judged against bars strictly before it - a
// Donchian-channel-style breakout reference, deliberately simpler than
// GetRecentHigh()/GetRecentLow()'s swing-point detection since a breakout
// model wants "the edge of recent range," not "the last confirmed swing".
double GetChannelHigh(int lookbackBars)
{
   int startBar = SignalBarIndex() + 1;
   double highest = -1.0;

   for(int i = startBar; i < startBar + lookbackBars; i++)
   {
      double h = iHigh(BrokerSymbol, EntryTF, i);

      if(h > highest)
         highest = h;
   }

   return highest;
}

double GetChannelLow(int lookbackBars)
{
   int startBar = SignalBarIndex() + 1;
   double lowest = -1.0;

   for(int i = startBar; i < startBar + lookbackBars; i++)
   {
      double l = iLow(BrokerSymbol, EntryTF, i);

      if(lowest < 0.0 || l < lowest)
         lowest = l;
   }

   return lowest;
}

bool VolatilityBreakoutBuySetup()
{
   if(!IsVolatilityExpanding())
      return false; // core gate - no genuine expansion, no breakout trade

   double channelHigh = GetChannelHigh(VolBreakout_ChannelLookbackBars);

   if(channelHigh <= 0.0)
      return false;

   double closeBar = iClose(BrokerSymbol, EntryTF, SignalBarIndex());
   double atr = GetFilterATR();
   double margin = (atr > 0.0) ? (atr * VolBreakout_MinBreakATRMultiple) : 0.0;

   return (closeBar > channelHigh + margin);
}

bool VolatilityBreakoutSellSetup()
{
   if(!IsVolatilityExpanding())
      return false;

   double channelLow = GetChannelLow(VolBreakout_ChannelLookbackBars);

   if(channelLow <= 0.0)
      return false;

   double closeBar = iClose(BrokerSymbol, EntryTF, SignalBarIndex());
   double atr = GetFilterATR();
   double margin = (atr > 0.0) ? (atr * VolBreakout_MinBreakATRMultiple) : 0.0;

   return (closeBar < channelLow - margin);
}

//+------------------------------------------------------------------+
//| APEX - WORLD-CLASS LIQUIDITY CONTINUITY (from scratch)           |
//+------------------------------------------------------------------+
// Best path I would build unconstrained:
//   Structural HTF bias (swings + MA) → liquidity pool (equal H/L / swing)
//   → stop-hunt of THAT pool → displacement reclaim + optional tick-vol
//   → unmitigated FVG/OB only → SL beyond sweep (cap MaxSL ATR)
//   → FIRE once. Tag APEX = zero post-FIRE veto.

bool APEX_HourInWindow(const int hour, const int startHour, const int endHour)
{
   // Supports normal windows (7-10) and wrap (e.g. 22-2): start>end means overnight
   if(startHour == endHour)
      return true; // full day if misconfigured equal
   if(startHour < endHour)
      return (hour >= startHour && hour < endHour);
   return (hour >= startHour || hour < endHour);
}

// OK71: always DETECT which session is active (name it). Independent of kill-zone allow flags.
void DetectMarketSession(string &name, string &detail, bool &inLondon, bool &inNY, bool &inAsia, bool &inOverlap, int &hourOut)
{
   name = "OFF";
   detail = "";
   inLondon = false;
   inNY = false;
   inAsia = false;
   inOverlap = false;
   hourOut = -1;

   if(!EnableSessionDetect && !EnableAPEXSessionFilter)
   {
      name = "OFF";
      detail = "session detect OFF (24/7)";
      return;
   }

   datetime now = APEX_UseGMT ? TimeGMT() : TimeCurrent();
   MqlDateTime dt;
   TimeToStruct(now, dt);
   hourOut = dt.hour;

   // Detect by clock windows (always — for clean analysis)
   inLondon = APEX_HourInWindow(hourOut, APEX_LondonStartHourGMT, APEX_LondonEndHourGMT);
   inNY     = APEX_HourInWindow(hourOut, APEX_NYStartHourGMT, APEX_NYEndHourGMT);
   inAsia   = APEX_HourInWindow(hourOut, APEX_AsiaStartHourGMT, APEX_AsiaEndHourGMT);
   inOverlap = (inLondon && inNY);

   if(inOverlap)      name = "LONDON+NY";
   else if(inLondon)  name = "LONDON";
   else if(inNY)      name = "NEWYORK";
   else if(inAsia)    name = "ASIA";
   else               name = "OFF";

   string clock = APEX_UseGMT ? "GMT" : "SERVER";
   detail = StringFormat("SESSION=%s hour=%d %s | London %d-%d=%s | NY %d-%d=%s | Asia %d-%d=%s",
                         name, hourOut, clock,
                         APEX_LondonStartHourGMT, APEX_LondonEndHourGMT, inLondon ? "Y" : "N",
                         APEX_NYStartHourGMT, APEX_NYEndHourGMT, inNY ? "Y" : "N",
                         APEX_AsiaStartHourGMT, APEX_AsiaEndHourGMT, inAsia ? "Y" : "N");

   if(SessionLogOnChange && name != g_LastSessionNameLogged)
   {
      g_LastSessionNameLogged = name;
      Print("SESSION DETECT: ", detail, " on ", BrokerSymbol,
            APEX_SessionHardBlock ? " | HardBlock=ON" : " | soft (trade anytime)");
   }
}

bool APEX_InKillZone(string &detail)
{
   detail = "";
   string name = "";
   bool inLondon = false, inNY = false, inAsia = false, inOverlap = false;
   int hour = -1;
   DetectMarketSession(name, detail, inLondon, inNY, inAsia, inOverlap, hour);

   if(!EnableAPEXSessionFilter)
   {
      detail = detail + " | filter OFF (24/7)";
      return true;
   }

   // Crypto: never hard-blocked unless SessionFilterCryptoToo + HardBlock
   if(!APEX_SessionFilterCryptoToo && IsNonScalpSymbol())
   {
      detail = detail + " | crypto anytime";
      return true;
   }

   // Kill-zone membership uses Allow* flags (detect still named session above)
   bool killLondon = APEX_AllowLondon && inLondon;
   bool killNY     = APEX_AllowNewYork && inNY;
   bool killAsia   = APEX_AllowAsia && inAsia;
   bool inZone = (killLondon || killNY || killAsia);

   if(inZone)
   {
      detail = StringFormat("%s | IN kill-zone%s%s%s",
                            detail,
                            killLondon ? " London" : "",
                            killNY ? " NY" : "",
                            killAsia ? " Asia" : "");
      return true;
   }

   detail = StringFormat("%s | OUTSIDE kill-zone%s",
                         detail,
                         APEX_SessionHardBlock ? " HARD-BLOCK" : " soft — still allowed anytime");

   if(APEX_SessionHardBlock)
      return false;

   return true;
}

double APEX_AvgRange(const ENUM_TIMEFRAMES tf, const int bars)
{
   int n = MathMax(bars, 2);
   double sum = 0.0;
   int used = 0;
   for(int i = 1; i <= n; i++)
   {
      double hi = iHigh(BrokerSymbol, tf, i);
      double lo = iLow(BrokerSymbol, tf, i);
      if(hi <= 0.0 || lo <= 0.0 || hi < lo)
         continue;
      sum += (hi - lo);
      used++;
   }
   return (used > 0) ? (sum / used) : 0.0;
}

double APEX_BiasSMA()
{
   int p = MathMax(APEX_BiasMA_Period, 10);
   if(Bars(BrokerSymbol, APEX_BiasTF) < p + 5)
      return 0.0;
   double sum = 0.0;
   for(int i = 0; i < p; i++)
      sum += iClose(BrokerSymbol, APEX_BiasTF, i);
   return sum / p;
}

bool APEX_IsSwingHigh(const int bar)
{
   int s = MathMax(APEX_SwingStrength, 1);
   ENUM_TIMEFRAMES tf = APEX_BiasTF;
   double h = iHigh(BrokerSymbol, tf, bar);
   if(h <= 0.0)
      return false;
   for(int i = 1; i <= s; i++)
   {
      if(iHigh(BrokerSymbol, tf, bar - i) >= h)
         return false;
      if(iHigh(BrokerSymbol, tf, bar + i) > h)
         return false;
   }
   return true;
}

bool APEX_IsSwingLow(const int bar)
{
   int s = MathMax(APEX_SwingStrength, 1);
   ENUM_TIMEFRAMES tf = APEX_BiasTF;
   double l = iLow(BrokerSymbol, tf, bar);
   if(l <= 0.0)
      return false;
   for(int i = 1; i <= s; i++)
   {
      if(iLow(BrokerSymbol, tf, bar - i) <= l && iLow(BrokerSymbol, tf, bar - i) > 0.0)
         return false;
      if(iLow(BrokerSymbol, tf, bar + i) < l)
         return false;
   }
   return true;
}

bool APEX_StructureBull(string &detail)
{
   ENUM_TIMEFRAMES tf = APEX_BiasTF;
   int lb = MathMax(APEX_SwingLookback, 20);
   int sh1 = 0, sh2 = 0, sl1 = 0, sl2 = 0;
   for(int i = APEX_SwingStrength + 1; i <= lb; i++)
   {
      if(sh1 == 0 && APEX_IsSwingHigh(i)) sh1 = i;
      else if(sh1 > 0 && sh2 == 0 && APEX_IsSwingHigh(i)) sh2 = i;
      if(sl1 == 0 && APEX_IsSwingLow(i)) sl1 = i;
      else if(sl1 > 0 && sl2 == 0 && APEX_IsSwingLow(i)) sl2 = i;
      if(sh1 > 0 && sh2 > 0 && sl1 > 0 && sl2 > 0)
         break;
   }
   if(sh1 == 0 || sh2 == 0 || sl1 == 0 || sl2 == 0)
   {
      detail = "APEX struct: not enough BiasTF swings";
      return false;
   }
   double h1 = iHigh(BrokerSymbol, tf, sh1);
   double h2 = iHigh(BrokerSymbol, tf, sh2);
   double l1 = iLow(BrokerSymbol, tf, sl1);
   double l2 = iLow(BrokerSymbol, tf, sl2);
   // Bullish structure: most recent swing high > prior, most recent swing low > prior
   // (sh1 is more recent than sh2)
   bool hh = (h1 > h2);
   bool hl = (l1 > l2);
   if(!(hh && hl))
   {
      detail = "APEX struct: no HH+HL bull structure";
      return false;
   }
   detail = "APEX struct: BULL HH+HL";
   return true;
}

bool APEX_StructureBear(string &detail)
{
   ENUM_TIMEFRAMES tf = APEX_BiasTF;
   int lb = MathMax(APEX_SwingLookback, 20);
   int sh1 = 0, sh2 = 0, sl1 = 0, sl2 = 0;
   for(int i = APEX_SwingStrength + 1; i <= lb; i++)
   {
      if(sh1 == 0 && APEX_IsSwingHigh(i)) sh1 = i;
      else if(sh1 > 0 && sh2 == 0 && APEX_IsSwingHigh(i)) sh2 = i;
      if(sl1 == 0 && APEX_IsSwingLow(i)) sl1 = i;
      else if(sl1 > 0 && sl2 == 0 && APEX_IsSwingLow(i)) sl2 = i;
      if(sh1 > 0 && sh2 > 0 && sl1 > 0 && sl2 > 0)
         break;
   }
   if(sh1 == 0 || sh2 == 0 || sl1 == 0 || sl2 == 0)
   {
      detail = "APEX struct: not enough BiasTF swings";
      return false;
   }
   double h1 = iHigh(BrokerSymbol, tf, sh1);
   double h2 = iHigh(BrokerSymbol, tf, sh2);
   double l1 = iLow(BrokerSymbol, tf, sl1);
   double l2 = iLow(BrokerSymbol, tf, sl2);
   bool lh = (h1 < h2);
   bool ll = (l1 < l2);
   if(!(lh && ll))
   {
      detail = "APEX struct: no LH+LL bear structure";
      return false;
   }
   detail = "APEX struct: BEAR LH+LL";
   return true;
}

bool APEX_BiasBull(string &detail)
{
   string sDetail = "";
   bool structOK = true;
   if(APEX_RequireStructureBias || APEX_BiasNeedStructOrMA)
      structOK = APEX_StructureBull(sDetail);

   bool maOK = true;
   if(APEX_RequireMAAlign || APEX_BiasNeedStructOrMA)
   {
      double sma = APEX_BiasSMA();
      double c0 = iClose(BrokerSymbol, APEX_BiasTF, 0);
      double c1 = iClose(BrokerSymbol, APEX_BiasTF, 1);
      maOK = (sma > 0.0 && c0 > sma && c1 > sma);
      if(!maOK)
         sDetail = (sDetail == "" ? "APEX bias: price not clearly above Bias MA" : sDetail);
   }

   // OK60: if StructOrMA — pass when either qualifies (and required flags don't both hard-fail)
   if(APEX_BiasNeedStructOrMA && (APEX_RequireStructureBias || APEX_RequireMAAlign || true))
   {
      if(structOK || maOK)
      {
         detail = structOK && maOK ? "APEX bias: BULL struct+MA"
                : (structOK ? "APEX bias: BULL structure" : "APEX bias: BULL MA");
         return true;
      }
      detail = (sDetail != "" ? sDetail : "APEX bias: no bull structure or MA");
      return false;
   }

   if(APEX_RequireStructureBias && !structOK)
   {
      detail = sDetail;
      return false;
   }
   if(APEX_RequireMAAlign && !maOK)
   {
      detail = "APEX bias: price not clearly above Bias MA";
      return false;
   }
   detail = "APEX bias: BULL";
   return true;
}

bool APEX_BiasBear(string &detail)
{
   string sDetail = "";
   bool structOK = true;
   if(APEX_RequireStructureBias || APEX_BiasNeedStructOrMA)
      structOK = APEX_StructureBear(sDetail);

   bool maOK = true;
   if(APEX_RequireMAAlign || APEX_BiasNeedStructOrMA)
   {
      double sma = APEX_BiasSMA();
      double c0 = iClose(BrokerSymbol, APEX_BiasTF, 0);
      double c1 = iClose(BrokerSymbol, APEX_BiasTF, 1);
      maOK = (sma > 0.0 && c0 < sma && c1 < sma);
      if(!maOK)
         sDetail = (sDetail == "" ? "APEX bias: price not clearly below Bias MA" : sDetail);
   }

   if(APEX_BiasNeedStructOrMA)
   {
      if(structOK || maOK)
      {
         detail = structOK && maOK ? "APEX bias: BEAR struct+MA"
                : (structOK ? "APEX bias: BEAR structure" : "APEX bias: BEAR MA");
         return true;
      }
      detail = (sDetail != "" ? sDetail : "APEX bias: no bear structure or MA");
      return false;
   }

   if(APEX_RequireStructureBias && !structOK)
   {
      detail = sDetail;
      return false;
   }
   if(APEX_RequireMAAlign && !maOK)
   {
      detail = "APEX bias: price not clearly below Bias MA";
      return false;
   }
   detail = "APEX bias: BEAR";
   return true;
}

// Map liquidity pool on EntryTF: equal highs (sell pool) or equal lows (buy pool)
bool APEX_FindBuyPool(double &poolLevel)   // sell-side liquidity = lows
{
   poolLevel = 0.0;
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double atr = APEX_AvgRange(tf, 14);
   double tol = (atr > 0.0) ? (atr * APEX_EqualTolATR) : (SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT) * 20.0);
   int lb = MathMax(APEX_PoolLookback, 10);

   // Prefer equal lows (two distinct lows within tolerance)
   for(int i = 2; i <= lb - 2; i++)
   {
      double l1 = iLow(BrokerSymbol, tf, i);
      if(l1 <= 0.0) continue;
      for(int j = i + 2; j <= lb; j++)
      {
         double l2 = iLow(BrokerSymbol, tf, j);
         if(l2 <= 0.0) continue;
         if(MathAbs(l1 - l2) <= tol)
         {
            poolLevel = MathMin(l1, l2);
            return true;
         }
      }
   }
   // Fallback: most recent swing-ish low (lowest of last N excluding bar0/1)
   double lowest = iLow(BrokerSymbol, tf, 3);
   for(int k = 4; k <= lb; k++)
   {
      double l = iLow(BrokerSymbol, tf, k);
      if(l > 0.0 && l < lowest) lowest = l;
   }
   if(lowest > 0.0)
   {
      poolLevel = lowest;
      return true;
   }
   return false;
}

bool APEX_FindSellPool(double &poolLevel)  // buy-side liquidity = highs
{
   poolLevel = 0.0;
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double atr = APEX_AvgRange(tf, 14);
   double tol = (atr > 0.0) ? (atr * APEX_EqualTolATR) : (SymbolInfoDouble(BrokerSymbol, SYMBOL_POINT) * 20.0);
   int lb = MathMax(APEX_PoolLookback, 10);

   for(int i = 2; i <= lb - 2; i++)
   {
      double h1 = iHigh(BrokerSymbol, tf, i);
      if(h1 <= 0.0) continue;
      for(int j = i + 2; j <= lb; j++)
      {
         double h2 = iHigh(BrokerSymbol, tf, j);
         if(h2 <= 0.0) continue;
         if(MathAbs(h1 - h2) <= tol)
         {
            poolLevel = MathMax(h1, h2);
            return true;
         }
      }
   }
   double highest = iHigh(BrokerSymbol, tf, 3);
   for(int k = 4; k <= lb; k++)
   {
      double h = iHigh(BrokerSymbol, tf, k);
      if(h > highest) highest = h;
   }
   if(highest > 0.0)
   {
      poolLevel = highest;
      return true;
   }
   return false;
}

bool APEX_SweepOfPool(const bool buy, const double poolLevel, int &sweepBar, double &sweepExtreme)
{
   sweepBar = 0;
   sweepExtreme = 0.0;
   if(poolLevel <= 0.0)
      return false;
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double atr = APEX_AvgRange(tf, 14);
   double minDepth = (atr > 0.0) ? (atr * APEX_MinSweepDepthATR) : 0.0;
   int lb = MathMax(APEX_SweepLookback, 3);

   for(int i = 1; i <= lb; i++)
   {
      double hi = iHigh(BrokerSymbol, tf, i);
      double lo = iLow(BrokerSymbol, tf, i);
      double cl = iClose(BrokerSymbol, tf, i);
      double range = hi - lo;
      if(range <= 0.0)
         continue;

      if(buy)
      {
         // Sell-side pool swept (lows taken) then close back above pool
         if(lo < poolLevel - minDepth && cl > poolLevel)
         {
            double wick = MathMin(cl, poolLevel) - lo;
            if(wick / range >= APEX_MinSweepWickRatio)
            {
               sweepBar = i;
               sweepExtreme = lo;
               return true;
            }
         }
      }
      else
      {
         if(hi > poolLevel + minDepth && cl < poolLevel)
         {
            double wick = hi - MathMax(cl, poolLevel);
            if(wick / range >= APEX_MinSweepWickRatio)
            {
               sweepBar = i;
               sweepExtreme = hi;
               return true;
            }
         }
      }
   }
   return false;
}

bool APEX_HasDisplacement(const bool buy)
{
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double o = iOpen(BrokerSymbol, tf, 1);
   double c = iClose(BrokerSymbol, tf, 1);
   double h = iHigh(BrokerSymbol, tf, 1);
   double l = iLow(BrokerSymbol, tf, 1);
   double range = h - l;
   if(range <= 0.0)
      return false;
   if(buy && !(c > o))
      return false;
   if(!buy && !(c < o))
      return false;
   if(MathAbs(c - o) / range < APEX_DispMinBodyRatio)
      return false;
   double atr = APEX_AvgRange(tf, 14);
   if(atr > 0.0 && (range / atr) < APEX_DispMinATR)
      return false;

   // Tick volume expansion (soft or hard)
   if(APEX_TickVolExpansion > 1.0)
   {
      long v1 = iTickVolume(BrokerSymbol, tf, 1);
      double avg = 0.0;
      int n = 0;
      for(int i = 2; i <= 15; i++)
      {
         long v = iTickVolume(BrokerSymbol, tf, i);
         if(v > 0) { avg += (double)v; n++; }
      }
      if(n > 0)
      {
         avg /= n;
         bool expanded = (avg > 0.0 && (double)v1 >= avg * APEX_TickVolExpansion);
         if(APEX_RequireTickVol && !expanded)
            return false;
      }
   }
   return true;
}

bool APEX_HasReclaim(const bool buy, const double poolLevel)
{
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double c1 = iClose(BrokerSymbol, tf, 1);
   double o1 = iOpen(BrokerSymbol, tf, 1);
   if(buy)
      return (c1 > o1 && c1 > poolLevel);
   return (c1 < o1 && c1 < poolLevel);
}

bool APEX_BullishFVG_Unmitigated()
{
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double low1 = iLow(BrokerSymbol, tf, 1);
   double high3 = iHigh(BrokerSymbol, tf, 3);
   if(!(low1 > 0.0 && high3 > 0.0 && low1 > high3))
      return false;
   // Unmitigated: current price has not fully traded through the gap bottom
   double bid = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);
   return (bid >= high3);
}

bool APEX_BearishFVG_Unmitigated()
{
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double high1 = iHigh(BrokerSymbol, tf, 1);
   double low3 = iLow(BrokerSymbol, tf, 3);
   if(!(high1 > 0.0 && low3 > 0.0 && high1 < low3))
      return false;
   double ask = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);
   return (ask <= low3);
}

bool APEX_BullishOB_Unmitigated()
{
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double o2 = iOpen(BrokerSymbol, tf, 2);
   double c2 = iClose(BrokerSymbol, tf, 2);
   double o1 = iOpen(BrokerSymbol, tf, 1);
   double c1 = iClose(BrokerSymbol, tf, 1);
   if(!(c2 < o2 && c1 > o1))
      return false;
   double bid = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);
   double obLow = iLow(BrokerSymbol, tf, 2);
   double obHigh = iHigh(BrokerSymbol, tf, 2);
   // Still in/above OB — not closed fully below
   return (bid >= obLow && iClose(BrokerSymbol, tf, 0) >= obLow && bid <= obHigh * 1.01);
}

bool APEX_BearishOB_Unmitigated()
{
   ENUM_TIMEFRAMES tf = APEX_EntryTF;
   double o2 = iOpen(BrokerSymbol, tf, 2);
   double c2 = iClose(BrokerSymbol, tf, 2);
   double o1 = iOpen(BrokerSymbol, tf, 1);
   double c1 = iClose(BrokerSymbol, tf, 1);
   if(!(c2 > o2 && c1 < o1))
      return false;
   double ask = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);
   double obLow = iLow(BrokerSymbol, tf, 2);
   double obHigh = iHigh(BrokerSymbol, tf, 2);
   return (ask <= obHigh && iClose(BrokerSymbol, tf, 0) <= obHigh && ask >= obLow * 0.99);
}

bool APEX_HasUnmitigatedZone(const bool buy)
{
   if(buy)
   {
      if(APEX_BullishFVG_Unmitigated() || APEX_BullishOB_Unmitigated())
         return true;
      // OK60 soft fallback: existing Active FVG/OB trackers
      return (ActiveFVG(true) || ActiveOrderBlock(true));
   }
   if(APEX_BearishFVG_Unmitigated() || APEX_BearishOB_Unmitigated())
      return true;
   return (ActiveFVG(false) || ActiveOrderBlock(false));
}

//================ SNIPER IDP - BUILT INTO EA ===========================//
// Same pulse math as SNIPER_IDP.mq5, computed inside the bot on EntryTF.

double IDP_ClampPulse(double v)
{
   if(v > 100.0) return 100.0;
   if(v < -100.0) return -100.0;
   return v;
}

double IDP_BarATR(const int shift)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   int period = (IDP_ATR_Period > 1 ? IDP_ATR_Period : 1);
   double sum = 0.0;
   int n = 0;
   for(int i = shift; i < shift + period; i++)
   {
      double h = iHigh(BrokerSymbol, tf, i);
      double l = iLow(BrokerSymbol, tf, i);
      double pc = iClose(BrokerSymbol, tf, i + 1);
      if(h <= 0.0 || l <= 0.0 || pc <= 0.0)
         continue;
      double tr = MathMax(h - l, MathMax(MathAbs(h - pc), MathAbs(l - pc)));
      sum += tr;
      n++;
   }
   return (n > 0) ? (sum / n) : 0.0;
}

double IDP_BarEMA(const int shift)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   int period = (IDP_EMA_Period > 1 ? IDP_EMA_Period : 1);
   double k = 2.0 / (period + 1.0);
   int seedShift = shift + period;
   double sma = 0.0;
   int n = 0;
   for(int i = seedShift; i < seedShift + period; i++)
   {
      double c = iClose(BrokerSymbol, tf, i);
      if(c <= 0.0) continue;
      sma += c;
      n++;
   }
   if(n == 0)
      return 0.0;
   double ema = sma / n;
   for(int i = seedShift - 1; i >= shift; i--)
   {
      double c = iClose(BrokerSymbol, tf, i);
      if(c <= 0.0) continue;
      ema = c * k + ema * (1.0 - k);
   }
   return ema;
}

double IDP_PriorSwingHigh(const int shift)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   double h = iHigh(BrokerSymbol, tf, shift + 1);
   for(int j = shift + 2; j <= shift + 1 + IDP_SwingLookback; j++)
   {
      double v = iHigh(BrokerSymbol, tf, j);
      if(v > h) h = v;
   }
   return h;
}

double IDP_PriorSwingLow(const int shift)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   double l = iLow(BrokerSymbol, tf, shift + 1);
   for(int j = shift + 2; j <= shift + 1 + IDP_SwingLookback; j++)
   {
      double v = iLow(BrokerSymbol, tf, j);
      if(v > 0.0 && v < l) l = v;
   }
   return l;
}

double IDP_SweepScore(const int shift, const double atr)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   double hi = iHigh(BrokerSymbol, tf, shift);
   double lo = iLow(BrokerSymbol, tf, shift);
   double cl = iClose(BrokerSymbol, tf, shift);
   double range = hi - lo;
   if(range <= 0.0 || atr <= 0.0)
      return 0.0;

   double priorHigh = IDP_PriorSwingHigh(shift);
   double priorLow  = IDP_PriorSwingLow(shift);
   double minDepth  = atr * IDP_SweepMinDepthATR;
   double score = 0.0;

   if(lo < priorLow - minDepth && cl > priorLow)
   {
      double wick = MathMin(cl, priorLow) - lo;
      double ratio = wick / range;
      if(ratio >= IDP_SweepMinWickRatio)
         score += 25.0 * MathMin(ratio / 0.6, 1.5);
   }
   if(hi > priorHigh + minDepth && cl < priorHigh)
   {
      double wick = hi - MathMax(cl, priorHigh);
      double ratio = wick / range;
      if(ratio >= IDP_SweepMinWickRatio)
         score -= 25.0 * MathMin(ratio / 0.6, 1.5);
   }
   return score;
}

double IDP_DisplacementScore(const int shift, const double atr)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   double o = iOpen(BrokerSymbol, tf, shift);
   double c = iClose(BrokerSymbol, tf, shift);
   double h = iHigh(BrokerSymbol, tf, shift);
   double l = iLow(BrokerSymbol, tf, shift);
   double range = h - l;
   if(range <= 0.0)
      return 0.0;

   double body = MathAbs(c - o);
   double bodyRatio = body / range;
   if(bodyRatio < IDP_DispMinBodyRatio)
      return 0.0;
   if(atr > 0.0 && range < atr * IDP_DispMinATR)
      return 0.0;

   double mag = 35.0 * MathMin(bodyRatio / 0.7, 1.4);
   if(atr > 0.0)
      mag *= MathMin(range / (atr * 0.8), 1.5);
   return (c > o) ? mag : -mag;
}

double IDP_BosScore(const int shift, const double atr)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   double c1 = iClose(BrokerSymbol, tf, shift);
   double c2 = iClose(BrokerSymbol, tf, shift + 1);
   double swingHigh = IDP_PriorSwingHigh(shift);
   double swingLow  = IDP_PriorSwingLow(shift);
   double margin = (atr > 0.0) ? (atr * 0.10) : 0.0;

   if(c2 <= swingHigh && c1 > swingHigh + margin)
      return 20.0;
   if(c2 >= swingLow && c1 < swingLow - margin)
      return -20.0;
   return 0.0;
}

double IDP_TrendSideScore(const int shift)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   double ema = IDP_BarEMA(shift);
   double c = iClose(BrokerSymbol, tf, shift);
   if(ema <= 0.0 || c <= 0.0)
      return 0.0;
   if(c > ema) return 10.0;
   if(c < ema) return -10.0;
   return 0.0;
}

double IDP_ExpansionScore(const int shift)
{
   ENUM_TIMEFRAMES tf = EntryTF;
   double r0 = iHigh(BrokerSymbol, tf, shift) - iLow(BrokerSymbol, tf, shift);
   double r1 = iHigh(BrokerSymbol, tf, shift + 1) - iLow(BrokerSymbol, tf, shift + 1);
   if(r1 <= 0.0 || r0 <= 0.0)
      return 0.0;
   if(r0 < r1 * 1.15)
      return 0.0;
   double c = iClose(BrokerSymbol, tf, shift);
   double o = iOpen(BrokerSymbol, tf, shift);
   double boost = 10.0 * MathMin(r0 / r1, 2.0);
   return (c > o) ? boost : -boost;
}

double IDP_ComputePulse(const int shift)
{
   double atr = IDP_BarATR(shift);
   double pulse = 0.0;
   pulse += IDP_SweepScore(shift, atr);
   pulse += IDP_DisplacementScore(shift, atr);
   pulse += IDP_BosScore(shift, atr);
   pulse += IDP_TrendSideScore(shift);
   pulse += IDP_ExpansionScore(shift);
   return IDP_ClampPulse(pulse);
}

bool IDP_GetPulse(double &pulse, string &detail)
{
   int shift;
   pulse = 0.0;
   detail = "";
   if(!EnableIDPConfluence)
   {
      detail = "IDP off";
      return false;
   }

   shift = (IDP_PulseShift > 0 ? IDP_PulseShift : 0);
   if(iBars(BrokerSymbol, EntryTF) < IDP_ATR_Period + IDP_EMA_Period + IDP_SwingLookback + 5)
   {
      detail = "IDP: not enough bars";
      return false;
   }

   pulse = IDP_ComputePulse(shift);
   detail = StringFormat("IDP built-in pulse=%.1f shift=%d", pulse, shift);
   return true;
}

bool IDP_ConfluenceOK(const bool buy, string &detail)
{
   // OK93: IDP retired as live gate — ULTRA confluence owns decisions
   detail = "IDP retired soft-pass OK93";
   return true;
}



bool APEX_SetupOK(const bool buy, string &detail, double &invalidation)
{
   // OK93 REMOVED — old APEX live strategy deleted
   detail = "APEX retired OK93";
   invalidation = 0.0;
   return false;
}


void EvaluateAPEXStrategies(bool &buySignal, bool &sellSignal, string &strategyTag)
{
   // OK93 REMOVED — never opens trades
   buySignal = false; sellSignal = false; strategyTag = "";
}


//+------------------------------------------------------------------+
//| LCS - LIQUIDITY CONTINUITY SNIPER (high-prob live engine)        |
//+------------------------------------------------------------------+
// From-scratch path (OK57):
//   1) BiasTF (H4) clear SMA bias
//   2) EntryTF (H1) stop-hunt sweep AGAINST bias (sell-side for BUY, buy-side for SELL)
//   3) Reclaim + displacement in bias direction
//   4) Price interacting with FVG or OB from that move
//   5) Invalidation = sweep extreme (used as SL when LCS_UseSweepSL)

double LCS_AvgRange(const ENUM_TIMEFRAMES tf, const int bars)
{
   int n = MathMax(bars, 2);
   double sum = 0.0;
   int used = 0;
   for(int i = 1; i <= n; i++)
   {
      double hi = iHigh(BrokerSymbol, tf, i);
      double lo = iLow(BrokerSymbol, tf, i);
      if(hi <= 0.0 || lo <= 0.0 || hi < lo)
         continue;
      sum += (hi - lo);
      used++;
   }
   return (used > 0) ? (sum / used) : 0.0;
}

double LCS_BiasSMA()
{
   int p = MathMax(LCS_BiasMA_Period, 10);
   if(Bars(BrokerSymbol, LCS_BiasTF) < p + 5)
      return 0.0;
   double sum = 0.0;
   for(int i = 0; i < p; i++)
      sum += iClose(BrokerSymbol, LCS_BiasTF, i);
   return sum / p;
}

bool LCS_BiasBull(string &detail)
{
   double sma = LCS_BiasSMA();
   double c0 = iClose(BrokerSymbol, LCS_BiasTF, 0);
   double c1 = iClose(BrokerSymbol, LCS_BiasTF, 1);
   if(sma <= 0.0 || c0 <= 0.0)
   {
      detail = "bias: BiasTF history/SMA unavailable";
      return false;
   }
   // Clear bull bias: price and prior close above SMA (no chop hug required beyond side)
   if(!(c0 > sma && c1 > sma))
   {
      detail = "bias: not clear bull (close vs SMA200 H4)";
      return false;
   }
   detail = "bias: BULL";
   return true;
}

bool LCS_BiasBear(string &detail)
{
   double sma = LCS_BiasSMA();
   double c0 = iClose(BrokerSymbol, LCS_BiasTF, 0);
   double c1 = iClose(BrokerSymbol, LCS_BiasTF, 1);
   if(sma <= 0.0 || c0 <= 0.0)
   {
      detail = "bias: BiasTF history/SMA unavailable";
      return false;
   }
   if(!(c0 < sma && c1 < sma))
   {
      detail = "bias: not clear bear (close vs SMA200 H4)";
      return false;
   }
   detail = "bias: BEAR";
   return true;
}

bool LCS_IsBuySideSweepAt(const int bar, double &sweepExtreme)
{
   sweepExtreme = 0.0;
   if(bar < 1)
      return false;
   ENUM_TIMEFRAMES tf = LCS_EntryTF;
   double currentHigh = iHigh(BrokerSymbol, tf, bar);
   double currentLow  = iLow(BrokerSymbol, tf, bar);
   double close = iClose(BrokerSymbol, tf, bar);
   double barRange = currentHigh - currentLow;
   if(barRange <= 0.0)
      return false;

   double previousHigh = iHigh(BrokerSymbol, tf, bar + 1);
   int pad = MathMax(LCS_SwingPadBars, 2);
   for(int j = bar + 2; j <= bar + pad + 1; j++)
   {
      double h = iHigh(BrokerSymbol, tf, j);
      if(h > previousHigh) previousHigh = h;
   }

   double atr = LCS_AvgRange(tf, 14);
   double minDepth = (atr > 0.0) ? (atr * LCS_MinSweepDepthATR) : 0.0;
   if(!(currentHigh > previousHigh + minDepth && close < previousHigh))
      return false;

   double wick = currentHigh - MathMax(close, previousHigh);
   if(wick / barRange < LCS_MinSweepWickRatio)
      return false;

   sweepExtreme = currentHigh;
   return true;
}

bool LCS_IsSellSideSweepAt(const int bar, double &sweepExtreme)
{
   sweepExtreme = 0.0;
   if(bar < 1)
      return false;
   ENUM_TIMEFRAMES tf = LCS_EntryTF;
   double currentHigh = iHigh(BrokerSymbol, tf, bar);
   double currentLow  = iLow(BrokerSymbol, tf, bar);
   double close = iClose(BrokerSymbol, tf, bar);
   double barRange = currentHigh - currentLow;
   if(barRange <= 0.0)
      return false;

   double previousLow = iLow(BrokerSymbol, tf, bar + 1);
   int pad = MathMax(LCS_SwingPadBars, 2);
   for(int j = bar + 2; j <= bar + pad + 1; j++)
   {
      double l = iLow(BrokerSymbol, tf, j);
      if(l < previousLow && l > 0.0) previousLow = l;
   }

   double atr = LCS_AvgRange(tf, 14);
   double minDepth = (atr > 0.0) ? (atr * LCS_MinSweepDepthATR) : 0.0;
   if(!(currentLow < previousLow - minDepth && close > previousLow))
      return false;

   double wick = MathMin(close, previousLow) - currentLow;
   if(wick / barRange < LCS_MinSweepWickRatio)
      return false;

   sweepExtreme = currentLow;
   return true;
}

int LCS_FindCorrectSweep(const bool buy, double &sweepExtreme)
{
   sweepExtreme = 0.0;
   int lb = MathMax(LCS_SweepLookbackBars, 2);
   for(int i = 1; i <= lb; i++)
   {
      double ext = 0.0;
      if(buy && LCS_IsSellSideSweepAt(i, ext))
      {
         sweepExtreme = ext;
         return i;
      }
      if(!buy && LCS_IsBuySideSweepAt(i, ext))
      {
         sweepExtreme = ext;
         return i;
      }
   }
   return 0;
}

bool LCS_HasDisplacement(const bool buy)
{
   ENUM_TIMEFRAMES tf = LCS_EntryTF;
   double o = iOpen(BrokerSymbol, tf, 1);
   double c = iClose(BrokerSymbol, tf, 1);
   double h = iHigh(BrokerSymbol, tf, 1);
   double l = iLow(BrokerSymbol, tf, 1);
   double range = h - l;
   if(range <= 0.0)
      return false;
   if(buy && !(c > o))
      return false;
   if(!buy && !(c < o))
      return false;
   double bodyRatio = MathAbs(c - o) / range;
   if(bodyRatio < LCS_DispMinBodyRatio)
      return false;
   double atr = LCS_AvgRange(tf, 14);
   if(atr <= 0.0)
      return true;
   return ((range / atr) >= LCS_DispMinATR);
}

bool LCS_HasReclaim(const bool buy, const int sweepBar)
{
   // After sweep, price must be back on the correct side of the swept level
   // and print a directional closed bar (bar 1).
   ENUM_TIMEFRAMES tf = LCS_EntryTF;
   double c1 = iClose(BrokerSymbol, tf, 1);
   double o1 = iOpen(BrokerSymbol, tf, 1);
   if(buy)
   {
      if(!(c1 > o1))
         return false;
      // reclaim above the sweep low extreme already implied by sell-side sweep close
      // also require close above midpoint of sweep bar
      double mid = 0.5 * (iHigh(BrokerSymbol, tf, sweepBar) + iLow(BrokerSymbol, tf, sweepBar));
      return (c1 >= mid);
   }
   if(!(c1 < o1))
      return false;
   double midS = 0.5 * (iHigh(BrokerSymbol, tf, sweepBar) + iLow(BrokerSymbol, tf, sweepBar));
   return (c1 <= midS);
}

bool LCS_BullishFVG()
{
   ENUM_TIMEFRAMES tf = LCS_EntryTF;
   // Classic 3-candle imbalance: low[1] > high[3]
   double low1 = iLow(BrokerSymbol, tf, 1);
   double high3 = iHigh(BrokerSymbol, tf, 3);
   return (low1 > 0.0 && high3 > 0.0 && low1 > high3);
}

bool LCS_BearishFVG()
{
   ENUM_TIMEFRAMES tf = LCS_EntryTF;
   double high1 = iHigh(BrokerSymbol, tf, 1);
   double low3 = iLow(BrokerSymbol, tf, 3);
   return (high1 > 0.0 && low3 > 0.0 && high1 < low3);
}

bool LCS_BullishOB()
{
   // Last opposing (bearish) candle before bullish displacement, still relevant
   ENUM_TIMEFRAMES tf = LCS_EntryTF;
   double o2 = iOpen(BrokerSymbol, tf, 2);
   double c2 = iClose(BrokerSymbol, tf, 2);
   double o1 = iOpen(BrokerSymbol, tf, 1);
   double c1 = iClose(BrokerSymbol, tf, 1);
   if(!(c2 < o2 && c1 > o1))
      return false;
   double bid = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);
   double obLow = iLow(BrokerSymbol, tf, 2);
   double obHigh = iHigh(BrokerSymbol, tf, 2);
   // Price still at/above OB (not fully traded through below)
   return (bid >= obLow && bid <= obHigh * 1.002);
}

bool LCS_BearishOB()
{
   ENUM_TIMEFRAMES tf = LCS_EntryTF;
   double o2 = iOpen(BrokerSymbol, tf, 2);
   double c2 = iClose(BrokerSymbol, tf, 2);
   double o1 = iOpen(BrokerSymbol, tf, 1);
   double c1 = iClose(BrokerSymbol, tf, 1);
   if(!(c2 > o2 && c1 < o1))
      return false;
   double ask = SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);
   double obLow = iLow(BrokerSymbol, tf, 2);
   double obHigh = iHigh(BrokerSymbol, tf, 2);
   return (ask <= obHigh && ask >= obLow * 0.998);
}

bool LCS_HasZone(const bool buy)
{
   if(buy)
      return (LCS_BullishFVG() || LCS_BullishOB() || ActiveFVG(true) || ActiveOrderBlock(true));
   return (LCS_BearishFVG() || LCS_BearishOB() || ActiveFVG(false) || ActiveOrderBlock(false));
}

bool LCS_SetupOK(const bool buy, string &detail, double &invalidation)
{
   detail = "";
   invalidation = 0.0;
   g_LCS_LastDetail = "";

   if(!EnableLCSStrategy)
   {
      detail = "LCS disabled";
      return false;
   }

   if(Bars(BrokerSymbol, LCS_BiasTF) < LCS_BiasMA_Period + 5 ||
      Bars(BrokerSymbol, LCS_EntryTF) < LCS_SweepLookbackBars + 10)
   {
      detail = "LCS: insufficient Bias/Entry TF bars";
      return false;
   }

   string biasDetail = "";
   if(buy)
   {
      if(!LCS_BiasBull(biasDetail))
      {
         detail = biasDetail;
         return false;
      }
   }
   else
   {
      if(!LCS_BiasBear(biasDetail))
      {
         detail = biasDetail;
         return false;
      }
   }

   double sweepExt = 0.0;
   int sweepBar = LCS_FindCorrectSweep(buy, sweepExt);
   if(sweepBar <= 0 || sweepExt <= 0.0)
   {
      detail = buy ? "LCS: need sell-side sweep (lows taken) on EntryTF"
                   : "LCS: need buy-side sweep (highs taken) on EntryTF";
      return false;
   }

   if(!LCS_HasReclaim(buy, sweepBar))
   {
      detail = "LCS: need reclaim after sweep";
      return false;
   }

   bool disp = LCS_HasDisplacement(buy);
   if(LCS_RequireDisplacement && !disp)
   {
      detail = "LCS: need displacement candle in bias direction";
      return false;
   }

   bool zone = LCS_HasZone(buy);
   if(LCS_RequireZone && !zone)
   {
      detail = "LCS: need FVG/OB zone in trade direction";
      return false;
   }

   // Invalidation = beyond sweep extreme
   double atr = LCS_AvgRange(LCS_EntryTF, 14);
   double buf = (atr > 0.0) ? (atr * LCS_SL_BufferATR) : 0.0;
   invalidation = buy ? (sweepExt - buf) : (sweepExt + buf);
   // For BUY, SL below sweep low; sweepExt IS the low. Subtract buffer.
   // For SELL, SL above sweep high; add buffer. Already set.

   detail = StringFormat("LCS OK %s sweep@%d zone=%s disp=%s inv=%s",
                         buy ? "BUY" : "SELL",
                         sweepBar,
                         zone ? "Y" : "N",
                         disp ? "Y" : "N",
                         DoubleToString(invalidation, UltraSymDigits(BrokerSymbol)));
   return true;
}

bool LCSBuySetup()
{
   string detail = "";
   double inv = 0.0;
   bool ok = LCS_SetupOK(true, detail, inv);
   g_LCS_LastDetail = detail;
   if(ok)
   {
      g_LCS_InvalidationPrice = inv;
      g_LCS_SweepBarTime = iTime(BrokerSymbol, LCS_EntryTF, 1);
      if(LCS_LogValidation)
         Print("LCS VALIDATE BUY: PASS - ", detail, " on ", BrokerSymbol);
      return true;
   }
   if(LCS_LogValidation && (EnableVerboseLogging || EnableSetupLogging))
      Print("LCS VALIDATE BUY: FAIL - ", detail, " on ", BrokerSymbol);
   return false;
}

bool LCSSellSetup()
{
   string detail = "";
   double inv = 0.0;
   bool ok = LCS_SetupOK(false, detail, inv);
   g_LCS_LastDetail = detail;
   if(ok)
   {
      g_LCS_InvalidationPrice = inv;
      g_LCS_SweepBarTime = iTime(BrokerSymbol, LCS_EntryTF, 1);
      if(LCS_LogValidation)
         Print("LCS VALIDATE SELL: PASS - ", detail, " on ", BrokerSymbol);
      return true;
   }
   if(LCS_LogValidation && (EnableVerboseLogging || EnableSetupLogging))
      Print("LCS VALIDATE SELL: FAIL - ", detail, " on ", BrokerSymbol);
   return false;
}

void EvaluateLCSStrategies(bool &buySignal, bool &sellSignal, string &strategyTag)
{
   // OK93 REMOVED — LCS deleted from live path
   buySignal = false; sellSignal = false; strategyTag = "";
}


void MarkContFallbackFillIfNeeded()
{
   if(g_PendingStrategyTag == "ContFallback" || g_PendingStrategyTag == "APEX" || g_PendingStrategyTag == "LCS" || PRIME_IsLiveTag(g_PendingStrategyTag))
   {
      g_ContFallbackLastFillTime = TimeCurrent();
      datetime barTime = iTime(BrokerSymbol, EntryTF, 0);
      if(barTime > 0)
         g_ContFallbackLastSignalBar = barTime;
   }
}

int CountOpenContFallbackPositions()
{
   int count = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != BrokerSymbol)
         continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;
      int st = FindTradeState(ticket);
      if(st >= 0 && TradeStates[st].strategyTag == "ContFallback")
         count++;
   }
   return count;
}

bool ContFallbackAntiScalpGatesPass(string &failReason)
{
   failReason = "";
   // OK81: InstantQualityMode never ContFallbackCooldown / OncePerBar blocks
   if(InstantQualityMode)
   {
      if(ContFallbackMaxOpen > 0 && CountOpenContFallbackPositions() >= ContFallbackMaxOpen)
      {
         failReason = "ContFallbackMaxOpen";
         return false;
      }
      return true;
   }
   if(ContFallbackMaxOpen > 0 && CountOpenContFallbackPositions() >= ContFallbackMaxOpen)
   {
      failReason = "ContFallbackMaxOpen";
      return false;
   }
   if(ContFallbackCooldownMinutes > 0 && g_ContFallbackLastFillTime > 0)
   {
      int waited = (int)(TimeCurrent() - g_ContFallbackLastFillTime);
      if(waited < ContFallbackCooldownMinutes * 60)
      {
         failReason = "ContFallbackCooldown";
         return false;
      }
   }
   if(EnableAntiScalpMode || ContFallbackOncePerBar)
   {
      datetime barTime = iTime(BrokerSymbol, EntryTF, 0);
      if(barTime > 0 && g_ContFallbackLastSignalBar == barTime)
      {
         failReason = "ContFallbackOncePerBar";
         return false;
      }
   }
   return true;
}

//================ CONT STRUCTURE BEST (OK68) ========================//
// World-class continuation structure — not PRISM ContSniper leftovers.
// Stack: clear trend → recent directional BOS → FRESH OB or quality FVG
// → price interacting with that zone → displacement impulse → optional HTF BOS.

bool ContStruct_TwoBarDirectionalBOS(const bool buy)
{
   double swingHigh = GetRecentHigh();
   double swingLow  = GetRecentLow();
   if(swingHigh == EMPTY_VALUE || swingLow == EMPTY_VALUE)
      return false;

   double close1 = iClose(BrokerSymbol, EntryTF, 1);
   double close2 = iClose(BrokerSymbol, EntryTF, 2);
   double close3 = iClose(BrokerSymbol, EntryTF, 3);
   double atr = GetFilterATR();
   double margin = (atr > 0.0) ? (atr * BOS_MinBreakATRMultiple) : 0.0;

   if(buy)
      return (close3 <= swingHigh &&
              close2 > swingHigh + margin &&
              close1 > swingHigh + margin);
   return (close3 >= swingLow &&
           close2 < swingLow - margin &&
           close1 < swingLow - margin);
}

bool ContStruct_HasQualityBOS(const bool buy)
{
   // Best: two-bar confirmation. Soft fallback: very fresh single-bar BOS still held.
   if(ContStruct_RequireTwoBarBOS)
   {
      if(ContStruct_TwoBarDirectionalBOS(buy))
         return true;
      return DetectDirectionalBOS(EntryTF, buy) && RecentDirectionalBOS(buy, 3);
   }
   return RecentDirectionalBOS(buy, ContStruct_BOS_MaxBars);
}

bool ContStruct_GetFreshZone(const bool buy, double &zTop, double &zBot, string &kind)
{
   zTop = 0.0;
   zBot = 0.0;
   kind = "";

   UpdateOrderBlockTracking();
   UpdateFVGTracking();

   int idx = GetSymbolIndex(BrokerSymbol);
   double atr = GetFilterATR();

   // 1) Fresh (unmitigated) order block — best demand/supply
   bool freshOB = IsOrderBlockFreshAndValid(buy);
   if(!freshOB && !ContStruct_FreshOBOnly)
      freshOB = ActiveOrderBlock(buy); // only if user allows mitigated

   if(freshOB && idx >= 0)
   {
      if(buy)
      {
         zTop = OB_Bull_TopArr[idx];
         zBot = OB_Bull_BottomArr[idx];
         kind = OB_Bull_MitigatedArr[idx] ? "OB-mitigated" : "OB-fresh";
      }
      else
      {
         zTop = OB_Bear_TopArr[idx];
         zBot = OB_Bear_BottomArr[idx];
         kind = OB_Bear_MitigatedArr[idx] ? "OB-mitigated" : "OB-fresh";
      }
      if(zTop > zBot && zBot > 0.0)
         return true;
   }
   else if(freshOB)
   {
      // untracked symbol fallback — use last 2-bar OB geometry
      zTop = iHigh(BrokerSymbol, EntryTF, 2);
      zBot = iLow(BrokerSymbol, EntryTF, 2);
      kind = "OB-detect";
      if(zTop > zBot)
         return true;
   }

   // 2) Quality FVG — active, not mostly filled, meaningful size
   if(idx >= 0)
   {
      bool fvgOn = buy ? FVG_Bull_ActiveArr[idx] : FVG_Bear_ActiveArr[idx];
      if(!fvgOn)
         fvgOn = ActiveFVG(buy);
      if(fvgOn)
      {
         double fill = buy ? FVG_Bull_FilledPctArr[idx] : FVG_Bear_FilledPctArr[idx];
         zTop = buy ? FVG_Bull_TopArr[idx] : FVG_Bear_TopArr[idx];
         zBot = buy ? FVG_Bull_BottomArr[idx] : FVG_Bear_BottomArr[idx];
         double gap = zTop - zBot;
         if(gap <= 0.0)
            return false;
         if(fill > ContStruct_MaxFVGFillPct)
            return false;
         if(atr > 0.0 && gap < atr * ContStruct_MinFVG_ATR)
            return false;
         kind = StringFormat("FVG(fill=%.0f%%)", fill);
         return true;
      }
   }
   else if(ActiveFVG(buy))
   {
      // fallback detect sizes
      if(buy)
      {
         zBot = iHigh(BrokerSymbol, EntryTF, 3);
         zTop = iLow(BrokerSymbol, EntryTF, 1);
      }
      else
      {
         zTop = iLow(BrokerSymbol, EntryTF, 3);
         zBot = iHigh(BrokerSymbol, EntryTF, 1);
         // bearish gap: top > bottom after swap
         double tmp = zTop; zTop = MathMax(tmp, zBot); zBot = MathMin(tmp, zBot);
      }
      double gap = zTop - zBot;
      if(gap > 0.0 && (atr <= 0.0 || gap >= atr * ContStruct_MinFVG_ATR))
      {
         kind = "FVG-detect";
         return true;
      }
   }

   return false;
}

bool ContStruct_PriceNearZone(const bool buy, const double zTop, const double zBot)
{
   if(zTop <= zBot)
      return false;
   double atr = GetFilterATR();
   double prox = (atr > 0.0) ? (atr * ContStruct_ZoneProximityATR) : 0.0;
   double price = buy ? SymbolInfoDouble(BrokerSymbol, SYMBOL_BID)
                      : SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);
   if(price <= 0.0)
      return false;
   // Must be interacting with the zone band (not miles away after BOS)
   return (price <= zTop + prox && price >= zBot - prox);
}

bool ContStruct_InDiscountPremium(const bool buy)
{
   if(!ContStruct_PreferDiscountPrem)
      return true;
   int lb = 20;
   double hi = iHigh(BrokerSymbol, EntryTF, 1);
   double lo = iLow(BrokerSymbol, EntryTF, 1);
   for(int i = 2; i <= lb; i++)
   {
      double h = iHigh(BrokerSymbol, EntryTF, i);
      double l = iLow(BrokerSymbol, EntryTF, i);
      if(h > hi) hi = h;
      if(l < lo && l > 0.0) lo = l;
   }
   if(hi <= lo)
      return true;
   double mid = (hi + lo) * 0.5;
   double price = buy ? SymbolInfoDouble(BrokerSymbol, SYMBOL_BID)
                      : SymbolInfoDouble(BrokerSymbol, SYMBOL_ASK);
   if(buy)
      return (price <= mid); // discount half for continuation buys into demand
   return (price >= mid);    // premium half for continuation sells into supply
}

bool ContStruct_HasDisplacement(const bool buy)
{
   double o = iOpen(BrokerSymbol, EntryTF, 1);
   double c = iClose(BrokerSymbol, EntryTF, 1);
   double h = iHigh(BrokerSymbol, EntryTF, 1);
   double l = iLow(BrokerSymbol, EntryTF, 1);
   double range = h - l;
   if(range <= 0.0)
      return false;
   double body = MathAbs(c - o);
   if(body / range < ContStruct_MinDispBodyRatio)
      return false;
   if(buy && c <= o)
      return false;
   if(!buy && c >= o)
      return false;
   double atr = GetFilterATR();
   if(atr > 0.0 && range < atr * ContStruct_MinDispATR)
      return false;
   return true;
}

bool ContStruct_HTF_OK(const bool buy)
{
   if(!ContStruct_RequireHTF_BOS)
      return true;
   if(DetectDirectionalBOS(APEX_BiasTF, buy))
      return true;
   if(DetectDirectionalBOS(HigherTimeframe, buy))
      return true;
   return RecentDirectionalBOS(buy, ContStruct_BOS_MaxBars) &&
          ((buy && IsBullTrend()) || (!buy && IsBearTrend()));
}

int ContStruct_Score(const bool buy)
{
   // Higher = stronger quality (conflict resolve + MinScore gate)
   int s = 0;
   if(ContStruct_HasQualityBOS(buy)) s += 40;
   if(TrendStrong()) s += 10;
   double zTop, zBot; string kind;
   if(ContStruct_GetFreshZone(buy, zTop, zBot, kind))
   {
      s += (StringFind(kind, "OB-fresh") >= 0) ? 35 : 22;
      bool near = ContStruct_PriceNearZone(buy, zTop, zBot);
      bool disp = ContStruct_HasDisplacement(buy);
      if(near) s += 15;
      if(disp) s += 15;
      if(near && disp) s += 10; // STRONG confluence bonus
   }
   if(ContStruct_InDiscountPremium(buy)) s += 5;
   return s;
}

string ContStruct_Grade(const bool buy)
{
   double zTop, zBot; string kind;
   bool zone = ContStruct_GetFreshZone(buy, zTop, zBot, kind);
   bool near = zone && ContStruct_PriceNearZone(buy, zTop, zBot);
   bool disp = ContStruct_HasDisplacement(buy);
   bool freshOB = (StringFind(kind, "OB-fresh") >= 0);
   if(near && disp && freshOB && TrendStrong())
      return "STRONG";
   if(ContStruct_Score(buy) >= ContStruct_MinScore + 15)
      return "STRONG";
   return "QUALITY";
}

bool ContFallbackBestStructureOK(const bool buy, string &detail)
{
   detail = "";
   double zTop = 0.0, zBot = 0.0;
   string kind = "";
   bool bos = false;
   bool hasZone = false;
   bool near = false;
   bool disp = false;
   int score = 0;

   // OK81 INSTANT OPEN: no trend / ranging / opposite-trend HARD blocks when InstantQualityMode.
   // Quality = prefer BOS + zone + displacement stack; open if ANY structural edge exists.
   if(InstantQualityMode)
   {
      bos = ContStruct_HasQualityBOS(buy);
      hasZone = ContStruct_GetFreshZone(buy, zTop, zBot, kind);
      near = hasZone && ContStruct_PriceNearZone(buy, zTop, zBot);
      disp = ContStruct_HasDisplacement(buy);
      score = ContStruct_Score(buy);

      // Must have at least one real edge (not random)
      if(!bos && !hasZone && !disp)
      {
         detail = "no bos/zone/disp edge yet";
         return false;
      }

      // Soft score: if two+ edges, allow even below MinScore
      int edges = (bos ? 1 : 0) + (hasZone ? 1 : 0) + (disp ? 1 : 0);
      if(ContStruct_MinScore > 0 && score < ContStruct_MinScore && edges < 2)
      {
         detail = StringFormat("score %d < %d and edges=%d", score, ContStruct_MinScore, edges);
         return false;
      }

      if(!ContStruct_HTF_OK(buy))
      {
         // soft: do not block in InstantQualityMode
      }

      detail = StringFormat("%s INSTANT edges=%d bos=%s zone=%s near=%s disp=%s score=%d",
                            ContStruct_Grade(buy),
                            edges,
                            bos ? "Y" : "N",
                            hasZone ? kind : "N",
                            near ? "Y" : "N",
                            disp ? "Y" : "N",
                            score);
      return true;
   }

   // Strict mode (InstantQualityMode=false)
   if(buy && !IsBullTrend()) { detail = "no bull trend"; return false; }
   if(!buy && !IsBearTrend()) { detail = "no bear trend"; return false; }

   if(ContStruct_RequireTrendADX && !TrendStrong())
   {
      detail = "trend not strong (ADX)";
      return false;
   }

   if(ContStruct_SkipRanging && EnableRegimeDetection && GetMarketRegime() == REGIME_RANGING)
   {
      detail = "ranging regime - wait strong trend";
      return false;
   }

   if(!ContStruct_HasQualityBOS(buy))
   {
      detail = "no quality directional BOS";
      return false;
   }

   if(!ContStruct_GetFreshZone(buy, zTop, zBot, kind))
   {
      detail = "no fresh OB / quality FVG";
      return false;
   }

   near = ContStruct_PriceNearZone(buy, zTop, zBot);
   disp = ContStruct_HasDisplacement(buy);

   if(ContStruct_ZoneOrDisplacement)
   {
      if(!near && !disp)
      {
         detail = "need price-at-zone OR displacement (" + kind + ")";
         return false;
      }
   }
   else
   {
      if(!near)
      {
         detail = "price not at structure zone (" + kind + ")";
         return false;
      }
      if(ContStruct_RequireDisplacement && !disp)
      {
         detail = "no displacement impulse";
         return false;
      }
   }

   if(!ContStruct_HTF_OK(buy))
   {
      detail = "HTF BOS missing";
      return false;
   }

   score = ContStruct_Score(buy);
   if(ContStruct_MinScore > 0 && score < ContStruct_MinScore)
   {
      detail = StringFormat("score %d < min %d (need stronger setup)", score, ContStruct_MinScore);
      return false;
   }

   if(IDP_ApplyToContFallback)
   {
      string idpDetail = "";
      if(!IDP_ConfluenceOK(buy, idpDetail))
      {
         detail = "IDP block: " + idpDetail;
         return false;
      }
   }

   string grade = ContStruct_Grade(buy);
   string idpNote = "";
   if(EnableIDPConfluence && IDP_ApplyToContFallback)
   {
      double p = 0.0;
      string pd = "";
      if(IDP_GetPulse(p, pd))
         idpNote = StringFormat(" | %s", pd);
   }
   string bosTag = "BOS";
   if(ContStruct_RequireTwoBarBOS) bosTag = "BOS2";
   string nearTag = "";
   if(near) nearTag = " + near";
   string dispTag = "";
   if(disp) dispTag = " + disp";
   detail = StringFormat("%s %s + %s%s%s score=%d%s",
                         grade,
                         bosTag,
                         kind,
                         nearTag,
                         dispTag,
                         score,
                         idpNote);
   return true;
}

bool ContFallbackSwingBuySetup()
{
   string d = "";
   return ContFallbackBestStructureOK(true, d);
}

bool ContFallbackSwingSellSetup()
{
   string d = "";
   return ContFallbackBestStructureOK(false, d);
}

void EvaluateContFallback(bool &buySignal, bool &sellSignal, string &strategyTag)
{
   // OK93 REMOVED — never opens trades
   buySignal = false; sellSignal = false; strategyTag = "";
}



//====================================================================//




//+------------------------------------------------------------------+
//|         DISPLACEMENT / MOMENTUM EXHAUSTION / DYNAMIC S&R (NEW)   |
//+------------------------------------------------------------------+

//================ DISPLACEMENT STRENGTH ==============================//
// "Displacement" in SMC terms is a forceful, wide-range, mostly-one-
// direction candle (or short run of them) that shows real institutional
// participation - it's the move that LEAVES the FVGs and order blocks
// behind, not just any candle. Previously nothing measured this directly;
// FVG/OB quality scoring approximated it indirectly through gap/impulse
// size. This scores the most recent closed bar's own range against ATR
// AND its body-to-range ratio (a wide bar that's mostly wick is chop, not
// displacement) so a genuine forceful move can be rewarded on its own
// merits, independent of whether it happened to also leave a gap.

input double DisplacementMinBodyRatio = 0.55; // body must be at least this fraction of the bar's total range to count as a real directional push, not an indecisive wick-heavy bar

int GetDisplacementScore(bool buy)
{
   double open1  = iOpen(BrokerSymbol, EntryTF, 1);
   double close1 = iClose(BrokerSymbol, EntryTF, 1);
   double high1  = iHigh(BrokerSymbol, EntryTF, 1);
   double low1   = iLow(BrokerSymbol, EntryTF, 1);

   double range = high1 - low1;
   if(range <= 0.0)
      return 0;

   bool bullishBar = close1 > open1;
   if(buy != bullishBar)
      return 0; // last bar didn't even close in the requested direction - no displacement credit

   double body = MathAbs(close1 - open1);
   double bodyRatio = body / range;

   if(bodyRatio < DisplacementMinBodyRatio)
      return 0; // wide but wick-heavy / indecisive - not real displacement

   double atr = GetFilterATR();
   if(atr <= 0.0)
      return 5;

   double ratio = range / atr;

   if(ratio >= 1.5) return 15; // a genuinely forceful, wide displacement bar
   if(ratio >= 1.0) return 10;
   if(ratio >= 0.6) return 5;

   return 0; // directionally correct and reasonably clean, but not actually wide relative to volatility
}

//================ MOMENTUM EXHAUSTION =================================//
// Momentum exhaustion without RSI/MACD/Stoch: shrinking candle bodies only.
input int MomentumExhaustionBars = 3;

bool IsMomentumExhausted(bool buy)
{
   // Directional check: last closed bar should still be in trade direction
   double o1 = iOpen(BrokerSymbol, EntryTF, 1);
   double c1 = iClose(BrokerSymbol, EntryTF, 1);
   if(buy && c1 <= o1)
      return false;
   if(!buy && c1 >= o1)
      return false;

   double bodies[];
   ArrayResize(bodies, MomentumExhaustionBars);

   for(int i = 0; i < MomentumExhaustionBars; i++)
   {
      double o = iOpen(BrokerSymbol, EntryTF, i+1);
      double c = iClose(BrokerSymbol, EntryTF, i+1);
      bodies[i] = MathAbs(c - o);
   }

   int shrinkCount = 0;
   for(int i = 0; i < MomentumExhaustionBars-1; i++)
   {
      if(bodies[i] < bodies[i+1])
         shrinkCount++;
   }

   return (shrinkCount >= (MomentumExhaustionBars-1+1)/2);
}

//================ DYNAMIC SUPPORT / RESISTANCE REACTIONS (NEW) =======//
// Rewards price currently sitting near a level that has PROVEN itself
// reactive recently - the EMA acting as dynamic S/R, or a still-active
// order block zone - rather than treating "near the EMA" as meaningful
// regardless of whether price has actually respected it lately. Counts how
// many of the last few closed bars reversed direction (a high followed by
// a lower close, or a low followed by a higher close) within one ATR of
// the EMA, as a cheap proxy for "this level has been getting real
// reactions," then checks whether price is currently back at it.

input int    DynamicSRLookbackBars   = 10;
input double DynamicSRProximityATRMultiple = 0.3;

int GetDynamicSRReactionScore(bool buy)
{
   double ema = GetEMA();
   double atr = GetFilterATR();

   if(ema == EMPTY_VALUE || atr <= 0.0)
      return 0;

   double proximity = atr * DynamicSRProximityATRMultiple;
   double price = SymbolInfoDouble(BrokerSymbol, SYMBOL_BID);

   // Only worth scoring if price is actually near the level right now.
   if(MathAbs(price - ema) > proximity)
      return 0;

   int reactions = 0;

   for(int i = 2; i <= DynamicSRLookbackBars; i++)
   {
      double hi = iHigh(BrokerSymbol, EntryTF, i);
      double lo = iLow(BrokerSymbol, EntryTF, i);
      double cl = iClose(BrokerSymbol, EntryTF, i);
      double clPrev = iClose(BrokerSymbol, EntryTF, i+1);

      bool nearLevel = (MathAbs(hi - ema) <= proximity) || (MathAbs(lo - ema) <= proximity);
      if(!nearLevel)
         continue;

      if(buy && lo <= ema + proximity && cl > clPrev)
         reactions++;
      else if(!buy && hi >= ema - proximity && cl < clPrev)
         reactions++;
   }

   if(reactions >= 3) return 10;
   if(reactions >= 1) return 5;
   return 0;
}

//+------------------------------------------------------------------+
//|              PART 15 - AI DECISION LAYER                         |
//+------------------------------------------------------------------+

//================ AI SETTINGS =====================================//

input int MinimumTradeScore = 20;

input group "SNIPER ENTRY FILTER"

// FIX/UPGRADE: the original score system is purely additive - any
// combination of signals that adds up to MinimumTradeScore passes, even
// if none of them actually agree with each other (e.g. a liquidity sweep
// with no real structure break behind it). "Sniper" entries here means
// requiring genuine confluence: a structure event (BOS or CHoCH) AND a
// supporting pattern (FVG or order block in the same direction) both
// present at once, on top of the existing score threshold - not instead
// of it. Turn this off to fall back to the original score-only behavior.

input bool RequireStructureConfluence = false; // OFF for aggressive sniper - was a stacked hard block on legacy confirmations

// FIX (this review): this used to require DetectBOS()/DetectCHoCH() to be
// true on the EXACT SAME BAR as everything else being checked (score
// clearing, a supporting FVG/OB pattern) - but both of those are one-bar-
// only events (true only on the single bar the break happens, false every
// other bar). Requiring all of that to land on one identical candle is
// almost never satisfied in practice, which is why real setups like
// score:25/20 + trend:true + HTF:true were still coming back
// confluence:false and getting blocked. "Structure confluence" now means
// a genuine BOS or CHoCH happened within the last StructureConfluenceLookbackBars
// bars (still real market structure, not stale) plus a supporting
// pattern present right now - matching how this concept is normally used
// in SMC-style analysis (break, then a pullback/retest a few bars later),
// instead of requiring literally the same candle.

input int StructureConfluenceLookbackBars = 5;

bool HasStructureConfluence(bool buy)
{
   int idx = GetSymbolIndex(BrokerSymbol);

   // Still call both so their per-bar detection/recording logic runs even
   // if nothing else does this cycle.
   bool bosNow   = DetectBOS();
   bool chochNow = DetectCHoCH();

   bool structureEvent = bosNow || chochNow;

   if(!structureEvent && idx >= 0 && idx < ArraySize(LastBOSTrueBarTimeArr))
   {
      int barsSinceBOS   = (LastBOSTrueBarTimeArr[idx]   > 0) ? iBarShift(BrokerSymbol, EntryTF, LastBOSTrueBarTimeArr[idx])   : INT_MAX;
      int barsSinceCHoCH = (LastCHoCHTrueBarTimeArr[idx] > 0) ? iBarShift(BrokerSymbol, EntryTF, LastCHoCHTrueBarTimeArr[idx]) : INT_MAX;

      structureEvent = (barsSinceBOS >= 0 && barsSinceBOS <= StructureConfluenceLookbackBars) ||
                        (barsSinceCHoCH >= 0 && barsSinceCHoCH <= StructureConfluenceLookbackBars);
   }

   bool supportingPattern;

   if(buy)
      supportingPattern = DetectBullishFVG() || DetectBullishOrderBlock();
   else
      supportingPattern = DetectBearishFVG() || DetectBearishOrderBlock();

   return (structureEvent && supportingPattern);
}


//================ MARKET REGIME DETECTION (UPGRADE) =================//
// Classifies the market as trending or ranging using ADX (already
// computed, no new indicator needed). SMC-style trend-following signals
// are inherently less reliable during chop - a "bullish" order block in a
// ranging market is a much weaker signal than the same pattern during a
// genuine trend. This doesn't block trades on its own; it feeds into
// adaptive scoring below, which raises the bar during ranging conditions
// rather than refusing to trade in them outright.

input group "MARKET REGIME DETECTION"

input bool   EnableRegimeDetection = true;
input double RegimeADXThreshold    = 22.0;

// FINE-TUNE (this pass): a raw ADX-vs-threshold read flips regime on every
// bar where ADX is oscillating near RegimeADXThreshold - literally the
// "regime switching accuracy" problem. Adds a buffer band: once a regime
// is confirmed, ADX has to clear the threshold by RegimeHysteresisBand in
// the OPPOSITE direction before the regime is allowed to flip again. A
// reading that stays within the band of the threshold keeps the
// last-confirmed regime instead of relabeling. Falls back to a plain
// threshold read (old behavior) the first time a symbol is evaluated,
// since there's no prior confirmed state to hold onto yet.
input double RegimeHysteresisBand = 3.0; // ADX must clear the threshold by this much, in the new direction, to flip an already-confirmed regime

MarketRegime GetMarketRegime()
{
   double adx = GetADX();

   if(adx == EMPTY_VALUE)
      return REGIME_RANGING; // unknown - treat as the more cautious case

   int idx = GetSymbolIndex(BrokerSymbol);
   int lastState = (idx >= 0 && idx < ArraySize(RegimeLastStateArr)) ? RegimeLastStateArr[idx] : -1;

   MarketRegime result;

   if(lastState == -1)
   {
      // No confirmed prior state yet - plain threshold read to seed it.
      result = (adx >= RegimeADXThreshold) ? REGIME_TRENDING : REGIME_RANGING;
   }
   else if((MarketRegime)lastState == REGIME_TRENDING)
   {
      // Already trending - only drop back to ranging if ADX has fallen
      // clearly below the threshold, not just touched it.
      result = (adx < RegimeADXThreshold - RegimeHysteresisBand) ? REGIME_RANGING : REGIME_TRENDING;
   }
   else
   {
      // Already ranging - only promote to trending once ADX has cleared
      // the threshold with margin, not just poked above it.
      result = (adx > RegimeADXThreshold + RegimeHysteresisBand) ? REGIME_TRENDING : REGIME_RANGING;
   }

   if(idx >= 0 && idx < ArraySize(RegimeLastStateArr))
      RegimeLastStateArr[idx] = (int)result;

   return result;
}


//================ ADAPTIVE SCORING (UPGRADE) =========================//
// Raises the effective score threshold above MinimumTradeScore when
// conditions call for more caution: a ranging market (per the regime
// detection above) and/or a recent losing streak (from the trade
// statistics in Part 18). This is real adaptation - the bar a setup has
// to clear moves based on current market conditions and recent
// performance, not a fixed number regardless of context. The loss-streak
// penalty is capped so it can't spiral into requiring an impossible score
// after a bad run.

input group "ADAPTIVE SCORING"

input bool EnableAdaptiveScoring        = true;
input int  RangingRegimeScorePenalty    = 5; // REDUCED from 10 - your GBPUSD log showed a SELL scoring 25 blocked by a 30 threshold, where the +10 from this penalty was the entire gap. At +5, that same 25 would clear a 25 threshold instead.
input int  ConsecutiveLossScorePenalty  = 5;
input int  MaxConsecutiveLossPenaltySteps = 3;

int GetEffectiveMinimumScore()
{
   int effective = MinimumTradeScore;

   if(!EnableAdaptiveScoring)
      return effective;

   if(EnableRegimeDetection && GetMarketRegime() == REGIME_RANGING)
      effective += RangingRegimeScorePenalty;

   // FIX: this used to read the single global Stat_ConsecutiveLosses -
   // shared across every symbol - so a BTC losing streak raised the score
   // bar for EURUSD (and vice versa) even though the two have no relation
   // to each other. Now reads this symbol's own consecutive-loss count
   // (tracked in OnTradeTransaction), falling back to the old global
   // behavior only if this symbol somehow isn't in the tracked list.
   int idx = GetSymbolIndex(BrokerSymbol);
   int consecutiveLosses = (idx >= 0 && idx < ArraySize(ConsecutiveLossesPerSymbolArr))
                           ? ConsecutiveLossesPerSymbolArr[idx]
                           : Stat_ConsecutiveLosses;

   int lossSteps = MathMin(consecutiveLosses, MaxConsecutiveLossPenaltySteps);
   effective += lossSteps * ConsecutiveLossScorePenalty;

   return effective;
}


//================ CALCULATE TRADE SCORE ============================//

int CalculateTradeScore(bool buy)
{
   int score = 0;

   // Trend
   if(buy)
   {
      if(IsBullTrend())
         score += 20;
   }
   else
   {
      if(IsBearTrend())
         score += 20;
   }

   // Structure - each component's raw contribution is now scaled by
   // SignalWeightMultiplier(), which reads that signal type's live,
   // persisted win/loss record (SigStat_*) and nudges its weight up or
   // down accordingly once there's enough sample to trust it. Neutral
   // (1.0x, i.e. no behavior change) until then, or if
   // EnableAdaptiveWeighting is off.
   if(DetectBOS())
      score += (int)MathRound(15 * SignalWeightMultiplier(SigStat_BOS_Win, SigStat_BOS_Loss));

   if(DetectCHoCH())
      score += (int)MathRound(15 * SignalWeightMultiplier(SigStat_CHoCH_Win, SigStat_CHoCH_Loss));

   if(DetectLiquiditySweep())
      score += (int)MathRound(GetLiquiditySweepQualityScore() * SignalWeightMultiplier(SigStat_Sweep_Win, SigStat_Sweep_Loss));

   // NEW: stop hunt is a stricter subset of a generic sweep - scored as an
   // additional bonus on top (not instead of) the sweep score above, since
   // a confirmed stop-hunt candle is stronger evidence than an ordinary
   // sweep. Shares the sweep win/loss stat since it's the same underlying
   // signal family, just a higher-conviction variant of it.
   // BUGFIX40: DetectStopHunt(true)=buy-side (highs). For a BUY score we need
   // sell-side (lows) hunt — was rewarding the wrong polarity.
   if(DetectStopHunt(buy ? false : true))
      score += (int)MathRound(10 * SignalWeightMultiplier(SigStat_Sweep_Win, SigStat_Sweep_Loss));

   // NEW: inducement - a shallow, fast-reversing liquidity grab in the
   // OPPOSITE direction, used here as supporting evidence FOR this trade's
   // direction (buy-side inducement = sell-side liquidity was induced and
   // swept, supporting a bullish reversal).
   if(DetectInducement(buy))
      score += 8;

   // NEW: displacement strength - a genuinely forceful, mostly-body
   // directional candle, independent of whether it happened to leave a
   // gap behind (see GetDisplacementScore()).
   score += GetDisplacementScore(buy);

   // NEW: dynamic support/resistance - price currently sitting at a level
   // (the EMA) that has demonstrably produced real reactions recently, not
   // just "near the EMA" on its own.
   score += GetDynamicSRReactionScore(buy);

   // Direction-specific confirmations
   if(buy)
   {
      // UPGRADE: was a flat +10 for any 2-bar "equal low"; now graduated by
      // how many bars actually cluster at that level - see
      // GetEqualLowPoolScore()/CountEqualLowTouches().
      score += GetEqualLowPoolScore();

      // UPGRADE: was a flat FVG size score with no mitigation awareness -
      // GetFVGQualityScore() discounts a gap that's already been partly or
      // fully traded back into (see FVG mitigation tracking above).
      score += (int)MathRound(GetFVGQualityScore(true) * SignalWeightMultiplier(SigStat_FVG_Win, SigStat_FVG_Loss));

      // UPGRADE: was a flat +15 for any OB detected in the last 2 candles
      // (impossible to tell fresh from already-tapped-and-invalid). Now
      // uses the persistent fresh/mitigated/invalidated tracker.
      double obWeight = SignalWeightMultiplier(SigStat_OB_Win, SigStat_OB_Loss);
      if(IsOrderBlockFreshAndValid(true))
         score += (int)MathRound(15 * obWeight);
      else if(IsOrderBlockMitigated(true))
         score += (int)MathRound(7 * obWeight); // still real support, just already tapped once - half credit
   }
   else
   {
      score += GetEqualHighPoolScore();

      score += (int)MathRound(GetFVGQualityScore(false) * SignalWeightMultiplier(SigStat_FVG_Win, SigStat_FVG_Loss));

      double obWeight = SignalWeightMultiplier(SigStat_OB_Win, SigStat_OB_Loss);
      if(IsOrderBlockFreshAndValid(false))
         score += (int)MathRound(15 * obWeight);
      else if(IsOrderBlockMitigated(false))
         score += (int)MathRound(7 * obWeight);
   }

   if(MarketConditionOK())
      score += 5;

   // UPGRADE: volatility expansion bonus - only contributes when the
   // filter is actually enabled (see IsVolatilityExpanding()).
   if(IsVolatilityExpanding())
      score += (int)MathRound(10 * SignalWeightMultiplier(SigStat_VolExp_Win, SigStat_VolExp_Loss));

   // NEW: bonus for trading near a prior D1/W1 liquidity level in the
   // trade's favor (see GetLiquidityProximityScore() above). Additive
   // only - never blocks a trade on its own, just nudges the score for
   // setups located at genuinely significant liquidity.
   score += GetLiquidityProximityScore(buy);

   // NEW: penalize a direction that just had a failed breakout/trap in it -
   // see DetectFakeBreakoutTrap() above.
   if(DetectFakeBreakoutTrap(buy))
      score -= 15;

   // NEW: momentum exhaustion penalty - RSI extreme + decelerating candle
   // bodies suggests this move is running out of conviction. Doesn't block
   // the trade on its own, just makes it need more support elsewhere to
   // clear the bar.
   if(IsMomentumExhausted(buy))
      score -= 10;

   return score;
}


//================ MANDATORY CONFIRMATIONS (formalized, this pass) ====//
// These are the institutional-structure gates that MUST pass before the
// optional, additive AI score (CalculateTradeScore) is even computed:
// trend direction, HTF agreement, structure confluence, MTF structure
// confluence, and premium/discount positioning. Previously this order
// lived as two separate, hand-copied sequences of if-checks in
// StrongBuySetup()/StrongSellSetup() - correct today, but nothing stopped
// a future edit to one from drifting out of sync with the other. Bundling
// them into a single function makes "mandatory confirmations always run
// before optional scoring, and both directions use the identical gate
// order" a structural guarantee instead of a convention that has to be
// remembered.
bool MandatoryConfirmationsPassed(bool buy)
{
   if(buy ? !IsBullTrend() : !IsBearTrend())
      return false;

   if(!HTFConfirms(buy))
      return false;

   if(RequireStructureConfluence && !HasStructureConfluence(buy))
      return false;

   if(EnableMTFStructureConfluence && !HasHTFStructureConfluence(buy))
      return false;

   if(EnablePremiumDiscountFilter && !(buy ? InDiscountZone() : InPremiumZone()))
      return false;

   return true;
}

//================ DUPLICATE SIGNAL FILTER (NEW, this pass) ===========//
// See LastApprovedBuyBarTimeArr/LastApprovedSellBarTimeArr declaration
// (Part 1) for the full rationale: CooldownFinished() only throttles by
// elapsed time since the last FILLED trade, which says nothing about
// whether THIS approval is a re-fire of the same signal that already
// filled earlier on the same still-forming bar (possible with
// EnableTickLevelSignalDetection on and a short TradeCooldownMinutes).
// TRADEFIRE54: never treat unset (0) bar times as a match — that was
// suppressing ContSniper on every tick when EntryTF history was not ready
// (iTime==0 == LastApproved init 0). Also do not suppress if the prior
// fill on this bar was already closed (defense/SL) — allow a fresh fire.
bool HasOpenEADirectionPosition(bool buy)
{
   ENUM_POSITION_TYPE want = buy ? POSITION_TYPE_BUY : POSITION_TYPE_SELL;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;
      if(!PositionSelectByTicket(ticket))
         continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != BrokerSymbol)
         continue;
      if((ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE) == want)
         return true;
   }
   return false;
}

bool IsDuplicateSignal(bool buy)
{
   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0)
      return false;

   datetime currentBarTime = iTime(BrokerSymbol, EntryTF, 0);
   // No valid bar identity → never suppress (was 0==0 false positive)
   if(currentBarTime <= 0)
      return false;

   datetime lastApproved = 0;
   if(buy)
   {
      if(idx < ArraySize(LastApprovedBuyBarTimeArr))
         lastApproved = LastApprovedBuyBarTimeArr[idx];
   }
   else
   {
      if(idx < ArraySize(LastApprovedSellBarTimeArr))
         lastApproved = LastApprovedSellBarTimeArr[idx];
   }

   // Never approved this symbol/direction, or different bar → not a duplicate
   if(lastApproved <= 0 || lastApproved != currentBarTime)
      return false;

   // Same bar was marked after a fill — only suppress while that position is still open
   if(!HasOpenEADirectionPosition(buy))
      return false;

   return true;
}

void MarkSignalApproved(bool buy)
{
   int idx = GetSymbolIndex(BrokerSymbol);
   if(idx < 0)
      return;

   datetime currentBarTime = iTime(BrokerSymbol, EntryTF, 0);
   // Do not stamp 0 — would re-create the 0==0 suppress bug
   if(currentBarTime <= 0)
      return;

   if(buy)
   {
      if(idx < ArraySize(LastApprovedBuyBarTimeArr))
         LastApprovedBuyBarTimeArr[idx] = currentBarTime;
   }
   else
   {
      if(idx < ArraySize(LastApprovedSellBarTimeArr))
         LastApprovedSellBarTimeArr[idx] = currentBarTime;
   }
}


//================ STRONG BUY SETUP ================================//

bool StrongBuySetup()
{
   return false; // OK67 RETIRED — not on live path

   // MANDATORY confirmations first, always - see MandatoryConfirmationsPassed().
   // The optional, additive score below never even runs if these don't
   // clear, by construction.
   if(!MandatoryConfirmationsPassed(true))
      return false;

   int score = CalculateTradeScore(true);
   int requiredScore = GetEffectiveMinimumScore();

   if(EnableVerboseLogging)
      Print("BUY AI Score: ", score, " / required: ", requiredScore,
            " (regime: ", EnumToString(GetMarketRegime()), ")");

   bool approved = (score >= requiredScore);

   // NEW: duplicate-signal guard - see IsDuplicateSignal() above. Checked
   // only once the setup has otherwise fully qualified, so it never masks
   // a genuinely fresh signal; it only blocks re-approving the identical
   // bar's signal a second time.
   if(approved && IsDuplicateSignal(true))
   {
      if(EnableVerboseLogging) Print("BUY approval suppressed - duplicate signal on the same bar.");
      approved = false;
   }

   // FIX #6: capture the exact snapshot (score + every signal flag) at the
   // moment the decision is actually made - before ExecuteBuy() runs and
   // potentially spends time on retries/requotes during which price and
   // indicators can move on. RecordSignalSnapshot() (Part 6) uses this
   // instead of recalculating everything fresh after the fact.
   if(approved)
   {
      MarkSignalApproved(true);
      CapturePendingSignalSnapshot(true);
   }

   return approved;
}


//================ STRONG SELL SETUP ===============================//

bool StrongSellSetup()
{
   return false; // OK67 RETIRED — not on live path

   if(!MandatoryConfirmationsPassed(false))
      return false;

   int score = CalculateTradeScore(false);
   int requiredScore = GetEffectiveMinimumScore();

   if(EnableVerboseLogging)
      Print("SELL AI Score: ", score, " / required: ", requiredScore,
            " (regime: ", EnumToString(GetMarketRegime()), ")");

   bool approved = (score >= requiredScore);

   if(approved && IsDuplicateSignal(false))
   {
      if(EnableVerboseLogging) Print("SELL approval suppressed - duplicate signal on the same bar.");
      approved = false;
   }

   if(approved)
   {
      MarkSignalApproved(false);
      CapturePendingSignalSnapshot(false);
   }

   return approved;
}
//+------------------------------------------------------------------+
//|              PART 16 - CHART DASHBOARD & THEME                   |
//+------------------------------------------------------------------+

//================ DASHBOARD SETTINGS ===============================//

input group "DASHBOARD"


// FIX/SIMPLIFY: the previous dashboard displayed a "win rate"/AI-score
// style accuracy figure that had no reliable, verifiable basis (a handful
// of trades can show 80%+ "accuracy" that means nothing statistically,
// and it invites over-trusting the EA). Per request, the dashboard is
// stripped down to exactly three things that are always simply, directly
// true: which chart/timeframe this is, which bot is running it, and how
// many trades it currently has open.

//================ CREATE DASHBOARD =================================//


// CreateDashboard -> HITMAN_ULTRA/08_Dashboard.mqh




//================ UPDATE DASHBOARD =================================//

// FIX: UpdateDashboard() ran CreateDashboard() (which calls
// CountOpenTrades() - a PositionsTotal() loop - plus a Comment() call)
// on every single OnTick(), regardless of how fast ticks were arriving.
// Throttled to at most once per second - the dashboard doesn't need
// tick-level refresh to be useful, and this cuts needless repeated work
// on fast-ticking symbols.


long g_LastDashboardUpdateMs = 0;

void UpdateDashboard()
{
   long nowMs = (long)GetTickCount();

   if(nowMs - g_LastDashboardUpdateMs < DashboardRefreshMillis)
      return;

   g_LastDashboardUpdateMs = nowMs;

   CreateDashboard();
}

//================ CHART THEME (white background / pink candles) =====//

input group "CHART THEME"

input bool  EnableCustomChartTheme = false;
input color ChartThemeBackground   = clrWhite;
input color ChartThemeForeground   = clrBlack;
input color ChartThemeGrid         = clrGainsboro;
input color ChartThemeBullCandle   = clrDeepPink;   // up candle body
input color ChartThemeBearCandle   = clrPink;        // down candle body - a lighter pink so bull/bear stay visually distinct while both reading as "pink"
input color ChartThemeCandleBorder = clrMediumVioletRed;
input color ChartThemeBidLine      = clrDeepPink;
input color ChartThemeAskLine      = clrHotPink;

void ApplyChartTheme()
{
   if(!EnableCustomChartTheme)
      return;

   ChartSetInteger(0, CHART_MODE, CHART_CANDLES);

   ChartSetInteger(0, CHART_COLOR_BACKGROUND, ChartThemeBackground);
   ChartSetInteger(0, CHART_COLOR_FOREGROUND, ChartThemeForeground);
   ChartSetInteger(0, CHART_COLOR_GRID, ChartThemeGrid);

   ChartSetInteger(0, CHART_COLOR_CANDLE_BULL, ChartThemeBullCandle);
   ChartSetInteger(0, CHART_COLOR_CANDLE_BEAR, ChartThemeBearCandle);
   ChartSetInteger(0, CHART_COLOR_CHART_UP,   ChartThemeCandleBorder);
   ChartSetInteger(0, CHART_COLOR_CHART_DOWN, ChartThemeCandleBorder);
   ChartSetInteger(0, CHART_COLOR_CHART_LINE, ChartThemeCandleBorder);

   ChartSetInteger(0, CHART_COLOR_VOLUME, ChartThemeCandleBorder);
   ChartSetInteger(0, CHART_COLOR_BID, ChartThemeBidLine);
   ChartSetInteger(0, CHART_COLOR_ASK, ChartThemeAskLine);
   ChartSetInteger(0, CHART_COLOR_STOP_LEVEL, clrGray);

   ChartSetInteger(0, CHART_SHOW_GRID, true);

   ChartRedraw();
}
//+------------------------------------------------------------------+
//|              PART 17 - FINAL INTEGRATION SYSTEM                  |
//+------------------------------------------------------------------+

// NOTE: StartFinalSystem()/RunFinalAnalysis() used to live here as wrappers
// around InitializeRiskEngine()/InitializeSymbols()/UpdateDashboard()/
// ScanMarkets()/ManageOpenTrades() - but were never called by OnInit/OnTick,
// which call those functions directly. Removed as dead code. ScanMarkets()
// itself (along with IsSymbolValid()) was later removed too, for the same
// reason - see Part 13.
//
// Also note: TradeSymbols/InitializeSymbols() preload and print
// availability for the listed symbols; with EnableMultiSymbolTrading on,
// ExecuteBuy()/ExecuteSell() run for every symbol in the list via
// RunTradingCycle() (Part 1) - see Part 13's notes for the mechanics.

//================ FINAL TRADE VALIDATION ============================//

bool FinalTradeCheck()
{
   if(!TradeProtectionOK())
   {
      if(EnableVerboseLogging) Print("FAILED: Trade Protection");
      return false;
   }

   if(!RiskManagementOK())
   {
      if(EnableVerboseLogging) Print("FAILED: Risk Engine");
      return false;
   }

   if(!MarketConditionOK())
   {
      if(EnableVerboseLogging) Print("FAILED: Market Condition");
      return false;
   }

   if(EnableVerboseLogging) Print("FINAL CHECK PASSED");

   return true;
}
//+------------------------------------------------------------------+
//|              INSTANT AI EXECUTION ENGINE                         |
//+------------------------------------------------------------------+

// FIX: "No valid setup" on its own gives no way to tell whether it's the
// trend filter, HTF confirmation, the structure confluence gate, or the
// score threshold that's blocking entries - which makes a quiet EA
// impossible to diagnose from the Journal alone. This prints a one-line
// breakdown of every gate for both directions, once per new bar PER
// SYMBOL (not every tick, to avoid flooding the log), so it's immediately
// visible which specific condition is holding back a g_Trade.


//================ CLEAN LIVE MARKET ANALYSIS (OK70) =================//
// One read of what matters for APEX + ContFallback — no ContSniper/PRISM noise.

void AnalyzeLiveMarket(const bool force)
{
   if(!force && g_LiveMktCycle == g_CycleCounter && g_LiveMkt.valid)
      return;

   g_LiveMktCycle = g_CycleCounter;
   LiveMarketAnalysis m;
   m.valid = true;
   m.barTime = iTime(BrokerSymbol, EntryTF, 0);
   m.bull = IsBullTrend();
   m.bear = IsBearTrend();
   m.trendStrong = TrendStrong();
   m.regime = GetMarketRegime();

   // Refresh zone trackers once so analysis matches ContFallback
   UpdateOrderBlockTracking();
   UpdateFVGTracking();

   m.bosBuy  = ContStruct_HasQualityBOS(true);
   m.bosSell = ContStruct_HasQualityBOS(false);

   double zTop = 0.0, zBot = 0.0;
   string kind = "";
   m.zoneBuy  = ContStruct_GetFreshZone(true,  zTop, zBot, kind);
   m.nearBuy  = m.zoneBuy  && ContStruct_PriceNearZone(true,  zTop, zBot);
   m.dispBuy  = ContStruct_HasDisplacement(true);

   zTop = 0.0; zBot = 0.0; kind = "";
   m.zoneSell = ContStruct_GetFreshZone(false, zTop, zBot, kind);
   m.nearSell = m.zoneSell && ContStruct_PriceNearZone(false, zTop, zBot);
   m.dispSell = ContStruct_HasDisplacement(false);

   m.contBuyDetail = "";
   m.contSellDetail = "";
   // OK93: live analysis from ULTRA only (old ContFallback/APEX probes removed)
   {
      UltraSnap us;
      UltraBuildSnapshot(BrokerSymbol, us);
      UltraSignal ub = UltraStrat_ContSniper(us);
      UltraSignal usw = UltraStrat_FlashSweep(us);
      m.contBuyOK = (ub.buy || usw.buy);
      m.contSellOK = (ub.sell || usw.sell);
      m.contBuyDetail  = m.contBuyOK  ? "ULTRA READY" : ("ULTRA confB=" + IntegerToString(UltraConfluenceBuy(us)));
      m.contSellDetail = m.contSellOK ? "ULTRA READY" : ("ULTRA confS=" + IntegerToString(UltraConfluenceSell(us)));
      g_APEX_LastBuyFail  = us.bos.buy  ? "" : "no ULTRA BOS buy";
      g_APEX_LastSellFail = us.bos.sell ? "" : "no ULTRA BOS sell";
   }

   string sess = "", sessName = "";
   bool inL = false, inN = false, inA = false, inO = false;
   int hourS = -1;
   DetectMarketSession(sessName, sess, inL, inN, inA, inO, hourS);
   // also annotate kill-zone soft/hard via APEX_InKillZone (does not change detect)
   string kz = "";
   APEX_InKillZone(kz);
   m.session = sess;
   m.sessionName = sessName;
   m.inLondon = inL;
   m.inNewYork = inN;
   m.inAsia = inA;
   m.inOverlap = inO;
   m.sessionHour = hourS;

   string newsDetail = "";
   bool newsWin = false;
   if(EnableNewsAwareness)
      newsWin = NewsAwarenessInWindow(newsDetail);
   m.news = newsWin ? newsDetail : (EnableNewsAwareness ? "news clear" : "news awareness off");

   m.apexBuy  = (g_APEX_LastBuyFail  == "" ? "ready/checking" : g_APEX_LastBuyFail);
   m.apexSell = (g_APEX_LastSellFail == "" ? "ready/checking" : g_APEX_LastSellFail);

   if(m.bull && !m.bear) m.bias = "BULL";
   else if(m.bear && !m.bull) m.bias = "BEAR";
   else if(m.bull && m.bear) m.bias = "MIXED";
   else m.bias = "FLAT";

   string adxTag = "";
   if(m.trendStrong) adxTag = "+ADX";
   string bosBuyS = "N"; if(m.bosBuy) bosBuyS = "Y";
   string bosSellS = "N"; if(m.bosSell) bosSellS = "Y";
   string zoneBuyS = "N"; if(m.zoneBuy) zoneBuyS = "Y";
   string zoneSellS = "N"; if(m.zoneSell) zoneSellS = "Y";
   string nearBuyS = "N"; if(m.nearBuy) nearBuyS = "Y";
   string nearSellS = "N"; if(m.nearSell) nearSellS = "Y";
   string dispBuyS = "N"; if(m.dispBuy) dispBuyS = "Y";
   string dispSellS = "N"; if(m.dispSell) dispSellS = "Y";
   string contBuyS = "wait"; if(m.contBuyOK) contBuyS = "READY";
   string contSellS = "wait"; if(m.contSellOK) contSellS = "READY";
   m.summary = StringFormat(
      "%s | SESSION=%s h%d | %s%s | BOS B/S=%s/%s | Zone B/S=%s/%s | Near=%s/%s | Disp=%s/%s | Cont B/S=%s/%s",
      m.bias,
      m.sessionName,
      m.sessionHour,
      EnumToString(m.regime),
      adxTag,
      bosBuyS,
      bosSellS,
      zoneBuyS,
      zoneSellS,
      nearBuyS,
      nearSellS,
      dispBuyS,
      dispSellS,
      contBuyS,
      contSellS);

   g_LiveMkt = m;
}

string LiveMarketSummary()
{
   AnalyzeLiveMarket(false);
   return g_LiveMkt.summary;
}

void PrintLiveMarketAnalysis()
{
   AnalyzeLiveMarket(true);
   Print("---- MARKET ANALYSIS BUILD=HA_ULTRA_93 (", BrokerSymbol, ") ----");
   Print("SESSION=", g_LiveMkt.sessionName,
         " hour=", g_LiveMkt.sessionHour,
         (APEX_UseGMT ? " GMT" : " SERVER"),
         " London=", g_LiveMkt.inLondon,
         " NY=", g_LiveMkt.inNewYork,
         " Asia=", g_LiveMkt.inAsia,
         " Overlap=", g_LiveMkt.inOverlap);
   Print("Bias=", g_LiveMkt.bias,
         " Regime=", EnumToString(g_LiveMkt.regime),
         " ADXstrong=", g_LiveMkt.trendStrong,
         " | ", g_LiveMkt.session);
   Print("Structure BUY : BOS=", g_LiveMkt.bosBuy,
         " Zone=", g_LiveMkt.zoneBuy,
         " Near=", g_LiveMkt.nearBuy,
         " Disp=", g_LiveMkt.dispBuy,
         " Cont=", (g_LiveMkt.contBuyOK ? "READY" : g_LiveMkt.contBuyDetail));
   Print("Structure SELL: BOS=", g_LiveMkt.bosSell,
         " Zone=", g_LiveMkt.zoneSell,
         " Near=", g_LiveMkt.nearSell,
         " Disp=", g_LiveMkt.dispSell,
         " Cont=", (g_LiveMkt.contSellOK ? "READY" : g_LiveMkt.contSellDetail));
   Print("APEX BUY wait : ", g_LiveMkt.apexBuy);
   Print("APEX SELL wait: ", g_LiveMkt.apexSell);
   Print("News: ", g_LiveMkt.news);
   Print("SUMMARY: ", g_LiveMkt.summary);
   Print("NOTE: ANYTIME + STRONG/QUALITY ContFallback | session detect soft | spread/news never hard-block");
}


void PrintSetupDiagnostics()
{
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0 || idx >= ArraySize(DiagLastBarTimeArr))
      return;

   datetime barTime = iTime(BrokerSymbol, EntryTF, 0);

   if(barTime == DiagLastBarTimeArr[idx])
      return;

   DiagLastBarTimeArr[idx] = barTime;

   // OK70: clean market analysis only (no ContSniper/PRISM spam)
   PrintLiveMarketAnalysis();
}

input bool EnableSetupLogging = true; // CHANGED default to true - "silent when nothing fires" was indistinguishable from "broken" with no way to tell the difference. Prints once per new bar only, not per-tick, so it won't flood the Journal.

// FIX/UPGRADE - NEW CANDLE CONFIRMATION: entry evaluation used to run on
// every single tick. On a fast-moving symbol like BTCUSD, price can cross
// back and forth over a trigger level many times within one bar, which
// can produce open/close churn - a trade opens, conditions flicker back
// the other way a few ticks later, and something closes it again. Gating
// entry evaluation to once per newly closed bar removes that tick-level
// noise. Trade MANAGEMENT (SL/TP, trailing, trend exit in ManageOpenTrades)
// still runs every tick as before - that part needs to react immediately,
// only new entries are bar-gated.
//
// FIX (found in this review): this bar-gate used to be a single global
// datetime (LastEntryEvalBarTime) shared across every symbol - see the
// note on DetectCHoCH()/PrintSetupDiagnostics() above for the same class
// of bug. Now uses LastEntryEvalBarTimeArr (Part 1), indexed per symbol.
//
// CHANGED per request: EnableTickLevelSignalDetection lets you evaluate
// on every tick instead of waiting for a new closed bar. Real tradeoff,
// not a free upgrade - this reopens the exact churn risk described above
// (price wobbling across a trigger level can open/re-evaluate rapidly).
// AttemptCooldownSeconds and the trade cooldowns still throttle actual
// EXECUTION, so this won't spam orders, but the signal check itself will
// now re-run continuously rather than once per bar. Default true per
// request; set back to false to restore the original once-per-bar gate.

input bool EnableTickLevelSignalDetection = true;

void InstantExecution()
{
   int idx = GetSymbolIndex(BrokerSymbol);

   if(idx < 0)
   {
      Print("InstantExecution: symbol not tracked: ", BrokerSymbol,
            " — skip (check DetectBrokerSymbol / MultiSymbolList)");
      return;
   }

   // OK70: news aware + clean market analysis (never refuse on news/spread)
   UpdateNewsAwareness();
   AnalyzeLiveMarket(false);

   if(EnableUltraCore && UltraHealthMonitor)
      g_UltraDecisionStartMs = (long)GetTickCount();

   // Every symbol gets its own trading-cycle "tick" for the indicator
   // cache (Part 2) - incremented once per RunTradingCycle() call so
   // GetEMA()/GetADX()/GetATR() only re-fetch buffers once per symbol per
   // cycle instead of once per call.
   g_CycleCounter++;

   datetime currentBarTime = iTime(BrokerSymbol, EntryTF, 0);

   // ALLTRADE56: iTime==0 must not equal LastEntryEval init 0 forever
   if(currentBarTime <= 0)
   {
      static datetime lastHistWarn = 0;
      if(TimeCurrent() - lastHistWarn >= 60)
      {
         lastHistWarn = TimeCurrent();
         Print("EntryTF history not ready for ", BrokerSymbol,
               " TF=", EnumToString(EntryTF), " — evaluating anyway (tick path)");
      }
   }
   else if(!EnableTickLevelSignalDetection)
   {
      if(currentBarTime == LastEntryEvalBarTimeArr[idx])
         return; // already evaluated this bar for this symbol - wait for the next one
   }

   // Ultra smart tick filter: same bid/ask + already decided this price → skip
   if(EnableTickLevelSignalDetection && UltraSmartTickUnchanged())
      return;

   if(currentBarTime > 0)
      LastEntryEvalBarTimeArr[idx] = currentBarTime;

   if(EnableVerboseLogging)
      Print("Instant Execution Running (", BrokerSymbol, ")");

   if(!FinalTradeCheck())
   {
      UltraSetWait("FinalTradeCheck wait");
      if(EnableVerboseLogging) Print("Final trade check failed");
      return;
   }

   if(!CooldownFinished())
   {
      UltraSetWait("trade cooldown wait");
      if(EnableVerboseLogging) Print("Trade cooldown active");
      return;
   }

   // EvaluateStrategySignals() = OK93 HITMAN AI complete architecture.
   bool buySignal, sellSignal;
   string strategyTag;
   EvaluateStrategySignals(buySignal, sellSignal, strategyTag);

   // Correlation confirmation filter (Part 15f) - applies to whichever
   // strategy fired above, regardless of which one it was. Off by default
   // (EnableCorrelationFilter=false), so no behavior change unless
   // deliberately turned on.
   if(buySignal && !CorrelationFilterOK(true))
   {
      UltraSetReject("correlation filter blocked BUY");
      buySignal = false;
   }

   if(sellSignal && !CorrelationFilterOK(false))
   {
      UltraSetReject("correlation filter blocked SELL");
      sellSignal = false;
   }

   if(buySignal)
   {
      if((EnableBeastMode || EnableUltraCore) && !PRISMFinalizeApproval(true, strategyTag))
      {
         Print("FIRE BLOCKED after ", strategyTag, " BUY select: ",
               (g_UltraLastReject == "" ? "FinalizeApproval failed" : g_UltraLastReject),
               " on ", BrokerSymbol);
         return;
      }

      Print("BUY approved (", BrokerSymbol, ") [", strategyTag, "]");
      g_PendingStrategyTag = strategyTag;
      if(ExecuteBuy())
      {
         UltraDiscipline_OnFill(BrokerSymbol, true, strategyTag, g_UltraLastSnap);
         UltraThesis_StoreLatest(BrokerSymbol, true, strategyTag, g_UltraLastSnap, g_UltraLastSignal.reason);
         // Position lock + decision log (Mission Control)
         {
            ulong tk = 0;
            for(int i = PositionsTotal() - 1; i >= 0; i--)
            {
               ulong tix = PositionGetTicket(i);
               if(tix == 0 || !PositionSelectByTicket(tix)) continue;
               if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
               if(PositionGetString(POSITION_SYMBOL) != BrokerSymbol) continue;
               if(PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_BUY) continue;
               tk = tix; break;
            }
            if(tk != 0)
               UltraMission_NoteOpen(tk, BrokerSymbol, true, strategyTag);
         }
         if(EnableBeastMode && BeastDuplicateBarGuard)
            MarkSignalApproved(true);
      }
      else
         Print("BUY approved but ExecuteBuy FAILED on ", BrokerSymbol, " [", strategyTag, "]");
      if(EnableUltraCore && UltraHealthMonitor)
      {
         g_UltraLastDecisionMs = (long)GetTickCount() - g_UltraDecisionStartMs;
         g_UltraHealthOK = (g_UltraLastDecisionMs < 500) ? 1 : 0;
      }
      return;
   }

   if(sellSignal)
   {
      if((EnableBeastMode || EnableUltraCore) && !PRISMFinalizeApproval(false, strategyTag))
      {
         Print("FIRE BLOCKED after ", strategyTag, " SELL select: ",
               (g_UltraLastReject == "" ? "FinalizeApproval failed" : g_UltraLastReject),
               " on ", BrokerSymbol);
         return;
      }

      Print("SELL approved (", BrokerSymbol, ") [", strategyTag, "]");
      g_PendingStrategyTag = strategyTag;
      if(ExecuteSell())
      {
         UltraDiscipline_OnFill(BrokerSymbol, false, strategyTag, g_UltraLastSnap);
         UltraThesis_StoreLatest(BrokerSymbol, false, strategyTag, g_UltraLastSnap, g_UltraLastSignal.reason);
         // Position lock + decision log (Mission Control)
         {
            ulong tk = 0;
            for(int i = PositionsTotal() - 1; i >= 0; i--)
            {
               ulong tix = PositionGetTicket(i);
               if(tix == 0 || !PositionSelectByTicket(tix)) continue;
               if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
               if(PositionGetString(POSITION_SYMBOL) != BrokerSymbol) continue;
               if(PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_SELL) continue;
               tk = tix; break;
            }
            if(tk != 0)
               UltraMission_NoteOpen(tk, BrokerSymbol, false, strategyTag);
         }
         if(EnableBeastMode && BeastDuplicateBarGuard)
            MarkSignalApproved(false);
      }
      else
         Print("SELL approved but ExecuteSell FAILED on ", BrokerSymbol, " [", strategyTag, "]");
      if(EnableUltraCore && UltraHealthMonitor)
      {
         g_UltraLastDecisionMs = (long)GetTickCount() - g_UltraDecisionStartMs;
         g_UltraHealthOK = (g_UltraLastDecisionMs < 500) ? 1 : 0;
      }
      return;
   }

   if(g_UltraLastReject == "" && EnableUltraCore)
   {
      AnalyzeLiveMarket(false);
      string wait = StringFormat("ULTRA WAIT | %s | ContB=%s ContS=%s | conf=%d prec=%d prob=%d | %s",
                             g_LiveMkt.summary,
                             g_LiveMkt.contBuyOK ? "READY" : g_LiveMkt.contBuyDetail,
                             g_LiveMkt.contSellOK ? "READY" : g_LiveMkt.contSellDetail,
                             g_UltraLastSnap.score.confidence,
                             g_UltraLastSnap.score.precision,
                             g_UltraLastSnap.score.probability,
                             g_UltraLastSignal.reason == "" ? UltraRegimeName(g_UltraLastSnap.regime) : g_UltraLastSignal.reason);
      g_UltraLastReject = wait;
      g_UltraLastDecision = "WAIT";
   }

   if(EnableUltraCore && UltraHealthMonitor)
      g_UltraLastDecisionMs = (long)GetTickCount() - g_UltraDecisionStartMs;

   if(EnableSetupLogging)
   {
      if(idx < ArraySize(DiagLastBarTimeArr) && DiagLastBarTimeArr[idx] != currentBarTime)
      {
         if(EnableUltraCore && g_UltraLastReject != "")
            Print("No valid setup (", BrokerSymbol, ") — ", g_UltraLastReject);
         else
            Print("No valid setup (", BrokerSymbol, ")");
      }

      PrintSetupDiagnostics();
   }
}
// (Long-term-holding, ATR-trailing, trend-exit, HTF-confirmation and
// news-filter inputs were moved to the top INPUTS block - they're read by
// functions defined earlier in the file, e.g. InitializeIndicators() and
// ManageOpenTrades(), and MQL5 requires global variables/inputs to be
// declared before their first point of use.)

//================ NEWS FILTER SYSTEM (real implementation) =================//
// Uses MQL5's built-in Economic Calendar (CalendarValueHistory), not a
// third-party API. Blocks trading in a window around high/medium impact
// events for the currencies in the traded symbol (e.g. EUR/USD events for
// EURUSD). If the calendar isn't available on this account/server, it
// fails safe (returns true / trading allowed) rather than blocking forever.

// OK66: ONE news path — awareness log only. Never hard-blocks trades.
bool NewsAwarenessInWindow(string &detail)
{
   detail = "";
   string baseCcy, quoteCcy;
   PRISM_GetSymbolCurrencies(baseCcy, quoteCcy);

   datetime from = TimeCurrent() - MinutesAfterNews  * 60;
   datetime to   = TimeCurrent() + MinutesBeforeNews * 60;

   MqlCalendarValue values[];
   int total = CalendarValueHistory(values, from, to, NULL, NULL);
   if(total <= 0)
   {
      detail = "news: calendar clear / unavailable";
      return false;
   }

   string names = "";
   int hit = 0;
   for(int i = 0; i < total; i++)
   {
      MqlCalendarEvent event;
      if(!CalendarEventById(values[i].event_id, event))
         continue;
      if(event.importance != CALENDAR_IMPORTANCE_HIGH)
         continue;

      MqlCalendarCountry country;
      if(!CalendarCountryById(event.country_id, country))
         continue;
      if(!PRISM_CalendarCurrencyRelevant(country.currency, baseCcy, quoteCcy, false))
         continue;

      hit++;
      if(StringLen(names) < 120)
      {
         if(names != "") names += "; ";
         names += country.currency + " " + event.name;
      }
   }

   if(hit <= 0)
   {
      detail = "news: no relevant high-impact in window";
      return false;
   }

   detail = StringFormat("news AWARE high-impact x%d [%s] — NOT blocking trades", hit, names);
   return true;
}

void UpdateNewsAwareness()
{
   if(!EnableNewsAwareness)
      return;

   datetime barTime = iTime(BrokerSymbol, EntryTF, 0);
   if(NewsAwarenessLogOncePerBar && barTime > 0 && barTime == g_NewsAwareLastLogBar)
      return;

   string detail = "";
   bool inWin = NewsAwarenessInWindow(detail);
   if(barTime > 0)
      g_NewsAwareLastLogBar = barTime;

   if(inWin)
      Print("NEWS AWARE: ", detail, " on ", BrokerSymbol, " | spread never blocks");
   else if(EnableVerboseLogging)
      Print("NEWS AWARE: ", detail, " on ", BrokerSymbol);
}

bool NewsTradingAllowed()
{
   return true; // OK66: hard news block retired — awareness only
}

void DebugSignals()
{
   Print("================ SIGNAL DEBUG ================");

   Print("Bull Trend: ", IsBullTrend());
   Print("Bear Trend: ", IsBearTrend());

   Print("EMA: ", GetEMA());
   Print("ADX: ", GetADX());
   Print("ATR: ", GetATR());

   Print("BOS: ", DetectBOS());
   Print("CHoCH: ", DetectCHoCH());

   Print("Liquidity Sweep: ", DetectLiquiditySweep());

   Print("Bullish FVG: ", DetectBullishFVG());
   Print("Bearish FVG: ", DetectBearishFVG());

   Print("Bullish OB (this bar): ", DetectBullishOrderBlock(), " | fresh&valid: ", IsOrderBlockFreshAndValid(true), " | mitigated: ", IsOrderBlockMitigated(true));
   Print("Bearish OB (this bar): ", DetectBearishOrderBlock(), " | fresh&valid: ", IsOrderBlockFreshAndValid(false), " | mitigated: ", IsOrderBlockMitigated(false));

   Print("Bullish FVG filled%: ", DoubleToString(GetFVGFilledPercent(true), 1), " | Bearish FVG filled%: ", DoubleToString(GetFVGFilledPercent(false), 1));

   Print("Equal High touches: ", CountEqualHighTouches(), " | Equal Low touches: ", CountEqualLowTouches());

   Print("Fake breakout trap (buy side): ", DetectFakeBreakoutTrap(true), " | (sell side): ", DetectFakeBreakoutTrap(false));

   Print("MPI Score (buy): ", CalculatePRISMScore(true), " | (sell): ", CalculatePRISMScore(false), " | Minimum required: ", MinimumMPIScore);

   Print("Trade Score: ", CalculateTradeScore(true));

   Print("---- Aggregate Trade Stats ----");
   Print("Win Rate: ", DoubleToString(GetWinRatePercent(),1), "% (", Stat_TotalTrades, " trades)");
   Print("Profit Factor: ", DoubleToString(GetProfitFactor(),2));
   Print("Average R:R: ", DoubleToString(GetAverageRR(),2));

   Print("=============================================");

   PrintSignalPerformanceReport();
}
//+------------------------------------------------------------------+
//|              PART 18 - TRADE STATISTICS                          |
//+------------------------------------------------------------------+
// Tracks win rate, average R:R, profit factor, and consecutive win/loss
// streaks - persisted via GlobalVariable (same mechanism as the TP1 state
// in Part 6) so the numbers survive an EA reload or terminal restart
// instead of resetting to zero every time. (Not shown on the simplified
// dashboard per request, but still tracked/persisted and available via
// DebugSignals()/PrintSignalPerformanceReport() and the Journal.)

// NOTE: Stat_TotalTrades/Stat_WinTrades/etc are aggregate counters shared
// across every symbol this EA instance trades (not broken out per symbol)
// - this reflects overall EA performance. The persistence key below
// deliberately does NOT include BrokerSymbol, to match that - keying it
// per-symbol while the in-memory counters stay shared would mean a
// restart only reloads one symbol's numbers into a bucket that's actually
// aggregate, silently losing the rest.

string StatsGVPrefix()
{
   return "HitmanAI_" + IntegerToString(MagicNumber) + "_Stats_Aggregate";
}

void SaveTradeStatistics()
{
   string prefix = StatsGVPrefix();

   GlobalVariableSet(prefix + "_total",  Stat_TotalTrades);
   GlobalVariableSet(prefix + "_wins",   Stat_WinTrades);
   GlobalVariableSet(prefix + "_losses", Stat_LossTrades);
   GlobalVariableSet(prefix + "_gprofit",Stat_GrossProfit);
   GlobalVariableSet(prefix + "_gloss",  Stat_GrossLoss);
   GlobalVariableSet(prefix + "_cwins",  Stat_ConsecutiveWins);
   GlobalVariableSet(prefix + "_closs",  Stat_ConsecutiveLosses);
}

void RestoreTradeStatistics()
{
   string prefix = StatsGVPrefix();

   if(!GlobalVariableCheck(prefix + "_total"))
      return; // nothing persisted yet - leave everything at zero

   Stat_TotalTrades       = (int)GlobalVariableGet(prefix + "_total");
   Stat_WinTrades         = (int)GlobalVariableGet(prefix + "_wins");
   Stat_LossTrades        = (int)GlobalVariableGet(prefix + "_losses");
   Stat_GrossProfit       = GlobalVariableGet(prefix + "_gprofit");
   Stat_GrossLoss         = GlobalVariableGet(prefix + "_gloss");
   Stat_ConsecutiveWins   = (int)GlobalVariableGet(prefix + "_cwins");
   Stat_ConsecutiveLosses = (int)GlobalVariableGet(prefix + "_closs");

   Print("Restored trade statistics: ", Stat_TotalTrades, " trades (",
         Stat_WinTrades, "W / ", Stat_LossTrades, "L)");
}

// Called from OnTradeTransaction whenever a position closes (profit
// already includes swap + commission).
void RecordTradeStatistic(double profit)
{
   Stat_TotalTrades++;

   if(profit >= 0)
   {
      Stat_WinTrades++;
      Stat_GrossProfit += profit;
      Stat_ConsecutiveWins++;
      Stat_ConsecutiveLosses = 0;
   }
   else
   {
      Stat_LossTrades++;
      Stat_GrossLoss += MathAbs(profit);
      Stat_ConsecutiveLosses++;
      Stat_ConsecutiveWins = 0;
   }

   SaveTradeStatistics();
}

double GetWinRatePercent()
{
   if(Stat_TotalTrades <= 0)
      return 0.0;

   return (double)Stat_WinTrades / (double)Stat_TotalTrades * 100.0;
}

double GetProfitFactor()
{
   if(Stat_GrossLoss <= 0.0)
      return (Stat_GrossProfit > 0.0) ? 999.0 : 0.0; // no losses yet - avoid divide-by-zero

   return Stat_GrossProfit / Stat_GrossLoss;
}

double GetAverageRR()
{
   if(Stat_WinTrades <= 0 || Stat_LossTrades <= 0)
      return 0.0;

   double avgWin  = Stat_GrossProfit / Stat_WinTrades;
   double avgLoss = Stat_GrossLoss / Stat_LossTrades;

   if(avgLoss <= 0.0)
      return 0.0;

   return avgWin / avgLoss;
}
#endif
//===== END Shell_B_TradeSystem.mqh =====
